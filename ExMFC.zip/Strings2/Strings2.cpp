/****************************************************************************\
*                                                                            *
*  Strings2.cpp                                                              *
*                                                                            *
*  This program shows how to display strings in a virtual buffer.            *
*                                                                            *
\****************************************************************************/

// Strings2.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Strings2.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStrings2App

BEGIN_MESSAGE_MAP(CStrings2App, CWinApp)
	//{{AFX_MSG_MAP(CStrings2App)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStrings2App construction

CStrings2App::CStrings2App()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CStrings2App object

CStrings2App theApp;

/////////////////////////////////////////////////////////////////////////////
// CStrings2App initialization

BOOL CStrings2App::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Display Strings in Virtual Buffer"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CStrings2App message handlers

'*****************************************************************************
'                                                                            *
'  Rainbow.vb                                                                *
'                                                                            *
'  This program demonstrates color palette cycling.                          *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Application variables.
    Dim Start As Integer
    Dim RGBvalues(2 * 24 * 3) As Byte ' two sets of 24 RGB triplets

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Name = "Form1"
        Me.Text = "Color Cycling"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim Color As Integer
        Dim xLen, yLen As Integer

        ' Create the logical palettte.
        hDC = g.GetHdc()
        fg_setdc(hDC)
        FillColorPalette()
        hPal = fg_logpal(10, 24, RGBvalues(0))
        fg_realize(hPal)

        ' Create a 640x480 virtual buffer.
        fg_vbinit()
        hVB = fg_vballoc(640, 480)
        fg_vbopen(hVB)
        fg_vbcolors()

        ' Construct a crude image of a rainbow.
        fg_setcolor(255)
        fg_fillpage()
        fg_setclip(0, 639, 0, 300)
        fg_move(320, 300)
        xLen = 240
        yLen = 120
        For Color = 10 To 33
            fg_setcolor(Color)
            fg_ellipsef(xLen, yLen)
            xLen -= 4
            yLen -= 3
        Next Color
        fg_setcolor(255)
        fg_ellipsef(xLen, yLen)
        fg_setclip(0, 639, 0, 479)

        ' Starting index into the array of color values.
        Start = 0

        ' Start the 50ms timer.
        Timer1.Interval = 50
        Timer1.Enabled = True
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, fg_getmaxx(), 0, fg_getmaxy(), 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, fg_getmaxx(), 0, fg_getmaxy(), 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Start = (Start + 3) Mod 72
        fg_setdacs(10, 24, RGBvalues(Start))
        If fg_colors() > 8 Then
            fg_vbscale(0, fg_getmaxx(), 0, fg_getmaxy(), 0, cxClient - 1, 0, cyClient - 1)
        End If
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  FillColorPalette()                                                        *
    '                                                                            *
    '  Set up the colors for the application's logical palette in the RGBvalues  *
    '  array. The logical palette will contain 24 non-system colors (indices 10  *
    '  to 33) defining the initial RGB values for the colors being cycled.       *
    '                                                                            *
    '  Note that we store two identical sets of 24 RGB triplets in RGBvalues. We *
    '  can then perform color cycling without having to worry about wrapping to  *
    '  the start of the array because the index pointing to the starting RGB     *
    '  triplet never extends beyond the first set of 24 RGB triplets.            *
    '                                                                            *
    '*****************************************************************************

    Private Sub FillColorPalette()
        Dim Colors() As Byte = { _
            182, 182, 255, 198, 182, 255, 218, 182, 255, 234, 182, 255, 255, 182, 255, _
            255, 182, 234, 255, 182, 218, 255, 182, 198, 255, 182, 182, 255, 198, 182, _
            255, 218, 182, 255, 234, 182, 255, 255, 182, 234, 255, 182, 218, 255, 182, _
            198, 255, 182, 182, 255, 182, 182, 255, 198, 182, 255, 218, 182, 255, 234, _
            182, 255, 255, 182, 234, 255, 182, 218, 255, 182, 198, 255}

        ' Set up two identical sets of the 24 colors in the RGBvalues array.
        Array.Copy(Colors, 0, RGBvalues, 0, 24 * 3)
        Array.Copy(Colors, 0, RGBvalues, 24 * 3, 24 * 3)
    End Sub
End Class
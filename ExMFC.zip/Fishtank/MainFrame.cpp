// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Fishtank.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAX(x,y) ((x) > (y)) ? (x) : (y)
#define MIN(x,y) ((x) < (y)) ? (x) : (y)

#define NFISH 11

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_PAINT()
	ON_WM_ACTIVATEAPP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB1 = -1;
	m_hVB2 = -1;
	m_cxClient = 0;
	m_cyClient = 0;
	m_bAppIsActive = FALSE;
}

CMainFrame::~CMainFrame()
{
	if (m_hVB1 >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB1);
		fg_vbfree(m_hVB2);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
		// use the default logical palette
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		// create two 320x200 virtual buffers
		fg_vbinit();
		m_hVB1 = fg_vballoc(vbWidth,vbHeight);
		m_hVB2 = fg_vballoc(vbWidth,vbHeight);

		// display the coral background in virtual buffer #2 (which
		// will always contain a clean copy of the background image)
		fg_vbopen(m_hVB2);
		fg_vbcolors();
		fg_showpcx("CORAL.PCX",FG_AT_XY|FG_KEEPCOLORS);

		// get the fish bitmaps
		GetFish();

		m_bAppIsActive = TRUE;
	}
	return bRet;
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CMainFrame::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

void CMainFrame::OnActivateApp(BOOL bActive, HTASK hTask)
{
	CFrameWnd::OnActivateApp(bActive, hTask);
	m_bAppIsActive = bActive;
}

/****************************************************************************\
*                                                                            *
*  GetFish()                                                                 *
*                                                                            *
*  Fill the fish bitmap arrays.                                              *
*                                                                            *
\****************************************************************************/

BYTE Fish1[56*25];
BYTE Fish2[54*38];
BYTE Fish3[68*26];
BYTE Fish4[56*30];
BYTE Fish5[62*22];
BYTE Fish6[68*36];

int FishX[]      = {  0, 64,128,200,  0, 80}; // location of fish (x)
int FishY[]      = {199,199,199,199,150,150}; // location of fish (y)
int FishWidth[]  = { 56, 54, 68, 56, 62, 68}; // size of fish: width
int FishHeight[] = { 25, 38, 26, 30, 22, 36}; // size of fish: height

BYTE *Fishes[] = {Fish1, // for convenience, an array of pointers to fish bitmaps
		  Fish2,
		  Fish3,
		  Fish4,
		  Fish5,
		  Fish6};

void CMainFrame::GetFish()
{
	register int FishNum;

	// get the fish bitmaps from a PCX file
	fg_vbopen(m_hVB1);
	fg_vbcolors();
	fg_showpcx("FISH.PCX",FG_AT_XY|FG_KEEPCOLORS|FG_IGNOREPALETTE);

	for (FishNum = 0; FishNum < 6; FishNum++)
	{
		fg_move(FishX[FishNum],FishY[FishNum]);
		fg_getimage(Fishes[FishNum],FishWidth[FishNum],FishHeight[FishNum]);
	}

	fg_erase();
}

/****************************************************************************\
*                                                                            *
*  GoFish()                                                                  *
*                                                                            *
*  Make the fish swim around.                                                *
*                                                                            *
\****************************************************************************/

/*  There are 11 fish total, and 6 different kinds of fish. These
*   arrays keep track of what kind of fish each fish is, and how each
*   fish moves:
*
*   Fish[]   -- which fish bitmap applies to this fish?
*   xStart[] -- starting x coordinate
*   yStart[] -- starting y coordinate
*
*   xMin[]   -- how far left (off screen) the fish can go
*   xMax[]   -- how far right (off screen) the fish can go
*   xInc[]   -- how fast the fish goes left and right
*   Dir[]    -- starting direction for each fish
*
*   yMin[]   -- how far up this fish can go
*   yMax[]   -- how far down this fish can go
*   yInc[]   -- how fast the fish moves up or down
*   yTurn[]  -- how long fish can go in the vertical direction
*               before stopping or turning around
*   yCount[] -- counter to compare to yTurn
*/

int Fish[]   = {   1,   1,   2,   3,   3,   0,   0,   5,   4,   2,   3};
int xStart[] = {-100,-150,-450,-140,-200, 520, 620,-800, 800, 800,-300};
int yStart[] = {  40,  60, 150,  80,  70, 190, 180, 100,  30, 130,  92};

int xMin[]   = {-300,-300,-800,-200,-200,-200,-300,-900,-900,-900,-400};
int xMax[]   = { 600, 600,1100,1000,1000, 750, 800,1200,1400,1200, 900};
int xInc[]   = {   2,   2,   8,   5,   5,  -3,  -3,   7,  -8,  -9,   6};
int Dir[]    = {   0,   0,   0,   0,   0,   1,   1,   0,   1,   1,   0};

int yMin[]   = {  40,  60, 120,  70,  60, 160, 160,  80,  30, 110,  72};
int yMax[]   = {  80, 100, 170, 110, 100, 199, 199, 120,  70, 150, 122};
int yTurn[]  = {  50,  30,  10,  30,  20,  10,  10,  10,  30,   20, 10};
int yCount[] = {   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0};
int yInc[]   = {   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0};

void CMainFrame::GoFish()
{
	register int i;

	// copy the background to the workspace
	fg_copypage(m_hVB2,m_hVB1);

	// put all the fish in their new positions
	for (i = 0; i < NFISH; i++)
	{
		yCount[i]++;
		if (yCount[i] > yTurn[i])
		{
			yCount[i] = 0;
			yInc[i] = (rand() % 3) - 1;
		}
		yStart[i] += yInc[i];
		yStart[i] = MIN(yMax[i],MAX(yStart[i],yMin[i]));

		if (xStart[i] >= -72 && xStart[i] < 320)
			PutFish(Fish[i],xStart[i],yStart[i],Dir[i]);

		xStart[i] += xInc[i];
		if (xStart[i] <= xMin[i] || xStart[i] >= xMax[i])
		{
			xInc[i] = -xInc[i];
			Dir[i] = 1 - Dir[i];
		}
	}

	// scale the workspace image to fill the client area
	fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
}

/****************************************************************************\
*                                                                            *
*  PutFish()                                                                 *
*                                                                            *
*  Draw one of the six fish anywhere you want.                               *
*                                                                            *
\****************************************************************************/

void CMainFrame::PutFish(int FishNum, int x, int y, int FishDir)
{
	// move to position where the fish will appear
	fg_move(x,y);

	// draw a left- or right-facing fish, depending on FishDir
	if (FishDir == 0)
		fg_flpimage(Fishes[FishNum],FishWidth[FishNum],FishHeight[FishNum]);
	else
		fg_clpimage(Fishes[FishNum],FishWidth[FishNum],FishHeight[FishNum]);
}

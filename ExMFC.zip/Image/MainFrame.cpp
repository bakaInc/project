// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Image.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SETFOCUS()
	ON_WM_CREATE()
	ON_COMMAND(IDM_BMP_Open, BMPOpenClick)
	ON_COMMAND(IDM_BMP_Make, BMPMakeClick)
	ON_COMMAND(IDM_BMP_Details, BMPDetailsClick)
	ON_COMMAND(IDM_PCX_Open, PCXOpenClick)
	ON_COMMAND(IDM_PCX_Make, PCXMakeClick)
	ON_COMMAND(IDM_PCX_Details, PCXDetailsClick)
	ON_COMMAND(IDM_JPEG_Open, JPEGOpenClick)
	ON_COMMAND(IDM_JPEG_Details, JPEGDetailsClick)
	ON_COMMAND(IDM_Flic_Open, FlicOpenClick)
	ON_COMMAND(IDM_Flic_Play, FlicPlayClick)
	ON_COMMAND(IDM_Flic_Frame, FlicFrameClick)
	ON_COMMAND(IDM_Flic_Reset, FlicResetClick)
	ON_COMMAND(IDM_Flic_Details, FlicDetailsClick)
	ON_COMMAND(IDM_AVI_Open, AVIOpenClick)
	ON_COMMAND(IDM_AVI_Play, AVIPlayClick)
	ON_COMMAND(IDM_AVI_Frame, AVIFrameClick)
	ON_COMMAND(IDM_AVI_Reset, AVIResetClick)
	ON_COMMAND(IDM_AVI_Details, AVIDetailsClick)
	ON_COMMAND(IDM_Exit, ExitClick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// create a view to occupy the client area of the frame
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("Failed to create view window\n");
		return -1;
	}

	CFrameWnd::m_bAutoMenuEnable = FALSE;
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnUpdateFrameTitle(BOOL bAddToTitle)
{
	CFrameWnd::OnUpdateFrameTitle(bAddToTitle);
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	// forward focus to the view window
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CMainFrame::EnableItem(UINT nID, UINT nEnable)
{
	CMenu* pMenu = GetMenu();
	if (pMenu)
	{
		pMenu->EnableMenuItem(nID,nEnable);
		DrawMenuBar();
	}
}

void CMainFrame::BMPOpenClick()
{
	if (m_wndView.BMPOpenClick())
	{
		EnableItem(IDM_BMP_Make,MF_ENABLED);
		EnableItem(IDM_BMP_Details,MF_ENABLED);
		EnableItem(IDM_PCX_Make,MF_ENABLED);
		EnableItem(IDM_PCX_Details,MF_GRAYED);
		EnableItem(IDM_JPEG_Details,MF_GRAYED);
		EnableItem(IDM_Flic_Play,MF_GRAYED);
		EnableItem(IDM_Flic_Frame,MF_GRAYED);
		EnableItem(IDM_Flic_Reset,MF_GRAYED);
		EnableItem(IDM_Flic_Details,MF_GRAYED);
		EnableItem(IDM_AVI_Play,MF_GRAYED);
		EnableItem(IDM_AVI_Frame,MF_GRAYED);
		EnableItem(IDM_AVI_Reset,MF_GRAYED);
		EnableItem(IDM_AVI_Details,MF_GRAYED);
	}
}

void CMainFrame::BMPMakeClick()
{
	m_wndView.BMPMakeClick();
}

void CMainFrame::BMPDetailsClick()
{
	m_wndView.BMPDetailsClick();
}

void CMainFrame::PCXOpenClick()
{
	if (m_wndView.PCXOpenClick())
	{
		EnableItem(IDM_BMP_Make,MF_ENABLED);
		EnableItem(IDM_BMP_Details,MF_GRAYED);
		EnableItem(IDM_PCX_Make,MF_ENABLED);
		EnableItem(IDM_PCX_Details,MF_ENABLED);
		EnableItem(IDM_JPEG_Details,MF_GRAYED);
		EnableItem(IDM_Flic_Play,MF_GRAYED);
		EnableItem(IDM_Flic_Frame,MF_GRAYED);
		EnableItem(IDM_Flic_Reset,MF_GRAYED);
		EnableItem(IDM_Flic_Details,MF_GRAYED);
		EnableItem(IDM_AVI_Play,MF_GRAYED);
		EnableItem(IDM_AVI_Frame,MF_GRAYED);
		EnableItem(IDM_AVI_Reset,MF_GRAYED);
		EnableItem(IDM_AVI_Details,MF_GRAYED);
	}
}

void CMainFrame::PCXMakeClick()
{
	m_wndView.PCXMakeClick();
}

void CMainFrame::PCXDetailsClick()
{
	m_wndView.PCXDetailsClick();
}

void CMainFrame::JPEGOpenClick()
{
	if (m_wndView.JPEGOpenClick())
	{
		EnableItem(IDM_BMP_Make,MF_ENABLED);
		EnableItem(IDM_BMP_Details,MF_GRAYED);
		EnableItem(IDM_PCX_Make,MF_ENABLED);
		EnableItem(IDM_PCX_Details,MF_GRAYED);
		EnableItem(IDM_JPEG_Details,MF_ENABLED);
		EnableItem(IDM_Flic_Play,MF_GRAYED);
		EnableItem(IDM_Flic_Frame,MF_GRAYED);
		EnableItem(IDM_Flic_Reset,MF_GRAYED);
		EnableItem(IDM_Flic_Details,MF_GRAYED);
		EnableItem(IDM_AVI_Play,MF_GRAYED);
		EnableItem(IDM_AVI_Frame,MF_GRAYED);
		EnableItem(IDM_AVI_Reset,MF_GRAYED);
		EnableItem(IDM_AVI_Details,MF_GRAYED);
	}
}

void CMainFrame::JPEGDetailsClick()
{
	m_wndView.JPEGDetailsClick();
}

void CMainFrame::FlicOpenClick()
{
	if (m_wndView.FlicOpenClick())
	{
		EnableItem(IDM_BMP_Make,MF_ENABLED);
		EnableItem(IDM_BMP_Details,MF_GRAYED);
		EnableItem(IDM_PCX_Make,MF_ENABLED);
		EnableItem(IDM_PCX_Details,MF_GRAYED);
		EnableItem(IDM_JPEG_Details,MF_GRAYED);
		EnableItem(IDM_Flic_Play,MF_ENABLED);
		EnableItem(IDM_Flic_Frame,MF_ENABLED);
		EnableItem(IDM_Flic_Reset,MF_ENABLED);
		EnableItem(IDM_Flic_Details,MF_ENABLED);
		EnableItem(IDM_AVI_Play,MF_GRAYED);
		EnableItem(IDM_AVI_Frame,MF_GRAYED);
		EnableItem(IDM_AVI_Reset,MF_GRAYED);
		EnableItem(IDM_AVI_Details,MF_GRAYED);
	}
}

void CMainFrame::FlicPlayClick()
{
	CWaitCursor wait;
	m_wndView.FlicPlayClick();
}

void CMainFrame::FlicFrameClick()
{
	m_wndView.FlicFrameClick();
}

void CMainFrame::FlicResetClick()
{
	m_wndView.FlicResetClick();
}

void CMainFrame::FlicDetailsClick()
{
	m_wndView.FlicDetailsClick();
}

void CMainFrame::AVIOpenClick()
{
	if (m_wndView.AVIOpenClick())
	{
		EnableItem(IDM_BMP_Make,MF_ENABLED);
		EnableItem(IDM_BMP_Details,MF_GRAYED);
		EnableItem(IDM_PCX_Make,MF_ENABLED);
		EnableItem(IDM_PCX_Details,MF_GRAYED);
		EnableItem(IDM_JPEG_Details,MF_GRAYED);
		EnableItem(IDM_Flic_Play,MF_GRAYED);
		EnableItem(IDM_Flic_Frame,MF_GRAYED);
		EnableItem(IDM_Flic_Reset,MF_GRAYED);
		EnableItem(IDM_Flic_Details,MF_GRAYED);
		EnableItem(IDM_AVI_Play,MF_ENABLED);
		EnableItem(IDM_AVI_Frame,MF_ENABLED);
		EnableItem(IDM_AVI_Reset,MF_ENABLED);
		EnableItem(IDM_AVI_Details,MF_ENABLED);
	}
	else
	{
		EnableItem(IDM_AVI_Play,MF_GRAYED);
		EnableItem(IDM_AVI_Frame,MF_GRAYED);
		EnableItem(IDM_AVI_Reset,MF_GRAYED);
		EnableItem(IDM_AVI_Details,MF_GRAYED);
	}
}

void CMainFrame::AVIPlayClick()
{
	CWaitCursor wait;
	m_wndView.AVIPlayClick();
}

void CMainFrame::AVIFrameClick()
{
	m_wndView.AVIFrameClick();
}

void CMainFrame::AVIResetClick()
{
	m_wndView.AVIResetClick();
}

void CMainFrame::AVIDetailsClick()
{
	m_wndView.AVIDetailsClick();
}

void CMainFrame::ExitClick()
{
	PostMessage(WM_CLOSE);
}

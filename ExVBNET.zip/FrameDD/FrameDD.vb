'*****************************************************************************
'                                                                            *
'  FrameDD.vb                                                                *
'                                                                            *
'  This program shows how to set up a full screen DirectDraw application     *
'  for either blitting or flipping. The selection of blitting or flipping is *
'  controlled by the BLIT and FLIP symbols defined below.                    *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Define either Blit or Flip, but not both, for blitting or flipping.
#Const Blit = True
#Const Flip = False

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim AppIsActive As Boolean = False

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 640
    Const vbHeight As Integer = 480

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.Text = "DirectDraw Frame Animation"

    End Sub

#End Region

    Protected Overrides Sub WndProc(ByRef m As Message)
        Const WM_ACTIVATEAPP As Integer = &H1C

        MyBase.WndProc(m)
        Select Case m.Msg
            Case WM_ACTIVATEAPP
                AppIsActive = (m.WParam.ToInt32 <> 0)
                If AppIsActive Then fg_ddrestore()
        End Select
    End Sub

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
#If Blit Then
        fg_ddsetup(vbWidth, vbHeight, 8, FG_DX_BLIT)
#Else
        fg_ddsetup(vbWidth, vbHeight, 8, FG_DX_FLIP)
#End If
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)
        Me.Show()
        Me.Focus()

        ' If blitting, create a virtual buffer the same size as the screen
        ' resolution; if flipping, use the primary surface's back buffer.
        fg_vbinit()
#If Blit Then
        hVB = fg_vballoc(vbWidth, vbHeight)
#Else
        hVB = 0
#End If
        fg_vbopen(hVB)
        fg_vbcolors()

        fg_mouseini()
        fg_mousevis(0)
        Timer1.Enabled = True
    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Or e.KeyCode = Keys.F12 Then Me.Close()
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        AppIsActive = False
        fg_mousevis(1)
        fg_vbclose()
#If Blit Then
        fg_vbfree(hVB)
#End If
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If AppIsActive Then Animate()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Animate()                                                                 *
    '                                                                            *
    '  Construct the next frame of animation and display it with either blitting *
    '  or flipping, as directed by the BLIT and FLIP symbols above.              *
    '                                                                            *
    '*****************************************************************************

    Private Sub Animate()
        ' Fill drawing surface with the next color.
        fg_setcolor((fg_getcolor() + 1) And &HFF)
        fg_fillpage()

        ' Blit or flip surface to the screen.
#If Blit Then
        fg_vbpaste(0, vbWidth - 1, 0, vbHeight - 1, 0, vbHeight - 1)
#Else
        fg_ddflip()
#End If
    End Sub
End Class
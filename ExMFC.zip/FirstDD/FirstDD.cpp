/****************************************************************************\
*                                                                            *
*  FirstDD.cpp                                                               *
*                                                                            *
*  This is a version of the first Fastgraph for Windows example program      *
*  modified for use as a DirectDraw windowed application.                    *
*                                                                            *
\****************************************************************************/

// FirstDD.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "FirstDD.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFirstDDApp

BEGIN_MESSAGE_MAP(CFirstDDApp, CWinApp)
	//{{AFX_MSG_MAP(CFirstDDApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFirstDDApp construction

CFirstDDApp::CFirstDDApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFirstDDApp object

CFirstDDApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CFirstDDApp initialization

BOOL CFirstDDApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"DirectDraw Windowed"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CFirstDDApp message handlers

// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "VBdemo.h"

#include "ChildView.h"
#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB1 = -1;
	m_hVB2 = -1;
	m_cxClient = 0;
	m_cyClient = 0;
}

CChildView::~CChildView()
{
	if (m_hVB1 >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB1);
		fg_vbfree(m_hVB2);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BEGIN_MESSAGE_MAP(CChildView, CWnd)
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

BOOL CChildView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL bRet = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		m_hVB2 = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB2);
		fg_vbcolors();
		m_hVB1 = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB1);
		fg_vbcolors();

		fg_setcolor(25);
		fg_fillpage();
		fg_setcolor(20);
		fg_rect(vbWidth/4,vbWidth*3/4,vbHeight/4,vbHeight*3/4);
	}
	return bRet;
}

void CChildView::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CChildView::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CChildView::OnSetFocus(CWnd* pOldWnd)
{
	CWnd::OnSetFocus(pOldWnd);
	fg_realize(m_hPal);
	Invalidate();
}

void CChildView::CutClick()
{
	fg_vbcopy(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1,m_hVB1,m_hVB2);
	fg_erase();
	fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CChildView::PasteClick()
{
	fg_tcdefine(25,1);
	fg_vbtccopy(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1,m_hVB2,m_hVB1);
	fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
}

//---------------------------------------------------------------------------
#ifndef ImageUH
#define ImageUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Menus.hpp>
#include <vcl\Dialogs.hpp>
#include <string.h>
#include <FGwin.h>

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:    // IDE-managed Components
   TMainMenu *MainMenu;
   TMenuItem *BMP;
   TMenuItem *BMPOpen;
   TMenuItem *BMPMake;
   TMenuItem *BMPDetails;
   TMenuItem *PCX;
   TMenuItem *PCXOpen;
   TMenuItem *PCXMake;
   TMenuItem *PCXDetails;
   TMenuItem *JPEG;
   TMenuItem *JPEGOpen;
   TMenuItem *JPEGDetails;
   TMenuItem *Flic;
   TMenuItem *FlicOpen;
   TMenuItem *FlicPlay;
   TMenuItem *FlicFrame;
   TMenuItem *FlicReset;
   TMenuItem *FlicDetails;
   TMenuItem *Exit;
   TMenuItem *AVI;
   TMenuItem *AVIOpen;
   TMenuItem *AVIPlay;
   TMenuItem *AVIFrame;
   TMenuItem *AVIReset;
   TMenuItem *AVIDetails;
   TOpenDialog *OpenDialog;
   TSaveDialog *SaveDialog;
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
   void __fastcall BMPOpenClick(TObject *Sender);
   void __fastcall BMPMakeClick(TObject *Sender);
   void __fastcall BMPDetailsClick(TObject *Sender);
   void __fastcall PCXOpenClick(TObject *Sender);
   void __fastcall PCXMakeClick(TObject *Sender);
   void __fastcall PCXDetailsClick(TObject *Sender);
   void __fastcall JPEGOpenClick(TObject *Sender);
   void __fastcall JPEGDetailsClick(TObject *Sender);
   void __fastcall FlicOpenClick(TObject *Sender);
   void __fastcall FlicPlayClick(TObject *Sender);
   void __fastcall FlicFrameClick(TObject *Sender);
   void __fastcall FlicResetClick(TObject *Sender);
   void __fastcall FlicDetailsClick(TObject *Sender);
   void __fastcall AVIOpenClick(TObject *Sender);
   void __fastcall AVIPlayClick(TObject *Sender);
   void __fastcall AVIFrameClick(TObject *Sender);
   void __fastcall AVIResetClick(TObject *Sender);
   void __fastcall AVIDetailsClick(TObject *Sender);
   void __fastcall ExitClick(TObject *Sender);
private:        // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   UINT cxClient, cyClient;
   int cxBuffer, cyBuffer;
   int nColors;
   String mbString;
   byte Context[48];
   byte FileHeader[128];
   char FileName[256];
   int nFrames;
   void __fastcall CloseContext(void);
   void __fastcall SwitchBuffers(void);
public:         // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

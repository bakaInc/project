/****************************************************************************\
*                                                                            *
*  CBdemo.cpp                                                                *
*  CBdemoU.cpp                                                               *
*                                                                            *
*  This program demonstrates how to exchange information between the active  *
*  virtual buffer and the Windows clipboard.                                 *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("CBdemoU.cpp", Form1);
USERES("CBdemo.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

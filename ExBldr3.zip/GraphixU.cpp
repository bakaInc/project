/****************************************************************************\
*                                                                            *
*  Graphix.cpp                                                               *
*  GraphixU.cpp                                                              *
*                                                                            *
*  This program demonstrates some of the Fastgraph for Windows graphics      *
*  primitive functions.                                                      *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "GraphixU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   Width = vbWidth;
   Height = vbHeight;

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_setcolor(25);
   fg_fillpage();

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   Blit();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}

/****************************************************************************\
*                                                                            *
*  Blit()                                                                    *
*                                                                            *
*  Use fg_vbpaste() or fg_vbscale() to display the virtual buffer contents   *
*  in the client area, depending on the size of the client window.           *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::Blit()
{
   if (cxClient > vbWidth || cyClient > vbHeight)   // window larger than 640x480
      fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
   else
      fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,cyClient-1);
}

/****************************************************************************\
*                                                                            *
*  CirclesClick()                                                            *
*                                                                            *
*  Draw a series of concentric circles.                                      *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::CirclesClick(TObject *Sender)
{
   register int i, Radius;

   fg_setcolor(11);
   fg_fillpage();

   // draw 25 concentric circles at the center of the virtual buffer
   fg_move(vbWidth/2,vbHeight/2);
   Radius = 4;
   fg_setcolor(25);
   for (i = 0; i < 25; i++)
   {
      fg_circle(Radius);
      Radius += 8;
   }

   Blit();
}

/****************************************************************************\
*                                                                            *
*  EllipsesClick()                                                           *
*                                                                            *
*  Draw a series of concentric ellipses.                                     *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::EllipsesClick(TObject *Sender)
{
   register int i;
   int Horiz, Vert;

   fg_setcolor(11);
   fg_fillpage();

   // draw 80 concentric ellipses at the center of the virtual buffer
   fg_move(vbWidth/2,vbHeight/2);
   Horiz = 4;
   Vert  = 1;
   fg_setcolor(25);
   for (i = 0; i < 80; i++)
   {
      fg_ellipse(Horiz,Vert);
      Horiz += 3;
      Vert++;
   }

   Blit();
}

/****************************************************************************\
*                                                                            *
*  LinesClick()                                                              *
*                                                                            *
*  Draw a pattern of solid lines.                                            *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::LinesClick(TObject *Sender)
{
   register int x, y;
   int i, x1, x2, y1;
   static int LineColor[] = {12,11,19,21,21,19,11,12};

   fg_setcolor(25);
   fg_fillpage();

   // draw horizontal lines
   for (y = 0; y < vbHeight; y+=40)
   {
      for (i = 0; i < 8; i++)
      {
         fg_setcolor(LineColor[i]);
         y1 = y + 3*i;
         fg_move(0,y1);
         fg_draw(vbWidth-1,y1);
      }
   }

   // draw vertical lines
   for (x = 0; x < vbWidth; x+=60)
   {
      for (i = 0; i < 8; i++)
      {
         fg_setcolor(LineColor[i]);
         x1 = x + 3*i;
         fg_move(x1,0);
         fg_draw(x1,vbHeight-1);
      }
   }

   // draw red diagonal lines
   fg_setcolor(22);
   for (x1 = -640; x1 < 640; x1+=60)
   {
      x2 = x1 + vbHeight;
      fg_move(x1,0);
      fg_draw(x2,vbHeight);
   }
   for (x1 = 0; x1 < 1280; x1+=60)
   {
      x2 = x1 - vbHeight;
      fg_move(x1,0);
      fg_draw(x2,vbHeight);
   }

   Blit();
}

/****************************************************************************\
*                                                                            *
*  PaintClick()                                                              *
*                                                                            *
*  Demonstrate region fill.                                                  *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::PaintClick(TObject *Sender)
{
   int x1, x2, y1, y2;

   fg_setcolor(25);
   fg_fillpage();

   // draw a rectangle
   x1 = 40;
   x2 = vbWidth - 40;
   y1 = 20;
   y2 = vbHeight - 20;
   fg_setcolor(21);
   fg_rect(x1,x2,y1,y2);

   // outline the rectangle
   fg_setcolor(10);
   fg_box(x1,x2,y1,y2);

   // draw the circle
   x1 = vbWidth / 2;
   y1 = vbHeight / 2;
   fg_move(x1,y1);
   fg_circle(80);

   // draw cross bars in the circle
   fg_move(x1,y1-80);
   fg_draw(x1,y1+80);
   fg_move(x1-80,y1);
   fg_draw(x1+80,y1);

   // paint each quarter of the circle
   fg_setcolor(11);
   fg_paint(x1-6,y1-6);
   fg_setcolor(12);
   fg_paint(x1+6,y1+6);
   fg_setcolor(13);
   fg_paint(x1+6,y1-6);
   fg_setcolor(14);
   fg_paint(x1-6,y1+6);

   // paint the area outside the box
   fg_setcolor(24);
   fg_paint(41,21);

   Blit();
}

/****************************************************************************\
*                                                                            *
*  PointsClick()                                                             *
*                                                                            *
*  Draw a pattern of points.                                                 *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::PointsClick(TObject *Sender)
{
   register int x, y;

   // fill the virtual buffer with yellow pixels
   fg_setcolor(24);
   fg_fillpage();

   // draw the patterns of points
   fg_setcolor(19);
   for (x = 7; x < vbWidth; x+=20)
      for (y = 0; y < vbHeight; y+=8)
         fg_point(x,y);
   fg_setcolor(22);
   for (x = 17; x < vbWidth; x+=20)
      for (y = 4; y < vbHeight; y+=8)
         fg_point(x,y);

   Blit();
}

/****************************************************************************\
*                                                                            *
*  PolygonsClick()                                                           *
*                                                                            *
*  Draw a grid of filled polygons.                                           *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::PolygonsClick(TObject *Sender)
{
   register int i, j;

   static int xyDarkBlue[]  = {0,16, 24,0, 24,40, 0,56};
   static int xyLightBlue[] = {24,0, 72,0, 72,40, 24,40};
   static int xyGreen[]     = {0,56, 24,40, 72,40, 48,56};

   fg_setcolor(25);
   fg_fillpage();

   // draw 225 filled polygons (15 rows of 15)
   for (j = 0; j < 15; j++)
   {
      for (i = 0; i < 15; i++)
      {
         fg_polyoff(i*72-j*24,j*56-i*16);
         fg_setcolor(11);
         fg_polyfill(xyDarkBlue,NULL,4);
         fg_setcolor(19);
         fg_polyfill(xyLightBlue,NULL,4);
         fg_setcolor(20);
         fg_polyfill(xyGreen,NULL,4);
      }
   }

   Blit();
}

/****************************************************************************\
*                                                                            *
*  RectanglesClick()                                                         *
*                                                                            *
*  Draw a grid of filled rectangles.                                         *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::RectanglesClick(TObject *Sender)
{
   register int i, j;
   int Color;
   int x1, x2, y1, y2;
   int xInc, yInc;

   x1 = 0;
   xInc = vbWidth / 10;
   x2 = xInc - 1;
   y1 = 0;
   yInc = vbHeight / 10;
   y2 = yInc - 1;
   Color = 10;

   // draw 100 filled rectangles (10 rows of 10)
   for (i = 0; i < 10; i++)
   {
      for (j = 0; j < 10; j++)
      {
         fg_setcolor(Color);
         fg_rect(x1,x2,y1,y2);
         Color++;
         if (Color > 24) Color = 10;
         x1 += xInc;
         x2 += xInc;
      }
      x1 = 0;
      x2 = xInc - 1;
      y1 += yInc;
      y2 += yInc;
   }

   Blit();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitClick(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------

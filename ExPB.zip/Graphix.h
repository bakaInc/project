//----------------------
// Graphix.h header file
//----------------------

#define IDM_Points     1
#define IDM_Lines      2
#define IDM_Rectangles 3
#define IDM_Circles    4
#define IDM_Ellipses   5
#define IDM_Polygons   6
#define IDM_Paint      7
#define IDM_Exit       8

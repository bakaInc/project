'*****************************************************************************
'                                                                            *
'  FirstDD.vb                                                                *
'                                                                            *
'  This is a version of the first Fastgraph for Windows example program      *
'  modified for use as a DirectDraw windowed application.                    *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Name = "Form1"
        Me.Text = "DirectDraw Windowed"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim bpp As Integer

        Me.Show()
        Me.Focus()

        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        bpp = fg_colors()
        fg_vbdepth(bpp)
        hVB = fg_vballoc(640, 480)
        fg_vbopen(hVB)
        fg_vbcolors()

        If bpp > 8 Then
            fg_setcolorrgb(85, 85, 255)
        Else
            fg_setcolor(19)
        End If
        fg_fillpage()
        Refresh()
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, fg_getmaxx(), 0, fg_getmaxy(), 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, fg_getmaxx(), 0, fg_getmaxy(), 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub
End Class
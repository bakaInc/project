/****************************************************************************\
*                                                                            *
*  ImgProc.cpp                                                               *
*  ImgProcU.cpp                                                              *
*                                                                            *
*  This program demonstrates several of the Fastgraph for Windows image      *
*  processing functions.                                                     *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("ImgProcU.cpp", Form1);
USERES("ImgProc.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

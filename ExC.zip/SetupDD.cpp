/****************************************************************************\
*                                                                            *
*  SetupDD.cpp                                                               *
*                                                                            *
*  This program shows how to manage DirectDraw outside of Fastgraph and      *
*  still use Fastgraph with DirectDraw.                                      *
*                                                                            *
*  Works with DirectX 5, 6, or 7.                                            *
*                                                                            *
\****************************************************************************/

// Define the DX5, DX6, DX7 symbol depending on what version of DirectX you
// are using. One, and only one, of these three symbols must be defined.

//#define DX5
//#define DX6
#define DX7

// The Windowed, FullScreenBlit, and FullScreenFlip symbols are mutually
// exclusive. One, and only one, of these three symbols must be defined.
// - Define Windowed for a windowed DirectDraw program
// - Define FullScreenBlit for a full screen DirectDraw program with blitting
// - Define FullScreenFlip for a full screen DirectDraw program with flipping

//#define Windowed
//#define FullScreenBlit
#define FullScreenFlip

// The vbWidth and vbHeight symbols define the virtual buffer resolution in
// pixels. For full screen DirectDraw programs, they also define the screen
// resolution, and vbDepth defines the virtual buffer and screen color depth.

#define vbWidth  640
#define vbHeight 480
#define vbDepth   16

#include <fgwin.h>
#include <initguid.h>
#include <ddraw.h>

#ifdef DX5
#define DXVERSION 5
#define IID_IDirectDrawN     IID_IDirectDraw2
#define DDSURFACEDESCn       DDSURFACEDESC
#define LPDIRECTDRAWn        LPDIRECTDRAW2
#define LPDIRECTDRAWSURFACEn LPDIRECTDRAWSURFACE
#endif

#ifdef DX6
#define DXVERSION 6
#define IID_IDirectDrawN     IID_IDirectDraw4
#define DDSURFACEDESCn       DDSURFACEDESC2
#define LPDIRECTDRAWn        LPDIRECTDRAW4
#define LPDIRECTDRAWSURFACEn LPDIRECTDRAWSURFACE4
#endif

#ifdef DX7
#define DXVERSION 7
#define IID_IDirectDrawN     IID_IDirectDraw7
#define DDSURFACEDESCn       DDSURFACEDESC2
#define LPDIRECTDRAWn        LPDIRECTDRAW7
#define LPDIRECTDRAWSURFACEn LPDIRECTDRAWSURFACE7
#endif

LPDIRECTDRAWn        lpDD = NULL;          // DirectDraw object
LPDIRECTDRAWSURFACEn lpDDPrimary = NULL;   // DirectDrawSurface object
LPDIRECTDRAWCLIPPER  lpDDClipper = NULL;   // DirectDrawClipper object
LPDIRECTDRAWPALETTE  lpDDPalette = NULL;   // DirectDrawPalette object

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);
void EndDirectDraw(void);
BOOL InitDirectDrawFullScreen(HWND,int,int,int,int);
BOOL InitDirectDrawWindowed(HWND);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGfirst";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor(NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

#ifdef Windowed
   hWnd = CreateWindow(szAppName, // window class name
      "DirectDraw Windowed",   // window caption
      WS_OVERLAPPEDWINDOW,     // window style
      CW_USEDEFAULT,           // initial x position
      CW_USEDEFAULT,           // initial y position
      CW_USEDEFAULT,           // initial x size
      CW_USEDEFAULT,           // initial y size
      NULL,                    // parent window handle
      NULL,                    // window menu handle
      hInstance,               // program instance handle
      NULL);                   // creation parameters
#else
   hWnd = CreateWindowEx(
      WS_EX_TOPMOST,           // extended window style
      szAppName,               // window class name
      "DirectDraw Full Screen",// window caption
      WS_POPUP,                // window style
      0,                       // initial x position
      0,                       // initial y position
      vbWidth,                 // initial x size
      vbHeight,                // initial y size
      NULL,                    // parent window handle
      NULL,                    // window menu handle
      hInstance,               // program instance handle
      NULL);                   // creation parameters
#endif

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   while (GetMessage(&msg,NULL,0,0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HDC      hDC;
HPALETTE hPal;
UINT     cxClient, cyClient;
int      hVB;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch(iMsg)
   {
      case WM_CREATE:
#ifdef FullScreenBlit
         fg_ddsetup(vbWidth,vbHeight,vbDepth,FG_DX_BLIT);
#endif
#ifdef FullScreenFlip
         fg_ddsetup(vbWidth,vbHeight,vbDepth,FG_DX_FLIP);
#endif
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);
         ShowWindow(hWnd,SW_SHOWNORMAL);

#ifdef Windowed
         InitDirectDrawWindowed(hWnd);
         fg_vbinit();
         fg_vbdepth(fg_colors());
#endif
#ifdef FullScreenBlit
         InitDirectDrawFullScreen(hWnd,vbWidth,vbHeight,vbDepth,0);
         fg_vbinit();
         fg_vbdepth(vbDepth);
#endif
#ifdef FullScreenFlip
         InitDirectDrawFullScreen(hWnd,vbWidth,vbHeight,vbDepth,1);
         fg_vbinit();
         fg_vbdepth(vbDepth);
#endif
         fg_ddapply(DXVERSION);

#ifdef FullScreenFlip
         hVB = 0;
#else
         hVB = fg_vballoc(vbWidth,vbHeight);
#endif
         fg_vbopen(hVB);
         fg_vbcolors();

         fg_setcolorrgb(85,85,255);
         fg_fillpage();
         return 0;

      case WM_KEYDOWN:
         switch(wParam)
         {
            case VK_ESCAPE:
            case VK_F12:
               DestroyWindow(hWnd);
               break;
         }
         return 0;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
#ifdef Windowed
         fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
#endif
#ifdef FullScreenBlit
         fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);
#endif
#ifdef FullScreenFlip
         fg_ddflip();
#endif
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,FALSE);
         return 0;

      case WM_SIZE:
         cxClient = LOWORD(lParam);
         cyClient = HIWORD(lParam);
         return 0;

      case WM_DESTROY:
         fg_vbclose();
#ifndef FullScreenFlip
         fg_vbfree(hVB);
#endif
         EndDirectDraw();
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

/****************************************************************************\
*                                                                            *
*  InitDirectDrawFullScreen()                                                *
*                                                                            *
*  Perform the initialization normally done in fg_vbinit() for full screen   *
*  DirectDraw programs.                                                      *
*                                                                            *
\****************************************************************************/

BOOL InitDirectDrawFullScreen (HWND hWnd, int xRes, int yRes,
                               int Depth, int Flags)
{
#ifndef DX7
   LPDIRECTDRAW   lpDD1;
#endif
   DDSURFACEDESCn ddsd;
   DWORD          dwFlags;
   HRESULT        rc;
   PALETTEENTRY   ColorTable[256];
   BYTE           RGBvalues[256*3];
   register int   i, j;

#ifdef DX7
   // Create the DirectDraw7 object
   rc = DirectDrawCreateEx(NULL,(void**)&lpDD,IID_IDirectDraw7,NULL);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"DirectDrawCreateEx() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }
#else
   // Create the DirectDraw object
   rc = DirectDrawCreate(NULL,&lpDD1,NULL);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"DirectDrawCreate() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Obtain the DirectDrawN object from the DirectDraw object (which can
   // then be released)
   rc = lpDD1->QueryInterface(IID_IDirectDrawN,(void**)&lpDD);
   lpDD1->Release();
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"QueryInterface() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }
#endif

   // Set the application's cooperative level
   dwFlags = DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT;
   rc = lpDD->SetCooperativeLevel(hWnd,dwFlags);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"SetCooperativeLevel() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   //  Set the display mode
   rc = lpDD->SetDisplayMode(xRes,yRes,Depth,0,0);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"SetDisplayMode() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Create the primary surface
   ZeroMemory(&ddsd,sizeof(ddsd));
   ddsd.dwSize = sizeof(ddsd);
   if (Flags & 1)   // DirectDraw flipping
   {
      ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
      ddsd.dwBackBufferCount = 1;
      ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_VIDEOMEMORY |
                            DDSCAPS_COMPLEX | DDSCAPS_FLIP;
   }
   else   // DirectDraw blitting
   {
      ddsd.dwFlags = DDSD_CAPS;
      ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_VIDEOMEMORY;
   }
   rc = lpDD->CreateSurface(&ddsd,&lpDDPrimary,NULL);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"CreatePrimarySurface() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Tell Fastgraph about the DirectDrawN object and the primary surface
   fg_ddsetobj(lpDD,0);
   fg_ddsetobj(lpDDPrimary,1);

   // If we're using a high color or true color display mode, we're through
   if (Depth > 8) return TRUE;

   // If we set a 256-color display mode, create a DirectDraw palette
   // with the same colors as Fastgraph's active logical palette
   fg_getdacs(0,256,RGBvalues);
   j = 0;
   for (i = 0; i < 256; i++)
   {
      ColorTable[i].peRed   = RGBvalues[j++];
      ColorTable[i].peGreen = RGBvalues[j++];
      ColorTable[i].peBlue  = RGBvalues[j++];
      ColorTable[i].peFlags = 0;
   }
   dwFlags = DDPCAPS_8BIT | DDPCAPS_INITIALIZE | DDPCAPS_ALLOW256;
   rc = lpDD->CreatePalette(dwFlags,ColorTable,&lpDDPalette,NULL);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"CreatePalette() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Attach the palette to the primary surface
   lpDDPrimary->SetPalette(lpDDPalette);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"SetPalette() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Tell Fastgraph about the DirectDraw palette
   fg_ddsetobj(lpDDPalette,3);

   return TRUE;
}

/****************************************************************************\
*                                                                            *
*  InitDirectDrawWindowed()                                                  *
*                                                                            *
*  Perform the initialization normally done in fg_vbinit() for windowed      *
*  DirectDraw programs.                                                      *
*                                                                            *
\****************************************************************************/

BOOL InitDirectDrawWindowed (HWND hWnd)
{
#ifndef DX7
   LPDIRECTDRAW   lpDD1;
#endif
   DDSURFACEDESCn ddsd;
   HRESULT        rc;

#ifdef DX7
   // Create the DirectDraw7 object
   rc = DirectDrawCreateEx(NULL,(void**)&lpDD,IID_IDirectDraw7,NULL);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"DirectDrawCreateEx() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }
#else
   // Create the DirectDraw object
   rc = DirectDrawCreate(NULL,&lpDD1,NULL);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"DirectDrawCreate() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Obtain the DirectDrawN object from the DirectDraw object (which can
   // then be released)
   rc = lpDD1->QueryInterface(IID_IDirectDrawN,(void**)&lpDD);
   lpDD1->Release();
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"QueryInterface() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }
#endif

   // Set the application's cooperative level
   rc = lpDD->SetCooperativeLevel(hWnd,DDSCL_NORMAL);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"SetCooperativeLevel() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Create the primary surface
   ZeroMemory(&ddsd,sizeof(ddsd));
   ddsd.dwSize = sizeof(ddsd);
   ddsd.dwFlags = DDSD_CAPS;
   ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_VIDEOMEMORY;
   rc = lpDD->CreateSurface(&ddsd,&lpDDPrimary,NULL);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"CreatePrimarySurface() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Create the DirectDraw clipper
   rc = lpDD->CreateClipper(NULL,&lpDDClipper,NULL);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"CreateClipper() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Define the window on which the clipper will operate
   rc = lpDDClipper->SetHWnd(NULL,hWnd);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"SetHWnd() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Attach the clipper to the primary surface
   lpDDPrimary->SetClipper(lpDDClipper);
   if (rc != DD_OK)
   {
      MessageBox(hWnd,"SetClipper() failed","Error",MB_OK|MB_ICONSTOP);
      return FALSE;
   }

   // Tell Fastgraph about the DirectDrawN object, primary surface,
   // and clipper
   fg_ddsetobj(lpDD,0);
   fg_ddsetobj(lpDDPrimary,1);
   fg_ddsetobj(lpDDClipper,2);

   return TRUE;
}

/****************************************************************************\
*                                                                            *
*  EndDirectDraw()                                                           *
*                                                                            *
*  Perform the DirectDraw cleanup tasks normally done in fg_vbfin().         *
*                                                                            *
\****************************************************************************/

void EndDirectDraw (void)
{
   // If we created a DirectDraw palette, detach the palette from the
   // DirectDraw primary surface and then release the palette
   if (lpDDPalette != NULL)
   {
      lpDDPrimary->SetPalette(NULL);
      lpDDPalette->Release();
      lpDDPalette = NULL;
      fg_ddsetobj(NULL,3);
   }

   // If we created a DirectDraw clipper, detach the clipper from the
   // DirectDraw primary surface and then release the clipper
   if (lpDDClipper != NULL)
   {
      lpDDPrimary->SetClipper(NULL);
      lpDDClipper->Release();
      lpDDClipper = NULL;
      fg_ddsetobj(NULL,2);
   }

   // If we created a DirectDraw primary surface, release it
   if (lpDDPrimary != NULL)
   {
      lpDDPrimary->Release();
      lpDDPrimary = NULL;
      fg_ddsetobj(NULL,1);
   }

   // If we created a DirectDrawN object, release it
   if (lpDD != NULL)
   {
      lpDD->Release();
      lpDD = NULL;
      fg_ddsetobj(NULL,0);
   }
}

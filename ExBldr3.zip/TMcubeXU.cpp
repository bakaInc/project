/****************************************************************************\
*                                                                            *
*  TMcubeX.cpp                                                               *
*  TMcubeXU.cpp                                                              *
*                                                                            *
*  This program is similar to the TMcube example, but it shows how to create *
*  a native, DirectDraw, or Direct3D program from the same source code.      *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "TMcubeXU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OnActivate(TObject *Sender)
{
   fg_realize(hPal);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OnIdle(TObject *Sender, bool &Done)
{
   if (AppIsActive) CheckForMovement(False);
   Done = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::WMActivateApp(TMessage &Msg)
{
   AppIsActive = Msg.WParam;
   if (AppIsActive && AppIsReady)
   {
#ifdef DIRECTX
      fg_ddrestore();
#endif
      CheckForMovement(True);
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   register int i;

   Visible = True;
#ifdef DIRECTX
   fg_ddsetup(vbWidth,vbHeight,vbDepth,DIRECTX_FLAGS);
#else
   fg_modeset(vbWidth,vbHeight,fg_colors(),1);
   WindowState = wsMaximized;
#endif
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   fg_vbdepth(vbDepth);
#ifdef DIRECTX
   hVB = 0;
#else
   hVB = fg_vballoc(vbWidth,vbHeight);
#endif
   fg_vbopen(hVB);
   fg_vbcolors();

   hZB = fg_zballoc(vbWidth,vbHeight);
   fg_zbopen(hZB);

   // define 3D viewport, clipping planes, and initial render state
   fg_3Dviewport(0,vbWidth-1,0,vbHeight-1,0.5);
   fg_3Dsetzclip(40.0,1000.0);
   fg_3Drenderstate(RENDER_STATE);

   // obtain the six texture maps from the CUBE.PCX file
   fg_tminit(6);
   fg_showpcx("CUBE.PCX",FG_AT_XY|FG_KEEPCOLORS);
   fg_move(0,tmWidth-1);
   for (i = 0; i < 6; i++)
   {
#if (vbDepth == 8)
      fg_getimage(Texture[i],tmWidth,tmWidth);
      fg_invert(Texture[i],tmWidth,tmWidth);
#else
      fg_getdcb(Texture[i],tmWidth,tmWidth);
      fg_invdcb(Texture[i],tmWidth,tmWidth);
#endif
      hTM[i] = fg_tmdefine(Texture[i],tmWidth,tmWidth);
      fg_moverel(tmWidth,0);
   }

   CheckForMovement(True);
   Application->OnActivate = OnActivate;
   Application->OnIdle = OnIdle;
   AppIsActive = True;
   AppIsReady = True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
	TShiftState Shift)
{
   if (Key == VK_ESCAPE || Key == VK_F12) Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_tmfree(-1);
   fg_zbfree(hZB);
#ifdef DIRECTX
   fg_vbfin();
#else
   fg_vbfree(hVB);
   fg_vbfin();
   fg_modeset(0,0,0,0);
#endif
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
   Application->Minimize();
}

/****************************************************************************\
*                                                                            *
*  CheckForMovement()                                                        *
*                                                                            *
*  The CheckForMovement() function checks for key presses that control the   *
*  cube's movement, and if required redraws the cube at its new position and *
*  orientation. It is called from the application's OnIdle event handler.    *
*                                                                            *
*  The Redraw parameter controls when CheckForMovement() redraws the cube.   *
*  If False, the cube is redrawn only if its position or orientation has     *
*  changed since the last call. If True, the cube is redrawn no matter what. *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::CheckForMovement(bool Redraw)
{
   static double xWorld = 0.0, yWorld = 0.0, zWorld = 100.0;
   static int xAngle = 0, yAngle = 0, zAngle = 0;
   bool ShiftKey;

   // check if either shift key is pressed
   ShiftKey = fg_kbtest(42) | fg_kbtest(54);

   // + and - move cube along the z axis (+ is toward viewer, - is
   // away from viewer)
   if (fg_kbtest(74))
   {
      zWorld += 3.0;
      Redraw = True;
   }
   else if (fg_kbtest(78))
   {
      zWorld -= 3.0;
      Redraw = True;
   }

   // left and right arrow keys move cube along x axis
   else if (fg_kbtest(75))
   {
      xWorld -= 3.0;
      Redraw = True;
   }
   else if (fg_kbtest(77))
   {
      xWorld += 3.0;
      Redraw = True;
   }

   // up and down arrow keys move cube along y axis
   else if (fg_kbtest(72))
   {
      yWorld += 3.0;
      Redraw = True;
   }
   else if (fg_kbtest(80))
   {
      yWorld -= 3.0;
      Redraw = True;
   }

   // x rotates counterclockwise around x axis, X rotates clockwise
   else if (fg_kbtest(45))
   {
      if (ShiftKey)
      {
         xAngle += 6;
         if (xAngle >= 360) xAngle -= 360;
      }
      else
      {
         xAngle -= 6;
         if (xAngle < 0) xAngle += 360;
      }
      Redraw = True;
   }

   // y rotates counterclockwise around y axis, Y rotates clockwise
   else if (fg_kbtest(21))
   {
      if (ShiftKey)
      {
         yAngle += 6;
         if (yAngle >= 360) yAngle -= 360;
      }
      else
      {
         yAngle -= 6;
         if (yAngle < 0) yAngle += 360;
      }
      Redraw = True;
   }

   // z rotates counterclockwise around z axis, Z rotates clockwise
   else if (fg_kbtest(44))
   {
      if (ShiftKey)
      {
         zAngle += 6;
         if (zAngle >= 360) zAngle -= 360;
      }
      else
      {
         zAngle -= 6;
         if (zAngle < 0) zAngle += 360;
      }
      Redraw = True;
   }

   // if the cube's position or rotation changed, redraw the cube
   if (Redraw)
   {
#ifdef DIRECTX
      // tell Direct3D we're about to start a new frame
      fg_ddframe(0);
#endif

      // prepare the z-buffer for the next frame
      fg_zbframe();

      // erase the previous frame from the virtual buffer
      fg_setcolor(-1);
      fg_fillpage();

      // define the cube's new position and rotation in 3D world space
      fg_3Dsetobject(xWorld,yWorld,zWorld,xAngle*10,yAngle*10,zAngle*10);

      // draw the cube
      DrawCube();

#ifdef DIRECTX
      // tell Direct3D we're finished with this frame
      fg_ddframe(1);
#endif

      // display what we just drew
      ShowCube();
   }
}

/****************************************************************************\
*                                                                            *
*  DrawCube()                                                                *
*                                                                            *
*  Draws each of the six cube faces in 3D world space.                       *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::DrawCube()
{
   register int i;

   for (i = 0; i < 6; i++)
   {
      fg_tmselect(hTM[i]);
      fg_3Dtexturemapobject((double *)Faces[i],(int *)tmSource,4);
   }
}

/****************************************************************************\
*                                                                            *
*  ShowCube()                                                                *
*                                                                            *
*  Performs a blit or flip to make the cube visible.                         *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::ShowCube()
{
#ifdef DIRECTX
   fg_ddflip();
#else
   fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);
#endif
}

// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "First.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
}

CMainFrame::~CMainFrame()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		m_hVB = fg_vballoc(640,480);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		fg_setcolor(19);
		fg_fillpage();
	}
	return bRet;
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,fg_getmaxx(),0,fg_getmaxy(),0,m_cxClient-1,0,m_cyClient-1);
}

void CMainFrame::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

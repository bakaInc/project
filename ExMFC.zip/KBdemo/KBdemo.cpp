/****************************************************************************\
*                                                                            *
*  KBdemo.cpp                                                                *
*                                                                            *
*  This program shows how to pan the contents of a virtual buffer through    *
*  a smaller window using the low-level keyboard handler.                    *
*                                                                            *
\****************************************************************************/

// KBdemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "KBdemo.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKBdemoApp

BEGIN_MESSAGE_MAP(CKBdemoApp, CWinApp)
	//{{AFX_MSG_MAP(CKBdemoApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKBdemoApp construction

CKBdemoApp::CKBdemoApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CKBdemoApp object

CKBdemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CKBdemoApp initialization

BOOL CKBdemoApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Keyboard Handler Demo"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

int CKBdemoApp::Run()
{
	if (!m_pMainWnd)
		AfxPostQuitMessage(0);

	MSG msg;
	CMainFrame* pFrame = STATIC_DOWNCAST(CMainFrame, m_pMainWnd);

	while (TRUE)
	{
		//see if there is a message waiting
		if (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			do //if there is pump all waiting
			{
				if (!PumpMessage())
					return ExitInstance();
			} while (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE));
		}
		else
		{
			if (!pFrame->m_bAppIsActive)
				WaitMessage();
			else
				pFrame->CheckForPanning();
		}
	}
	return msg.wParam;
}

/////////////////////////////////////////////////////////////////////////////
// CKBdemoApp message handlers

/****************************************************************************\
*                                                                            *
*  Blend.c                                                                   *
*                                                                            *
*  This program illustrates some of the Fastgraph for Windows alpha blending *
*  functions.                                                                *
*                                                                            *
*  Press F1 to view the foreground image.                                    *
*  Press F2 to view the background image.                                    *
*  Press F3 to create and view a 50% blended image.                          *
*  Press F4 to create and view a variable blended image.                     *
*                                                                            *
\****************************************************************************/

#include <fgwin.h>
#include <stdlib.h>

#define vbWidth  640
#define vbHeight 480
#define vbDepth   16

// direct color bitmap containing the foreground image
BYTE Foreground[vbWidth*vbHeight*(vbDepth/8)];

// direct color bitmap containing the background image
BYTE Background[vbWidth*vbHeight*(vbDepth/8)];

// direct color bitmap containing the resulting blended image
BYTE Blended[vbWidth*vbHeight*(vbDepth/8)];

// 256-color bitmap containing variable opacity values
BYTE Opacity[vbWidth*vbHeight];

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);
void MakeOpacityBitmap();

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGblend";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor(NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindow(szAppName, // window class name
      "Alpha Blending Demo",   // window caption
      WS_OVERLAPPEDWINDOW,     // window style
      CW_USEDEFAULT,           // initial x position
      CW_USEDEFAULT,           // initial y position
      CW_USEDEFAULT,           // initial x size
      CW_USEDEFAULT,           // initial y size
      NULL,                    // parent window handle
      NULL,                    // window menu handle
      hInstance,               // program instance handle
      NULL);                   // creation parameters

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   while (GetMessage(&msg,NULL,0,0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HCURSOR  hCursor;
HDC      hDC;
HPALETTE hPal;
int      hVB;
UINT     cxClient, cyClient;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch (iMsg)
   {
      case WM_CREATE:
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);

         fg_vbinit();
         fg_vbdepth(vbDepth);
         hVB = fg_vballoc(vbWidth,vbHeight);
         fg_vbopen(hVB);
         fg_vbcolors();

         // get background image from the CAT.BMP file
         fg_showbmp("CAT.BMP",0);
         fg_move(0,vbHeight-1);
         fg_getdcb(Background,vbWidth,vbHeight);

         // get foreground image from the PORCH.BMP file
         fg_showbmp("PORCH.BMP",0);
         fg_move(0,vbHeight-1);
         fg_getdcb(Foreground,vbWidth,vbHeight);

         // calcluate variable opacity bitmap
         MakeOpacityBitmap();
         return 0;

      case WM_KEYDOWN:
         switch(wParam)
         {
            // display foreground image
            case VK_F1:
               fg_move(0,vbHeight-1);
               fg_putdcb(Foreground,vbWidth,vbHeight);
               fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
               SetWindowText(hWnd,"Alpha Blending: Foreground Image");
               break;

            // display background image
            case VK_F2:
               fg_move(0,vbHeight-1);
               fg_putdcb(Background,vbWidth,vbHeight);
               fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
               SetWindowText(hWnd,"Alpha Blending: Background Image");
               break;

            // display blended image with constant 50% foreground opacity
            case VK_F3:
               hCursor = SetCursor(LoadCursor(NULL,IDC_WAIT));
               ShowCursor(TRUE);
               fg_opacity(128);
               fg_blenddcb(Foreground,Background,Blended,vbWidth*vbHeight);
               fg_move(0,vbHeight-1);
               fg_putdcb(Blended,vbWidth,vbHeight);
               fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
               SetWindowText(hWnd,"Alpha Blending: 50% Blended Image");
               ShowCursor(FALSE);
               SetCursor(hCursor);
               break;

            // display blended image with variable foreground opacity
            case VK_F4:
               hCursor = SetCursor(LoadCursor(NULL,IDC_WAIT));
               ShowCursor(TRUE);
               fg_blendvar(Foreground,Background,Opacity,Blended,vbWidth*vbHeight);
               fg_move(0,vbHeight-1);
               fg_putdcb(Blended,vbWidth,vbHeight);
               fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
               SetWindowText(hWnd,"Alpha Blending: Variable Blended Image");
               ShowCursor(FALSE);
               SetCursor(hCursor);
               break;
         }
         return 0;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
         fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,TRUE);
         return 0;

      case WM_SIZE:
         cxClient = LOWORD(lParam);
         cyClient = HIWORD(lParam);
         return 0;

      case WM_DESTROY:
         fg_vbclose();
         fg_vbfree(hVB);
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

/****************************************************************************\
*                                                                            *
*  MakeOpacityBitmap()                                                       *
*                                                                            *
*  Define a 256-color bitmap with varying opacity values. The foregound      *
*  opacities will be zero at the image center and will gradually increase    *
*  as we move farther from the center.                                       *
*                                                                            *
\****************************************************************************/

void MakeOpacityBitmap()
{
   register int i, x, y;
   int OpacityValue;
   int yTerm;

   i = 0;

   for (y = 0; y < vbHeight; y++)
   {
      yTerm = abs(y - vbHeight/2);
      for (x = 0; x < vbWidth; x++)
      {
         OpacityValue = abs(x - vbWidth/2) + yTerm;
         if (OpacityValue > 255)
            Opacity[i++] = 255;
         else
            Opacity[i++] = (BYTE)OpacityValue;
      }
   }
}

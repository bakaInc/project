/****************************************************************************\
*                                                                            *
*  Geometry.cs                                                               *
*                                                                            *
*  This program shows how to display 3D objects in object space and 3D world *
*  space.                                                                    *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Geometry
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int hZB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		const int vbWidth = 300;
		const int vbHeight = 300;

		// Colors of cube faces.
		int [] Colors = {19, 20, 21, 22, 23, 24};

		// Six faces of a 2x2x2 cube, defined in object coordinates.
		double [,] CubeFaces = {
			{-1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,-1.0,-1.0, 1.0,-1.0},
			{-1.0, 1.0,-1.0, 1.0, 1.0,-1.0, 1.0,-1.0,-1.0,-1.0,-1.0,-1.0},
			{-1.0, 1.0, 1.0,-1.0, 1.0,-1.0,-1.0,-1.0,-1.0,-1.0,-1.0, 1.0},
			{ 1.0, 1.0,-1.0, 1.0, 1.0, 1.0, 1.0,-1.0, 1.0, 1.0,-1.0,-1.0},
			{-1.0,-1.0,-1.0, 1.0,-1.0,-1.0, 1.0,-1.0, 1.0,-1.0,-1.0, 1.0},
			{ 1.0, 1.0, 1.0,-1.0, 1.0, 1.0,-1.0,-1.0, 1.0, 1.0,-1.0, 1.0}};

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(300, 300);
			this.Name = "Form1";
			this.Text = "3D Geometry";
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Closed += new System.EventHandler(this.Form1_Closed);
		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			// Create the device context and logical palette.
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			// Create and open the virtual buffer.
			fg.vbinit();
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();

			// Fill the virtual buffer with white pixels.
			fg.setcolor(-1);
			fg.fillpage();

			// Create and open the z-buffer.
			hZB = fg.zballoc(vbWidth, vbHeight);
			fg.zbopen(hZB);

			// Define 3D viewport and render state.
			fg._3Dviewport(0, vbWidth-1, 0, vbHeight-1, 1.0);
			fg._3Drenderstate(fg.ZBUFFER);

			// Draw the cubes and coordinate axes.
			DrawCubes();
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.zbfree(hZB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		/****************************************************************************\
		*                                                                            *
		*  DrawCubes()                                                               *
		*                                                                            *
		*  Draws two cubes, one in 3D world space and the other in object space,     *
		*  along with 3D coordinate axes.                                            *
		*                                                                            *
		\****************************************************************************/

		private void DrawCubes()
		{
			int i;

			// Set the point of view (POV).
			fg._3Dmove(4.0, 4.0, -15.0);

			// Position a cube at z=20.0 with no rotation.
			fg._3Dmoveobject(0.0, 0.0, 20.0);

			// Draw the 3D coordinate axes in world space.
			fg.setcolor(0);
			fg._3Dline(0.0, 0.0, 0.0, 10.0, 0.0, 0.0);
			fg._3Dline(0.0, 0.0, 0.0, 0.0, 10.0, 0.0);
			fg._3Dline(0.0, 0.0, 0.0, 0.0, 0.0, 500.0);

			// Draw all six faces in both cubes.
			for (i = 0; i < 6; i++)
			{
				fg.setcolor(Colors[i]);
				fg._3Dpolygon(ref CubeFaces[i,0], 4);
				fg._3Dpolygonobject(ref CubeFaces[i,0], 4);
			}
		}
	}
}
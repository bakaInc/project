//---------------------------------------------------------------------------
#ifndef BlendUH
#define BlendUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <FGwin.h>
#include <stdlib.h>

#define vbWidth  640
#define vbHeight 480
#define vbDepth   16
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   UINT cxClient, cyClient;
   void __fastcall MakeOpacityBitmap(void);
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
// direct color bitmap containing the foreground image
byte Foreground[vbWidth*vbHeight*(vbDepth/8)];
// direct color bitmap containing the background image
byte Background[vbWidth*vbHeight*(vbDepth/8)];
// direct color bitmap containing the resulting blended image
byte Blended[vbWidth*vbHeight*(vbDepth/8)];
// 256-color bitmap containing variable opacity values
byte Opacity[vbWidth*vbHeight];
//---------------------------------------------------------------------------
#endif

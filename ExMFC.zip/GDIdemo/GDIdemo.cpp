/****************************************************************************\
*                                                                            *
*  GDIdemo.cpp                                                               *
*                                                                            *
*  This program shows how to use Windows GDI functions to write to a virtual *
*  buffer. It uses GDI functions to display a cross-hatched rectangle with a *
*  border, something that would require construction from several graphics   *
*  primitives if using Fastgraph for Windows drawing functions only.         *
*                                                                            *
\****************************************************************************/

// GDIdemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "GDIdemo.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGDIdemoApp

BEGIN_MESSAGE_MAP(CGDIdemoApp, CWinApp)
	//{{AFX_MSG_MAP(CGDIdemoApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGDIdemoApp construction

CGDIdemoApp::CGDIdemoApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CGDIdemoApp object

CGDIdemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CGDIdemoApp initialization

BOOL CGDIdemoApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Fastgraph for Windows GDI Demo"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CGDIdemoApp message handlers

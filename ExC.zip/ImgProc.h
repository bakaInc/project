//----------------------
// ImgProc.h header file
//----------------------

#define IDM_File_Open                101
#define IDM_File_SaveAs              102
#define IDM_File_Details             103
#define IDM_File_Exit                104

#define IDM_Edit_Undo                201
#define IDM_Edit_RestoreOriginal     202
#define IDM_Edit_ContrastEnhancement 203
#define IDM_Edit_GammaCorrection     204
#define IDM_Edit_Grayscale           205
#define IDM_Edit_PhotoInversion      206

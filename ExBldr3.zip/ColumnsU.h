//---------------------------------------------------------------------------
#ifndef ColumnsUH
#define ColumnsUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <FGwin.h>
#include <stdio.h>

#define vbWidth  600
#define vbHeight 400

#define InfoHeight 80

#define WinWidth  vbWidth
#define WinHeight (vbHeight+InfoHeight)
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   int hZB;
   void __fastcall CheckForMotion(void);
   void __fastcall DrawColumns(void);
   void __fastcall UpdateInfo(void);
   void __fastcall OnIdle(TObject *Sender, bool &Done);
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
// six faces of a 2x2x10 column, defined in object coordinates
double ColumnData[6][12] =
{
   {-1.0,10.0, 1.0,  1.0,10.0, 1.0,  1.0,10.0,-1.0, -1.0,10.0,-1.0}, // top
   {-1.0,10.0,-1.0,  1.0,10.0,-1.0,  1.0, 0.0,-1.0, -1.0, 0.0,-1.0}, // front
   {-1.0,10.0, 1.0, -1.0,10.0,-1.0, -1.0, 0.0,-1.0, -1.0, 0.0, 1.0}, // left
   { 1.0,10.0,-1.0,  1.0,10.0, 1.0,  1.0, 0.0, 1.0,  1.0, 0.0,-1.0}, // right
   {-1.0, 0.0,-1.0,  1.0, 0.0,-1.0,  1.0, 0.0, 1.0, -1.0, 0.0, 1.0}, // bottom
   { 1.0,10.0, 1.0, -1.0,10.0, 1.0, -1.0, 0.0, 1.0,  1.0, 0.0, 1.0}  // back
};
//---------------------------------------------------------------------------
#endif

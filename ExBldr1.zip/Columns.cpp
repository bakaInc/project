/****************************************************************************\
*                                                                            *
*  Columns.cpp                                                               *
*  ColumnsU.cpp                                                              *
*                                                                            *
*  This program draws a grid of columns in 3D world space. It demonstrates   *
*  polygon culling and Fastgraph's incremental POV functions.                *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("ColumnsU.cpp", Form1);
USERES("Columns.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

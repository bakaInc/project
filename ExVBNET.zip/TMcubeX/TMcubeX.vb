'*****************************************************************************
'                                                                            *
'  TMcubeX.vb                                                                *
'                                                                            *
'  This program is similar to the TMcube example, but it shows how to create *
'  a native, DirectDraw, or Direct3D program from the same source code.      *
'                                                                            *
'  Use the FGWinD.vb module file if creating a DirectX program, or use the   *
'  FGWin.vb module file if creating a native program.                        *
'                                                                            *
'*****************************************************************************
Imports System.Runtime.InteropServices
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Set DIRECTX to
    '   True if creating a DirectDraw or Direct3D program (use module FGWinD.vb).
    '   False if creating a native Win32 program (use module FGWin.vb).
#Const DIRECTX = True

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim hZB As Integer
    Dim hTM(6) As Integer
    Dim AppIsActive As Boolean = False

    ' Define the flag bits for fg_ddsetup():
    ' Specify FG_DX_FLIP for a Direct3D application.
    ' Specify FG_DX_RENDER_HW or FG_DX_RENDER_SW for a Direct3D application.
    ' Specify FG_DX_ZBUFFER only if FG_ZBUFFER is defined in RENDER_STATE.
#If DIRECTX Then
    Const DIRECTX_FLAGS As Integer = FG_DX_FLIP + FG_DX_RENDER_HW + FG_DX_ZBUFFER
#End If

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 640
    Const vbHeight As Integer = 480
    Const vbDepth As Integer = 16

    ' Application variables.
    Const RENDER_STATE As Integer = FG_PERSPECTIVE_TM + FG_ZBUFFER + FG_ZCLIP
    Const tmWidth As Integer = 64
    Dim Redraw As Boolean
    Dim xAngle, yAngle, zAngle As Integer
    Dim xWorld, yWorld, zWorld As Double

    ' Six faces of a 40x40x40 cube, defined in object coordinates.
    Dim Faces(,) As Double = { _
        {20.0, -20.0, -20.0, -20.0, -20.0, -20.0, -20.0, 20.0, -20.0, 20.0, 20.0, -20.0}, _
        {-20.0, -20.0, -20.0, -20.0, -20.0, 20.0, -20.0, 20.0, 20.0, -20.0, 20.0, -20.0}, _
        {20.0, 20.0, 20.0, -20.0, 20.0, 20.0, -20.0, -20.0, 20.0, 20.0, -20.0, 20.0}, _
        {20.0, -20.0, 20.0, 20.0, -20.0, -20.0, 20.0, 20.0, -20.0, 20.0, 20.0, 20.0}, _
        {20.0, -20.0, 20.0, -20.0, -20.0, 20.0, -20.0, -20.0, -20.0, 20.0, -20.0, -20.0}, _
        {20.0, 20.0, -20.0, -20.0, 20.0, -20.0, -20.0, 20.0, 20.0, 20.0, 20.0, 20.0}}

    ' Texture map array.
    Dim Texture(6, tmWidth * tmWidth * (vbDepth \ 8)) As Byte

    ' Texture map arrays passed to fg_tmdefine() must be pinned objects when using the
    ' .NET framework (this restriction may be lifted in a future version of Fastgraph).
    Dim TextureHandle As GCHandle = GCHandle.Alloc(Texture, GCHandleType.Pinned)

    ' Coordinates defining source polygon vertices within the texture map array.
    Dim tmSource() As Integer = _
        {tmWidth - 1, tmWidth - 1, 0, tmWidth - 1, 0, 0, tmWidth - 1, 0}

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.Text = "Texture-Mapped Cube"

    End Sub

#End Region

    Protected Overrides Sub WndProc(ByRef m As Message)
        Const WM_ACTIVATEAPP As Integer = &H1C

        MyBase.WndProc(m)
        Select Case m.Msg
            Case WM_ACTIVATEAPP
                AppIsActive = (m.WParam.ToInt32 <> 0)
                If AppIsActive Then
#If DIRECTX Then
                    fg_ddrestore()
#End If
                    Redraw = True
                End If
        End Select
    End Sub

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim I As Integer

        Me.Show()
        Me.Focus()
#If DIRECTX Then
        fg_ddsetup(vbWidth, vbHeight, vbDepth, DIRECTX_FLAGS)
#Else
        fg_modeset(vbWidth, vbHeight, fg_colors(), 1)
        Me.WindowState = FormWindowState.Maximized
#End If

        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        fg_vbdepth(vbDepth)
#If DIRECTX Then
        hVB = 0
#Else
        hVB = fg_vballoc(vbWidth, vbHeight)
#End If
        fg_vbopen(hVB)
        fg_vbcolors()

        hZB = fg_zballoc(vbWidth, vbHeight)
        fg_zbopen(hZB)

        ' Define 3D viewport, clipping planes, and initial render state.
        fg_3Dviewport(0, vbWidth - 1, 0, vbHeight - 1, 0.5)
        fg_3Dsetzclip(40.0, 1000.0)
        fg_3Drenderstate(RENDER_STATE)

        ' Obtain the six texture maps from the CUBE.PCX file.
        fg_tminit(6)
        fg_showpcx("CUBE.PCX", FG_AT_XY + FG_KEEPCOLORS)
        fg_move(0, tmWidth - 1)
        For I = 0 To 5
#If vbDepth = 8 Then
            fg_getimage(Texture(I, 0), tmWidth, tmWidth)
            fg_invert(Texture(I, 0), tmWidth, tmWidth)
#Else
            fg_getdcb(Texture(I, 0), tmWidth, tmWidth)
            fg_invdcb(Texture(I, 0), tmWidth, tmWidth)
#End If
            hTM(I) = fg_tmdefine(Texture(I, 0), tmWidth, tmWidth)
            fg_moverel(tmWidth, 0)
        Next

        xAngle = 0
        yAngle = 0
        zAngle = 0
        xWorld = 0.0
        yWorld = 0.0
        zWorld = 100.0
        Redraw = True

        fg_setcolor(-1)
        fg_fillpage()

        Timer1.Enabled = True
    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Or e.KeyCode = Keys.F12 Then Me.Close()
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        AppIsActive = False
        fg_vbclose()
        fg_tmfree(-1)
        fg_zbfree(hZB)
#If DIRECTX Then
        fg_vbfin()
#Else
        fg_vbfree(hVB)
        fg_vbfin()
        fg_modeset(0, 0, 0, 0)
#End If
        g.ReleaseHdc(hDC)
        TextureHandle.Free()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If AppIsActive Then CheckForMovement()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  CheckForMovement()                                                        *
    '                                                                            *
    '  The CheckForMovement() function checks for key presses that control the   *
    '  cube's movement, and if required redraws the cube at its new position and *
    '  orientation. It is called every 10ms from the timer's OnTick event        *
    '  handler.                                                                  *
    '                                                                            *
    '*****************************************************************************

    Private Sub CheckForMovement()
        Dim ShiftKey As Boolean

        ' Check if either shift key is pressed.
        ShiftKey = (fg_kbtest(42) = 1) Or (fg_kbtest(54) = 1)

        ' + and - move cube along the z axis (+ is toward viewer, - is
        ' away from viewer).
        If fg_kbtest(74) = 1 Then
            zWorld += 3.0
            Redraw = True
        ElseIf fg_kbtest(78) = 1 Then
            zWorld -= 3.0
            Redraw = True

            ' Left and right arrow keys move cube along x axis.
        ElseIf fg_kbtest(75) = 1 Then
            xWorld -= 3.0
            Redraw = True
        ElseIf fg_kbtest(77) = 1 Then
            xWorld += 3.0
            Redraw = True

            ' Up and down arrow keys move cube along y axis.
        ElseIf fg_kbtest(72) = 1 Then
            yWorld += 3.0
            Redraw = True
        ElseIf fg_kbtest(80) = 1 Then
            yWorld -= 3.0
            Redraw = True

            ' x rotates counterclockwise around x axis, X rotates clockwise.
        ElseIf fg_kbtest(45) = 1 Then
            If ShiftKey Then
                xAngle += 6
                If xAngle >= 360 Then xAngle -= 360
            Else
                xAngle -= 6
                If xAngle < 0 Then xAngle += 360
            End If
            Redraw = True

            ' y rotates counterclockwise around y axis, Y rotates clockwise.
        ElseIf fg_kbtest(21) = 1 Then
            If ShiftKey Then
                yAngle += 6
                If yAngle >= 360 Then yAngle -= 360
            Else
                yAngle -= 6
                If yAngle < 0 Then yAngle += 360
            End If
            Redraw = True

            ' z rotates counterclockwise around z axis, Z rotates clockwise.
        ElseIf fg_kbtest(44) = 1 Then
            If ShiftKey Then
                zAngle += 6
                If zAngle >= 360 Then zAngle -= 360
            Else
                zAngle -= 6
                If zAngle < 0 Then zAngle += 360
            End If
            Redraw = True
        End If

        ' If the cube's position or orientation changed, redraw the cube.
        If Redraw Then

#If DIRECTX Then
            ' Tell Direct3D we're about to start a new frame.
            fg_ddframe(0)
#End If

            ' Prepare the z-buffer for the next frame.
            fg_zbframe()

            ' Erase the previous frame from the virtual buffer.
            fg_setcolor(-1)
            fg_fillpage()

            ' Define the cube's new position and rotation in 3D world space.
            fg_3Dsetobject(xWorld, yWorld, zWorld, xAngle * 10, yAngle * 10, zAngle * 10)

            ' Draw the cube.
            DrawCube()

#If DIRECTX Then
            ' Tell Direct3D we're finished with this frame.
            fg_ddframe(1)
#End If

            ' Display what we just drew.
            ShowCube()
            Redraw = False
        End If
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  DrawCube()                                                                *
    '                                                                            *
    '  Draws each of the six cube faces in 3D world space.                       *
    '                                                                            *
    '*****************************************************************************

    Private Sub DrawCube()
        Dim I As Integer

        For I = 0 To 5
            fg_tmselect(hTM(I))
            fg_3Dtexturemapobject(Faces(I, 0), tmSource(0), 4)
        Next
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  ShowCube()                                                                *
    '                                                                            *
    '  Performs a blit or flip to make the cube visible.                         *
    '                                                                            *
    '*****************************************************************************

    Private Sub ShowCube()
#If DIRECTX Then
        fg_ddflip()
#Else
        fg_vbpaste(0, vbWidth - 1, 0, vbHeight - 1, 0, vbHeight - 1)
#End If
    End Sub
End Class
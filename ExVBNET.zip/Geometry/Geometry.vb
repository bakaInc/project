'*****************************************************************************
'                                                                            *
'  Geometry.vb                                                               *
'                                                                            *
'  This program shows how to display 3D objects in object space and 3D world *
'  space.                                                                    *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim hZB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 300
    Const vbHeight As Integer = 300

    ' Colors of cube faces.
    Dim Colors() As Integer = {19, 20, 21, 22, 23, 24}

    ' Six faces of a 2x2x2 cube, defined in object coordinates.
    Dim CubeFaces(,) As Double = { _
        {-1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0}, _
        {-1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0}, _
        {-1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0}, _
        {1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0}, _
        {-1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0}, _
        {1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0}}

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(300, 300)
        Me.Name = "Form1"
        Me.Text = "3D Geometry"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Create the device context and logical palette.
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        ' Create and open the virtual buffer.
        fg_vbinit()
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        ' Fill the virtual buffer with white pixels.
        fg_setcolor(-1)
        fg_fillpage()

        ' Create and open the z-buffer.
        hZB = fg_zballoc(vbWidth, vbHeight)
        fg_zbopen(hZB)

        ' Define 3D viewport and render state.
        fg_3Dviewport(0, vbWidth - 1, 0, vbHeight - 1, 1.0)
        fg_3Drenderstate(FG_ZBUFFER)

        ' Draw the cubes and coordinate axes.
        DrawCubes()
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_zbfree(hZB)
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  DrawCubes()                                                               *
    '                                                                            *
    '  Draws two cubes, one in 3D world space and the other in object space,     *
    '  along with 3D coordinate axes.                                            *
    '                                                                            *
    '*****************************************************************************

    Private Sub DrawCubes()
        Dim I As Integer

        ' Set the point of view (POV).
        fg_3Dmove(4.0, 4.0, -15.0)

        ' Position a cube at z=20.0 with no rotation.
        fg_3Dmoveobject(0.0, 0.0, 20.0)

        ' Draw the 3D coordinate axes in world space.
        fg_setcolor(0)
        fg_3Dline(0.0, 0.0, 0.0, 10.0, 0.0, 0.0)
        fg_3Dline(0.0, 0.0, 0.0, 0.0, 10.0, 0.0)
        fg_3Dline(0.0, 0.0, 0.0, 0.0, 0.0, 500.0)

        ' Draw all six faces in both cubes.
        For I = 0 To 5
            fg_setcolor(Colors(I))
            fg_3Dpolygon(CubeFaces(I, 0), 4)
            fg_3Dpolygonobject(CubeFaces(I, 0), 4)
        Next
    End Sub
End Class

/****************************************************************************\
*                                                                            *
*  Columns.c                                                                 *
*                                                                            *
*  This program draws a grid of columns in 3D world space. It demonstrates   *
*  polygon culling and Fastgraph's incremental POV functions.                *
*                                                                            *
\****************************************************************************/

#include <fgwin.h>
#include <stdio.h>

#define vbWidth  600
#define vbHeight 400

#define InfoHeight 80

#define WinWidth  vbWidth
#define WinHeight (vbHeight+InfoHeight)

// six faces of a 2x2x10 column, defined in object coordinates
double ColumnData[6][12] =
{
   {-1.0,10.0, 1.0,  1.0,10.0, 1.0,  1.0,10.0,-1.0, -1.0,10.0,-1.0}, // top
   {-1.0,10.0,-1.0,  1.0,10.0,-1.0,  1.0, 0.0,-1.0, -1.0, 0.0,-1.0}, // front
   {-1.0,10.0, 1.0, -1.0,10.0,-1.0, -1.0, 0.0,-1.0, -1.0, 0.0, 1.0}, // left
   { 1.0,10.0,-1.0,  1.0,10.0, 1.0,  1.0, 0.0, 1.0,  1.0, 0.0,-1.0}, // right
   {-1.0, 0.0,-1.0,  1.0, 0.0,-1.0,  1.0, 0.0, 1.0, -1.0, 0.0, 1.0}, // bottom
   { 1.0,10.0, 1.0, -1.0,10.0, 1.0, -1.0, 0.0, 1.0,  1.0, 0.0, 1.0}  // back
};

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);
void CheckForMotion(void);
void DrawColumns(void);
void SetWindowSize(int,int);
void UpdateInfo(void);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int nCmdShow)
{
   static char szAppName[] = "FGcolumns";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor(NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindow(szAppName, // window class name
      "3D Columns",               // window caption
      WS_POPUPWINDOW|WS_CAPTION,  // window style
      0,                          // initial x position
      0,                          // initial y position
      WinWidth,                   // initial x size
      WinHeight,                  // initial y size
      NULL,                       // parent window handle
      NULL,                       // window menu handle
      hInstance,                  // program instance handle
      NULL);                      // creation parameters

   ShowWindow(hWnd,nCmdShow);
   UpdateWindow(hWnd);

   while (TRUE)
   {
      if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
      {
         if (msg.message == WM_QUIT)
            break;
         else
         {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
         }
      }
      else
         CheckForMotion();
   }

   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HDC      hDC;
HPALETTE hPal;
int      hVB;
int      hZB;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch (iMsg)
   {
      case WM_CREATE:
         // set up the device context and logical palette
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);

         // initialize the virtual buffer environment
         fg_vbinit();
         fg_vbdepth(fg_colors());

         // create and open the virtual buffer
         hVB = fg_vballoc(vbWidth,vbHeight);
         fg_vbopen(hVB);
         fg_vbcolors();

         // create and open the z-buffer
         hZB = fg_zballoc(vbWidth,vbHeight);
         fg_zbopen(hZB);

         // define 3D viewport, render state, and initial POV
         fg_3Dviewport(0,vbWidth-1,0,vbHeight-1,1.0);
         fg_3Drenderstate(FG_ZBUFFER|FG_ZCLIP);
         fg_3Dlookat(10.0,20.0,100.0,0.0,20.0,0.0);

         // direct strings to the active virtual buffer
         fg_fontdc(fg_getdc());

         // make the client area equal to the required size
         ShowWindow(hWnd,SW_SHOWNORMAL);
         SetWindowSize(WinWidth,WinHeight);
         return 0;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
         DrawColumns();
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,TRUE);
         return 0;

      case WM_DESTROY:
         fg_vbclose();
         fg_zbfree(hZB);
         fg_vbfree(hVB);
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

/****************************************************************************\
*                                                                            *
*  CheckForMotion()                                                          *
*                                                                            *
*  The CheckForMotion() function checks for key presses that control the     *
*  viewer's position and orientation, and if required redraws the scene at   *
*  its new POV. It is called from the WinMain() message loop when there are  *
*  no messages waiting.                                                      *
*                                                                            *
\****************************************************************************/

void CheckForMotion(void)
{
   BOOL ShiftKey;

   ShiftKey = fg_kbtest(42) | fg_kbtest(54);

   if (fg_kbtest(71))      // Home
   {
      fg_3Dmoveup(5.0);
      DrawColumns();
   }
   else if (fg_kbtest(72)) // Up arrow
   {
      fg_3Dmoveforward(5.0);
      DrawColumns();
   }
   else if (fg_kbtest(73)) // PgUp
   {
      fg_3Drotateup(100);
      DrawColumns();
   }
   else if (fg_kbtest(75)) // Left arrow
   {
      if (ShiftKey)
         fg_3Dmoveright(-5.0);
      else
         fg_3Drotateright(-100);
      DrawColumns();
   }
   else if (fg_kbtest(77)) // Right arrow
   {
      if (ShiftKey)
         fg_3Dmoveright(5.0);
      else
         fg_3Drotateright(100);
      DrawColumns();
   }
   else if (fg_kbtest(79)) // End
   {
      fg_3Dmoveup(-5.0);
      DrawColumns();
   }
   else if (fg_kbtest(80)) // Down arrow
   {
      fg_3Dmoveforward(-5.0);
      DrawColumns();
   }
   else if (fg_kbtest(81)) // PgDn
   {
      fg_3Drotateup(-100);
      DrawColumns();
   }
}

/****************************************************************************\
*                                                                            *
*  DrawColumns()                                                             *
*                                                                            *
*  Draws the scene at its new POV. Columns behind the viewer are culled out. *
*                                                                            *
\****************************************************************************/

void DrawColumns()
{
   static int r[] = {254,243,226,203,123,166};
   static int g[] = {219,194,172,150, 98,125};
   static int b[] = {164,117, 86, 67, 59, 60};
   int nColor[6];
   int row, col;
   register int i;

   // prepare for the new frame
   fg_zbframe();
   fg_setcolor(-1);
   fg_fillpage();

   // create the six encoded color values
   for (i = 0; i < 6; i++)
      nColor[i] = fg_maprgb(r[i],g[i],b[i]);

   // 50x50x6 = 15000 polygons per frame
   for (row = -500; row < 500; row += 20)
   {
      for (col = -500; col < 500; col += 20)
      {
         if (fg_3Dbehindviewer((double)row,0.0,(double)col,-1.0) == 0)
         {
            fg_3Dmoveobject((double)row,0.0,(double)col);

            // draw all the faces
            for (i = 0; i < 6; i++)
            {
               // set the color
               fg_setcolor(nColor[i]);

               // draw the face
               fg_3Dpolygonobject(ColumnData[i],4);
            }
         }
      }
   }

   // display the scene
   fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);

   // display the 3D information at the bottom of the window
   UpdateInfo();
}

/****************************************************************************\
*                                                                            *
*  UpdateInfo()                                                              *
*                                                                            *
*  Displays the information at the bottom of the window.                     *
*                                                                            *
\****************************************************************************/

void UpdateInfo()
{
   double x, y, z, xDir, yDir, zDir;
   char String[64];

   // get current position and direction
   fg_3Dgetpov(&x,&y,&z,&xDir,&yDir,&zDir);

   // clear an area to write on
   fg_setcolorrgb(0,0,140);
   fg_rect(0,249,0,InfoHeight-1);

   fg_setcolorrgb(0,140,0);
   fg_rect(250,vbWidth-1,0,InfoHeight-1);

   fg_setcolor(-1);

   // print current position and unit vector
   fg_move(20,32);
   sprintf(String,"x =%7.2f  xDir = %7.2f",x,xDir);
   fg_print(String,strlen(String));

   fg_move(20,46);
   sprintf(String,"y =%7.2f  yDir = %7.2f",y,yDir);
   fg_print(String,strlen(String));

   fg_move(20,60);
   sprintf(String,"z =%7.2f  zDir = %7.2f",z,zDir);
   fg_print(String,strlen(String));

   // print instructions
   fg_move(270,18);
   sprintf(String,"Up    = move forward   Home = move up");
   fg_print(String,strlen(String));

   fg_move(270,32);
   sprintf(String,"Down  = move back      End  = move down");
   fg_print(String,strlen(String));

   fg_move(270,46);
   sprintf(String,"Left  = turn left      PgUp = look up");
   fg_print(String,strlen(String));

   fg_move(270,60);
   sprintf(String,"Right = turn right     PgDn = look down");
   fg_print(String,strlen(String));

   fg_move(290,74);
   sprintf(String,"Shift+Left/Right = move left/right");
   fg_print(String,strlen(String));

   fg_vbpaste(0,vbWidth-1,0,InfoHeight-1,0,WinHeight-1);
}

/****************************************************************************\
*                                                                            *
*  SetWindowSize()                                                           *
*                                                                            *
*  Sets the window size so the client area has the specified dimensions.     *
*                                                                            *
\****************************************************************************/

void SetWindowSize(int ClientWidth, int ClientHeight)
{
   RECT ClientRect;
   RECT WindowRect;
   int WindowWidth, WindowHeight;

   GetClientRect(GetActiveWindow(),&ClientRect);
   GetWindowRect(GetActiveWindow(),&WindowRect);

   WindowWidth = ClientWidth +
      (WindowRect.right - WindowRect.left) -
      (ClientRect.right - ClientRect.left);
   WindowHeight = ClientHeight +
      (WindowRect.bottom - WindowRect.top) -
      (ClientRect.bottom - ClientRect.top);
   SetWindowPos(GetActiveWindow(),NULL,0,0,
      WindowWidth,WindowHeight,SWP_NOMOVE|SWP_NOZORDER);
}

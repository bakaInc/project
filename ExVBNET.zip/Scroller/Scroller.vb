'*****************************************************************************
'                                                                            *
'  Scroller.vb                                                               *
'                                                                            *
'  This program demonstrates circular scrolling within a virtual buffer.     *
'                                                                            *
'  Because fg_scroll() requires a "hidden" virtual buffer to save and then   *
'  restore portions of the area being scrolled, we create a second virtual   *
'  buffer for this purpose.                                                  *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB1, hVB2 As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 320
    Const vbHeight As Integer = 200

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Name = "Form1"
        Me.Text = "Scrolling Demo"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        hVB1 = fg_vballoc(vbWidth, vbHeight)
        hVB2 = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB2)
        fg_vbcolors()
        fg_vbopen(hVB1)
        fg_vbcolors()
        fg_sethpage(hVB2)

        fg_setcolor(19)
        fg_fillpage()
        fg_setcolor(25)
        fg_rect(132, 188, 50, 150)

        fg_setcolor(20)
        fg_move(160, 67)
        fg_draw(175, 107)
        fg_draw(140, 82)
        fg_draw(180, 82)
        fg_draw(145, 107)
        fg_draw(160, 67)
        fg_paint(160, 77)
        fg_paint(150, 87)
        fg_paint(160, 87)
        fg_paint(170, 87)
        fg_paint(155, 97)
        fg_paint(165, 97)

        Timer1.Enabled = True
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB1)
        fg_vbfree(hVB2)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Scroll()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Scroll()                                                                  *
    '                                                                            *
    '  The Scroll() subroutine moves the scrolling region up four pixels in a    *
    '  circular manner. It is called every 10ms from the timer's OnTick event    *
    '  handler.                                                                  *
    '                                                                            *
    '*****************************************************************************

    Private Sub Scroll()
        fg_scroll(136, 184, 50, 150, -4, 0)
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub
End Class
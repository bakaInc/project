/****************************************************************************\
*                                                                            *
*  SWchars.cpp                                                               *
*  SWcharsU.cpp                                                              *
*                                                                            *
*  This program displays all characters in the Fastgraph for Windows primary *
*  and alternate software fonts.                                             *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "SWCharsU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   Left = 0;
   Top = 0;
   Width = vbWidth;
   Height = vbHeight;

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_initw();
   fg_setworld(0.0,6.39,0.0,4.79);
   fg_setsizew(0.2);

   fg_setcolor(25);
   fg_fillpage();
   fg_setcolor(19);
   fg_movew(3.2,4.2);
   fg_swchar("Software characters - font 1",28,0);
   fg_setcolor(10);
   fg_movew(0.5,3.9);
   fg_swchar("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,-1);
   fg_movew(0.5,3.6);
   fg_swchar("abcdefghijklmnopqrstuvwxyz",26,-1);
   fg_movew(0.5,3.3);
   fg_swchar("0123456789",10,-1);
   fg_movew(0.5,3.0);
   fg_swchar("!\"#$%&'()*+,-./:;<=>?[]^`{|}~",29,-1);

   fg_setcolor(19);
   fg_movew(3.2,2.5);
   fg_swchar("Software characters - font 2",28,0);
   fg_setcolor(10);
   fg_movew(0.5,2.2);
   fg_swchar("\\ABCDEFGHIJKLMNOPRSTUWXYZ",25,-1);
   fg_movew(0.5,1.9);
   fg_swchar("\\abcdefghijklmnoprstuwxyz",25,-1);
   fg_movew(0.5,1.3);
   fg_swchar("\\012345678#$%&()*+/<=>?[]{}",27,-1);

   fg_setratio(1.2);
   fg_movew(0.5,0.6);
   fg_swchar("cos\\^2\\h\\+sin\\^2\\h\\=1",21,-1);

   fg_movew(5.9,0.6);
   fg_swchar("H\\v2O U\\v2\\v3\\v2",16,1);

   fg_setratio(1.0);
   fg_movew(3.2,0.2);
   fg_swchar("One _word_ is underlined.",25,0);

   fg_setcolor(19);
   fg_movew(0.0,2.8);
   fg_draww(6.39,2.8);
   fg_movew(0.0,0.9);
   fg_draww(6.39,0.9);

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbpaste(0,vbWidth-1,0,vbHeight-1,xDest,yDest);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   xDest = (ClientWidth-vbWidth)/2;
   yDest = (ClientHeight-vbHeight)/2;
   if (xDest < 0) xDest = 0;
   if (yDest < 0) yDest = 0;
   yDest = (ClientHeight-1)-yDest;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------

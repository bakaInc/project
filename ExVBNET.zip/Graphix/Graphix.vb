'*****************************************************************************
'                                                                            *
'  Graphix.vb                                                                *
'                                                                            *
'  This program demonstrates some of the Fastgraph for Windows graphics      *
'  primitive functions.                                                      *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 640
    Const vbHeight As Integer = 480

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuPoints As System.Windows.Forms.MenuItem
    Friend WithEvents menuLines As System.Windows.Forms.MenuItem
    Friend WithEvents menuRectangles As System.Windows.Forms.MenuItem
    Friend WithEvents menuCircles As System.Windows.Forms.MenuItem
    Friend WithEvents menuEllipses As System.Windows.Forms.MenuItem
    Friend WithEvents menuPolygons As System.Windows.Forms.MenuItem
    Friend WithEvents menuPaint As System.Windows.Forms.MenuItem
    Friend WithEvents menuExit As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.menuPoints = New System.Windows.Forms.MenuItem()
        Me.menuLines = New System.Windows.Forms.MenuItem()
        Me.menuRectangles = New System.Windows.Forms.MenuItem()
        Me.menuCircles = New System.Windows.Forms.MenuItem()
        Me.menuEllipses = New System.Windows.Forms.MenuItem()
        Me.menuPolygons = New System.Windows.Forms.MenuItem()
        Me.menuPaint = New System.Windows.Forms.MenuItem()
        Me.menuExit = New System.Windows.Forms.MenuItem()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuPoints, Me.menuLines, Me.menuRectangles, Me.menuCircles, Me.menuEllipses, Me.menuPolygons, Me.menuPaint, Me.menuExit})
        '
        'menuPoints
        '
        Me.menuPoints.Index = 0
        Me.menuPoints.Text = "&Points"
        '
        'menuLines
        '
        Me.menuLines.Index = 1
        Me.menuLines.Text = "&Lines"
        '
        'menuRectangles
        '
        Me.menuRectangles.Index = 2
        Me.menuRectangles.Text = "&Rectangles"
        '
        'menuCircles
        '
        Me.menuCircles.Index = 3
        Me.menuCircles.Text = "&Circles"
        '
        'menuEllipses
        '
        Me.menuEllipses.Index = 4
        Me.menuEllipses.Text = "&Ellipses"
        '
        'menuPolygons
        '
        Me.menuPolygons.Index = 5
        Me.menuPolygons.Text = "P&olygons"
        '
        'menuPaint
        '
        Me.menuPaint.Index = 6
        Me.menuPaint.Text = "P&aint"
        '
        'menuExit
        '
        Me.menuExit.Index = 7
        Me.menuExit.Text = "E&xit"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(632, 433)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Graphics Primitives"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        fg_setcolor(25)
        fg_fillpage()
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Blit()
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Blit()
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Points_Click()                                                            *
    '                                                                            *
    '  Draw a pattern of points.                                                 *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuPoints_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuPoints.Click
        Dim X, Y As Integer

        ' Fill the virtual buffer with yellow pixels.
        fg_setcolor(24)
        fg_fillpage()

        ' Draw the patterns of points.
        fg_setcolor(19)
        For X = 7 To vbWidth - 1 Step 20
            For Y = 0 To vbHeight - 1 Step 8
                fg_point(X, Y)
            Next Y
        Next X

        fg_setcolor(22)
        For X = 17 To vbWidth - 1 Step 20
            For Y = 4 To vbHeight - 1 Step 8
                fg_point(X, Y)
            Next Y
        Next X

        Blit()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Lines_Click()                                                             *
    '                                                                            *
    '  Draw a pattern of solid lines.                                            *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuLines_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuLines.Click
        Dim X, Y As Integer
        Dim I, X1, X2, Y1 As Integer
        Dim LineColor() As Integer = {12, 11, 19, 21, 21, 19, 11, 12}

        fg_setcolor(25)
        fg_fillpage()

        ' Draw horizontal lines.
        For Y = 0 To vbHeight - 1 Step 40
            For I = 0 To 7
                fg_setcolor(LineColor(I))
                Y1 = Y + 3 * I
                fg_move(0, Y1)
                fg_draw(vbWidth - 1, Y1)
            Next I
        Next Y

        ' Draw vertical lines.
        For X = 0 To vbWidth - 1 Step 60
            For I = 0 To 7
                fg_setcolor(LineColor(I))
                X1 = X + 3 * I
                fg_move(X1, 0)
                fg_draw(X1, vbHeight - 1)
            Next I
        Next X

        ' Draw red diagonal lines.
        fg_setcolor(22)
        For X1 = -640 To 639 Step 60
            X2 = X1 + vbHeight
            fg_move(X1, 0)
            fg_draw(X2, vbHeight)
        Next X1
        For X1 = 0 To 1279 Step 60
            X2 = X1 - vbHeight
            fg_move(X1, 0)
            fg_draw(X2, vbHeight)
        Next X1

        Blit()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Rectangles_Click()                                                        *
    '                                                                            *
    '  Draw a grid of filled rectangles.                                         *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuRectangles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuRectangles.Click
        Dim I, J As Integer
        Dim Color As Integer
        Dim X1, X2, Y1, Y2 As Integer
        Dim xInc, yInc As Integer

        X1 = 0
        xInc = vbWidth \ 10
        X2 = xInc - 1
        Y1 = 0
        yInc = vbHeight \ 10
        Y2 = yInc - 1
        Color = 10

        ' Draw 100 filled rectangles (10 rows of 10).
        For I = 1 To 10
            For J = 1 To 10
                fg_setcolor(Color)
                fg_rect(X1, X2, Y1, Y2)
                Color += 1
                If (Color > 24) Then Color = 10
                X1 += xInc
                X2 += xInc
            Next J
            X1 = 0
            X2 = xInc - 1
            Y1 += yInc
            Y2 += yInc
        Next I

        Blit()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Circles_Click()                                                           *
    '                                                                            *
    '  Draw a series of concentric circles.                                      *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuCircles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuCircles.Click
        Dim I, Radius As Integer

        fg_setcolor(11)
        fg_fillpage()

        ' Draw 25 concentric circles at the center of the virtual buffer.
        fg_move(vbWidth \ 2, vbHeight \ 2)
        Radius = 4
        fg_setcolor(25)
        For I = 1 To 25
            fg_circle(Radius)
            Radius += 8
        Next I

        Blit()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Ellipses_Click()                                                          *
    '                                                                            *
    '  Draw a series of concentric ellipses.                                     *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuEllipses_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuEllipses.Click
        Dim I As Integer
        Dim Horiz, Vert As Integer

        fg_setcolor(11)
        fg_fillpage()

        ' Draw 80 concentric ellipses at the center of the virtual buffer.
        fg_move(vbWidth \ 2, vbHeight \ 2)
        Horiz = 4
        Vert = 1
        fg_setcolor(25)
        For I = 1 To 80
            fg_ellipse(Horiz, Vert)
            Horiz += 3
            Vert += 1
        Next I

        Blit()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Polygons_Click()                                                          *
    '                                                                            *
    '  Draw a grid of filled polygons.                                           *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuPolygons_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuPolygons.Click
        Dim I, J As Integer
        Dim xyDarkBlue() As Integer = {0, 16, 24, 0, 24, 40, 0, 56}
        Dim xyLightBlue() As Integer = {24, 0, 72, 0, 72, 40, 24, 40}
        Dim xyGreen() As Integer = {0, 56, 24, 40, 72, 40, 48, 56}

        fg_setcolor(25)
        fg_fillpage()

        ' Draw 225 filled polygons (15 rows of 15).
        For J = 0 To 14
            For I = 0 To 14
                fg_polyoff(I * 72 - J * 24, J * 56 - I * 16)
                fg_setcolor(11)
                fg_polyfill(xyDarkBlue(0), 0, 4)
                fg_setcolor(19)
                fg_polyfill(xyLightBlue(0), 0, 4)
                fg_setcolor(20)
                fg_polyfill(xyGreen(0), 0, 4)
            Next I
        Next J

        Blit()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Paint_Click()                                                             *
    '                                                                            *
    '  Demonstrate region fill.                                                  *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuPaint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuPaint.Click
        Dim X1, X2, Y1, Y2 As Integer

        fg_setcolor(25)
        fg_fillpage()

        ' Draw a rectangle.
        X1 = 40
        X2 = vbWidth - 40
        Y1 = 20
        Y2 = vbHeight - 20
        fg_setcolor(21)
        fg_rect(X1, X2, Y1, Y2)

        ' Outline the rectangle.
        fg_setcolor(10)
        fg_box(X1, X2, Y1, Y2)

        ' Draw the circle.
        X1 = vbWidth \ 2
        Y1 = vbHeight \ 2
        fg_move(X1, Y1)
        fg_circle(80)

        ' Draw cross bars in the circle.
        fg_move(X1, Y1 - 80)
        fg_draw(X1, Y1 + 80)
        fg_move(X1 - 80, Y1)
        fg_draw(X1 + 80, Y1)

        ' Paint each quarter of the circle.
        fg_setcolor(11)
        fg_paint(X1 - 6, Y1 - 6)
        fg_setcolor(12)
        fg_paint(X1 + 6, Y1 + 6)
        fg_setcolor(13)
        fg_paint(X1 + 6, Y1 - 6)
        fg_setcolor(14)
        fg_paint(X1 - 6, Y1 + 6)

        ' Paint the area outside the box.
        fg_setcolor(24)
        fg_paint(41, 21)

        Blit()
    End Sub

    '*****************************************************************************

    Private Sub menuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuExit.Click
        Me.Close()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Blit()                                                                    *
    '                                                                            *
    '  Use fg_vbpaste() or fg_vbscale() to display the virtual buffer contents   *
    '  in the client area, depending on the size of the client window.           *
    '                                                                            *
    '*****************************************************************************

    Private Sub Blit()
        ' Window larger than 640x480.
        If cxClient > vbWidth Or cyClient > vbHeight Then
            fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)

            ' Window 640x480 or smaller.
        Else
            fg_vbpaste(0, vbWidth - 1, 0, vbHeight - 1, 0, cyClient - 1)
        End If
    End Sub
End Class
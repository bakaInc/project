// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "Graphix.h"

#include "ChildView.h"
#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
}

CChildView::~CChildView()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BEGIN_MESSAGE_MAP(CChildView, CWnd)
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_COMMAND(IDM_Circles, CirclesClick)
	ON_COMMAND(IDM_Ellipses, EllipsesClick)
	ON_COMMAND(IDM_Lines, LinesClick)
	ON_COMMAND(IDM_Paint, PaintClick)
	ON_COMMAND(IDM_Points, PointsClick)
	ON_COMMAND(IDM_Polygons, PolygonsClick)
	ON_COMMAND(IDM_Rectangles, RectanglesClick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

BOOL CChildView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL bRet = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		m_hVB = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		fg_setcolor(25);
		fg_fillpage();
	}
	return bRet;
}

void CChildView::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	Blit();
}

void CChildView::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CChildView::OnSetFocus(CWnd* pOldWnd)
{
	CWnd::OnSetFocus(pOldWnd);
	fg_realize(m_hPal);
	Invalidate();
}

/****************************************************************************\
*                                                                            *
*  Blit()                                                                    *
*                                                                            *
*  Use fg_vbpaste() or fg_vbscale() to display the virtual buffer contents   *
*  in the client area, depending on the size of the client window.           *
*                                                                            *
\****************************************************************************/

void CChildView::Blit()
{
	if (m_cxClient > vbWidth || m_cyClient > vbHeight)   // window larger than 640x480
		fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
	else
		fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,m_cyClient-1);
}

/****************************************************************************\
*                                                                            *
*  CirclesClick()                                                            *
*                                                                            *
*  Draw a series of concentric circles.                                      *
*                                                                            *
\****************************************************************************/

void CChildView::CirclesClick()
{
	register int i, Radius;

	fg_setcolor(11);
	fg_fillpage();

	// draw 25 concentric circles at the center of the virtual buffer
	fg_move(vbWidth/2,vbHeight/2);
	Radius = 4;
	fg_setcolor(25);
	for (i = 0; i < 25; i++)
	{
		fg_circle(Radius);
		Radius += 8;
	}

	Blit();
}

/****************************************************************************\
*                                                                            *
*  EllipsesClick()                                                           *
*                                                                            *
*  Draw a series of concentric ellipses.                                     *
*                                                                            *
\****************************************************************************/

void CChildView::EllipsesClick()
{
	register int i;
	int Horiz, Vert;

	fg_setcolor(11);
	fg_fillpage();

	// draw 80 concentric ellipses at the center of the virtual buffer

	fg_move(vbWidth/2,vbHeight/2);
	Horiz = 4;
	Vert  = 1;
	fg_setcolor(25);
	for (i = 0; i < 80; i++)
	{
		fg_ellipse(Horiz,Vert);
		Horiz += 3;
		Vert++;
	}

	Blit();
}

/****************************************************************************\
*                                                                            *
*  LinesClick()                                                              *
*                                                                            *
*  Draw a pattern of solid lines.                                            *
*                                                                            *
\****************************************************************************/

void CChildView::LinesClick()
{
	register int x, y;
	int i, x1, x2, y1;
	static int LineColor[] = {12,11,19,21,21,19,11,12};

	fg_setcolor(25);
	fg_fillpage();

	// draw horizontal lines
	for (y = 0; y < vbHeight; y+=40)
	{
		for (i = 0; i < 8; i++)
		{
			fg_setcolor(LineColor[i]);
			y1 = y + 3*i;
			fg_move(0,y1);
			fg_draw(vbWidth-1,y1);
		}
	}

	// draw vertical lines
	for (x = 0; x < vbWidth; x+=60)
	{
		for (i = 0; i < 8; i++)
		{
			fg_setcolor(LineColor[i]);
			x1 = x + 3*i;
			fg_move(x1,0);
			fg_draw(x1,vbHeight-1);
		}
	}

	// draw red diagonal lines
	fg_setcolor(22);
	for (x1 = -640; x1 < 640; x1+=60)
	{
		x2 = x1 + vbHeight;
		fg_move(x1,0);
		fg_draw(x2,vbHeight);
	}
	for (x1 = 0; x1 < 1280; x1+=60)
	{
		x2 = x1 - vbHeight;
		fg_move(x1,0);
		fg_draw(x2,vbHeight);
	}

	Blit();
}

/****************************************************************************\
*                                                                            *
*  PaintClick()                                                              *
*                                                                            *
*  Demonstrate region fill.                                                  *
*                                                                            *
\****************************************************************************/

void CChildView::PaintClick()
{
	int x1, x2, y1, y2;

	fg_setcolor(25);
	fg_fillpage();

	// draw a rectangle
	x1 = 40;
	x2 = vbWidth - 40;
	y1 = 20;
	y2 = vbHeight - 20;
	fg_setcolor(21);
	fg_rect(x1,x2,y1,y2);

	// outline the rectangle
	fg_setcolor(10);
	fg_box(x1,x2,y1,y2);

	// draw the circle
	x1 = vbWidth / 2;
	y1 = vbHeight / 2;
	fg_move(x1,y1);
	fg_circle(80);

	// draw cross bars in the circle
	fg_move(x1,y1-80);
	fg_draw(x1,y1+80);
	fg_move(x1-80,y1);
	fg_draw(x1+80,y1);

	// paint each quarter of the circle
	fg_setcolor(11);
	fg_paint(x1-6,y1-6);
	fg_setcolor(12);
	fg_paint(x1+6,y1+6);
	fg_setcolor(13);
	fg_paint(x1+6,y1-6);
	fg_setcolor(14);
	fg_paint(x1-6,y1+6);

	// paint the area outside the box
	fg_setcolor(24);
	fg_paint(41,21);

	Blit();
}

/****************************************************************************\
*                                                                            *
*  PointsClick()                                                             *
*                                                                            *
*  Draw a pattern of points.                                                 *
*                                                                            *
\****************************************************************************/

void CChildView::PointsClick()
{
	register int x, y;

	// fill the virtual buffer with yellow pixels
	fg_setcolor(24);
	fg_fillpage();

	// draw the patterns of points
	fg_setcolor(19);
	for (x = 7; x < vbWidth; x+=20)
		for (y = 0; y < vbHeight; y+=8)
			fg_point(x,y);
	fg_setcolor(22);
	for (x = 17; x < vbWidth; x+=20)
		for (y = 4; y < vbHeight; y+=8)
			fg_point(x,y);

	Blit();
}

/****************************************************************************\
*                                                                            *
*  PolygonsClick()                                                           *
*                                                                            *
*  Draw a grid of filled polygons.                                           *
*                                                                            *
\****************************************************************************/

void CChildView::PolygonsClick()
{
	register int i, j;

	static int xyDarkBlue[]  = {0,16, 24,0, 24,40, 0,56};
	static int xyLightBlue[] = {24,0, 72,0, 72,40, 24,40};
	static int xyGreen[]     = {0,56, 24,40, 72,40, 48,56};

	fg_setcolor(25);
	fg_fillpage();

	// draw 225 filled polygons (15 rows of 15)
	for (j = 0; j < 15; j++)
	{
		for (i = 0; i < 15; i++)
		{
			fg_polyoff(i*72-j*24,j*56-i*16);
			fg_setcolor(11);
			fg_polyfill(xyDarkBlue,NULL,4);
			fg_setcolor(19);
			fg_polyfill(xyLightBlue,NULL,4);
			fg_setcolor(20);
			fg_polyfill(xyGreen,NULL,4);
		}
	}

	Blit();
}

/****************************************************************************\
*                                                                            *
*  RectanglesClick()                                                         *
*                                                                            *
*  Draw a grid of filled rectangles.                                         *
*                                                                            *
\****************************************************************************/

void CChildView::RectanglesClick()
{
	register int i, j;
	int Color;
	int x1, x2, y1, y2;
	int xInc, yInc;

	x1 = 0;
	xInc = vbWidth / 10;
	x2 = xInc - 1;
	y1 = 0;
	yInc = vbHeight / 10;
	y2 = yInc - 1;
	Color = 10;

	// draw 100 filled rectangles (10 rows of 10)
	for (i = 0; i < 10; i++)
	{
		for (j = 0; j < 10; j++)
		{
			fg_setcolor(Color);
			fg_rect(x1,x2,y1,y2);
			Color++;
			if (Color > 24) Color = 10;
			x1 += xInc;
			x2 += xInc;
		}
		x1 = 0;
		x2 = xInc - 1;
		y1 += yInc;
		y2 += yInc;
	}

	Blit();
}

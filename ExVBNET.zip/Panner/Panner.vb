'*****************************************************************************
'                                                                            *
'  Panner.vb                                                                 *
'                                                                            *
'  This program shows how to pan the contents of a virtual buffer through    *
'  a smaller window.                                                         *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 640
    Const vbHeight As Integer = 480

    ' Application variables.
    Dim X, Y As Integer
    Dim xLimit, yLimit As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuLeft As System.Windows.Forms.MenuItem
    Friend WithEvents menuRight As System.Windows.Forms.MenuItem
    Friend WithEvents menuUp As System.Windows.Forms.MenuItem
    Friend WithEvents menuDown As System.Windows.Forms.MenuItem
    Friend WithEvents menuReset As System.Windows.Forms.MenuItem
    Friend WithEvents menuExit As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.menuLeft = New System.Windows.Forms.MenuItem()
        Me.menuRight = New System.Windows.Forms.MenuItem()
        Me.menuUp = New System.Windows.Forms.MenuItem()
        Me.menuDown = New System.Windows.Forms.MenuItem()
        Me.menuReset = New System.Windows.Forms.MenuItem()
        Me.menuExit = New System.Windows.Forms.MenuItem()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuLeft, Me.menuRight, Me.menuUp, Me.menuDown, Me.menuReset, Me.menuExit})
        '
        'menuLeft
        '
        Me.menuLeft.Enabled = False
        Me.menuLeft.Index = 0
        Me.menuLeft.Text = "&Left"
        '
        'menuRight
        '
        Me.menuRight.Index = 1
        Me.menuRight.Text = "&Right"
        '
        'menuUp
        '
        Me.menuUp.Enabled = False
        Me.menuUp.Index = 2
        Me.menuUp.Text = "&Up"
        '
        'menuDown
        '
        Me.menuDown.Index = 3
        Me.menuDown.Text = "&Down"
        '
        'menuReset
        '
        Me.menuReset.Index = 4
        Me.menuReset.Text = "R&eset"
        '
        'menuExit
        '
        Me.menuExit.Index = 5
        Me.menuExit.Text = "E&xit"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Panning Demo"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        fg_showbmp("PORCH.BMP", 0)
        X = 0
        Y = 0
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        If cxClient < vbWidth Then
            xLimit = vbWidth - cxClient
            If X > 0 Then menuLeft.Enabled = True
            If X < xLimit Then menuRight.Enabled = True
        Else
            xLimit = 0
            menuLeft.Enabled = False
            menuRight.Enabled = False
        End If
        If cyClient < vbHeight Then
            yLimit = vbHeight - cyClient
            If Y > 0 Then menuUp.Enabled = True
            If Y < yLimit Then menuDown.Enabled = True
        Else
            yLimit = 0
            menuUp.Enabled = False
            menuDown.Enabled = False
        End If
        fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub menuLeft_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuLeft.Click
        If X = xLimit Then menuRight.Enabled = True
        X -= 1
        fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
        If X = 0 Then menuLeft.Enabled = False
    End Sub

    Private Sub menuRight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuRight.Click
        If X = 0 Then menuLeft.Enabled = True
        X += 1
        fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
        If X = xLimit Then menuRight.Enabled = False
    End Sub

    Private Sub menuUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuUp.Click
        If Y = yLimit Then menuDown.Enabled = True
        Y -= 1
        fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
        If Y = 0 Then menuUp.Enabled = False
    End Sub

    Private Sub menuDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuDown.Click
        If Y = 0 Then menuUp.Enabled = True
        Y += 1
        fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
        If Y = yLimit Then menuDown.Enabled = False
    End Sub

    Private Sub menuReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuReset.Click
        X = 0
        Y = 0
        fg_vbpaste(0, vbWidth - 1, 0, vbHeight - 1, 0, vbHeight - 1)
        If xLimit > 0 Then menuRight.Enabled = True
        If yLimit > 0 Then menuDown.Enabled = True
        menuLeft.Enabled = False
        menuUp.Enabled = False
    End Sub

    Private Sub menuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuExit.Click
        Me.Close()
    End Sub
End Class
/****************************************************************************\
*                                                                            *
*  Strings1.cpp                                                              *
*                                                                            *
*  This program shows how to display strings in the client area.             *
*                                                                            *
\****************************************************************************/

// Strings1.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Strings1.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStrings1App

BEGIN_MESSAGE_MAP(CStrings1App, CWinApp)
	//{{AFX_MSG_MAP(CStrings1App)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStrings1App construction

CStrings1App::CStrings1App()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CStrings1App object

CStrings1App theApp;

/////////////////////////////////////////////////////////////////////////////
// CStrings1App initialization

BOOL CStrings1App::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Display Strings in Client Area"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CStrings1App message handlers

/****************************************************************************\
*                                                                            *
*  SWchars.c                                                                 *
*                                                                            *
*  This program displays all characters in the Fastgraph for Windows primary *
*  and alternate software fonts.                                             *
*                                                                            *
\****************************************************************************/

#include <fgwin.h>

#define vbWidth  640
#define vbHeight 480

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGswchars";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor (NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindow(szAppName, // window class name
      "Software Character Set",   // window caption
      WS_OVERLAPPEDWINDOW,        // window style
      CW_USEDEFAULT,              // initial x position
      CW_USEDEFAULT,              // initial y position
      vbWidth,                    // initial x size
      vbHeight,                   // initial y size
      NULL,                       // parent window handle
      NULL,                       // window menu handle
      hInstance,                  // program instance handle
      NULL);                      // creation parameters

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   while (GetMessage(&msg,NULL,0,0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HDC      hDC;
HPALETTE hPal;
int      hVB;
int      xDest, yDest;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch (iMsg)
   {
      case WM_CREATE:
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);

         fg_vbinit();
         hVB = fg_vballoc(vbWidth,vbHeight);
         fg_vbopen(hVB);
         fg_vbcolors();

         fg_initw();
         fg_setworld(0.0,6.39,0.0,4.79);
         fg_setsizew(0.2);

         fg_setcolor(25);
         fg_fillpage();
         fg_setcolor(19);
         fg_movew(3.2,4.2);
         fg_swchar("Software characters - font 1",28,0);
         fg_setcolor(10);
         fg_movew(0.5,3.9);
         fg_swchar("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,-1);
         fg_movew(0.5,3.6);
         fg_swchar("abcdefghijklmnopqrstuvwxyz",26,-1);
         fg_movew(0.5,3.3);
         fg_swchar("0123456789",10,-1);
         fg_movew(0.5,3.0);
         fg_swchar("!\"#$%&'()*+,-./:;<=>?[]^`{|}~",29,-1);

         fg_setcolor(19);
         fg_movew(3.2,2.5);
         fg_swchar("Software characters - font 2",28,0);
         fg_setcolor(10);
         fg_movew(0.5,2.2);
         fg_swchar("\\ABCDEFGHIJKLMNOPRSTUWXYZ",25,-1);
         fg_movew(0.5,1.9);
         fg_swchar("\\abcdefghijklmnoprstuwxyz",25,-1);
         fg_movew(0.5,1.3);
         fg_swchar("\\012345678#$%&()*+/<=>?[]{}",27,-1);

         fg_setratio(1.2);
         fg_movew(0.5,0.6);
         fg_swchar("cos\\^2\\h\\+sin\\^2\\h\\=1",21,-1);

         fg_movew(5.9,0.6);
         fg_swchar("H\\v2O U\\v2\\v3\\v2",16,1);

         fg_setratio(1.0);
         fg_movew(3.2,0.2);
         fg_swchar("One _word_ is underlined.",25,0);

         fg_setcolor(19);
         fg_movew(0.0,2.8);
         fg_draww(6.39,2.8);
         fg_movew(0.0,0.9);
         fg_draww(6.39,0.9);
         return 0;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
         fg_vbpaste(0,vbWidth-1,0,vbHeight-1,xDest,yDest);
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,TRUE);
         return 0;

      case WM_SIZE:
         xDest = ((int)LOWORD(lParam) - vbWidth) / 2;
         yDest = ((int)HIWORD(lParam) - vbHeight) / 2;
         if (xDest < 0) xDest = 0;
         if (yDest < 0) yDest = 0;
         yDest = ((int)HIWORD(lParam)-1) - yDest;
         return 0;

      case WM_DESTROY:
         fg_vbclose();
         fg_vbfree(hVB);
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

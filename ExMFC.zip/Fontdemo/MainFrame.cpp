// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Fontdemo.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hFont = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
}

CMainFrame::~CMainFrame()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hFont)
	{
		DeleteObject(m_hFont);
		m_hFont = NULL;
	}
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	LOGFONT lf;

	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		m_hVB = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		fg_setcolor(24);
		fg_fillpage();

		lf.lfHeight = 24;                // character height in pixels
		lf.lfWidth = 0;                  // default character width
		lf.lfEscapement = 0;             // orientation of next character
		lf.lfOrientation = 0;            // orientation of first character
		lf.lfWeight = FW_NORMAL;         // normal thickness
		lf.lfItalic = FALSE;             // not italic characters
		lf.lfUnderline = FALSE;          // not underlined characters
		lf.lfStrikeOut = FALSE;          // not strikeout characters
		lf.lfCharSet = ANSI_CHARSET;     // ANSI character set
		lf.lfOutPrecision = 0;           // default output precision
		lf.lfClipPrecision = 0;          // default clipping precision
		lf.lfQuality = DEFAULT_QUALITY;  // default scaling quality
		lf.lfPitchAndFamily = 0;         // default pitch and font family
		lstrcpy(lf.lfFaceName,"Arial");  // Arial typeface
		m_hFont = CreateFontIndirect(&lf);
	}
	return bRet;
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
	DrawStrings();
}

void CMainFrame::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

void CMainFrame::DrawStrings()
{
	register int x;

	fg_setcolor(19);
	x = fg_xclient(20);

	fg_move(x,fg_yclient(20));
	fg_fontload(10);
	fg_print("OEM fixed font",14);

	fg_move(x,fg_yclient(40));
	fg_fontload(11);
	fg_print("ANSI fixed font",15);

	fg_move(x,fg_yclient(60));
	fg_fontload(12);
	fg_print("ANSI var font",13);

	fg_move(x,fg_yclient(80));
	fg_fontload(13);
	fg_print("system font",11);

	fg_move(x,fg_yclient(100));
	fg_fontload(14);
	fg_print("device default font",19);

	fg_move(x,fg_yclient(120));
	fg_fontload(16);
	fg_print("system fixed font",17);

	fg_move(x,fg_yclient(160));
	fg_logfont(m_hFont);
	fg_print("Arial 24 font",13);
}
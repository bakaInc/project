// MainFrame.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRAME_H__B9D62A07_F4FD_11D3_B530_DB1186611A4A__INCLUDED_)
#define AFX_MAINFRAME_H__B9D62A07_F4FD_11D3_B530_DB1186611A4A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define RENDER_STATE (FG_PERSPECTIVE_TM | FG_ZBUFFER | FG_ZCLIP)

// define DIRECTX if creating a DirectDraw or Direct3D application
// if you change this definition, also change the library #pragma in StdAfx.h
#define DIRECTX

// define the flag bits for fg_ddsetup()
// specify FG_DX_FLIP for a Direct3D application
// specify FG_DX_RENDER_HW or FG_DX_RENDER_SW for a Direct3D application
// specify FG_DX_ZBUFFER only if FG_ZBUFFER is defined in RENDER_STATE
#define DIRECTX_FLAGS (FG_DX_FLIP | FG_DX_RENDER_HW | FG_DX_ZBUFFER)

#define vbWidth  640
#define vbHeight 480
#define vbDepth  16

#define tmWidth  64

class CMainFrame : public CFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

//Attributes
protected:
	HDC m_hDC;
	HPALETTE m_hPal;
	int m_hVB;
	int m_hZB;
	int m_hTM[6];
// Operations
public:
	void CheckForMovement(BOOL);
	void DrawCube();
	void ShowCube();
	BOOL m_bAppIsActive;
	BOOL m_bAppIsReady;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	afx_msg BOOL OnQueryNewPalette();
	afx_msg void OnPaletteChanged(CWnd* pFocusWnd);
	afx_msg void OnActivateApp(BOOL bActive, HTASK hTask);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRAME_H__B9D62A07_F4FD_11D3_B530_DB1186611A4A__INCLUDED_)

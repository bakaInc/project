// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Tunnel.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

typedef struct point3d
{
	double x;
	double y;
	double z;
} POINT3D;

// four sides of a 20x40x100 tunnel, defined in 3D world coordinates
POINT3D Floor[] = {
	{-10.0, 0.0,100.0},
	{-10.0, 0.0,200.0},
	{ 10.0, 0.0,200.0},
	{ 10.0, 0.0,100.0}
};
POINT3D WestSide[] = {
	{-10.0,  0.0,100.0},
	{-10.0, 40.0,100.0},
	{-10.0, 40.0,200.0},
	{-10.0,  0.0,200.0}
};
POINT3D EastSide[] = {
	{ 10.0,  0.0,100.0},
	{ 10.0,  0.0,200.0},
	{ 10.0, 40.0,200.0},
	{ 10.0, 40.0,100.0}
};
POINT3D Ceiling[] = {
	{-10.0, 40.0,100.0},
	{ 10.0, 40.0,100.0},
	{ 10.0, 40.0,200.0},
	{-10.0, 40.0,200.0}
};

// RGB color values at each vertex of each side
BYTE FloorRGB[]    = {192,192,192,  64, 64, 64,  64, 64, 64, 192,192,192};
BYTE WestSideRGB[] = { 32, 32,255,  32, 32,255,  32, 32, 96,  32, 32, 96};
BYTE EastSideRGB[] = { 32, 32,255,  32, 32, 96,  32, 32, 96,  32, 32,255};
BYTE CeilingRGB[]  = {192,192,192, 192,192,192,  64, 64, 64,  64, 64, 64};

// for convenience, an array of pointers to each of the four sides
POINT3D *Faces[] = {Floor,WestSide,EastSide,Ceiling};

// a similar array of pointers to each side's RGB values
BYTE *FacesRGB[] = {FloorRGB,WestSideRGB,EastSideRGB,CeilingRGB};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_PAINT()
	ON_WM_ACTIVATEAPP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
	m_hZB = -1;
	m_bAppIsActive = FALSE;
}

CMainFrame::~CMainFrame()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	if (m_hZB >= 0)
	{
		fg_zbfree(m_hZB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	int vbDepth;
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		vbDepth = fg_colors();
		if (vbDepth < 16) vbDepth = 16;
		fg_vbdepth(vbDepth);
		m_hVB = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		m_hZB = fg_zballoc(vbWidth,vbHeight);
		fg_zbopen(m_hZB);

		fg_setcolor(-1);
		fg_fillpage();

		fg_3Dviewport(0,vbWidth-1,0,vbHeight-1,1.0);
		fg_3Drenderstate(FG_ZBUFFER | FG_ZCLIP);
		fg_3Dlookat(0.0,10.0,50.0,0.0,10.0,100.0);

		m_bAppIsActive = TRUE;
	}
	return bRet;
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CMainFrame::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

void CMainFrame::OnActivateApp(BOOL bActive, HTASK hTask)
{
	CFrameWnd::OnActivateApp(bActive, hTask);
	m_bAppIsActive = bActive;
}

/****************************************************************************\
*                                                                            *
*  CheckForMovement()                                                        *
*                                                                            *
*  The CheckForMovement() function checks for key presses that control the   *
*  user's movement, and if required redraws the tunnel viewed from the new   *
*  camera position. It is called from the WinMain() message loop when there  *
*  are no messages waiting.                                                  *
*                                                                            *
\****************************************************************************/

void CMainFrame::CheckForMovement()
{
	static BOOL Redraw = TRUE;

	// up arrow moves viewer forward
	if (fg_kbtest(72))
	{
		fg_3Dmoveforward(2.0);
		Redraw = TRUE;
	}

	// down arrow moves viewer backward
	else if (fg_kbtest(80))
	{
		fg_3Dmoveforward(-2.0);
		Redraw = TRUE;
	}

	// right arrow turns viewer to the right
	else if (fg_kbtest(77))
	{
		fg_3Drotateright(6*10);
		Redraw = TRUE;
	}

	// left arrow turns viewer to the left
	else if (fg_kbtest(75))
	{
		fg_3Drotateright(-6*10);
		Redraw = TRUE;
	}

	// if the viewer's position or rotation changed, redraw the tunnel
	if (Redraw)
	{
		// prepare the z-buffer for the next frame
		fg_zbframe();

		// erase the previous frame from the virtual buffer
		fg_setcolor(-1);
		fg_fillpage();

		// draw the tunnel
		DrawTunnel();

		// display what we just drew
		fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
		Redraw = FALSE;
	}
}

/****************************************************************************\
*                                                                            *
*  DrawTunnel()                                                              *
*                                                                            *
*  Draws each of the tunnel's four sides in 3D world space.                  *
*                                                                            *
\****************************************************************************/

void CMainFrame::DrawTunnel()
{
	register int i;

	for (i = 0; i < 4; i++)
	{
		fg_3Dshade((double *)Faces[i],(char *)FacesRGB[i],4);
	}
}

/****************************************************************************\
*                                                                            *
*  Blend.cpp                                                                 *
*  BlendU.cpp                                                                *
*                                                                            *
*  This program illustrates some of the Fastgraph for Windows alpha blending *
*  functions.                                                                *
*                                                                            *
*  Press F1 to view the foreground image.                                    *
*  Press F2 to view the background image.                                    *
*  Press F3 to create and view a 50% blended image.                          *
*  Press F4 to create and view a variable blended image.                     *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "BlendU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   fg_vbdepth(vbDepth);
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   // get background image from the CAT.BMP file
   fg_showbmp("CAT.BMP",0);
   fg_move(0,vbHeight-1);
   fg_getdcb(Background,vbWidth,vbHeight);

   // get foreground image from the PORCH.BMP file
   fg_showbmp("PORCH.BMP",0);
   fg_move(0,vbHeight-1);
   fg_getdcb(Foreground,vbWidth,vbHeight);

   // calcluate variable opacity bitmap
   MakeOpacityBitmap();

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
	TShiftState Shift)
{
   switch (Key)
   {
      // display foreground image
      case VK_F1:
        fg_move(0,vbHeight-1);
        fg_putdcb(Foreground,vbWidth,vbHeight);
        fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
        Caption = "Alpha Blending: Foreground Image";
        break;

      // display background image
      case VK_F2:
        fg_move(0,vbHeight-1);
        fg_putdcb(Background,vbWidth,vbHeight);
        fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
        Caption = "Alpha Blending: Background Image";
        break;

      // display blended image with constant 50% foreground opacity
      case VK_F3:
        Cursor = crHourGlass;
        fg_opacity(128);
        fg_blenddcb(Foreground,Background,Blended,vbWidth*vbHeight);
        fg_move(0,vbHeight-1);
        fg_putdcb(Blended,vbWidth,vbHeight);
        fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
        Caption = "Alpha Blending: 50% Blended Image";
        Cursor = crDefault;
        break;

      // display blended image with variable foreground opacity
      case VK_F4:
        Cursor = crHourGlass;
        fg_blendvar(Foreground,Background,Opacity,Blended,vbWidth*vbHeight);
        fg_move(0,vbHeight-1);
        fg_putdcb(Blended,vbWidth,vbHeight);
        fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
        Caption = "Alpha Blending: Variable Blended Image";
        Cursor = crDefault;
        break;
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}

/****************************************************************************\
*                                                                            *
*  MakeOpacityBitmap()                                                       *
*                                                                            *
*  Define a 256-color bitmap with varying opacity values. The foregound      *
*  opacities will be zero at the image center and will gradually increase    *
*  as we move farther from the center.                                       *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::MakeOpacityBitmap()
{
   register int i, x, y;
   int OpacityValue;
   int yTerm;

   i = 0;

   for (y = 0; y < vbHeight; y++)
   {
      yTerm = abs(y - vbHeight/2);
      for (x = 0; x < vbWidth; x++)
      {
        OpacityValue = abs(x - vbWidth/2) + yTerm;
        if (OpacityValue > 255)
           Opacity[i++] = 255;
        else
           Opacity[i++] = (byte)OpacityValue;
      }
   }
}

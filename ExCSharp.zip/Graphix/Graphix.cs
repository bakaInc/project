/****************************************************************************\
*                                                                            *
*  Graphix.cs                                                                *
*                                                                            *
*  This program demonstrates some of the Fastgraph for Windows graphics      *
*  primitive functions.                                                      *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Graphix
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		const int vbWidth = 640;
		const int vbHeight = 480;

		// Component declarations.
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuPoints;
		private System.Windows.Forms.MenuItem menuLines;
		private System.Windows.Forms.MenuItem menuRectangles;
		private System.Windows.Forms.MenuItem menuCircles;
		private System.Windows.Forms.MenuItem menuElllipses;
		private System.Windows.Forms.MenuItem menuPolygons;
		private System.Windows.Forms.MenuItem menuPaint;
		private System.Windows.Forms.MenuItem menuExit;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuPoints = new System.Windows.Forms.MenuItem();
			this.menuLines = new System.Windows.Forms.MenuItem();
			this.menuRectangles = new System.Windows.Forms.MenuItem();
			this.menuCircles = new System.Windows.Forms.MenuItem();
			this.menuElllipses = new System.Windows.Forms.MenuItem();
			this.menuPolygons = new System.Windows.Forms.MenuItem();
			this.menuPaint = new System.Windows.Forms.MenuItem();
			this.menuExit = new System.Windows.Forms.MenuItem();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuPoints,
																					  this.menuLines,
																					  this.menuRectangles,
																					  this.menuCircles,
																					  this.menuElllipses,
																					  this.menuPolygons,
																					  this.menuPaint,
																					  this.menuExit});
			// 
			// menuPoints
			// 
			this.menuPoints.Index = 0;
			this.menuPoints.Text = "&Points";
			this.menuPoints.Click += new System.EventHandler(this.menuPoints_Click);
			// 
			// menuLines
			// 
			this.menuLines.Index = 1;
			this.menuLines.Text = "&Lines";
			this.menuLines.Click += new System.EventHandler(this.menuLines_Click);
			// 
			// menuRectangles
			// 
			this.menuRectangles.Index = 2;
			this.menuRectangles.Text = "&Rectangles";
			this.menuRectangles.Click += new System.EventHandler(this.menuRectangles_Click);
			// 
			// menuCircles
			// 
			this.menuCircles.Index = 3;
			this.menuCircles.Text = "&Circles";
			this.menuCircles.Click += new System.EventHandler(this.menuCircles_Click);
			// 
			// menuElllipses
			// 
			this.menuElllipses.Index = 4;
			this.menuElllipses.Text = "&Ellipses";
			this.menuElllipses.Click += new System.EventHandler(this.menuElllipses_Click);
			// 
			// menuPolygons
			// 
			this.menuPolygons.Index = 5;
			this.menuPolygons.Text = "P&olygons";
			this.menuPolygons.Click += new System.EventHandler(this.menuPolygons_Click);
			// 
			// menuPaint
			// 
			this.menuPaint.Index = 6;
			this.menuPaint.Text = "P&aint";
			this.menuPaint.Click += new System.EventHandler(this.menuPaint_Click);
			// 
			// menuExit
			// 
			this.menuExit.Index = 7;
			this.menuExit.Text = "E&xit";
			this.menuExit.Click += new System.EventHandler(this.menuExit_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(632, 433);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Graphics Primitives";
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Closed += new System.EventHandler(this.Form1_Closed);
		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();

			fg.setcolor(25);
			fg.fillpage();
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Blit();
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Blit();
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		/****************************************************************************\
		*                                                                            *
		*  Points_Click()                                                            *
		*                                                                            *
		*  Draw a pattern of points.                                                 *
		*                                                                            *
		\****************************************************************************/

		private void menuPoints_Click(object sender, System.EventArgs e)
		{
			int x, y;

			// Fill the virtual buffer with yellow pixels.
			fg.setcolor(24);
			fg.fillpage();

			// Draw the patterns of points.
			fg.setcolor(19);
			for (x = 7; x < vbWidth; x += 20)
			{
				for (y = 0; y < vbHeight; y += 8)
				{
					fg.point(x, y);
				}
			}

			fg.setcolor(22);
			for (x = 17; x < vbWidth; x += 20)
			{
				for (y = 4; y < vbHeight; y += 8)
				{
					fg.point(x, y);
				}
			}

			Blit();
		}

		/****************************************************************************\
		*                                                                            *
		*  Lines_Click()                                                             *
		*                                                                            *
		*  Draw a pattern of solid lines.                                            *
		*                                                                            *
		\****************************************************************************/

		private void menuLines_Click(object sender, System.EventArgs e)
		{
			int x, y;
			int i, x1, x2, y1;
			int [] LineColor = {12, 11, 19, 21, 21, 19, 11, 12};

			fg.setcolor(25);
			fg.fillpage();

			// Draw horizontal lines.
			for (y = 0; y < vbHeight; y += 40)
			{
				for (i = 0; i < 8; i++)
				{
					fg.setcolor(LineColor[i]);
					y1 = y + 3 * i;
					fg.move(0, y1);
					fg.draw(vbWidth-1, y1);
				}
			}

			// Draw vertical lines.
			for (x = 0; x < vbWidth; x += 60)
			{
				for (i = 0; i < 8; i++)
				{
					fg.setcolor(LineColor[i]);
					x1 = x + 3 * i;
					fg.move(x1, 0);
					fg.draw(x1, vbHeight-1);
				}
			}
			
			// Draw red diagonal lines.
			fg.setcolor(22);
			for (x1 = -640; x1 < 640; x1 += 60)
			{
				x2 = x1 + vbHeight;
				fg.move(x1, 0);
				fg.draw(x2, vbHeight);
			}
			for (x1 = 0; x1 < 1280; x1 += 60)
			{
				x2 = x1 - vbHeight;
				fg.move(x1, 0);
				fg.draw(x2, vbHeight);
			}

			Blit();
		}

		/****************************************************************************\
		*                                                                            *
		*  Rectangles_Click()                                                        *
		*                                                                            *
		*  Draw a grid of filled rectangles.                                         *
		*                                                                            *
		\****************************************************************************/

		private void menuRectangles_Click(object sender, System.EventArgs e)
		{
			int i, j;
			int Color;
			int x1, x2, y1, y2;
			int xInc, yInc;

			x1 = 0;
			xInc = vbWidth / 10;
			x2 = xInc - 1;
			y1 = 0;
			yInc = vbHeight / 10;
			y2 = yInc - 1;
			Color = 10;

			// Draw 100 filled rectangles (10 rows of 10).
			for (i = 0; i < 10; i++)
			{
				for (j = 0; j < 10; j++)
				{
					fg.setcolor(Color);
					fg.rect(x1, x2, y1, y2);
					Color++;
					if (Color > 24) Color = 10;
					x1 += xInc;
					x2 += xInc;
				}
				x1 = 0;
				x2 = xInc - 1;
				y1 += yInc;
				y2 += yInc;
			}

			Blit();
		}

		/****************************************************************************\
		*                                                                            *
		*  Circles_Click()                                                           *
		*                                                                            *
		*  Draw a series of concentric circles.                                      *
		*                                                                            *
		\****************************************************************************/

		private void menuCircles_Click(object sender, System.EventArgs e)
		{
			int i, Radius;

			fg.setcolor(11);
			fg.fillpage();

			// Draw 25 concentric circles at the center of the virtual buffer.
			fg.move(vbWidth / 2, vbHeight / 2);
			Radius = 4;
			fg.setcolor(25);
			for (i = 0; i < 25; i++)
			{
				fg.circle(Radius);
				Radius += 8;
			}

			Blit();
		}

		/****************************************************************************\
		*                                                                            *
		*  Ellipses_Click()                                                          *
		*                                                                            *
		*  Draw a series of concentric ellipses.                                     *
		*                                                                            *
		\****************************************************************************/

		private void menuElllipses_Click(object sender, System.EventArgs e)
		{
			int i;
			int Horiz, Vert;

			fg.setcolor(11);
			fg.fillpage();

			// Draw 80 concentric ellipses at the center of the virtual buffer.
			fg.move(vbWidth / 2, vbHeight / 2);
			Horiz = 4;
			Vert = 1;
			fg.setcolor(25);
			for (i = 0; i < 80; i++)
			{
				fg.ellipse(Horiz, Vert);
				Horiz += 3;
				Vert++;
			}

			Blit();
		}

		/****************************************************************************\
		*                                                                            *
		*  Polygons_Click()                                                          *
		*                                                                            *
		*  Draw a grid of filled polygons.                                           *
		*                                                                            *
		\****************************************************************************/

		private void menuPolygons_Click(object sender, System.EventArgs e)
		{
			int i, j;
			int [] xyDarkBlue = {0, 16, 24, 0, 24, 40, 0, 56};
			int [] xyLightBlue = {24, 0, 72, 0, 72, 40, 24, 40};
			int [] xyGreen = {0, 56, 24, 40, 72, 40, 48, 56};

			fg.setcolor(25);
			fg.fillpage();

			// Draw 225 filled polygons (15 rows of 15).
			for (j = 0; j < 15; j++)
			{
				for (i = 0; i < 15; i++)
				{
					fg.polyoff(i*72 - j*24, j*56 - i*16);
					fg.setcolor(11);
					fg.polyfill(ref xyDarkBlue[0], 0, 4);
					fg.setcolor(19);
					fg.polyfill(ref xyLightBlue[0], 0, 4);
					fg.setcolor(20);
					fg.polyfill(ref xyGreen[0], 0, 4);
				}
			}

			Blit();
		}

		/****************************************************************************\
		*                                                                            *
		*  Paint_Click()                                                             *
		*                                                                            *
		*  Demonstrate region fill.                                                  *
		*                                                                            *
		\****************************************************************************/

		private void menuPaint_Click(object sender, System.EventArgs e)
		{
			int x1, x2, y1, y2;

			fg.setcolor(25);
			fg.fillpage();

			// Draw a rectangle.
			x1 = 40;
			x2 = vbWidth - 40;
			y1 = 20;
			y2 = vbHeight - 20;
			fg.setcolor(21);
			fg.rect(x1, x2, y1, y2);

			// Outline the rectangle.
			fg.setcolor(10);
			fg.box(x1, x2, y1, y2);

			// Draw the circle.
			x1 = vbWidth / 2;
			y1 = vbHeight / 2;
			fg.move(x1, y1);
			fg.circle(80);

			// Draw cross bars in the circle.
			fg.move(x1, y1-80);
			fg.draw(x1, y1+80);
			fg.move(x1-80, y1);
			fg.draw(x1+80, y1);

			// Paint each quarter of the circle.
			fg.setcolor(11);
			fg.paint(x1-6, y1-6);
			fg.setcolor(12);
			fg.paint(x1+6, y1+6);
			fg.setcolor(13);
			fg.paint(x1+6, y1-6);
			fg.setcolor(14);
			fg.paint(x1-6, y1+6);

			// Paint the area outside the box.
			fg.setcolor(24);
			fg.paint(41, 21);

			Blit();
		}

		//****************************************************************************

		private void menuExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		/****************************************************************************\
		*                                                                            *
		*  Blit()                                                                    *
		*                                                                            *
		*  Use fg.vbpaste() or fg.vbscale() to display the virtual buffer contents   *
		*  in the client area, depending on the size of the client window.           *
		*                                                                            *
		\****************************************************************************/

		private void Blit()
		{
			// Window larger than 640x480.
			if (cxClient > vbWidth || cyClient > vbHeight)
				fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);

			// Window 640x480 or smaller.
			else
				fg.vbpaste(0, vbWidth-1, 0, vbHeight-1, 0, cyClient-1);
		}
	}
}
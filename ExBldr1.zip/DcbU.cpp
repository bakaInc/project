/****************************************************************************\
*                                                                            *
*  Dcb.cpp                                                                   *
*  DcbU.cpp                                                                  *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows direct color bitmap   *
*  display functions.                                                        *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "DCBU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   fg_vbdepth(16);
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_setcolorrgb(85,255,85);
   fg_fillpage();

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ClipDCBClick(TObject *Sender)
{
   fg_fillpage();
   fg_move(-20,vbHeight/2+10);
   fg_clipdcb(Bird,40,20);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DrawDCBClick(TObject *Sender)
{
   fg_fillpage();
   fg_move(vbWidth/2-20,vbHeight/2+10);
   fg_drawdcb(Bird,40,20);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FlipDCBClick(TObject *Sender)
{
   fg_fillpage();
   fg_move(vbWidth-20,vbHeight/2+10);
   fg_flipdcb(Bird,40,20);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::PutDCBClick(TObject *Sender)
{
   fg_fillpage();
   fg_move(vbWidth/2-20,vbHeight/2+10);
   fg_putdcb(Bird,40,20);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RevDCBClick(TObject *Sender)
{
   fg_fillpage();
   fg_move(vbWidth/2-20,vbHeight/2+10);
   fg_revdcb(Bird,40,20);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
 }
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitClick(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------

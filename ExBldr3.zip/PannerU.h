//---------------------------------------------------------------------------
#ifndef PannerUH
#define PannerUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Menus.hpp>
#include <FGwin.h>

#define vbWidth  640
#define vbHeight 480
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   TMainMenu *MainMenu1;
   TMenuItem *Left;
   TMenuItem *Right;
   TMenuItem *Up;
   TMenuItem *Down;
   TMenuItem *Reset;
   TMenuItem *Exit;
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
   void __fastcall LeftClick(TObject *Sender);
   void __fastcall RightClick(TObject *Sender);
   void __fastcall UpClick(TObject *Sender);
   void __fastcall DownClick(TObject *Sender);
   void __fastcall ResetClick(TObject *Sender);
   void __fastcall ExitClick(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   UINT cxClient, cyClient;
   int x, y;
   int xLimit, yLimit;
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

/****************************************************************************\
*                                                                            *
*  Fontdemo.cpp                                                              *
*  FontdemoU.cpp                                                             *
*                                                                            *
*  This program shows how use Windows stock fonts in Fastgraph for Windows,  *
*  and also how to create and use a Windows logical font. The logical font   *
*  is a 24pt Arial font.                                                     *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "FontdemoU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_setcolor(24);
   fg_fillpage();

   lf.lfHeight = 24;                // character height in pixels
   lf.lfWidth = 0;                  // default character width
   lf.lfEscapement = 0;             // orientation of next character
   lf.lfOrientation = 0;            // orientation of first character
   lf.lfWeight = FW_NORMAL;         // normal thickness
   lf.lfItalic = False;             // not italic characters
   lf.lfUnderline = False;          // not underlined characters
   lf.lfStrikeOut = False;          // not strikeout characters
   lf.lfCharSet = ANSI_CHARSET;     // ANSI character set
   lf.lfOutPrecision = 0;           // default output precision
   lf.lfClipPrecision = 0;          // default clipping precision
   lf.lfQuality = DEFAULT_QUALITY;  // default scaling quality
   lf.lfPitchAndFamily = 0;         // default pitch and font family
   lstrcpy(lf.lfFaceName,"Arial");  // Arial typeface
   hFont = CreateFontIndirect(&lf);

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
   DrawStrings();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hFont);
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DrawStrings(void)
{
   register int x;

   fg_setcolor(19);
   x = fg_xclient(20);

   fg_move(x,fg_yclient(20));
   fg_fontload(10);
   fg_print("OEM fixed font",14);

   fg_move(x,fg_yclient(40));
   fg_fontload(11);
   fg_print("ANSI fixed font",15);

   fg_move(x,fg_yclient(60));
   fg_fontload(12);
   fg_print("ANSI var font",13);

   fg_move(x,fg_yclient(80));
   fg_fontload(13);
   fg_print("system font",11);

   fg_move(x,fg_yclient(100));
   fg_fontload(14);
   fg_print("device default font",19);

   fg_move(x,fg_yclient(120));
   fg_fontload(16);
   fg_print("system fixed font",17);

   fg_move(x,fg_yclient(160));
   fg_logfont(hFont);
   fg_print("Arial 24 font",13);
}
//---------------------------------------------------------------------------

// Tunnel.h : main header file for the TUNNEL application
//
#if !defined(AFX_TUNNEL_H__0256F10D_80A3_11D2_8EBA_204C4F4F5020__INCLUDED_)
#define AFX_TUNNEL_H__0256F10D_80A3_11D2_8EBA_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTunnelApp:
// See Tunnel.cpp for the implementation of this class
//

class CTunnelApp : public CWinApp
{
public:
	CTunnelApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTunnelApp)
	public:
	virtual BOOL InitInstance();
	virtual int Run();
	//}}AFX_VIRTUAL

// Implementation

public:
	//{{AFX_MSG(CTunnelApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TUNNEL_H__0256F10D_80A3_11D2_8EBA_204C4F4F5020__INCLUDED_)

/****************************************************************************\
*                                                                            *
*  Bitmap.cs                                                                 *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows 256-color bitmap      *
*  display functions.                                                        *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Bitmap
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		const int vbWidth = 320;
		const int vbHeight = 240;

		// 40x20 256-color bitmapped image of a bird.
		byte [] Bird = {
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0,10,10, 0,10, 0,10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0,10,25,10,17,10,17,10,10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0,10,25,25,10,17,10,17,10,25,10, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			10,25,25,25,25,10,25,10,25,25,10, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,10,10,
			10,25,25,25,25,10,25,10,25,10, 0, 0, 0, 0, 0, 0, 0,10,10, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,25,25,
			10,25,25,25,25,25,25,25,25,10, 0, 0,10,10,10,10,10,17,10, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,10,25,25,10,
			25,25,25,25,25,25,25,25,10, 0, 0,10,25,25,25,25,25,10, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,25,10,25,25,
			10,25,25,25,25,25,25,25,10, 0,10,25,25,25,25,25,10, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,10,25,25,10,25,
			25,25,25,25,25,25,25,25,10, 0,10,25,25,25,25,10, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,25,10,25,25,10,
			25,25,25,25,25,25,25,25,10,10,25,25,25,25,10, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,10,25,25,10,25,
			25,25,25,25,25,25,25,10,25,25,25,25,25,10, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,10,25,25,10,25,25,25,25,
			25,25,25,25,25,25,25,10,25,25,10,25,10, 0, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,10,25,25,25,25,25,25,25,
			25,25,25,25,25,25,25,10,25,25,25,25,10, 0, 0, 0, 0, 0, 0, 0,
			 0,10,10,10,10, 0, 0, 0, 0, 0,10,25,25,10,25,25,25,25,25,25,
			25,25,25,25,25,25,25,25,25,10,25,10, 0, 0, 0, 0, 0, 0, 0, 0,
			10,17,17,17,17,10,10,10,10, 0,10,10,25,25,25,25,25,25,25,25,
			25,25,25,25,25,10,25,25,25,10,10,10,10, 0, 0, 0, 0, 0, 0, 0,
			 0,10,17,17,17,17,17,17,17,10,25,25,10,25,25,25,25,25,25,25,
			25,25,25,25,10,25,25,25,10,17,17,17,17,10,10,10,10,10,10, 0,
			 0, 0,10,10,10,10,25,25,25,25,25,25,25,25,25,25,25,25,25,25,
			25,25,25,25,25,25,25,25,25,25,25,25,25,25,10,14,14,10, 0, 0,
			 0, 0, 0, 0, 0, 0,10,10,10,10,10,10,10,10,25,25,25,25,25,25,
			25,25,25,25,25,25,25,25,25,25,25,25,14,25,25,10,10, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,10,25,25,25,25,
			25,25,25,25,25,25,25,10,10,10,10,25,25,25,10, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,10,10,10,
			10,10,10,10,10,10,10, 0, 0, 0, 0,10,10,10, 0, 0, 0, 0, 0, 0};

		// Component declarations.
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuDrwimage;
		private System.Windows.Forms.MenuItem menuClpimage;
		private System.Windows.Forms.MenuItem menuRevimage;
		private System.Windows.Forms.MenuItem menuFlpimage;
		private System.Windows.Forms.MenuItem menuPutimage;
		private System.Windows.Forms.MenuItem menuExit;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuDrwimage = new System.Windows.Forms.MenuItem();
			this.menuClpimage = new System.Windows.Forms.MenuItem();
			this.menuRevimage = new System.Windows.Forms.MenuItem();
			this.menuFlpimage = new System.Windows.Forms.MenuItem();
			this.menuPutimage = new System.Windows.Forms.MenuItem();
			this.menuExit = new System.Windows.Forms.MenuItem();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
				this.menuDrwimage,
				this.menuClpimage,
				this.menuRevimage,
				this.menuFlpimage,
				this.menuPutimage,
				this.menuExit});
			// 
			// menuDrwimage
			// 
			this.menuDrwimage.Index = 0;
			this.menuDrwimage.Text = "&Drwimage";
			this.menuDrwimage.Click += new System.EventHandler(this.menuDrwimage_Click);
			// 
			// menuClpimage
			// 
			this.menuClpimage.Index = 1;
			this.menuClpimage.Text = "&Clpimage";
			this.menuClpimage.Click += new System.EventHandler(this.menuClpimage_Click);
			// 
			// menuRevimage
			// 
			this.menuRevimage.Index = 2;
			this.menuRevimage.Text = "&Revimage";
			this.menuRevimage.Click += new System.EventHandler(this.menuRevimage_Click);
			// 
			// menuFlpimage
			// 
			this.menuFlpimage.Index = 3;
			this.menuFlpimage.Text = "&Flpimage";
			this.menuFlpimage.Click += new System.EventHandler(this.menuFlpimage_Click);
			// 
			// menuPutimage
			// 
			this.menuPutimage.Index = 4;
			this.menuPutimage.Text = "&Putimage";
			this.menuPutimage.Click += new System.EventHandler(this.menuPutimage_Click);
			// 
			// menuExit
			// 
			this.menuExit.Index = 5;
			this.menuExit.Text = "E&xit";
			this.menuExit.Click += new System.EventHandler(this.menuExit_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "256-Color Bitmap Demo";
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Closed += new System.EventHandler(this.Form1_Closed);
		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();

			fg.setcolor(20);
			fg.fillpage();
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void menuDrwimage_Click(object sender, System.EventArgs e)
		{
			fg.fillpage();
			fg.move(vbWidth/2 - 20, vbHeight/2 + 10);
			fg.drwimage(ref Bird[0], 40, 20);
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void menuClpimage_Click(object sender, System.EventArgs e)
		{
			fg.fillpage();
			fg.move(-20, vbHeight / 2 + 10);
			fg.clpimage(ref Bird[0], 40, 20);
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void menuRevimage_Click(object sender, System.EventArgs e)
		{
			fg.fillpage();
			fg.move(vbWidth/2 - 20, vbHeight/2 + 10);
			fg.revimage(ref Bird[0], 40, 20);
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void menuFlpimage_Click(object sender, System.EventArgs e)
		{
			fg.fillpage();
			fg.move(vbWidth - 20, vbHeight/2 + 10);
			fg.flpimage(ref Bird[0], 40, 20);
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void menuPutimage_Click(object sender, System.EventArgs e)
		{
			fg.fillpage();
			fg.move(vbWidth/2 - 20, vbHeight/2 + 10);
			fg.putimage(ref Bird[0], 40, 20);
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void menuExit_Click(object sender, System.EventArgs e)
		{
			this.Close();		
		}
	}
}
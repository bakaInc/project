/****************************************************************************\
*                                                                            *
*  KBdemo.cs                                                                 *
*                                                                            *
*  This program shows how to pan the contents of a virtual buffer through    *
*  a smaller window using the low-level keyboard handler.                    *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace KBdemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		const int vbWidth = 640;
		const int vbHeight = 480;

		// Application variables.
		int x, y;
		int xLimit, yLimit;
		bool CanGoLeft, CanGoRight;
		bool CanGoUp, CanGoDown;

		// Component declarations.
		private System.Windows.Forms.Timer timer1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			// 
			// timer1
			// 
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Name = "Form1";
			this.Text = "Keyboard Handler Demo";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();

			fg.showbmp("..\\PORCH.BMP", 0);
			x = 0;
			y = 0;
			CanGoRight = true;
			CanGoDown = true;
			CanGoLeft = false;
			CanGoUp = false;

			Form1_Resize(sender, e);
			timer1.Enabled = true;
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbpaste(x, x+(vbWidth-1), y, y+(vbHeight-1), 0, vbHeight-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			if (cxClient < vbWidth)
			{
				xLimit = vbWidth - cxClient;
				if (x > 0) CanGoLeft = true;
				if (x < xLimit) CanGoRight = true;
			}
			else
			{
				xLimit = 0;
				CanGoLeft = false;
				CanGoRight = false;
			}
			if (cyClient < vbHeight)
			{
				yLimit = vbHeight - cyClient;
				if (y > 0) CanGoUp = true;
				if (y < yLimit) CanGoDown = true;
			}
			else
			{
				yLimit = 0;
				CanGoUp = false;
				CanGoDown = false;
			}
			fg.vbpaste(x, x+(vbWidth-1), y, y+(vbHeight-1), 0, vbHeight-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			CheckForPanning();
		}

		/****************************************************************************\
		*                                                                            *
		*  CheckForPanning()                                                         *
		*                                                                            *
		*  The CheckForPanning function checks if any of the four arrow keys are     *
		*  pressed, and if so, pans in that direction if possible. It is called      *
		*  every 10ms from the timer's OnTick event handler.                         *
		*                                                                            *
		\****************************************************************************/

		private void CheckForPanning()
		{
			const int kbEscape = 1;
			const int kbLeft = 75;
			const int kbRight = 77;
			const int kbUp = 72;
			const int kbDown = 80;

			if (fg.kbtest(kbLeft) == 1 && CanGoLeft)
			{
				if (x == xLimit) CanGoRight = true;
				x--;
				fg.vbpaste(x, x+(vbWidth-1), y, y+(vbHeight-1), 0, vbHeight-1);
				if (x == 0) CanGoLeft = false;
			}
			else if (fg.kbtest(kbRight) == 1 && CanGoRight)
			{
				if (x == 0) CanGoLeft = true;
				x++;
				fg.vbpaste(x, x+(vbWidth-1), y, y+(vbHeight-1), 0, vbHeight-1);
				if (x == xLimit) CanGoRight = false;
			}
			else if (fg.kbtest(kbUp) == 1 && CanGoUp)
			{
				if (y == yLimit) CanGoDown = true;
				y--;
				fg.vbpaste(x, x+(vbWidth-1), y, y+(vbHeight-1), 0, vbHeight-1);
				if (y == 0) CanGoUp = false;
			}
			else if (fg.kbtest(kbDown) == 1 && CanGoDown)
			{
				if (y == 0) CanGoUp = true;
				y++;
				fg.vbpaste(x, x+(vbWidth-1), y, y+(vbHeight-1), 0, vbHeight-1);
				if (y == yLimit) CanGoDown = false;
			}
			else if (fg.kbtest(kbEscape) == 1)
			{
				x = 0;
				y = 0;
				fg.vbpaste(0, vbWidth-1, 0, vbHeight-1, 0, vbHeight-1);
				if (xLimit > 0) CanGoRight = true;
				if (yLimit > 0) CanGoDown = true;
				CanGoLeft = false;
				CanGoUp = false;
			}
		}
	}
}
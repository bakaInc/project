/****************************************************************************\
*                                                                            *
*  AVImake.cpp                                                               *
*  AVImakeU.cpp                                                              *
*                                                                            *
*  This program creates an AVI file from an FLI or FLC file.                 *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("AVImakeU.cpp", Form1);
USERES("AVImake.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
        Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

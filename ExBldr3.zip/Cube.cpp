/****************************************************************************\
*                                                                            *
*  Cube.cpp                                                                  *
*  CubeU.cpp                                                                 *
*                                                                            *
*  This program draws a cube in 3D world space and allows the user to move   *
*  and rotate the cube through keyboard controls. Each of the six cube faces *
*  is a different color.                                                     *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("CubeU.cpp", Form1);
USERES("Cube.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
        Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

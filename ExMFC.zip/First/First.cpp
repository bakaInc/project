/****************************************************************************\
*                                                                            *
*  First.cpp                                                                 *
*                                                                            *
*  This is the first Fastgraph for Windows example program. It demonstrates  *
*  tasks common to most Fastgraph for Windows programs and serves as a       *
*  template for building the other examples.                                 *
*                                                                            *
\****************************************************************************/

// First.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "First.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFirstApp

BEGIN_MESSAGE_MAP(CFirstApp, CWinApp)
	//{{AFX_MSG_MAP(CFirstApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFirstApp construction

CFirstApp::CFirstApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFirstApp object

CFirstApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CFirstApp initialization

BOOL CFirstApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"First Fastgraph for Windows Program"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CFirstApp message handlers
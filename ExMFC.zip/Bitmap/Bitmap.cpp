/****************************************************************************\
*                                                                            *
*  Bitmap.cpp                                                                *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows 256-color bitmap      *
*  display functions.                                                        *
*                                                                            *
\****************************************************************************/

// Bitmap.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Bitmap.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBitmapApp

BEGIN_MESSAGE_MAP(CBitmapApp, CWinApp)
	//{{AFX_MSG_MAP(CBitmapApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBitmapApp construction

CBitmapApp::CBitmapApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CBitmapApp object

CBitmapApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CBitmapApp initialization

BOOL CBitmapApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->LoadFrame(IDR_MAINFRAME, WS_OVERLAPPEDWINDOW|FWS_ADDTOTITLE,
		NULL, NULL))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapApp message handlers

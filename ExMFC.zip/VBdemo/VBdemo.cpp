/****************************************************************************\
*                                                                            *
*  VBdemo.cpp                                                                *
*                                                                            *
*  This program demonstrates how to copy the contents of one virtual buffer  *
*  to another, with and without transparent colors.                          *
*                                                                            *
\****************************************************************************/

// VBdemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "VBdemo.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVBdemoApp

BEGIN_MESSAGE_MAP(CVBdemoApp, CWinApp)
	//{{AFX_MSG_MAP(CVBdemoApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVBdemoApp construction

CVBdemoApp::CVBdemoApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CVBdemoApp object

CVBdemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CVBdemoApp initialization

BOOL CVBdemoApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->LoadFrame(IDR_MAINFRAME, WS_OVERLAPPEDWINDOW|FWS_ADDTOTITLE,
		NULL, NULL))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CVBdemoApp message handlers

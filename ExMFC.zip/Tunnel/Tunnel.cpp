/****************************************************************************\
*                                                                            *
*  Tunnel.cpp                                                                *
*                                                                            *
*  This program draws a Gouraud-shaded tunnel and allows the viewer to move  *
*  through the tunnel using keyboard controls.                               *
*                                                                            *
\****************************************************************************/

// Tunnel.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Tunnel.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTunnelApp

BEGIN_MESSAGE_MAP(CTunnelApp, CWinApp)
	//{{AFX_MSG_MAP(CTunnelApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTunnelApp construction

CTunnelApp::CTunnelApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTunnelApp object

CTunnelApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTunnelApp initialization

BOOL CTunnelApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Gouraud-Shaded Tunnel"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

int CTunnelApp::Run()
{
	if (!m_pMainWnd)
		AfxPostQuitMessage(0);

	MSG msg;
	CMainFrame* pFrame = STATIC_DOWNCAST(CMainFrame, m_pMainWnd);

	while (TRUE)
	{
		//see if there is a message waiting
		if (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			do //if there is pump all waiting
			{
				if (!PumpMessage())
					return ExitInstance();
			} while (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE));
		}
		else
		{
			if (!pFrame->m_bAppIsActive)
				WaitMessage();
			else
				pFrame->CheckForMovement();
		}
	}
	return msg.wParam;
}

/////////////////////////////////////////////////////////////////////////////
// CTunnelApp message handlers

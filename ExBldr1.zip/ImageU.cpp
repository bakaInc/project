/****************************************************************************\
*                                                                            *
*  Image.cpp                                                                 *
*  ImageU.cpp                                                                *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows image file display    *
*  and creation functions.                                                   *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "ImageU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   cxBuffer = cyBuffer = 32;
   hVB = fg_vballoc(cxBuffer,cyBuffer);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_setcolor(-1);
   fg_fillpage();

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   CloseContext();
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the BMP menu.                             *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::BMPOpenClick(TObject *Sender)
{
   OpenDialog->DefaultExt = "bmp";
   OpenDialog->FileName = "";
   OpenDialog->Filter = "BMP files (*.bmp)|*.BMP";
   OpenDialog->Options << ofReadOnly;
   if (!OpenDialog->Execute()) return;
   strcpy(FileName,OpenDialog->FileName.c_str());

   if (fg_bmphead(FileName,FileHeader) < 0)
   {
      mbString = OpenDialog->FileName + "\nis not a BMP file.";
      MessageDlg(mbString,mtError,TMsgDlgButtons()<<mbOK,0);
      return;
   }
   Cursor = crHourGlass;
   nColors = fg_bmppal(FileName,NULL);
   fg_bmpsize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   fg_showbmp(FileName,0);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   Cursor = crDefault;

   BMPMake->Enabled = True;
   BMPDetails->Enabled = True;
   PCXMake->Enabled = True;
   PCXDetails->Enabled = False;
   JPEGDetails->Enabled = False;
   FlicPlay->Enabled = False;
   FlicFrame->Enabled = False;
   FlicReset->Enabled = False;
   FlicDetails->Enabled = False;
   AVIPlay->Enabled = False;
   AVIFrame->Enabled = False;
   AVIReset->Enabled = False;
   AVIDetails->Enabled = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BMPMakeClick(TObject *Sender)
{
   int ColorDepth;

   SaveDialog->DefaultExt = "bmp";
   SaveDialog->FileName = ChangeFileExt(FileName,".bmp");
   SaveDialog->Filter = "BMP files (*.bmp)|*.BMP";
   SaveDialog->Options << ofHideReadOnly;
   SaveDialog->Options << ofOverwritePrompt;
   SaveDialog->Options << ofPathMustExist;
   if (!SaveDialog->Execute()) return;
   strcpy(FileName,SaveDialog->FileName.c_str());

   if (nColors == 0)
      ColorDepth = 24;
   else if (nColors == 256)
      ColorDepth = 8;
   else if (nColors == 16)
      ColorDepth = 4;
   else
      ColorDepth = 1;
   Cursor = crHourGlass;
   fg_makebmp(0,cxBuffer-1,0,cyBuffer-1,ColorDepth,FileName);
   Cursor = crDefault;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BMPDetailsClick(TObject *Sender)
{
   mbString = "";
   mbString = mbString + FileName + "\n" + cxBuffer + "x" + cyBuffer + " pixels\n";
   if (nColors > 0)
      mbString = mbString + nColors + " colors";
   else
      mbString = mbString + "24-bit RGB";
   MessageDlg(mbString,mtInformation,TMsgDlgButtons()<<mbOK,0);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the PCX menu.                             *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::PCXOpenClick(TObject *Sender)
{
   OpenDialog->DefaultExt = "pcx";
   OpenDialog->FileName = "";
   OpenDialog->Filter = "PCX files (*.pcx)|*.PCX";
   OpenDialog->Options << ofReadOnly;
   if (!OpenDialog->Execute()) return;
   strcpy(FileName,OpenDialog->FileName.c_str());

   if (fg_pcxhead(FileName,FileHeader) < 0)
   {
      mbString = OpenDialog->FileName + "\nis not a PCX file.";
      MessageDlg(mbString,mtError,TMsgDlgButtons()<<mbOK,0);
      return;
   }
   Cursor = crHourGlass;
   nColors = fg_pcxpal(FileName,NULL);
   fg_pcxsize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   fg_move(0,0);
   fg_showpcx(FileName,FG_AT_XY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   Cursor = crDefault;

   BMPMake->Enabled = True;
   BMPDetails->Enabled = False;
   PCXMake->Enabled = True;
   PCXDetails->Enabled = True;
   JPEGDetails->Enabled = False;
   FlicPlay->Enabled = False;
   FlicFrame->Enabled = False;
   FlicReset->Enabled = False;
   FlicDetails->Enabled = False;
   AVIPlay->Enabled = False;
   AVIFrame->Enabled = False;
   AVIReset->Enabled = False;
   AVIDetails->Enabled = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::PCXMakeClick(TObject *Sender)
{
   SaveDialog->DefaultExt = "pcx";
   SaveDialog->FileName = ChangeFileExt(FileName,".pcx");
   SaveDialog->Filter = "PCX files (*.pcx)|*.PCX";
   SaveDialog->Options << ofHideReadOnly;
   SaveDialog->Options << ofOverwritePrompt;
   SaveDialog->Options << ofPathMustExist;
   if (!SaveDialog->Execute()) return;
   strcpy(FileName,SaveDialog->FileName.c_str());

   Cursor = crHourGlass;
   fg_makepcx(0,cxBuffer-1,0,cyBuffer-1,FileName);
   Cursor = crDefault;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::PCXDetailsClick(TObject *Sender)
{
   mbString = "";
   mbString = mbString + FileName + "\n" + cxBuffer + "x" + cyBuffer + " pixels\n";
   if (nColors > 0)
      mbString = mbString + nColors + " colors";
   else
      mbString = mbString + "24-bit RGB";
   MessageDlg(mbString,mtInformation,TMsgDlgButtons()<<mbOK,0);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the JPEG menu.                            *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::JPEGOpenClick(TObject *Sender)
{
   OpenDialog->DefaultExt = "jpg";
   OpenDialog->FileName = "";
   OpenDialog->Filter = "JPEG files (*.jpg)|*.JPG";
   OpenDialog->Options << ofReadOnly;
   if (!OpenDialog->Execute()) return;
   strcpy(FileName,OpenDialog->FileName.c_str());

   if (fg_jpeghead(FileName,FileHeader) < 0)
   {
      mbString = OpenDialog->FileName + "\nis not a baseline JPEG file.";
      MessageDlg(mbString,mtError,TMsgDlgButtons()<<mbOK,0);
      return;
   }
   Cursor = crHourGlass;
   nColors = 0;
   fg_jpegsize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   fg_showjpeg(FileName,0);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   Cursor = crDefault;

   BMPMake->Enabled = True;
   BMPDetails->Enabled = False;
   PCXMake->Enabled = True;
   PCXDetails->Enabled = False;
   JPEGDetails->Enabled = True;
   FlicPlay->Enabled = False;
   FlicFrame->Enabled = False;
   FlicReset->Enabled = False;
   FlicDetails->Enabled = False;
   AVIPlay->Enabled = False;
   AVIFrame->Enabled = False;
   AVIReset->Enabled = False;
   AVIDetails->Enabled = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::JPEGDetailsClick(TObject *Sender)
{
   mbString = "";
   mbString = mbString
      + FileName + "\n"
      + cxBuffer + "x" + cyBuffer + " pixels\n"
      + "24-bit RGB";
   MessageDlg(mbString,mtInformation,TMsgDlgButtons()<<mbOK,0);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the FLI/FLC menu.                         *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::FlicOpenClick(TObject *Sender)
{
   OpenDialog->DefaultExt = "fli";
   OpenDialog->FileName = "";
   OpenDialog->Filter = "flic files (*.fli,*.flc)|*.FLI;*.FLC";
   OpenDialog->Options << ofReadOnly;
   if (!OpenDialog->Execute()) return;
   strcpy(FileName,OpenDialog->FileName.c_str());

   if (fg_flichead(FileName,FileHeader) < 0)
   {
      mbString = OpenDialog->FileName + "\nis not an FLI or FLC file.";
      MessageDlg(mbString,mtError,TMsgDlgButtons()<<mbOK,0);
      return;
   }
   nColors = 256;
   fg_flicsize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   fg_flicopen(FileName,Context);
   fg_flicplay(Context,1,FG_NODELAY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   memcpy(&nFrames,&FileHeader[6],2);

   BMPMake->Enabled = True;
   BMPDetails->Enabled = False;
   PCXMake->Enabled = True;
   PCXDetails->Enabled = False;
   JPEGDetails->Enabled = False;
   FlicPlay->Enabled = True;
   FlicFrame->Enabled = True;
   FlicReset->Enabled = True;
   FlicDetails->Enabled = True;
   AVIPlay->Enabled = False;
   AVIFrame->Enabled = False;
   AVIReset->Enabled = False;
   AVIDetails->Enabled = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FlicPlayClick(TObject *Sender)
{
   Cursor = crHourGlass;
   fg_showflic(FileName,0,FG_NODELAY);
   Cursor = crDefault;
   fg_flicskip(Context,-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FlicFrameClick(TObject *Sender)
{
   if (fg_flicplay(Context,1,FG_NODELAY) == 0)
   {
      fg_flicskip(Context,-1);
      fg_flicplay(Context,1,FG_NODELAY);
   }
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FlicResetClick(TObject *Sender)
{
   fg_flicskip(Context,-1);
   fg_flicplay(Context,1,FG_NODELAY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FlicDetailsClick(TObject *Sender)
{
   mbString = "";
   mbString = mbString
      + FileName + "\n"
      + cxBuffer + "x" + cyBuffer + " pixels\n"
      + nFrames + " frames";
   MessageDlg(mbString,mtInformation,TMsgDlgButtons()<<mbOK,0);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the AVI menu.                             *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::AVIOpenClick(TObject *Sender)
{
   OpenDialog->DefaultExt = "avi";
   OpenDialog->FileName = "";
   OpenDialog->Filter = "AVI files (*.avi)|*.AVI";
   OpenDialog->Options << ofReadOnly;
   if (!OpenDialog->Execute()) return;
   strcpy(FileName,OpenDialog->FileName.c_str());

   if (fg_avihead(FileName,FileHeader) < 0)
   {
      mbString = OpenDialog->FileName + "\nis not an AVI file.";
      MessageDlg(mbString,mtError,TMsgDlgButtons()<<mbOK,0);
      return;
   }
   nColors = fg_avipal(FileName,NULL);
   fg_avisize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   if (fg_aviopen(FileName,Context) < 0)
   {
      mbString = "Cannot play AVI file\n" + OpenDialog->FileName + ".";
      MessageDlg(mbString,mtError,TMsgDlgButtons()<<mbOK,0);
      AVIPlay->Enabled = False;
      AVIFrame->Enabled = False;
      AVIReset->Enabled = False;
      AVIDetails->Enabled = False;
      return;
   }
   fg_aviplay(Context,1,FG_NODELAY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);

   BMPMake->Enabled = True;
   BMPDetails->Enabled = False;
   PCXMake->Enabled = True;
   PCXDetails->Enabled = False;
   JPEGDetails->Enabled = False;
   FlicPlay->Enabled = False;
   FlicFrame->Enabled = False;
   FlicReset->Enabled = False;
   FlicDetails->Enabled = False;
   AVIPlay->Enabled = True;
   AVIFrame->Enabled = True;
   AVIReset->Enabled = True;
   AVIDetails->Enabled = True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AVIPlayClick(TObject *Sender)
{
   Cursor = crHourGlass;
   fg_showavi(FileName,0,FG_NODELAY);
   Cursor = crDefault;
   fg_aviskip(Context,-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AVIFrameClick(TObject *Sender)
{
   if (fg_aviplay(Context,1,FG_NODELAY) == 0)
   {
      fg_aviskip(Context,-1);
      fg_aviplay(Context,1,FG_NODELAY);
   }
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AVIResetClick(TObject *Sender)
{
   fg_aviskip(Context,-1);
   fg_aviplay(Context,1,FG_NODELAY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AVIDetailsClick(TObject *Sender)
{
   mbString = "";
   mbString = mbString + FileName + "\n" + cxBuffer + "x" + cyBuffer + " pixels\n";
   if (nColors > 0)
      mbString = mbString + nColors + " colors";
   else
      mbString = mbString + "24-bit RGB";
   MessageDlg(mbString,mtInformation,TMsgDlgButtons()<<mbOK,0);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitClick(TObject *Sender)
{
   Close();
}

/****************************************************************************\
*                                                                            *
*  CloseContext()                                                            *
*                                                                            *
*  Closes the active flic or AVI context. This function is called from       *
*  SwitchBuffers() and also from the FormDestroy handler.                    *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::CloseContext(void)
{
   if (FlicDetails->Enabled)
      fg_flicdone(Context);
   else if (AVIDetails->Enabled)
      fg_avidone(Context);
}

/****************************************************************************\
*                                                                            *
*  SwitchBuffers()                                                           *
*                                                                            *
*  Close the and release the active virtual buffer, then create and open a   *
*  new virtual buffer to hold the new image file.                            *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::SwitchBuffers(void)
{
   CloseContext();
   fg_vbclose();
   fg_vbfree(hVB);
   if (nColors == 0)
      fg_vbdepth(24);
   else
      fg_vbdepth(8);
   hVB = fg_vballoc(cxBuffer,cyBuffer);
   fg_vbopen(hVB);
   fg_vbcolors();
}

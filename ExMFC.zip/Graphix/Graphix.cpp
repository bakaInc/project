/****************************************************************************\
*                                                                            *
*  Graphix.cpp                                                               *
*                                                                            *
*  This program demonstrates some of the Fastgraph for Windows graphics      *
*  primitive functions.                                                      *
*                                                                            *
\****************************************************************************/

// Graphix.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Graphix.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGraphixApp

BEGIN_MESSAGE_MAP(CGraphixApp, CWinApp)
	//{{AFX_MSG_MAP(CGraphixApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGraphixApp construction

CGraphixApp::CGraphixApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CGraphixApp object

CGraphixApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CGraphixApp initialization

BOOL CGraphixApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->LoadFrame(IDR_MAINFRAME, WS_OVERLAPPEDWINDOW|FWS_ADDTOTITLE,
		NULL, NULL))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CGraphixApp message handlers

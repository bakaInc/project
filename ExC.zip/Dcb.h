//------------------
// Dcb.h header file
//------------------

#define IDM_DrawDCB 1
#define IDM_ClipDCB 2
#define IDM_RevDCB  3
#define IDM_FlipDCB 4
#define IDM_PutDCB  5
#define IDM_Exit    6

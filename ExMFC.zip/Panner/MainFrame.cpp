// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Panner.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SETFOCUS()
	ON_WM_CREATE()
	ON_COMMAND(IDM_Left, LeftClick)
	ON_COMMAND(IDM_Right, RightClick)
	ON_COMMAND(IDM_Up, UpClick)
	ON_COMMAND(IDM_Down, DownClick)
	ON_COMMAND(IDM_Reset, ResetClick)
	ON_COMMAND(IDM_Exit, ExitClick)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// create a view to occupy the client area of the frame
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("Failed to create view window\n");
		return -1;
	}

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.cx = vbWidth / 2;
	cs.cy = vbHeight / 2;
	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnUpdateFrameTitle(BOOL bAddToTitle)
{
	CFrameWnd::OnUpdateFrameTitle(bAddToTitle);
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	// forward focus to the view window
	m_wndView.SetFocus();
}

void CMainFrame::OnSize(UINT nType, int cx, int cy)
{
	CFrameWnd::OnSize(nType, cx, cy);
	EnableItem(IDM_Left,m_wndView.CanGoLeft());
	EnableItem(IDM_Right,m_wndView.CanGoRight());
	EnableItem(IDM_Up,m_wndView.CanGoUp());
	EnableItem(IDM_Down,m_wndView.CanGoDown());
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CMainFrame::EnableItem(UINT nID, BOOL bEnable)
{
	CMenu* pMenu = GetMenu();
	if (pMenu)
	{
		if (bEnable)
			pMenu->EnableMenuItem(nID,MF_ENABLED);
		else
			pMenu->EnableMenuItem(nID,MF_GRAYED);
		DrawMenuBar();
	}
}

void CMainFrame::LeftClick()
{
	m_wndView.LeftClick();
	EnableItem(IDM_Left,m_wndView.CanGoLeft());
	EnableItem(IDM_Right,m_wndView.CanGoRight());
}

void CMainFrame::RightClick()
{
	m_wndView.RightClick();
	EnableItem(IDM_Left,m_wndView.CanGoLeft());
	EnableItem(IDM_Right,m_wndView.CanGoRight());
}

void CMainFrame::UpClick()
{
	m_wndView.UpClick();
	EnableItem(IDM_Up,m_wndView.CanGoUp());
	EnableItem(IDM_Down,m_wndView.CanGoDown());
}

void CMainFrame::DownClick()
{
	m_wndView.DownClick();
	EnableItem(IDM_Up,m_wndView.CanGoUp());
	EnableItem(IDM_Down,m_wndView.CanGoDown());
}

void CMainFrame::ResetClick()
{
	m_wndView.ResetClick();
	EnableItem(IDM_Left,m_wndView.CanGoLeft());
	EnableItem(IDM_Right,m_wndView.CanGoRight());
	EnableItem(IDM_Up,m_wndView.CanGoUp());
	EnableItem(IDM_Down,m_wndView.CanGoDown());
}

void CMainFrame::ExitClick()
{
	PostMessage(WM_CLOSE);
}

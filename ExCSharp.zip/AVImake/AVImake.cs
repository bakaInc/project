/****************************************************************************\
*                                                                            *
*  AVImake.cs                                                                *
*                                                                            *
*  This program creates an AVI file from an FLI or FLC file.                 *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace AVImake
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		int cxBuffer, cyBuffer;

		// Component declarations.
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.MenuItem menuConvert;
		private System.Windows.Forms.MenuItem menuExit;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuConvert = new System.Windows.Forms.MenuItem();
			this.menuExit = new System.Windows.Forms.MenuItem();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
				this.menuConvert,
				this.menuExit});
			// 
			// menuConvert
			// 
			this.menuConvert.Index = 0;
			this.menuConvert.Text = "&Convert";
			this.menuConvert.Click += new System.EventHandler(this.menuConvert_Click);
			// 
			// menuExit
			// 
			this.menuExit.Index = 1;
			this.menuExit.Text = "E&xit";
			this.menuExit.Click += new System.EventHandler(this.menuExit_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Create AVI File From Flic File";
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Closed += new System.EventHandler(this.Form1_Closed);
		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			cxBuffer = 32;
			cyBuffer = 32;
			hVB = fg.vballoc(cxBuffer, cyBuffer);
			fg.vbopen(hVB);
			fg.vbcolors();

			fg.setcolor(-1);
			fg.fillpage();
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void menuConvert_Click(object sender, System.EventArgs e)
		{
			byte [] Bitmap;
			byte [] ContextFlic = new byte [16];
			byte [] ContextAVI = new byte [24];
			byte [] FileHeader = new byte [128];
			string FileName;

			// Open the flic file to convert.
			openFileDialog1.DefaultExt = "fli";
			openFileDialog1.FileName = "";
			openFileDialog1.Filter = "flic files (*.fli,*.flc)|*.FLI;*.FLC";
			if (openFileDialog1.ShowDialog() != DialogResult.OK) return;
			FileName = openFileDialog1.FileName;

			// Make sure it really is a flic file, and if so, open it.
			if (fg.flichead(FileName, ref FileHeader[0]) < 0)
			{
				MessageBox.Show(FileName + " is not an FLI or FLC file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			fg.flicsize(ref FileHeader[0], out cxBuffer, out cyBuffer);
			SwitchBuffers();
			fg.flicopen(FileName, ref ContextFlic[0]);

			// Display the first flic frame.
			fg.flicplay(ref ContextFlic[0], 1, fg.NODELAY);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);

			// Create an empty AVI file with the same name as the flic file,
			// but with an .avi extension.
			FileName = FileName.Substring(0, FileName.IndexOf(".")) + ".avi";
			if (fg.avimake(FileName, ref ContextAVI[0], -1, cxBuffer, cyBuffer, 8, 10000, 30) < 0)
			{
				MessageBox.Show("Cannot create AVI file\n" + FileName, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			// Create a 256-color bitmap whose size is equal to the flic resolution.
			Bitmap = new byte [fg.imagesiz(cxBuffer, cyBuffer)];

			// Create the AVI file frame by frame.
			this.Cursor = Cursors.WaitCursor;
			fg.move(0, cyBuffer-1);
			do
			{
				fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
				fg.getimage(ref Bitmap[0], cxBuffer, cyBuffer);
				fg.aviframe(ref ContextAVI[0], ref Bitmap[0]);
			}
			while (fg.flicplay(ref ContextFlic[0], 1, fg.NODELAY) == 1);
			this.Cursor = Cursors.Default;

			// Close the flic and AVI files, and release the bitmap memory.
			fg.flicdone(ref ContextFlic[0]);
			fg.avidone(ref ContextAVI[0]);
		}

		private void menuExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		/****************************************************************************\
		*                                                                            *
		*  SwitchBuffers()                                                           *
		*                                                                            *
		*  Close the and release the active virtual buffer, then create and open a   *
		*  new virtual buffer to hold the new image file.                            *
		*                                                                            *
		\****************************************************************************/

		private void SwitchBuffers()
		{
			fg.vbclose();
			fg.vbfree(hVB);
			hVB = fg.vballoc(cxBuffer, cyBuffer);
			fg.vbopen(hVB);
			fg.vbcolors();
		}
	}
}
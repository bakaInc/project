/****************************************************************************\
*                                                                            *
*  Rainbow.cpp                                                               *
*  RainbowU.cpp                                                              *
*                                                                            *
*  This program demonstrates color palette cycling.                          *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "RainbowU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   int Color, xLen, yLen;

   // create the logical palette
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   FillColorPalette();
   hPal = fg_logpal(10,24,RGBvalues);
   fg_realize(hPal);

   // create a 640x480 virtual buffer
   fg_vbinit();
   hVB = fg_vballoc(640,480);
   fg_vbopen(hVB);
   fg_vbcolors();

   // construct a crude image of a rainbow
   fg_setcolor(255);
   fg_fillpage();
   fg_setclip(0,639,0,300);
   fg_move(320,300);
   xLen = 240;
   yLen = 120;
   for (Color = 10; Color < 34; Color++)
   {
      fg_setcolor(Color);
      fg_ellipsef(xLen,yLen);
      xLen -= 4;
      yLen -= 3;
   }
   fg_setcolor(255);
   fg_ellipsef(xLen,yLen);
   fg_setclip(0,639,0,479);

   // starting index into the array of color values
   Start = 0;

   // start the 50ms timer
   Timer1->Interval = 50;
   Timer1->Enabled = true;

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,fg_getmaxx(),0,fg_getmaxy(),0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
   if (GetActiveWindow() == Form1->Handle)
   {
      Start = (Start + 3) % 72;
      fg_setdacs(10,24,&RGBvalues[Start]);
      if (fg_colors() > 8)
         fg_vbscale(0,fg_getmaxx(),0,fg_getmaxy(),0,cxClient-1,0,cyClient-1);
   }
}

/****************************************************************************\
*                                                                            *
*  FillColorpalette()                                                        *
*                                                                            *
*  Set up the colors for the application's logical palette in the RGBvalues  *
*  array. The logical palette will contain 24 non-system colors (indices 10  *
*  to 33) defining the initial RGB values for the colors being cycled.       *
*                                                                            *
*  Note that we store two identical sets of 24 RGB triplets in RGBvalues. We *
*  can then perform color cycling without having to worry about wrapping to  *
*  the start of the array because the index pointing to the starting RGB     *
*  triplet never extends beyond the first set of 24 RGB triplets.            *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::FillColorPalette()
{
   static byte Colors[] = {
      182,182,255, 198,182,255, 218,182,255, 234,182,255, 255,182,255,
      255,182,234, 255,182,218, 255,182,198, 255,182,182, 255,198,182,
      255,218,182, 255,234,182, 255,255,182, 234,255,182, 218,255,182,
      198,255,182, 182,255,182, 182,255,198, 182,255,218, 182,255,234,
      182,255,255, 182,234,255, 182,218,255, 182,198,255};

   // set up two identical sets of the 24 colors in the RGBvalues array
   memcpy(RGBvalues,Colors,24*3);
   memcpy(&RGBvalues[24*3],Colors,24*3);
}

//---------------------------------------------------------------------------
#ifndef FontdemoUH
#define FontdemoUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <FGwin.h>

#define vbWidth  320
#define vbHeight 240
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HFONT hFont;
   HPALETTE hPal;
   int hVB;
   UINT cxClient, cyClient;
   LOGFONT lf;
public:   // User declarations
   __fastcall TForm1(TComponent* Owner);
   void __fastcall DrawStrings(void);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

/****************************************************************************\
*                                                                            *
*  Image.cs                                                                  *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows image file display    *
*  and creation functions.                                                   *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Image
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		int cxBuffer, cyBuffer;

		// Application variables.
		int nColors;
		int nFrames;
		byte [] Context = new byte [48];
		byte [] FileHeader = new byte [128];
		string FileName;
		string mbString;

		// Component declarations.
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuBMP;
		private System.Windows.Forms.MenuItem menuBMPOpen;
		private System.Windows.Forms.MenuItem menuBMPMake;
		private System.Windows.Forms.MenuItem menuBMPDetails;
		private System.Windows.Forms.MenuItem menuPCX;
		private System.Windows.Forms.MenuItem menuPCXOpen;
		private System.Windows.Forms.MenuItem menuPCXMake;
		private System.Windows.Forms.MenuItem menuPCXDetails;
		private System.Windows.Forms.MenuItem menuJPEG;
		private System.Windows.Forms.MenuItem menuJPEGOpen;
		private System.Windows.Forms.MenuItem menuJPEGDetails;
		private System.Windows.Forms.MenuItem menuFlic;
		private System.Windows.Forms.MenuItem menuFlicOpen;
		private System.Windows.Forms.MenuItem menuFlicPlay;
		private System.Windows.Forms.MenuItem menuFlicFrame;
		private System.Windows.Forms.MenuItem menuFlicReset;
		private System.Windows.Forms.MenuItem menuFlicDetails;
		private System.Windows.Forms.MenuItem menuAVI;
		private System.Windows.Forms.MenuItem menuAVIOpen;
		private System.Windows.Forms.MenuItem menuAVIPlay;
		private System.Windows.Forms.MenuItem menuAVIFrame;
		private System.Windows.Forms.MenuItem menuAVIReset;
		private System.Windows.Forms.MenuItem menuAVIDetails;
		private System.Windows.Forms.MenuItem menuExit;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuBMP = new System.Windows.Forms.MenuItem();
			this.menuBMPOpen = new System.Windows.Forms.MenuItem();
			this.menuBMPMake = new System.Windows.Forms.MenuItem();
			this.menuBMPDetails = new System.Windows.Forms.MenuItem();
			this.menuPCX = new System.Windows.Forms.MenuItem();
			this.menuPCXOpen = new System.Windows.Forms.MenuItem();
			this.menuPCXMake = new System.Windows.Forms.MenuItem();
			this.menuPCXDetails = new System.Windows.Forms.MenuItem();
			this.menuJPEG = new System.Windows.Forms.MenuItem();
			this.menuJPEGOpen = new System.Windows.Forms.MenuItem();
			this.menuJPEGDetails = new System.Windows.Forms.MenuItem();
			this.menuFlic = new System.Windows.Forms.MenuItem();
			this.menuFlicOpen = new System.Windows.Forms.MenuItem();
			this.menuFlicPlay = new System.Windows.Forms.MenuItem();
			this.menuFlicFrame = new System.Windows.Forms.MenuItem();
			this.menuFlicReset = new System.Windows.Forms.MenuItem();
			this.menuFlicDetails = new System.Windows.Forms.MenuItem();
			this.menuAVI = new System.Windows.Forms.MenuItem();
			this.menuAVIOpen = new System.Windows.Forms.MenuItem();
			this.menuAVIPlay = new System.Windows.Forms.MenuItem();
			this.menuAVIFrame = new System.Windows.Forms.MenuItem();
			this.menuAVIReset = new System.Windows.Forms.MenuItem();
			this.menuAVIDetails = new System.Windows.Forms.MenuItem();
			this.menuExit = new System.Windows.Forms.MenuItem();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuBMP,
																					  this.menuPCX,
																					  this.menuJPEG,
																					  this.menuFlic,
																					  this.menuAVI,
																					  this.menuExit});
			// 
			// menuBMP
			// 
			this.menuBMP.Index = 0;
			this.menuBMP.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.menuBMPOpen,
																					this.menuBMPMake,
																					this.menuBMPDetails});
			this.menuBMP.Text = "&BMP";
			// 
			// menuBMPOpen
			// 
			this.menuBMPOpen.Index = 0;
			this.menuBMPOpen.Text = "&Open";
			this.menuBMPOpen.Click += new System.EventHandler(this.menuBMPOpen_Click);
			// 
			// menuBMPMake
			// 
			this.menuBMPMake.Enabled = false;
			this.menuBMPMake.Index = 1;
			this.menuBMPMake.Text = "&Make";
			this.menuBMPMake.Click += new System.EventHandler(this.menuBMPMake_Click);
			// 
			// menuBMPDetails
			// 
			this.menuBMPDetails.Enabled = false;
			this.menuBMPDetails.Index = 2;
			this.menuBMPDetails.Text = "&Details";
			this.menuBMPDetails.Click += new System.EventHandler(this.menuBMPDetails_Click);
			// 
			// menuPCX
			// 
			this.menuPCX.Index = 1;
			this.menuPCX.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.menuPCXOpen,
																					this.menuPCXMake,
																					this.menuPCXDetails});
			this.menuPCX.Text = "&PCX";
			// 
			// menuPCXOpen
			// 
			this.menuPCXOpen.Index = 0;
			this.menuPCXOpen.Text = "&Open";
			this.menuPCXOpen.Click += new System.EventHandler(this.menuPCXOpen_Click);
			// 
			// menuPCXMake
			// 
			this.menuPCXMake.Enabled = false;
			this.menuPCXMake.Index = 1;
			this.menuPCXMake.Text = "&Make";
			this.menuPCXMake.Click += new System.EventHandler(this.menuPCXMake_Click);
			// 
			// menuPCXDetails
			// 
			this.menuPCXDetails.Enabled = false;
			this.menuPCXDetails.Index = 2;
			this.menuPCXDetails.Text = "&Details";
			this.menuPCXDetails.Click += new System.EventHandler(this.menuPCXDetails_Click);
			// 
			// menuJPEG
			// 
			this.menuJPEG.Index = 2;
			this.menuJPEG.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuJPEGOpen,
																					 this.menuJPEGDetails});
			this.menuJPEG.Text = "&JPEG";
			// 
			// menuJPEGOpen
			// 
			this.menuJPEGOpen.Index = 0;
			this.menuJPEGOpen.Text = "&Open";
			this.menuJPEGOpen.Click += new System.EventHandler(this.menuJPEGOpen_Click);
			// 
			// menuJPEGDetails
			// 
			this.menuJPEGDetails.Enabled = false;
			this.menuJPEGDetails.Index = 1;
			this.menuJPEGDetails.Text = "&Details";
			this.menuJPEGDetails.Click += new System.EventHandler(this.menuJPEGDetails_Click);
			// 
			// menuFlic
			// 
			this.menuFlic.Index = 3;
			this.menuFlic.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuFlicOpen,
																					 this.menuFlicPlay,
																					 this.menuFlicFrame,
																					 this.menuFlicReset,
																					 this.menuFlicDetails});
			this.menuFlic.Text = "&FLI/FLC";
			// 
			// menuFlicOpen
			// 
			this.menuFlicOpen.Index = 0;
			this.menuFlicOpen.Text = "&Open";
			this.menuFlicOpen.Click += new System.EventHandler(this.menuFlicOpen_Click);
			// 
			// menuFlicPlay
			// 
			this.menuFlicPlay.Enabled = false;
			this.menuFlicPlay.Index = 1;
			this.menuFlicPlay.Text = "&Play";
			this.menuFlicPlay.Click += new System.EventHandler(this.menuFlicPlay_Click);
			// 
			// menuFlicFrame
			// 
			this.menuFlicFrame.Enabled = false;
			this.menuFlicFrame.Index = 2;
			this.menuFlicFrame.Text = "&Frame";
			this.menuFlicFrame.Click += new System.EventHandler(this.menuFlicFrame_Click);
			// 
			// menuFlicReset
			// 
			this.menuFlicReset.Enabled = false;
			this.menuFlicReset.Index = 3;
			this.menuFlicReset.Text = "&Reset";
			this.menuFlicReset.Click += new System.EventHandler(this.menuFlicReset_Click);
			// 
			// menuFlicDetails
			// 
			this.menuFlicDetails.Enabled = false;
			this.menuFlicDetails.Index = 4;
			this.menuFlicDetails.Text = "&Details";
			this.menuFlicDetails.Click += new System.EventHandler(this.menuFlicDetails_Click);
			// 
			// menuAVI
			// 
			this.menuAVI.Index = 4;
			this.menuAVI.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.menuAVIOpen,
																					this.menuAVIPlay,
																					this.menuAVIFrame,
																					this.menuAVIReset,
																					this.menuAVIDetails});
			this.menuAVI.Text = "&AVI";
			// 
			// menuAVIOpen
			// 
			this.menuAVIOpen.Index = 0;
			this.menuAVIOpen.Text = "&Open";
			this.menuAVIOpen.Click += new System.EventHandler(this.menuAVIOpen_Click);
			// 
			// menuAVIPlay
			// 
			this.menuAVIPlay.Enabled = false;
			this.menuAVIPlay.Index = 1;
			this.menuAVIPlay.Text = "&Play";
			this.menuAVIPlay.Click += new System.EventHandler(this.menuAVIPlay_Click);
			// 
			// menuAVIFrame
			// 
			this.menuAVIFrame.Enabled = false;
			this.menuAVIFrame.Index = 2;
			this.menuAVIFrame.Text = "&Frame";
			this.menuAVIFrame.Click += new System.EventHandler(this.menuAVIFrame_Click);
			// 
			// menuAVIReset
			// 
			this.menuAVIReset.Enabled = false;
			this.menuAVIReset.Index = 3;
			this.menuAVIReset.Text = "&Reset";
			this.menuAVIReset.Click += new System.EventHandler(this.menuAVIReset_Click);
			// 
			// menuAVIDetails
			// 
			this.menuAVIDetails.Enabled = false;
			this.menuAVIDetails.Index = 4;
			this.menuAVIDetails.Text = "&Details";
			this.menuAVIDetails.Click += new System.EventHandler(this.menuAVIDetails_Click);
			// 
			// menuExit
			// 
			this.menuExit.Index = 5;
			this.menuExit.Text = "E&xit";
			this.menuExit.Click += new System.EventHandler(this.menuExit_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.ReadOnlyChecked = true;
			this.openFileDialog1.RestoreDirectory = true;
			this.openFileDialog1.ShowReadOnly = true;
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.FileName = "doc1";
			this.saveFileDialog1.RestoreDirectory = true;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Image File Demo";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			cxBuffer = 32;
			cyBuffer = 32;
			hVB = fg.vballoc(cxBuffer, cyBuffer);
			fg.vbopen(hVB);
			fg.vbcolors();

			fg.setcolor(-1);
			fg.fillpage();
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			CloseContext();
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		/****************************************************************************\
		*                                                                            *
		*  Event handlers for the items on the BMP menu.                             *
		*                                                                            *
		\****************************************************************************/

		private void menuBMPOpen_Click(object sender, System.EventArgs e)
		{
			openFileDialog1.DefaultExt = "bmp";
			openFileDialog1.FileName = "";
			openFileDialog1.Filter = "BMP files (*.bmp)|*.BMP";
			if (openFileDialog1.ShowDialog() != DialogResult.OK) return;
			FileName = openFileDialog1.FileName;
			if (fg.bmphead(FileName, ref FileHeader[0]) < 0)
			{
				MessageBox.Show(FileName + "\nis not a BMP file.",
					"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			this.Cursor = Cursors.WaitCursor;
			nColors = fg.bmppal(FileName, 0);
			fg.bmpsize(ref FileHeader[0], out cxBuffer, out cyBuffer);
			SwitchBuffers();
			fg.showbmp(FileName, 0);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			this.Cursor = Cursors.Default;

			menuBMPMake.Enabled = true;
			menuBMPDetails.Enabled = true;
			menuPCXMake.Enabled = true;
			menuPCXDetails.Enabled = false;
			menuJPEGDetails.Enabled = false;
			menuFlicPlay.Enabled = false;
			menuFlicFrame.Enabled = false;
			menuFlicReset.Enabled = false;
			menuFlicDetails.Enabled = false;
			menuAVIPlay.Enabled = false;
			menuAVIFrame.Enabled = false;
			menuAVIReset.Enabled = false;
			menuAVIDetails.Enabled = false;
		}

		private void menuBMPMake_Click(object sender, System.EventArgs e)
		{
			int ColorDepth;

			saveFileDialog1.DefaultExt = "bmp";
			saveFileDialog1.FileName = FileName.Substring(0, FileName.IndexOf(".")) + ".bmp";
			saveFileDialog1.Filter = "BMP files (*.bmp)|*.BMP";
			if (saveFileDialog1.ShowDialog() != DialogResult.OK) return;
			FileName = saveFileDialog1.FileName;
			if (nColors == 0)
				ColorDepth = 24;
			else if (nColors == 256)
				ColorDepth = 8;
			else if (nColors == 16)
				ColorDepth = 4;
			else
				ColorDepth = 1;
			this.Cursor = Cursors.WaitCursor;
			fg.makebmp(0, cxBuffer-1, 0, cyBuffer-1, ColorDepth, FileName);
			this.Cursor = Cursors.Default;
		}

		private void menuBMPDetails_Click(object sender, System.EventArgs e)
		{
			mbString = FileName + String.Format("\n{0:0}x{1:0} pixels\n", cxBuffer, cyBuffer);
			if (nColors > 0)
				mbString += String.Format("{0:0} colors", nColors);
			else
				mbString += "24-bit RGB";
			MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		/****************************************************************************\
		*                                                                            *
		*  Event handlers for the items on the PCX menu.                             *
		*                                                                            *
		\****************************************************************************/

		private void menuPCXOpen_Click(object sender, System.EventArgs e)
		{
			openFileDialog1.DefaultExt = "pcx";
			openFileDialog1.FileName = "";
			openFileDialog1.Filter = "PCX files (*.pcx)|*.PCX";
			if (openFileDialog1.ShowDialog() != DialogResult.OK) return;
			FileName = openFileDialog1.FileName;
			if (fg.pcxhead(FileName, ref FileHeader[0]) < 0)
			{
				MessageBox.Show(FileName + "\nis not a PCX file.",
					"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			this.Cursor = Cursors.WaitCursor;
			nColors = fg.pcxpal(FileName, 0);
			fg.pcxsize(ref FileHeader[0], out cxBuffer, out cyBuffer);
			SwitchBuffers();
			fg.move(0, 0);
			fg.showpcx(FileName, fg.AT_XY);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			this.Cursor = Cursors.Default;

			menuBMPMake.Enabled = true;
			menuBMPDetails.Enabled = false;
			menuPCXMake.Enabled = true;
			menuPCXDetails.Enabled = true;
			menuJPEGDetails.Enabled = false;
			menuFlicPlay.Enabled = false;
			menuFlicFrame.Enabled = false;
			menuFlicReset.Enabled = false;
			menuFlicDetails.Enabled = false;
			menuAVIPlay.Enabled = false;
			menuAVIFrame.Enabled = false;
			menuAVIReset.Enabled = false;
			menuAVIDetails.Enabled = false;
		}

		private void menuPCXMake_Click(object sender, System.EventArgs e)
		{
			saveFileDialog1.DefaultExt = "pcx";
			saveFileDialog1.FileName = FileName.Substring(0, FileName.IndexOf(".")) + ".pcx";
			saveFileDialog1.Filter = "PCX files (*.pcx)|*.PCX";
			if (saveFileDialog1.ShowDialog() != DialogResult.OK) return;
			FileName = saveFileDialog1.FileName;
			this.Cursor = Cursors.WaitCursor;
			fg.makepcx(0, cxBuffer-1, 0, cyBuffer-1, FileName);
			this.Cursor = Cursors.Default;
		}

		private void menuPCXDetails_Click(object sender, System.EventArgs e)
		{
			mbString = FileName + String.Format("\n{0:0}x{1:0} pixels\n", cxBuffer, cyBuffer);
			if (nColors > 0)
				mbString += String.Format("{0:0} colors", nColors);
			else
				mbString += "24-bit RGB";
			MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		/****************************************************************************\
		*                                                                            *
		*  Event handlers for the items on the JPEG menu.                            *
		*                                                                            *
		\****************************************************************************/

		private void menuJPEGOpen_Click(object sender, System.EventArgs e)
		{
			openFileDialog1.DefaultExt = "jpg";
			openFileDialog1.FileName = "";
			openFileDialog1.Filter = "JPEG files (*.jpg)|*.JPG";
			if (openFileDialog1.ShowDialog() != DialogResult.OK) return;
			FileName = openFileDialog1.FileName;
			if (fg.jpeghead(FileName, ref FileHeader[0]) < 0)
			{
				MessageBox.Show(FileName + "\nis not a baseline JPEG file.",
					"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			this.Cursor = Cursors.WaitCursor;
			nColors = 0;
			fg.jpegsize(ref FileHeader[0], out cxBuffer, out cyBuffer);
			SwitchBuffers();
			fg.showjpeg(FileName, 0);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			this.Cursor = Cursors.Default;

			menuBMPMake.Enabled = true;
			menuBMPDetails.Enabled = false;
			menuPCXMake.Enabled = true;
			menuPCXDetails.Enabled = false;
			menuJPEGDetails.Enabled = true;
			menuFlicPlay.Enabled = false;
			menuFlicFrame.Enabled = false;
			menuFlicReset.Enabled = false;
			menuFlicDetails.Enabled = false;
			menuAVIPlay.Enabled = false;
			menuAVIFrame.Enabled = false;
			menuAVIReset.Enabled = false;
			menuAVIDetails.Enabled = false;
		}

		private void menuJPEGDetails_Click(object sender, System.EventArgs e)
		{
			mbString = FileName + String.Format("\n{0:0}x{1:0} pixels\n24-bit RGB", cxBuffer, cyBuffer);
			MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		/****************************************************************************\
		*                                                                            *
		*  Event handlers for the items on the FLI/FLC menu.                         *
		*                                                                            *
		\****************************************************************************/

		private void menuFlicOpen_Click(object sender, System.EventArgs e)
		{
			openFileDialog1.DefaultExt = "fli";
			openFileDialog1.FileName = "";
			openFileDialog1.Filter = "flic files (*.fli,*.flc)|*.FLI;*.FLC";
			if (openFileDialog1.ShowDialog() != DialogResult.OK) return;
			FileName = openFileDialog1.FileName;
			if (fg.flichead(FileName, ref FileHeader[0]) < 0)
			{
				MessageBox.Show(FileName + "\nis not an FLI or FLC file.",
					"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			nColors = 256;
			fg.flicsize(ref FileHeader[0], out cxBuffer, out cyBuffer);
			SwitchBuffers();
			fg.flicopen(FileName, ref Context[0]);
			fg.flicplay(ref Context[0], 1, fg.NODELAY);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			nFrames = FileHeader[7] * 256 + FileHeader[6];

			menuBMPMake.Enabled = true;
			menuBMPDetails.Enabled = false;
			menuPCXMake.Enabled = true;
			menuPCXDetails.Enabled = false;
			menuJPEGDetails.Enabled = false;
			menuFlicPlay.Enabled = true;
			menuFlicFrame.Enabled = true;
			menuFlicReset.Enabled = true;
			menuFlicDetails.Enabled = true;
			menuAVIPlay.Enabled = false;
			menuAVIFrame.Enabled = false;
			menuAVIReset.Enabled = false;
			menuAVIDetails.Enabled = false;
		}

		private void menuFlicPlay_Click(object sender, System.EventArgs e)
		{
			this.Cursor = Cursors.WaitCursor;
			fg.showflic(FileName, 0, fg.NODELAY);
			this.Cursor = Cursors.Default;
			fg.flicskip(ref Context[0], -1);
		}

		private void menuFlicFrame_Click(object sender, System.EventArgs e)
		{
			if (fg.flicplay(ref Context[0], 1, fg.NODELAY) == 0)
			{
				fg.flicskip(ref Context[0], -1);
				fg.flicplay(ref Context[0], 1, fg.NODELAY);
			}
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void menuFlicReset_Click(object sender, System.EventArgs e)
		{
			fg.flicskip(ref Context[0], -1);
			fg.flicplay(ref Context[0], 1, fg.NODELAY);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void menuFlicDetails_Click(object sender, System.EventArgs e)
		{
			mbString = FileName + String.Format("\n{0:0}x{1:0} pixels\n{2:0} frames", cxBuffer, cyBuffer, nFrames);
			MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		/****************************************************************************\
		*                                                                            *
		*  Event handlers for the items on the AVI menu.                             *
		*                                                                            *
		\****************************************************************************/

		private void menuAVIOpen_Click(object sender, System.EventArgs e)
		{
			openFileDialog1.DefaultExt = "avi";
			openFileDialog1.FileName = "";
			openFileDialog1.Filter = "AVI files (*.avi)|*.AVI";
			if (openFileDialog1.ShowDialog() != DialogResult.OK) return;
			FileName = openFileDialog1.FileName;
			if (fg.avihead(FileName, ref FileHeader[0]) < 0)
			{
				MessageBox.Show(FileName + "\nis not an AVI file.",
					"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			nColors = fg.avipal(FileName, 0);
			fg.avisize(ref FileHeader[0], out cxBuffer, out cyBuffer);
			SwitchBuffers();
			if (fg.aviopen(FileName, ref Context[0]) < 0)
			{
				MessageBox.Show("Cannot play AVI file\n" + FileName + ".",
					"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				menuAVIPlay.Enabled = false;
				menuAVIFrame.Enabled = false;
				menuAVIReset.Enabled = false;
				menuAVIDetails.Enabled = false;
				return;
			}
			fg.aviplay(ref Context[0], 1, fg.NODELAY);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);

			menuBMPMake.Enabled = true;
			menuBMPDetails.Enabled = false;
			menuPCXMake.Enabled = true;
			menuPCXDetails.Enabled = false;
			menuJPEGDetails.Enabled = false;
			menuFlicPlay.Enabled = false;
			menuFlicFrame.Enabled = false;
			menuFlicReset.Enabled = false;
			menuFlicDetails.Enabled = false;
			menuAVIPlay.Enabled = true;
			menuAVIFrame.Enabled = true;
			menuAVIReset.Enabled = true;
			menuAVIDetails.Enabled = true;
		}

		private void menuAVIPlay_Click(object sender, System.EventArgs e)
		{
			this.Cursor = Cursors.WaitCursor;
			fg.showavi(FileName, 0, fg.NODELAY);
			this.Cursor = Cursors.Default;
			fg.aviskip(ref Context[0], -1);
		}

		private void menuAVIFrame_Click(object sender, System.EventArgs e)
		{
			if (fg.aviplay(ref Context[0], 1, fg.NODELAY) == 0)
			{
				fg.aviskip(ref Context[0], -1);
				fg.aviplay(ref Context[0], 1, fg.NODELAY);
			}
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void menuAVIReset_Click(object sender, System.EventArgs e)
		{
			fg.aviskip(ref Context[0], -1);
			fg.aviplay(ref Context[0], 1, fg.NODELAY);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void menuAVIDetails_Click(object sender, System.EventArgs e)
		{
			mbString = FileName + String.Format("\n{0:0}x{1:0} pixels\n", cxBuffer, cyBuffer);
			if (nColors > 0)
				mbString += String.Format("{0:0} colors", nColors);
			else
				mbString += "24-bit RGB";
			MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		/****************************************************************************/

		private void menuExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		/****************************************************************************\
		*                                                                            *
		*  CloseContext()                                                            *
		*                                                                            *
		*  Closes the active flic or AVI context. This function is called from       *
		*  SwitchBuffers() and also from the Form_Closed handler.                    *
		*                                                                            *
		\****************************************************************************/

		private void CloseContext()
		{
			if (menuFlicDetails.Enabled)
			{
				fg.flicdone(ref Context[0]);
			}
			else if (menuAVIDetails.Enabled)
			{
				fg.avidone(ref Context[0]);
			}
		}

		/****************************************************************************\
		*                                                                            *
		*  SwitchBuffers()                                                           *
		*                                                                            *
		*  Close the and release the active virtual buffer, then create and open a   *
		*  new virtual buffer to hold the new image file.                            *
		*                                                                            *
		\****************************************************************************/

		private void SwitchBuffers()
		{
			CloseContext();
			fg.vbclose();
			fg.vbfree(hVB);
			if (nColors == 0)
			{
				fg.vbdepth(24);
			}
			else
			{
				fg.vbdepth(8);
			}
			hVB = fg.vballoc(cxBuffer, cyBuffer);
			fg.vbopen(hVB);
			fg.vbcolors();
		}
	}
}
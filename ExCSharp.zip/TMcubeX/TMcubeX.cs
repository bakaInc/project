/****************************************************************************\
*                                                                            *
*  TMcubeX.cs                                                                *
*                                                                            *
*  This program is similar to the TMcube example, but it shows how to create *
*  a native, DirectDraw, or Direct3D program from the same source code.      *
*                                                                            *
*  Add the FGWinD.cs file if creating a DirectX program, or add the FGWin.cs *
*  file if creating a native program.                                        *
*                                                                            *
\****************************************************************************/

// Define DIRECTX if creating a DirectDraw or Direct3D program (use FGWinD.vb).
// Undefine DIRECTX if creating a native Win32 program (use FGWin.vb).
#define DIRECTX

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace TMcubeX
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int hZB;
		int [] hTM = new int [6];
		bool AppIsActive = false;

		// Define the flag bits for fg.ddsetup():
		// Specify fg.DX_FLIP for a Direct3D application.
		// Specify fg.DX_RENDER_HW or fg.DX_RENDER_SW for a Direct3D application.
		// Specify fg.DX_ZBUFFER only if fg.ZBUFFER is defined in RENDER_STATE.
		#if DIRECTX
		const int DIRECTX_FLAGS = fg.DX_FLIP + fg.DX_RENDER_HW + fg.DX_ZBUFFER;
		#endif

		// Virtual buffer dimensions.
		const int vbWidth = 640;
		const int vbHeight = 480;
		const int vbDepth = 16;

		// Application variables.
		const int RENDER_STATE = fg.PERSPECTIVE_TM + fg.ZBUFFER + fg.ZCLIP;
		const int tmWidth = 64;
		bool Redraw;
		int xAngle, yAngle, zAngle;
		double xWorld, yWorld, zWorld;

		// Six faces of a 40x40x40 cube, defined in object coordinates.
		double [,] Faces = {
			{ 20.0,-20.0,-20.0, -20.0,-20.0,-20.0, -20.0, 20.0,-20.0,  20.0, 20.0,-20.0},
			{-20.0,-20.0,-20.0, -20.0,-20.0, 20.0, -20.0, 20.0, 20.0, -20.0, 20.0,-20.0},
			{ 20.0, 20.0, 20.0, -20.0, 20.0, 20.0, -20.0,-20.0, 20.0,  20.0,-20.0, 20.0},
			{ 20.0,-20.0, 20.0,  20.0,-20.0,-20.0,  20.0, 20.0,-20.0,  20.0, 20.0, 20.0},
			{ 20.0,-20.0, 20.0, -20.0,-20.0, 20.0, -20.0,-20.0,-20.0,  20.0,-20.0,-20.0},
			{ 20.0, 20.0,-20.0, -20.0, 20.0,-20.0, -20.0, 20.0, 20.0,  20.0, 20.0, 20.0}};

		// Texture map array.
		static byte [,] Texture = new byte [6, tmWidth*tmWidth*(vbDepth/8)];

		// Texture map arrays passed to fg.tmdefine() must be pinned objects when using the
		// .NET framework (this restriction may be lifted in a future version of Fastgraph).
		GCHandle TextureHandle = GCHandle.Alloc(Texture, GCHandleType.Pinned);

		// Coordinates defining source polygon vertices within the texture map array.
		int [] tmSource = {tmWidth-1,tmWidth-1, 0,tmWidth-1, 0,0, tmWidth-1,0};

		// Component declarations.
		private System.Windows.Forms.Timer timer1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			// 
			// timer1
			// 
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "Form1";
			this.Text = "Texture-Mapped Cube";
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		protected override void WndProc(ref Message m)
		{
			const int WM_ACTIVATEAPP = 0x1C;

			base.WndProc(ref m);
			switch (m.Msg)
			{
				case WM_ACTIVATEAPP:
					AppIsActive = (m.WParam.ToInt32() != 0);
					if (AppIsActive)
					{
						#if DIRECTX
						fg.ddrestore();
						#endif
						Redraw = true;
					}
					break;
			}
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			int i;

			this.Show();
			this.Focus();
			#if DIRECTX
			fg.ddsetup(vbWidth, vbHeight, vbDepth, DIRECTX_FLAGS);
			#else
			fg.modeset(vbWidth, vbHeight, fg.colors(), 1);
			this.WindowState = FormWindowState.Maximized;
			#endif

			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			fg.vbdepth(vbDepth);
			#if DIRECTX
			hVB = 0;
			#else
			hVB = fg.vballoc(vbWidth, vbHeight);
			#endif
			fg.vbopen(hVB);
			fg.vbcolors();

			hZB = fg.zballoc(vbWidth, vbHeight);
			fg.zbopen(hZB);

			// Define 3D viewport, clipping planes, and initial render state.
			fg._3Dviewport(0, vbWidth-1, 0, vbHeight-1, 0.5);
			fg._3Dsetzclip(40.0, 1000.0);
			fg._3Drenderstate(RENDER_STATE);

			// Obtain the six texture maps from the CUBE.PCX file.
			fg.tminit(6);
			fg.showpcx("..\\CUBE.PCX", fg.AT_XY + fg.KEEPCOLORS);
			fg.move(0, tmWidth-1);
			for (i = 0; i < 6; i++)
			{
				if (vbDepth == 8)
				{
					fg.getimage(ref Texture[i,0], tmWidth, tmWidth);
					fg.invert(ref Texture[i,0], tmWidth, tmWidth);
				}
				else
				{
					fg.getdcb(ref Texture[i,0], tmWidth, tmWidth);
					fg.invdcb(ref Texture[i,0], tmWidth, tmWidth);
				}
				hTM[i] = fg.tmdefine(ref Texture[i,0], tmWidth, tmWidth);
				fg.moverel(tmWidth, 0);
			}

			xAngle = 0;
			yAngle = 0;
			zAngle = 0;
			xWorld = 0.0;
			yWorld = 0.0;
			zWorld = 100.0;
			Redraw = true;

			fg.setcolor(-1);
			fg.fillpage();

			timer1.Enabled = true;
		}

		private void Form1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Escape || e.KeyCode == Keys.F12) this.Close();
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			AppIsActive = false;
			fg.vbclose();
			fg.tmfree(-1);
			fg.zbfree(hZB);
			#if DIRECTX
			fg.vbfin();
			#else
			fg.vbfree(hVB);
			fg.vbfin();
			fg.modeset(0, 0, 0, 0);
			#endif
			g.ReleaseHdc(hDC);
			TextureHandle.Free();
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			if (AppIsActive) CheckForMovement();
		}

		/****************************************************************************\
		*                                                                            *
		*  CheckForMovement()                                                        *
		*                                                                            *
		*  The CheckForMovement() function checks for key presses that control the   *
		*  cube's movement, and if required redraws the cube at its new position and *
		*  orientation. It is called every 10ms from the timer's OnTick event        *
		*  handler.                                                                  *
		*                                                                            *
		\****************************************************************************/

		private void CheckForMovement()
		{
			bool ShiftKey;

			// Check if either shift key is pressed.
			ShiftKey = (fg.kbtest(42) == 1) || (fg.kbtest(54) == 1);

			// + and - move cube along the z axis (+ is toward viewer, - is
			// away from viewer).
			if (fg.kbtest(74) == 1)
			{
				zWorld += 3.0;
				Redraw = true;
			}
			else if (fg.kbtest(78) == 1)
			{
				zWorld -= 3.0;
				Redraw = true;
			}

				// Left and right arrow keys move cube along x axis.
			else if (fg.kbtest(75) == 1)
			{
				xWorld -= 3.0;
				Redraw = true;
			}
			else if (fg.kbtest(77) == 1)
			{
				xWorld += 3.0;
				Redraw = true;
			}

				// Up and down arrow keys move cube along y axis.
			else if (fg.kbtest(72) == 1)
			{
				yWorld += 3.0;
				Redraw = true;
			}
			else if (fg.kbtest(80) == 1)
			{
				yWorld -= 3.0;
				Redraw = true;
			}

				// x rotates counterclockwise around x axis, X rotates clockwise.
			else if (fg.kbtest(45) == 1)
			{
				if (ShiftKey)
				{
					xAngle += 6;
					if (xAngle >= 360) xAngle -= 360;
				}
				else
				{
					xAngle -= 6;
					if (xAngle < 0) xAngle += 360;
				}
				Redraw = true;
			}

				// y rotates counterclockwise around y axis, Y rotates clockwise.
			else if (fg.kbtest(21) == 1)
			{
				if (ShiftKey)
				{
					yAngle += 6;
					if (yAngle >= 360) yAngle -= 360;
				}
				else
				{
					yAngle -= 6;
					if (yAngle < 0) yAngle += 360;
				}
				Redraw = true;
			}

				// z rotates counterclockwise around z axis, Z rotates clockwise.
			else if (fg.kbtest(44) == 1)
			{
				if (ShiftKey)
				{
					zAngle += 6;
					if (zAngle >= 360) zAngle -= 360;
				}
				else
				{
					zAngle -= 6;
					if (zAngle < 0) zAngle += 360;
				}
				Redraw = true;
			}

			// if the cube's position or orientation changed, redraw the cube.
			if (Redraw)
			{
				#if DIRECTX
				// Tell Direct3D we're about to start a new frame.
				fg.ddframe(0);
				#endif

				// Prepare the z-buffer for the next frame.
				fg.zbframe();

				// Erase the previous frame from the virtual buffer.
				fg.setcolor(-1);
				fg.fillpage();

				// Define the cube's new position and rotation in 3D world space.
				fg._3Dsetobject(xWorld, yWorld, zWorld, xAngle*10, yAngle*10, zAngle*10);

				// Draw the cube.
				DrawCube();

				#if DIRECTX
				// Tell Direct3D we're finished with this frame.
				fg.ddframe(1);
				#endif

				// Display what we just drew.
				ShowCube();
				Redraw = false;
			}
		}

		/****************************************************************************\
		*                                                                            *
		*  DrawCube()                                                                *
		*                                                                            *
		*  Draws each of the six cube faces in 3D world space.                       *
		*                                                                            *
		\****************************************************************************/

		private void DrawCube()
		{
			int i;

			for (i = 0; i < 6; i++)
			{
				fg.tmselect(hTM[i]);
				fg._3Dtexturemapobject(ref Faces[i,0], ref tmSource[0], 4);
			}
		}

		/****************************************************************************\
		*                                                                            *
		*  ShowCube()                                                                *
		*                                                                            *
		*  Performs a blit or flip to make the cube visible.                         *
		*                                                                            *
		\****************************************************************************/

		private void ShowCube()
		{
			#if DIRECTX
			fg.ddflip();
			#else
			fg.vbpaste(0, vbWidth-1, 0, vbHeight-1, 0, vbHeight-1);
			#endif
		}
	}
}
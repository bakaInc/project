/****************************************************************************\
*                                                                            *
*  TMcubeX.cpp                                                               *
*  TMcubeXU.cpp                                                              *
*                                                                            *
*  This program is similar to the TMcube example, but it shows how to create *
*  a native, DirectDraw, or Direct3D program from the same source code.      *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("TMcubeXU.cpp", Form1);
USERES("TMcubeX.res");
USELIB("FGWBC32D.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

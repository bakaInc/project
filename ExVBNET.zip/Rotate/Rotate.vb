'*****************************************************************************
'                                                                            *
'  Rotate.vb                                                                 *
'                                                                            *
'  This program demonstrates the Fastgraph for Windows 256-color bitmap      *
'  rotation functions.                                                       *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 320
    Const vbHeight As Integer = 240

    ' 40x20 bitmapped image of a bird.
    Dim Bird() As Byte = { _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
        0, 0, 10, 10, 0, 10, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
        0, 0, 10, 25, 10, 17, 10, 17, 10, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
        0, 10, 25, 25, 10, 17, 10, 17, 10, 25, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
        10, 25, 25, 25, 25, 10, 25, 10, 25, 25, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 10, 10, _
        10, 25, 25, 25, 25, 10, 25, 10, 25, 10, 0, 0, 0, 0, 0, 0, 0, 10, 10, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 25, 25, 25, _
        10, 25, 25, 25, 25, 25, 25, 25, 25, 10, 0, 0, 10, 10, 10, 10, 10, 17, 10, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 10, 25, 25, 10, _
        25, 25, 25, 25, 25, 25, 25, 25, 10, 0, 0, 10, 25, 25, 25, 25, 25, 10, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 25, 25, 10, 25, 25, _
        10, 25, 25, 25, 25, 25, 25, 25, 10, 0, 10, 25, 25, 25, 25, 25, 10, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 25, 10, 25, 25, 10, 25, _
        25, 25, 25, 25, 25, 25, 25, 25, 10, 0, 10, 25, 25, 25, 25, 10, 0, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 25, 25, 10, 25, 25, 10, _
        25, 25, 25, 25, 25, 25, 25, 25, 10, 10, 25, 25, 25, 25, 10, 0, 0, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 25, 10, 25, 25, 10, 25, _
        25, 25, 25, 25, 25, 25, 25, 10, 25, 25, 25, 25, 25, 10, 0, 0, 0, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 10, 25, 25, 10, 25, 25, 25, 25, _
        25, 25, 25, 25, 25, 25, 25, 10, 25, 25, 10, 25, 10, 0, 0, 0, 0, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 25, 10, 25, 25, 25, 25, 25, 25, 25, _
        25, 25, 25, 25, 25, 25, 25, 10, 25, 25, 25, 25, 10, 0, 0, 0, 0, 0, 0, 0, _
        0, 10, 10, 10, 10, 0, 0, 0, 0, 0, 10, 25, 25, 10, 25, 25, 25, 25, 25, 25, _
        25, 25, 25, 25, 25, 25, 25, 25, 25, 10, 25, 10, 0, 0, 0, 0, 0, 0, 0, 0, _
        10, 17, 17, 17, 17, 10, 10, 10, 10, 0, 10, 10, 25, 25, 25, 25, 25, 25, 25, 25, _
        25, 25, 25, 25, 25, 10, 25, 25, 25, 10, 10, 10, 10, 0, 0, 0, 0, 0, 0, 0, _
        0, 10, 17, 17, 17, 17, 17, 17, 17, 10, 25, 25, 10, 25, 25, 25, 25, 25, 25, 25, _
        25, 25, 25, 25, 10, 25, 25, 25, 10, 17, 17, 17, 17, 10, 10, 10, 10, 10, 10, 0, _
        0, 0, 10, 10, 10, 10, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, _
        25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 10, 14, 14, 10, 0, 0, _
        0, 0, 0, 0, 0, 0, 10, 10, 10, 10, 10, 10, 10, 10, 25, 25, 25, 25, 25, 25, _
        25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 14, 25, 25, 10, 10, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 10, 25, 25, 25, 25, _
        25, 25, 25, 25, 25, 25, 25, 10, 10, 10, 10, 25, 25, 25, 10, 0, 0, 0, 0, 0, _
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 10, 10, 10, _
        10, 10, 10, 10, 10, 10, 10, 0, 0, 0, 0, 10, 10, 10, 0, 0, 0, 0, 0, 0}

    ' Rotated bird bitmap.
    Dim RotatedBird(40 * 20 * 4) As Byte

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Name = "Form1"
        Me.Text = "Bitmap Rotation Demo"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim RotatedWidth, RotatedHeight As Integer
        Dim Angle As Integer

        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        fg_setcolor(20)
        fg_fillpage()

        ' Display the original (unrotated) bird bitmap.
        fg_move(140, 80)
        fg_drwimage(Bird(0), 40, 20)

        ' Display the bitmap rotated by 30, 60, 90, 120, 150, and 180 degrees.
        fg_move(10, 140)
        For Angle = 30 To 180 Step 30
            fg_rotsize(40, 20, Angle * 10, RotatedWidth, RotatedHeight)
            fg_rotate(Bird(0), RotatedBird(0), 40, 20, Angle * 10)
            fg_drwimage(RotatedBird(0), RotatedWidth, RotatedHeight)
            fg_moverel(RotatedWidth + 10, 0)
        Next Angle
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub
End Class
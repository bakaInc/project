/****************************************************************************\
*                                                                            *
*  Blend.cpp                                                                 *
*  BlendU.cpp                                                                *
*                                                                            *
*  This program illustrates some of the Fastgraph for Windows alpha blending *
*  functions.                                                                *
*                                                                            *
*  Press F1 to view the foreground image.                                    *
*  Press F2 to view the background image.                                    *
*  Press F3 to create and view a 50% blended image.                          *
*  Press F4 to create and view a variable blended image.                     *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("BlendU.cpp", Form1);
USERES("Blend.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
        Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

// Rainbow.h : main header file for the RAINBOW application
//
#if !defined(AFX_RAINBOW_H__0256F0E3_80A3_11D2_8EBA_204C4F4F5020__INCLUDED_)
#define AFX_RAINBOW_H__0256F0E3_80A3_11D2_8EBA_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CRainbowApp:
// See Rainbow.cpp for the implementation of this class
//

class CRainbowApp : public CWinApp
{
public:
	CRainbowApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRainbowApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

public:
	//{{AFX_MSG(CRainbowApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RAINBOW_H__0256F0E3_80A3_11D2_8EBA_204C4F4F5020__INCLUDED_)

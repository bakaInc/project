'*****************************************************************************
'                                                                            *
'  Fishtank.vb                                                               *
'                                                                            *
'  This program shows how to perform simple animation using Fastgraph for    *
'  Windows. Several types of tropical fish swim back and forth against a     *
'  coral reef background. The background image and fish sprites are stored   *
'  in PCX files.                                                             *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB1, hVB2 As Integer
    Dim cxClient, cyClient As Integer

    ' Total number of fish sprites.
    Const nFish As Integer = 11

    ' Location of fish x & y.
    Dim FishX() As Integer = {0, 64, 128, 200, 0, 80}
    Dim FishY() As Integer = {199, 199, 199, 199, 150, 150}

    ' Size of fish: width and height.
    Dim FishWidth() As Integer = {56, 54, 68, 56, 62, 68}
    Dim FishHeight() As Integer = {25, 38, 26, 30, 22, 36}

    ' Bitmap offsets into Fishes() array.
    Dim FishOffset(6) As Integer

    ' The Fishes array holds the bitmaps for all 6 kinds of fish.
    Dim Fishes(56 * 25 + 54 * 38 + 68 * 26 + 56 * 30 + 62 * 22 + 68 * 36) As Byte

    ' There are 11 fish total, and 6 different kinds of fish. These
    ' arrays keep track of what kind of fish each fish is, and how each
    ' fish moves:

    ' Which fish bitmap applies to this fish?
    Dim Fish() As Integer = {1, 1, 2, 3, 3, 0, 0, 5, 4, 2, 3}

    ' Starting x and y coordinates.
    Dim xStart() As Integer = {-100, -150, -450, -140, -200, 520, 620, -800, 800, 800, -300}
    Dim yStart() As Integer = {40, 60, 150, 80, 70, 190, 180, 100, 30, 130, 92}

    ' How far left and right (off screen) the fish can go.
    Dim xMin() As Integer = {-300, -300, -800, -200, -200, -200, -300, -900, -900, -900, -400}
    Dim xMax() As Integer = {600, 600, 1100, 1000, 1000, 750, 800, 1200, 1400, 1200, 900}

    ' How fast the fish goes left and right.
    Dim xInc() As Integer = {2, 2, 8, 5, 5, -3, -3, 7, -8, -9, 6}

    ' Starting direction for each fish.
    Dim FishDir() As Integer = {0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0}

    ' How far up and down this fish can go.
    Dim yMin() As Integer = {40, 60, 120, 70, 60, 160, 160, 80, 30, 110, 72}
    Dim yMax() As Integer = {80, 100, 170, 110, 100, 199, 199, 120, 70, 150, 122}

    ' How fast the fish moves up or down.
    Dim yInc() As Integer = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

    ' Counter to compare to yTurn values.
    Dim yCount() As Integer = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

    ' How long fish can go in the vertical direction before stopping or turning around.
    Dim yTurn() As Integer = {50, 30, 10, 30, 20, 10, 10, 10, 30, 20, 10}

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Name = "Form1"
        Me.Text = "Fastgraph Fish Tank"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)

        ' Use the default logical palette.
        hPal = fg_defpal()
        fg_realize(hPal)

        ' Create two 320x200 virtual buffers.
        fg_vbinit()
        hVB1 = fg_vballoc(320, 200)
        hVB2 = fg_vballoc(320, 200)

        ' Display the coral background in virtual buffer #2 (which
        ' will always contain a clean copy of the background image).
        fg_vbopen(hVB2)
        fg_vbcolors()
        fg_showpcx("CORAL.PCX", FG_AT_XY + FG_KEEPCOLORS)

        ' Get the fish bitmaps.
        GetFish()

        ' Enable the timer to start the animation.
        Timer1.Enabled = True
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, fg_getmaxx(), 0, fg_getmaxy(), 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, fg_getmaxx(), 0, fg_getmaxy(), 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB1)
        fg_vbfree(hVB2)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        GoFish()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  GetFish()                                                                 *
    '                                                                            *
    '  Fill the fish bitmap arrays.                                              *
    '                                                                            *
    '*****************************************************************************

    Private Sub GetFish()
        Dim I, J As Integer

        For I = 0 To nFish - 1
            yCount(I) = 0
            yInc(I) = 0
        Next I

        ' Get the fish bitmaps from a PCX file.
        fg_vbopen(hVB1)
        fg_vbcolors()
        fg_showpcx("FISH.PCX", FG_AT_XY + FG_IGNOREPALETTE + FG_KEEPCOLORS)

        J = 0
        For I = 0 To 5
            fg_move(FishX(I), FishY(I))
            fg_getimage(Fishes(J), FishWidth(I), FishHeight(I))
            FishOffset(I) = J
            J += FishWidth(I) * FishHeight(I)
        Next I

        fg_erase()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  GoFish()                                                                  *
    '                                                                            *
    '  Make the fish swim around.                                                *
    '                                                                            *
    '*****************************************************************************

    Private Sub GoFish()
        Dim I As Integer

        ' Copy the background to the workspace.
        fg_copypage(hVB2, hVB1)

        ' Put all the fish in their new positions.
        For I = 0 To nFish - 1
            yCount(I) += 1
            If yCount(I) > yTurn(I) Then
                yCount(I) = 0
                yInc(I) = Int(Rnd() * 3 - 1)
            End If
            yStart(I) += yInc(I)
            yStart(I) = Math.Min(yMax(I), Math.Max(yStart(I), yMin(I)))

            If xStart(I) >= -72 And xStart(I) < 320 Then
                PutFish(Fish(I), xStart(I), yStart(I), FishDir(I))
            End If

            xStart(I) += xInc(I)
            If xStart(I) <= xMin(I) Or xStart(I) >= xMax(I) Then
                xInc(I) = -xInc(I)
                FishDir(I) = 1 - FishDir(I)
            End If
        Next I

        ' Scale the workspace image to fill the client area.
        fg_vbscale(0, 319, 0, 199, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  PutFish()                                                                 *
    '                                                                            *
    '  Draw one of the six fish anywhere you want.                               *
    '                                                                            *
    '*****************************************************************************

    Private Sub PutFish(ByRef FishNum As Integer, ByRef X As Integer, ByRef Y As Integer, ByRef FishDir As Integer)
        Dim I As Integer

        ' Move to position where the fish will appear.
        fg_move(X, Y)

        ' Draw a left- or right-facing fish, depending on FishDir.
        I = FishOffset(FishNum)
        If FishDir = 0 Then
            fg_flpimage(Fishes(I), FishWidth(FishNum), FishHeight(FishNum))
        Else
            fg_clpimage(Fishes(I), FishWidth(FishNum), FishHeight(FishNum))
        End If
    End Sub
End Class
/****************************************************************************\
*                                                                            *
*  Rotate.cpp                                                                *
*  RotateU.cpp                                                               *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows 256-color bitmap      *
*  rotation functions.                                                       *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "RotateU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   int RotatedWidth, RotatedHeight;
   int Angle;

   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_setcolor(20);
   fg_fillpage();

   // display the original (unrotated) bird bitmap
   fg_move(140,80);
   fg_drwimage(Bird,40,20);

   // display the bitmap rotated by 30, 60, 90, 120, 150, and 180 degrees
   fg_move(10,140);
   for (Angle = 30; Angle <= 180; Angle += 30)
   {
      fg_rotsize(40,20,Angle*10,&RotatedWidth,&RotatedHeight);
      fg_rotate(Bird,RotatedBird,40,20,Angle*10);
      fg_drwimage(RotatedBird,RotatedWidth,RotatedHeight);
      fg_moverel(RotatedWidth+10,0);
   }

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------

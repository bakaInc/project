/****************************************************************************\
*                                                                            *
*  Columns.cpp                                                               *
*                                                                            *
*  This program draws a grid of columns in 3D world space. It demonstrates   *
*  polygon culling and Fastgraph's incremental POV functions.                *
*                                                                            *
\****************************************************************************/

// Columns.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Columns.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColumnsApp

BEGIN_MESSAGE_MAP(CColumnsApp, CWinApp)
	//{{AFX_MSG_MAP(CColumnsApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColumnsApp construction

CColumnsApp::CColumnsApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CColumnsApp object

CColumnsApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CColumnsApp initialization

BOOL CColumnsApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"3D Columns"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

int CColumnsApp::Run()
{
	if (!m_pMainWnd)
		AfxPostQuitMessage(0);

	MSG msg;
	CMainFrame* pFrame = STATIC_DOWNCAST(CMainFrame, m_pMainWnd);

	while (TRUE)
	{
		//see if there is a message waiting
		if (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			do //if there is pump all waiting
			{
				if (!PumpMessage())
					return ExitInstance();
			} while (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE));
		}
		else
		{
			if (!pFrame->m_bAppIsActive)
				WaitMessage();
			else
				pFrame->CheckForMotion();
		}
	}
	return msg.wParam;
}

/////////////////////////////////////////////////////////////////////////////
// CColumnsApp message handlers

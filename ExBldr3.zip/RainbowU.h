//---------------------------------------------------------------------------
#ifndef RainbowUH
#define RainbowUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
#include <FGwin.h>

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   TTimer *Timer1;
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
   void __fastcall Timer1Timer(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   UINT cxClient, cyClient;
   int Start;
   byte RGBvalues[2*24*3];    // two sets of 24 RGB triplets
   void __fastcall FillColorPalette(void);
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

/****************************************************************************\
*                                                                            *
*  Tunnel.cs                                                                 *
*                                                                            *
*  This program draws a Gouraud-shaded tunnel and allows the viewer to move  *
*  through the tunnel using keyboard controls.                               *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Tunnel
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int hZB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		const int vbWidth = 640;
		const int vbHeight = 480;

		// Application variables.
		bool Redraw;

		// Four sides of a 20x40x100 tunnel, defined in 3D world coordinates.
		// Sides are in the order floor, west side, east side, ceiling.
		double [,] Faces = {
			{-10.0, 0.0,100.0, -10.0, 0.0,200.0,  10.0, 0.0,200.0,  10.0, 0.0,100.0},
			{-10.0, 0.0,100.0, -10.0,40.0,100.0, -10.0,40.0,200.0, -10.0, 0.0,200.0},
			{ 10.0, 0.0,100.0,  10.0, 0.0,200.0,  10.0,40.0,200.0,  10.0,40.0,100.0},
			{-10.0,40.0,100.0,  10.0,40.0,100.0,  10.0,40.0,200.0, -10.0,40.0,200.0}};

		// RGB color values at each vertex of each side.
		// Sides are in the order floor, west side, east side, ceiling.
		byte [,] FacesRGB = {
			{192,192,192,  64, 64, 64,  64, 64, 64, 192,192,192},
			{ 32, 32,255,  32, 32,255,  32, 32, 96,  32, 32, 96},
			{ 32, 32,255,  32, 32, 96,  32, 32, 96,  32, 32,255},
			{192,192,192, 192,192,192,  64, 64, 64,  64, 64, 64}};

		// Component declarations.
		private System.Windows.Forms.Timer timer1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			// 
			// timer1
			// 
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(640, 480);
			this.Name = "Form1";
			this.Text = "Gouraud-Shaded Tunnel";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			int vbDepth;

			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			vbDepth = fg.colors();
			if (vbDepth < 16) vbDepth = 16;
			fg.vbdepth(vbDepth);
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();

			hZB = fg.zballoc(vbWidth, vbHeight);
			fg.zbopen(hZB);

			fg.setcolor(-1);
			fg.fillpage();

			fg._3Dviewport(0, vbWidth-1, 0, vbHeight-1, 1.0);
			fg._3Drenderstate(fg.ZBUFFER + fg.ZCLIP);
			fg._3Dlookat(0.0, 10.0, 50.0, 0.0, 10.0, 100.0);
			Redraw = true;
			timer1.Enabled = true;
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.zbfree(hZB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			CheckForMovement();
		}

		/****************************************************************************\
		*                                                                            *
		*  CheckForMovement()                                                        *
		*                                                                            *
		*  The CheckForMovement() function checks for key presses that control the   *
		*  user's movement, and if required redraws the tunnel viewed from the new   *
		*  camera position. It is called every 10ms from the timer's OnTick event    *
		*  handler.                                                                  *
		*                                                                            *
		\****************************************************************************/

		private void CheckForMovement()
		{
			// Up arrow moves viewer forward.
			if (fg.kbtest(72) == 1)
			{
				fg._3Dmoveforward(2.0);
				Redraw = true;
			}

			// Down arrow moves viewer backward.
			else if (fg.kbtest(80) == 1)
			{
				fg._3Dmoveforward(-2.0);
				Redraw = true;
			}

			// Right arrow turns viewer to the right.
			else if (fg.kbtest(77) == 1)
			{
				fg._3Drotateright(6*10);
				Redraw = true;
			}

			// Left arrow turns viewer to the left.
			else if (fg.kbtest(75) == 1)
			{
				fg._3Drotateright(-6*10);
				Redraw = true;
			}

			// If the viewer's position or orientation changed, redraw the tunnel.
			if (Redraw)
			{
				// Prepare the z-buffer for the next frame.
				fg.zbframe();

				// Erase the previous frame from the virtual buffer.
				fg.setcolor(-1);
				fg.fillpage();

				// Draw the tunnel.
				DrawTunnel();

				// Display what we just drew.
				fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
				Redraw = false;
			}
		}

		/****************************************************************************\
		*                                                                            *
		*  DrawTunnel()                                                              *
		*                                                                            *
		*  Draws each of the tunnel's four sides in 3D world space.                  *
		*                                                                            *
		\****************************************************************************/

		private void DrawTunnel()
		{
			int i;

			for (i = 0; i < 4; i++)
			{
				fg._3Dshade(ref Faces[i,0], ref FacesRGB[i,0], 4);
			}
		}
	}
}
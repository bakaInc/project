/****************************************************************************\
*                                                                            *
*  Dcb.cpp                                                                   *
*  DcbU.cpp                                                                  *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows direct color bitmap   *
*  display functions.                                                        *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("DcbU.cpp", Form1);
USERES("Dcb.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

/****************************************************************************\
*                                                                            *
*  FrameDD.cs                                                                *
*                                                                            *
*  This program shows how to set up a full screen DirectDraw application     *
*  for either blitting or flipping. The selection of blitting or flipping is *
*  controlled by the BLIT and FLIP symbols defined below.                    *
*                                                                            *
\****************************************************************************/

// Define either BLIT or FLIP, but not both, for blitting or flipping.
#define BLIT
#undef FLIP

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace FrameDD
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		bool AppIsActive = false;

		// Virtual buffer dimensions.
		const int vbWidth = 640;
		const int vbHeight = 480;

		// Component declarations.
		private System.Windows.Forms.Timer timer1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			// 
			// timer1
			// 
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "Form1";
			this.Text = "DirectDraw Frame Animation";
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		protected override void WndProc(ref Message m)
		{
			const int WM_ACTIVATEAPP = 0x1C;

			base.WndProc(ref m);
			switch (m.Msg)
			{
				case WM_ACTIVATEAPP:
					AppIsActive = (m.WParam.ToInt32() != 0);
					if (AppIsActive) fg.ddrestore();
					break;
			}
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			#if BLIT
			fg.ddsetup(vbWidth, vbHeight, 8, fg.DX_BLIT);
			#else
			fg.ddsetup(vbWidth, vbHeight, 8, fg.DX_FLIP);
			#endif
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);
			this.Show();
			this.Focus();

			// If blitting, create a virtual buffer the same size as the screen
			// resolution; if flipping, use the primary surface's back buffer.
			fg.vbinit();
			#if BLIT
			hVB = fg.vballoc(vbWidth, vbHeight);
			#else
			hVB = 0;
			#endif
			fg.vbopen(hVB);
			fg.vbcolors();

			fg.mouseini();
			fg.mousevis(0);
			timer1.Enabled = true;
		}

		private void Form1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Escape || e.KeyCode == Keys.F12) this.Close();
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			AppIsActive = false;
			fg.mousevis(1);
			fg.vbclose();
			#if BLIT
			fg.vbfree(hVB);
			#endif
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			if (AppIsActive) Animate();
		}

		/****************************************************************************\
		*                                                                            *
		*  Animate()                                                                 *
		*                                                                            *
		*  Construct the next frame of animation and display it with either blitting *
		*  or flipping, as directed by the BLIT and FLIP symbols above. When the     *
		*  application is the active application, this function is called every 10ms *
		*  from the timer's OnTick event handler.                                    *
		*                                                                            *
		\****************************************************************************/

		private void Animate()
		{
			// Fill drawing surface with the next color.
			fg.setcolor((fg.getcolor()+1) & 0xFF);
			fg.fillpage();

			// Blit or flip surface to the screen.
			#if BLIT
			fg.vbpaste(0, vbWidth-1, 0, vbHeight-1, 0, vbHeight-1);
			#else
			fg.ddflip();
			#endif
		}
	}
}
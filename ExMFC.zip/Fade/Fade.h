// Fade.h : main header file for the FADE application
//
#if !defined(AFX_FADE_H__C1996815_8255_11D2_8EBF_204C4F4F5020__INCLUDED_)
#define AFX_FADE_H__C1996815_8255_11D2_8EBF_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CFadeApp:
// See Fade.cpp for the implementation of this class
//

class CFadeApp : public CWinApp
{
public:
	CFadeApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFadeApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

public:
	//{{AFX_MSG(CFadeApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FADE_H__C1996815_8255_11D2_8EBF_204C4F4F5020__INCLUDED_)

'*****************************************************************************
'                                                                            *
'  Cube.vb                                                                   *
'                                                                            *
'  This program draws a cube in 3D world space and allows the user to move   *
'  and rotate the cube through keyboard controls. Each of the six cube faces *
'  is a different color.                                                     *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 640
    Const vbHeight As Integer = 480

    ' Application variables.
    Dim vbDepth As Integer
    Dim Redraw As Boolean
    Dim xAngle, yAngle, zAngle As Integer
    Dim xWorld, yWorld, zWorld As Double

    ' Colors of the six cube faces.
    Dim Colors() As Integer = {84, 88, 92, 96, 100, 104}

    ' Six faces of a 40x40x40 cube, defined in object coordinates.
    Dim Faces(,) As Double = { _
        {20.0, -20.0, -20.0, -20.0, -20.0, -20.0, -20.0, 20.0, -20.0, 20.0, 20.0, -20.0}, _
        {-20.0, -20.0, -20.0, -20.0, -20.0, 20.0, -20.0, 20.0, 20.0, -20.0, 20.0, -20.0}, _
        {20.0, 20.0, 20.0, -20.0, 20.0, 20.0, -20.0, -20.0, 20.0, 20.0, -20.0, 20.0}, _
        {20.0, -20.0, 20.0, 20.0, -20.0, -20.0, 20.0, 20.0, -20.0, 20.0, 20.0, 20.0}, _
        {20.0, -20.0, 20.0, -20.0, -20.0, 20.0, -20.0, -20.0, -20.0, 20.0, -20.0, -20.0}, _
        {20.0, 20.0, -20.0, -20.0, 20.0, -20.0, -20.0, 20.0, 20.0, 20.0, 20.0, 20.0}}

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(640, 480)
        Me.Name = "Form1"
        Me.Text = "Single 3D Cube"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        vbDepth = fg_colors()
        fg_vbdepth(vbDepth)
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()
        fg_setcolor(-1)
        fg_fillpage()

        fg_3Dviewport(0, vbWidth - 1, 0, vbHeight - 1, 0.5)
        fg_3Drenderstate(FG_ZCLIP)
        xAngle = 0
        yAngle = 0
        zAngle = 0
        xWorld = 0.0
        yWorld = 0.0
        zWorld = 100.0
        Redraw = True

        Timer1.Enabled = True
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        CheckForMovement()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  CheckForMovement()                                                        *
    '                                                                            *
    '  The CheckForMovement() function checks for key presses that control the   *
    '  cube's movement, and if required redraws the cube at its new position and *
    '  orientation. It is called every 10ms from the timer's OnTick event        *
    '  handler.                                                                  *
    '                                                                            *
    '*****************************************************************************

    Private Sub CheckForMovement()
        Dim ShiftKey As Boolean

        ' Check if either shift key is pressed.
        ShiftKey = (fg_kbtest(42) = 1) Or (fg_kbtest(54) = 1)

        ' + and - move cube along the z axis (+ is toward viewer, - is
        ' away from viewer)
        If fg_kbtest(74) = 1 Then
            zWorld += 3.0
            Redraw = True
        ElseIf fg_kbtest(78) = 1 Then
            zWorld -= 3.0
            Redraw = True

            ' Left and right arrow keys move cube along x axis.
        ElseIf fg_kbtest(75) = 1 Then
            xWorld -= 3.0
            Redraw = True
        ElseIf fg_kbtest(77) = 1 Then
            xWorld += 3.0
            Redraw = True

            ' Up and down arrow keys move cube along y axis.
        ElseIf fg_kbtest(72) = 1 Then
            yWorld += 3.0
            Redraw = True
        ElseIf fg_kbtest(80) = 1 Then
            yWorld -= 3.0
            Redraw = True

            ' x rotates counterclockwise around x axis, X rotates clockwise.
        ElseIf fg_kbtest(45) = 1 Then
            If ShiftKey Then
                xAngle += 6
                If xAngle >= 360 Then xAngle -= 360
            Else
                xAngle -= 6
                If xAngle < 0 Then xAngle += 360
            End If
            Redraw = True

            ' y rotates counterclockwise around y axis, Y rotates clockwise.
        ElseIf fg_kbtest(21) = 1 Then
            If ShiftKey Then
                yAngle += 6
                If yAngle >= 360 Then yAngle -= 360
            Else
                yAngle -= 6
                If yAngle < 0 Then yAngle += 360
            End If
            Redraw = True

            ' z rotates counterclockwise around z axis, Z rotates clockwise.
        ElseIf fg_kbtest(44) = 1 Then
            If ShiftKey Then
                zAngle += 6
                If zAngle >= 360 Then zAngle -= 360
            Else
                zAngle -= 6
                If zAngle < 0 Then zAngle += 360
            End If
            Redraw = True
        End If

        ' If the cube's position or orientation changed, redraw the cube.
        If Redraw Then
            ' Erase the previous frame from the virtual buffer.
            fg_setcolor(-1)
            fg_fillpage()

            ' Define the cube's new position and rotation in 3D world space.
            fg_3Dsetobject(xWorld, yWorld, zWorld, xAngle * 10, yAngle * 10, zAngle * 10)

            ' Draw the cube.
            DrawCube()

            ' Display what we just drew.
            fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
            Redraw = False
        End If
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  DrawCube()                                                                *
    '                                                                            *
    '  Draws each of the six cube faces in 3D world space.                       *
    '                                                                            *
    '*****************************************************************************

    Private Sub DrawCube()
        Dim I As Integer
        Dim R, G, B As Integer

        For I = 0 To 5
            If vbDepth > 8 Then
                fg_getrgb(Colors(I), R, G, B)
                fg_setcolorrgb(R, G, B)
            Else
                fg_setcolor(Colors(I))
            End If
            fg_3Dpolygonobject(Faces(I, 0), 4)
        Next
    End Sub
End Class
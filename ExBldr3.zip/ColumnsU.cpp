/****************************************************************************\
*                                                                            *
*  Columns.cpp                                                               *
*  ColumnsU.cpp                                                              *
*                                                                            *
*  This program draws a grid of columns in 3D world space. It demonstrates   *
*  polygon culling and Fastgraph's incremental POV functions.                *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "ColumnsU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OnIdle(TObject *Sender, bool &Done)
{
   CheckForMotion();
   Done = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   // set up the device context and logical palette
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   // initialize the virtual buffer environment
   fg_vbinit();
   fg_vbdepth(fg_colors());

   // create and open the virtual buffer
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   // create and open the z-buffer
   hZB = fg_zballoc(vbWidth,vbHeight);
   fg_zbopen(hZB);

   // define 3D viewport, render state, and initial POV
   fg_3Dviewport(0,vbWidth-1,0,vbHeight-1,1.0);
   fg_3Drenderstate(FG_ZBUFFER|FG_ZCLIP);
   fg_3Dlookat(10.0,20.0,100.0,0.0,20.0,0.0);

   // direct strings to the active virtual buffer
   fg_fontdc(fg_getdc());

   // make the client area equal to the required size
   Top = 0;
   Left = 0;
   ClientWidth = WinWidth;
   ClientHeight = WinHeight;

   Application->OnActivate = OnActivate;
   Application->OnIdle = OnIdle;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   DrawColumns();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_zbfree(hZB);
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}

/****************************************************************************\
*                                                                            *
*  CheckForMotion()                                                          *
*                                                                            *
*  The CheckForMotion() function checks for key presses that control the     *
*  viewer's position and orientation, and if required redraws the scene at   *
*  its new POV. It is called from the WinMain() message loop when there are  *
*  no messages waiting.                                                      *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::CheckForMotion()
{
   bool ShiftKey;

   ShiftKey = fg_kbtest(42) | fg_kbtest(54);

   if (fg_kbtest(71))      // Home
   {
      fg_3Dmoveup(5.0);
      DrawColumns();
   }
   else if (fg_kbtest(72)) // Up arrow
   {
      fg_3Dmoveforward(5.0);
      DrawColumns();
   }
   else if (fg_kbtest(73)) // PgUp
   {
      fg_3Drotateup(100);
      DrawColumns();
   }
   else if (fg_kbtest(75)) // Left arrow
   {
      if (ShiftKey)
         fg_3Dmoveright(-5.0);
      else
         fg_3Drotateright(-100);
      DrawColumns();
   }
   else if (fg_kbtest(77)) // Right arrow
   {
      if (ShiftKey)
         fg_3Dmoveright(5.0);
      else
         fg_3Drotateright(100);
      DrawColumns();
   }
   else if (fg_kbtest(79)) // End
   {
      fg_3Dmoveup(-5.0);
      DrawColumns();
   }
   else if (fg_kbtest(80)) // Down arrow
   {
      fg_3Dmoveforward(-5.0);
      DrawColumns();
   }
   else if (fg_kbtest(81)) // PgDn
   {
      fg_3Drotateup(-100);
      DrawColumns();
   }
}

/****************************************************************************\
*                                                                            *
*  DrawColumns()                                                             *
*                                                                            *
*  Draws the scene at its new POV. Columns behind the viewer are culled out. *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::DrawColumns()
{
   static int r[] = {254,243,226,203,123,166};
   static int g[] = {219,194,172,150, 98,125};
   static int b[] = {164,117, 86, 67, 59, 60};
   int nColor[6];
   int row, col;
   register int i;

   // prepare for the new frame
   fg_zbframe();
   fg_setcolor(-1);
   fg_fillpage();

   // create the six encoded color values
   for (i = 0; i < 6; i++)
      nColor[i] = fg_maprgb(r[i],g[i],b[i]);

   // 50x50x6 = 15000 polygons per frame
   for (row = -500; row < 500; row += 20)
   {
      for (col = -500; col < 500; col += 20)
      {
         if (fg_3Dbehindviewer((double)row,0.0,(double)col,-1.0) == 0)
         {
            fg_3Dmoveobject((double)row,0.0,(double)col);

            // draw all the faces
            for (i = 0; i < 6; i++)
            {
               // set the color
               fg_setcolor(nColor[i]);

               // draw the face
               fg_3Dpolygonobject(ColumnData[i],4);
            }
         }
      }
   }

   // display the scene
   fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);

   // display the 3D information at the bottom of the window
   UpdateInfo();
}

/****************************************************************************\
*                                                                            *
*  UpdateInfo()                                                              *
*                                                                            *
*  Displays the information at the bottom of the window.                     *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::UpdateInfo()
{
   double x, y, z, xDir, yDir, zDir;
   char String[64];

   // get current position and direction
   fg_3Dgetpov(&x,&y,&z,&xDir,&yDir,&zDir);

   // clear an area to write on
   fg_setcolorrgb(0,0,140);
   fg_rect(0,249,0,InfoHeight-1);

   fg_setcolorrgb(0,140,0);
   fg_rect(250,vbWidth-1,0,InfoHeight-1);

   fg_setcolor(-1);

   // print current position and unit vector
   fg_move(20,32);
   sprintf(String,"x =%7.2f  xDir = %7.2f",x,xDir);
   fg_print(String,strlen(String));

   fg_move(20,46);
   sprintf(String,"y =%7.2f  yDir = %7.2f",y,yDir);
   fg_print(String,strlen(String));

   fg_move(20,60);
   sprintf(String,"z =%7.2f  zDir = %7.2f",z,zDir);
   fg_print(String,strlen(String));

   // print instructions
   fg_move(270,18);
   sprintf(String,"Up    = move forward   Home = move up");
   fg_print(String,strlen(String));

   fg_move(270,32);
   sprintf(String,"Down  = move back      End  = move down");
   fg_print(String,strlen(String));

   fg_move(270,46);
   sprintf(String,"Left  = turn left      PgUp = look up");
   fg_print(String,strlen(String));

   fg_move(270,60);
   sprintf(String,"Right = turn right     PgDn = look down");
   fg_print(String,strlen(String));

   fg_move(290,74);
   sprintf(String,"Shift+Left/Right = move left/right");
   fg_print(String,strlen(String));

   fg_vbpaste(0,vbWidth-1,0,InfoHeight-1,0,WinHeight-1);
}

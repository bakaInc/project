/****************************************************************************\
*                                                                            *
*  Scale.cpp                                                                 *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows 256-color bitmap      *
*  scaling and shearing functions.                                           *
*                                                                            *
\****************************************************************************/

// Scale.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Scale.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScaleApp

BEGIN_MESSAGE_MAP(CScaleApp, CWinApp)
	//{{AFX_MSG_MAP(CScaleApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScaleApp construction

CScaleApp::CScaleApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CScaleApp object

CScaleApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CScaleApp initialization

BOOL CScaleApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Bitmap Scaling and Shearing"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CScaleApp message handlers

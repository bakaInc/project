// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Blend.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// direct color bitmap containing the foreground image
BYTE Foreground[vbWidth*vbHeight*(vbDepth/8)];

// direct color bitmap containing the background image
BYTE Background[vbWidth*vbHeight*(vbDepth/8)];

// direct color bitmap containing the resulting blended image
BYTE Blended[vbWidth*vbHeight*(vbDepth/8)];

// 256-color bitmap containing variable opacity values
BYTE Opacity[vbWidth*vbHeight];

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_PAINT()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
}

CMainFrame::~CMainFrame()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		fg_vbdepth(vbDepth);
		m_hVB = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		// get background image from the CAT.BMP file
		fg_showbmp("CAT.BMP",0);
		fg_move(0,vbHeight-1);
		fg_getdcb(Background,vbWidth,vbHeight);

		// get foreground image from the PORCH.BMP file
		fg_showbmp("PORCH.BMP",0);
		fg_move(0,vbHeight-1);
		fg_getdcb(Foreground,vbWidth,vbHeight);

		// calcluate variable opacity bitmap
		MakeOpacityBitmap();
	}
	return bRet;
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CMainFrame::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CMainFrame::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CFrameWnd::OnKeyDown(nChar, nRepCnt, nFlags);
	switch(nChar)
	{
		// display foreground image
		case VK_F1:
		{
			fg_move(0,vbHeight-1);
			fg_putdcb(Foreground,vbWidth,vbHeight);
			fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
			SetWindowText("Alpha Blending: Foreground Image");
			break;
		}

		// display background image
		case VK_F2:
		{
			fg_move(0,vbHeight-1);
			fg_putdcb(Background,vbWidth,vbHeight);
			fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
			SetWindowText("Alpha Blending: Background Image");
			break;
		}

		// display blended image with constant 50% foreground opacity
		case VK_F3:
		{
			CWaitCursor wait;
			fg_opacity(128);
			fg_blenddcb(Foreground,Background,Blended,vbWidth*vbHeight);
			fg_move(0,vbHeight-1);
			fg_putdcb(Blended,vbWidth,vbHeight);
			fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
			SetWindowText("Alpha Blending: 50% Blended Image");
			break;
		}

		// display blended image with variable foreground opacity
		case VK_F4:
		{
			CWaitCursor wait;
			fg_blendvar(Foreground,Background,Opacity,Blended,vbWidth*vbHeight);
			fg_move(0,vbHeight-1);
			fg_putdcb(Blended,vbWidth,vbHeight);
			fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
			SetWindowText("Alpha Blending: Variable Blended Image");
			break;
		}
	}
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

/****************************************************************************\
*                                                                            *
*  MakeOpacityBitmap()                                                       *
*                                                                            *
*  Define a 256-color bitmap with varying opacity values. The foregound      *
*  opacities will be zero at the image center and will gradually increase    *
*  as we move farther from the center.                                       *
*                                                                            *
\****************************************************************************/

void CMainFrame::MakeOpacityBitmap()
{
	register int i, x, y;
	int OpacityValue;
	int yTerm;

	i = 0;

	for (y = 0; y < vbHeight; y++)
	{
		yTerm = abs(y - vbHeight/2);
		for (x = 0; x < vbWidth; x++)
		{
			OpacityValue = abs(x - vbWidth/2) + yTerm;
			if (OpacityValue > 255)
				Opacity[i++] = 255;
			else
				Opacity[i++] = (BYTE)OpacityValue;
		}
	}
}

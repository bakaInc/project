/****************************************************************************\
*                                                                            *
*  Colors.cpp                                                                *
*  ColorsU.cpp                                                               *
*                                                                            *
*  This program illustrates how to establish the current color for 256-color *
*  and direct color virtual buffers. It obtains the display driver's color   *
*  depth, creates a 640x480 virtual buffer with the same color depth, and    *
*  fills it with blue pixels.                                                *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("ColorsU.cpp", Form1);
USERES("Colors.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

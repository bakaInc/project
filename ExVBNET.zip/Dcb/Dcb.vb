'*****************************************************************************
'                                                                            *
'  Dcb.vb                                                                    *
'                                                                            *
'  This program demonstrates the Fastgraph for Windows direct color bitmap   *
'  display functions.                                                        *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 320
    Const vbHeight As Integer = 240

    ' 40x20 high color bitmapped image of a bird
    ' Image is stored as a Byte array for compatibility with Fastgraph's bitmap display
    ' functions (note each pair of bytes is inverted due to byte ordering -- that is,
    ' the word value &H1234 is stored as byte &H34 followed by byte &H12).
    Dim Bird() As Byte = { _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H21, &H8, &H21, &H8, &H0, &H0, &H21, &H8, &H0, &H0, &H21, &H8, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H21, &H8, &HFF, &HFF, &H21, &H8, &H55, &HAD, &H21, &H8, &H55, &HAD, &H21, &H8, &H21, &H8, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H55, &HAD, &H21, &H8, &H55, &HAD, &H21, &H8, &HFF, &HFF, _
        &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, _
        &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &H21, &H8, &H21, &H8, _
        &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &H21, &H8, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &H21, &H8, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, _
        &H0, &H0, &H0, &H0, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H55, &HAD, &H21, &H8, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &H21, &H8, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &H0, _
        &H0, &H0, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, _
        &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &H0, _
        &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &H0, _
        &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &H21, &H8, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H21, &H8, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H21, &H8, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, _
        &H21, &H8, &HFF, &HFF, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H21, &H8, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H21, &H8, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, _
        &HFF, &HFF, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H21, &H8, &H55, &HAD, &H55, &HAD, &H55, &HAD, &H55, &HAD, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H0, &H0, _
        &H21, &H8, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, _
        &H21, &H8, &H21, &H8, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H21, &H8, &H55, &HAD, &H55, &HAD, &H55, &HAD, &H55, &HAD, &H55, &HAD, &H55, &HAD, &H55, &HAD, &H21, &H8, _
        &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H55, &HAD, _
        &H55, &HAD, &H55, &HAD, &H55, &HAD, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &HA8, &H0, &HA8, &H21, &H8, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, _
        &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &H0, &HA8, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, _
        &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H21, &H8, &H21, &H8, _
        &H21, &H8, &HFF, &HFF, &HFF, &HFF, &HFF, &HFF, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, _
        &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H21, &H8, &H0, &H0, &H0, &H0, &H0, &H0, _
        &H0, &H0, &H8, &H21, &H8, &H21, &H8, &H21, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0}

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuDrawDCB As System.Windows.Forms.MenuItem
    Friend WithEvents menuClipDCB As System.Windows.Forms.MenuItem
    Friend WithEvents menuRevDCB As System.Windows.Forms.MenuItem
    Friend WithEvents menuFlipDCB As System.Windows.Forms.MenuItem
    Friend WithEvents menuPutDCB As System.Windows.Forms.MenuItem
    Friend WithEvents menuExit As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.menuDrawDCB = New System.Windows.Forms.MenuItem()
        Me.menuClipDCB = New System.Windows.Forms.MenuItem()
        Me.menuRevDCB = New System.Windows.Forms.MenuItem()
        Me.menuFlipDCB = New System.Windows.Forms.MenuItem()
        Me.menuPutDCB = New System.Windows.Forms.MenuItem()
        Me.menuExit = New System.Windows.Forms.MenuItem()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuDrawDCB, Me.menuClipDCB, Me.menuRevDCB, Me.menuFlipDCB, Me.menuPutDCB, Me.menuExit})
        '
        'menuDrawDCB
        '
        Me.menuDrawDCB.Index = 0
        Me.menuDrawDCB.Text = "&DrawDCB"
        '
        'menuClipDCB
        '
        Me.menuClipDCB.Index = 1
        Me.menuClipDCB.Text = "&ClipDCB"
        '
        'menuRevDCB
        '
        Me.menuRevDCB.Index = 2
        Me.menuRevDCB.Text = "&RevDCB"
        '
        'menuFlipDCB
        '
        Me.menuFlipDCB.Index = 3
        Me.menuFlipDCB.Text = "&FlipDCB"
        '
        'menuPutDCB
        '
        Me.menuPutDCB.Index = 4
        Me.menuPutDCB.Text = "&PutDCB"
        '
        'menuExit
        '
        Me.menuExit.Index = 5
        Me.menuExit.Text = "E&xit"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Direct Color Bitmap Demo"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        fg_vbdepth(16)
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        fg_setcolorrgb(85, 255, 85)
        fg_fillpage()
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub menuDrawDCB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuDrawDCB.Click
        fg_fillpage()
        fg_move(vbWidth \ 2 - 20, vbHeight \ 2 + 10)
        fg_drawdcb(Bird(0), 40, 20)
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub menuClipDCB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuClipDCB.Click
        fg_fillpage()
        fg_move(-20, vbHeight \ 2 + 10)
        fg_clipdcb(Bird(0), 40, 20)
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub menuRevDCB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuRevDCB.Click
        fg_fillpage()
        fg_move(vbWidth \ 2 - 20, vbHeight \ 2 + 10)
        fg_revdcb(Bird(0), 40, 20)
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub menuFlipDCB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFlipDCB.Click
        fg_fillpage()
        fg_move(vbWidth - 20, vbHeight \ 2 + 10)
        fg_flipdcb(Bird(0), 40, 20)
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub menuPutDCB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuPutDCB.Click
        fg_fillpage()
        fg_move(vbWidth \ 2 - 20, vbHeight \ 2 + 10)
        fg_putdcb(Bird(0), 40, 20)
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub menuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuExit.Click
        Me.Close()
    End Sub
End Class
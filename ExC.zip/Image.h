//--------------------
// Image.h header file
//--------------------

#define IDM_BMP_Open     101
#define IDM_BMP_Make     102
#define IDM_BMP_Details  103

#define IDM_PCX_Open     201
#define IDM_PCX_Make     202
#define IDM_PCX_Details  203

#define IDM_JPEG_Open    301
#define IDM_JPEG_Details 302

#define IDM_Flic_Open    401
#define IDM_Flic_Play    402
#define IDM_Flic_Frame   403
#define IDM_Flic_Reset   404
#define IDM_Flic_Details 405

#define IDM_AVI_Open     501
#define IDM_AVI_Play     502
#define IDM_AVI_Frame    503
#define IDM_AVI_Reset    504
#define IDM_AVI_Details  505

#define IDM_Exit         6

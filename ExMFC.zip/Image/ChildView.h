// ChildView.h : interface of the CChildView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDVIEW_H__CBDE14EA_829E_11D2_8EBF_204C4F4F5020__INCLUDED_)
#define AFX_CHILDVIEW_H__CBDE14EA_829E_11D2_8EBF_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMainFrame;

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildView)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CChildView();

	BOOL BMPOpenClick();
	void BMPMakeClick();
	void BMPDetailsClick();
	BOOL PCXOpenClick();
	void PCXMakeClick();
	void PCXDetailsClick();
	BOOL JPEGOpenClick();
	void JPEGDetailsClick();
	BOOL FlicOpenClick();
	void FlicPlayClick();
	void FlicFrameClick();
	void FlicResetClick();
	void FlicDetailsClick();
	BOOL AVIOpenClick();
	void AVIPlayClick();
	void AVIFrameClick();
	void AVIResetClick();
	void AVIDetailsClick();
	void CloseContext();
	CString IntToStr(int n);
	void SwitchBuffers();
	CString& GetTitleText()          {return m_Title;}

	// Generated message map functions
protected:
	CMainFrame* GetMainFrame() {return (CMainFrame*)AfxGetApp()->m_pMainWnd;}

	CString m_Title;
	HDC m_hDC;
	HPALETTE m_hPal;
	int m_hVB;
	UINT m_cxClient;
	UINT m_cyClient;
	int m_cxBuffer;
	int m_cyBuffer;
	int m_nColors;
	int m_nFrames;
	BOOL m_LoadedAVI;
	BOOL m_LoadedFlic;
	CString m_FileName;
	BYTE m_Context[48];
	BYTE m_FileHeader[128];

	//{{AFX_MSG(CChildView)
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT,int,int);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDVIEW_H__CBDE14EA_829E_11D2_8EBF_204C4F4F5020__INCLUDED_)

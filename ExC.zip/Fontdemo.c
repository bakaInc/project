/****************************************************************************\
*                                                                            *
*  Fontdemo.c                                                                *
*                                                                            *
*  This program shows how use Windows stock fonts in Fastgraph for Windows,  *
*  and also how to create and use a Windows logical font. The logical font   *
*  is a 24pt Arial font.                                                     *
*                                                                            *
\****************************************************************************/

#include <fgwin.h>
#include <stdlib.h>

#define vbWidth  320
#define vbHeight 240

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);
void DrawStrings(void);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGfontdemo";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor (NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindow(szAppName,   // window class name
      "Fastgraph for Windows Font Demo", // window caption
      WS_OVERLAPPEDWINDOW,          // window style
      CW_USEDEFAULT,                // initial x position
      CW_USEDEFAULT,                // initial y position
      CW_USEDEFAULT,                // initial x size
      CW_USEDEFAULT,                // initial y size
      NULL,                         // parent window handle
      NULL,                         // window menu handle
      hInstance,                    // program instance handle
      NULL);                        // creation parameters

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   while (GetMessage(&msg,NULL,0,0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HDC      hDC;
HFONT    hFont;
HPALETTE hPal;
int      hVB;
UINT     cxClient, cyClient;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;
   LOGFONT lf;

   switch (iMsg)
   {
      case WM_CREATE:
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);

         fg_vbinit();
         hVB = fg_vballoc(vbWidth,vbHeight);
         fg_vbopen(hVB);
         fg_vbcolors();

         fg_setcolor(24);
         fg_fillpage();

         lf.lfHeight = 24;                // character height in pixels
         lf.lfWidth = 0;                  // defaultl character width
         lf.lfEscapement = 0;             // orientation of next character
         lf.lfOrientation = 0;            // orientation of first character
         lf.lfWeight = FW_NORMAL;         // normal thickness
         lf.lfItalic = FALSE;             // not italic characters
         lf.lfUnderline = FALSE;          // not underlined characters
         lf.lfStrikeOut = FALSE;          // not strikeout characters
         lf.lfCharSet = ANSI_CHARSET;     // ANSI character set
         lf.lfOutPrecision = 0;           // default output precision
         lf.lfClipPrecision = 0;          // default clipping precision
         lf.lfQuality = DEFAULT_QUALITY;  // default scaling quality
         lf.lfPitchAndFamily = 0;         // default pitch and font family
         lstrcpy(lf.lfFaceName,"Arial");  // Arial typeface
         hFont = CreateFontIndirect(&lf);
         return 0;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
         fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
         DrawStrings();
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,TRUE);
         return 0;

      case WM_SIZE:
         cxClient = LOWORD(lParam);
         cyClient = HIWORD(lParam);
         return 0;

      case WM_DESTROY:
         fg_vbclose();
         fg_vbfree(hVB);
         fg_vbfin();
         DeleteObject(hFont);
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

void DrawStrings()
{
   register int x;

   fg_setcolor(19);
   x = fg_xclient(20);

   fg_move(x,fg_yclient(20));
   fg_fontload(10);
   fg_print("OEM fixed font",14);

   fg_move(x,fg_yclient(40));
   fg_fontload(11);
   fg_print("ANSI fixed font",15);

   fg_move(x,fg_yclient(60));
   fg_fontload(12);
   fg_print("ANSI var font",13);

   fg_move(x,fg_yclient(80));
   fg_fontload(13);
   fg_print("system font",11);

   fg_move(x,fg_yclient(100));
   fg_fontload(14);
   fg_print("device default font",19);

   fg_move(x,fg_yclient(120));
   fg_fontload(16);
   fg_print("system fixed font",17);

   fg_move(x,fg_yclient(160));
   fg_logfont(hFont);
   fg_print("Arial 24 font",13);
}

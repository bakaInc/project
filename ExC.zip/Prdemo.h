//---------------------
// Prdemo.h header file
//---------------------

#define IDM_Print 1
#define IDM_Exit  2

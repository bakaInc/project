/****************************************************************************\
*                                                                            *
*  Fontdemo.cpp                                                              *
*                                                                            *
*  This program shows how use Windows stock fonts in Fastgraph for Windows,  *
*  and also how to create and use a Windows logical font. The logical font   *
*  is a 24pt Arial font.                                                     *
*                                                                            *
\****************************************************************************/

// Fontdemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Fontdemo.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFontdemoApp

BEGIN_MESSAGE_MAP(CFontdemoApp, CWinApp)
	//{{AFX_MSG_MAP(CFontdemoApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFontdemoApp construction

CFontdemoApp::CFontdemoApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFontdemoApp object

CFontdemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CFontdemoApp initialization

BOOL CFontdemoApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Fastgraph for Windows Font Demo"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CFontdemoApp message handlers

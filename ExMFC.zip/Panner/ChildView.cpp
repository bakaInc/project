// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "Panner.h"

#include "ChildView.h"
#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
	m_cxLimit = 0;
	m_cyLimit = 0;
	m_xOrigin = 0;
	m_yOrigin = 0;
	m_bCanGoLeft = FALSE;
	m_bCanGoRight = TRUE;
	m_bCanGoUp = FALSE;
	m_bCanGoDown = TRUE;
}

CChildView::~CChildView()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BEGIN_MESSAGE_MAP(CChildView, CWnd)
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

BOOL CChildView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL bRet = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		m_hVB = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		fg_showbmp("PORCH.BMP",0);
	}
	return bRet;
}

void CChildView::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbpaste(m_xOrigin,m_xOrigin+(vbWidth-1),m_yOrigin,m_yOrigin+(vbHeight-1),0,vbHeight-1);
}

void CChildView::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;

	if (cx < vbWidth)
	{
		m_cxLimit = vbWidth - cx;
		if (m_xOrigin > 0) m_bCanGoLeft = TRUE;
		if (m_xOrigin < m_cxLimit) m_bCanGoRight = TRUE;
	}
	else
	{
		m_cxLimit = 0;
		m_bCanGoLeft = m_bCanGoRight = FALSE;
	}
	if (cy < vbHeight)
	{
		m_cyLimit = vbHeight - cy;
		if (m_yOrigin > 0) m_bCanGoUp = TRUE;
		if (m_yOrigin < m_cyLimit) m_bCanGoDown = TRUE;
	}
	else
	{
		m_cyLimit = 0;
		m_bCanGoUp = m_bCanGoDown = FALSE;
	}
}

void CChildView::OnSetFocus(CWnd* pOldWnd)
{
	CWnd::OnSetFocus(pOldWnd);
	fg_realize(m_hPal);
	Invalidate();
}

void CChildView::LeftClick()
{
   if (m_xOrigin == m_cxLimit) m_bCanGoRight = TRUE;
   m_xOrigin--;
   fg_vbpaste(m_xOrigin,m_xOrigin+(vbWidth-1),m_yOrigin,m_yOrigin+(vbHeight-1),0,vbHeight-1);
   if (m_xOrigin == 0) m_bCanGoLeft = FALSE;
}

void CChildView::RightClick()
{
   if (m_xOrigin == 0) m_bCanGoLeft = TRUE;
   m_xOrigin++;
   fg_vbpaste(m_xOrigin,m_xOrigin+(vbWidth-1),m_yOrigin,m_yOrigin+(vbHeight-1),0,vbHeight-1);
   if (m_xOrigin == m_cxLimit) m_bCanGoRight = FALSE;
}

void CChildView::UpClick()
{
   if (m_yOrigin == m_cyLimit) m_bCanGoDown = TRUE;
   m_yOrigin--;
   fg_vbpaste(m_xOrigin,m_xOrigin+(vbWidth-1),m_yOrigin,m_yOrigin+(vbHeight-1),0,vbHeight-1);
   if (m_yOrigin == 0) m_bCanGoUp = FALSE;
}

void CChildView::DownClick()
{
   if (m_yOrigin == 0) m_bCanGoUp = TRUE;
   m_yOrigin++;
   fg_vbpaste(m_xOrigin,m_xOrigin+(vbWidth-1),m_yOrigin,m_yOrigin+(vbHeight-1),0,vbHeight-1);
   if (m_yOrigin == m_cyLimit) m_bCanGoDown = FALSE;
}

void CChildView::ResetClick()
{
   m_xOrigin = m_yOrigin = 0;
   fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);
   if (m_cxLimit > 0) m_bCanGoRight = TRUE;
   if (m_cyLimit > 0) m_bCanGoDown = TRUE;
   m_bCanGoLeft = m_bCanGoUp = FALSE;
}
/****************************************************************************\
*                                                                            *
*  Prdemo.cpp                                                                *
*                                                                            *
*  This program shows how to print the contents of a virtual buffer.  It     *
*  first loads a 640x480 BMP file into a virtual buffer and displays it.     *
*  When the user clicks the Print selection on the top-level menu, a 6-inch  *
*  by 4-inch copy of the BMP image is sent to the selected printer.          *
*                                                                            *
\****************************************************************************/

// Prdemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Prdemo.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPrdemoApp

BEGIN_MESSAGE_MAP(CPrdemoApp, CWinApp)
	//{{AFX_MSG_MAP(CPrdemoApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPrdemoApp construction

CPrdemoApp::CPrdemoApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CPrdemoApp object

CPrdemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CPrdemoApp initialization

BOOL CPrdemoApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->LoadFrame(IDR_MAINFRAME, WS_OVERLAPPEDWINDOW|FWS_ADDTOTITLE,
		NULL, NULL))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CPrdemoApp message handlers

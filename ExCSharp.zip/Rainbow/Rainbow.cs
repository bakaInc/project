/****************************************************************************\
*                                                                            *
*  Rainbow.cs                                                                *
*                                                                            *
*  This program demonstrates color palette cycling.                          *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Rainbow
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int cxClient, cyClient;

		// Application variables.
		int Start;
		byte [] RGBvalues = new byte [2*24*3];  // two sets of 24 RGB triplets

		// Component declarations.
		private System.Windows.Forms.Timer timer1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			// 
			// timer1
			// 
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Name = "Form1";
			this.Text = "Color Cycling";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			int Color;
			int xLen, yLen;

			// Create the logical palettte.
			hDC = g.GetHdc();
			fg.setdc(hDC);
			FillColorPalette();
			hPal = fg.logpal(10, 24, ref RGBvalues[0]);
			fg.realize(hPal);

			// Ccreate a 640x480 virtual buffer.
			fg.vbinit();
			hVB = fg.vballoc(640, 480);
			fg.vbopen(hVB);
			fg.vbcolors();

			// Construct a crude image of a rainbow.
			fg.setcolor(255);
			fg.fillpage();
			fg.setclip(0, 639, 0, 300);
			fg.move(320, 300);
			xLen = 240;
			yLen = 120;
			for (Color = 10; Color < 34; Color++)
			{
				fg.setcolor(Color);
				fg.ellipsef(xLen, yLen);
				xLen -= 4;
				yLen -= 3;
			}
			fg.setcolor(255);
			fg.ellipsef(xLen, yLen);
			fg.setclip(0, 639, 0, 479);

			// Starting index into the array of color values.
			Start = 0;

			// Start the 50ms timer.
			timer1.Interval = 50;
			timer1.Enabled = true;
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
	        fg.vbscale(0, fg.getmaxx(), 0, fg.getmaxy(), 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, fg.getmaxx(), 0, fg.getmaxy(), 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			Start = (Start + 3) % 72;
			fg.setdacs(10, 24, ref RGBvalues[Start]);
			if (fg.colors() > 8)
				fg.vbscale(0, fg.getmaxx(), 0, fg.getmaxy(), 0, cxClient-1, 0, cyClient-1);
		}

		/****************************************************************************\
		*                                                                            *
		*  FillColorPalette()                                                        *
		*                                                                            *
		*  Set up the colors for the application's logical palette in the RGBvalues  *
		*  array. The logical palette will contain 24 non-system colors (indices 10  *
		*  to 33) defining the initial RGB values for the colors being cycled.       *
		*                                                                            *
		*  Note that we store two identical sets of 24 RGB triplets in RGBvalues. We *
		*  can then perform color cycling without having to worry about wrapping to  *
		*  the start of the array because the index pointing to the starting RGB     *
		*  triplet never extends beyond the first set of 24 RGB triplets.            *
		*                                                                            *
		\****************************************************************************/

		private void FillColorPalette()
		{
			byte [] Colors = {
				182, 182, 255, 198, 182, 255, 218, 182, 255, 234, 182, 255, 255, 182, 255,
				255, 182, 234, 255, 182, 218, 255, 182, 198, 255, 182, 182, 255, 198, 182,
				255, 218, 182, 255, 234, 182, 255, 255, 182, 234, 255, 182, 218, 255, 182,
				198, 255, 182, 182, 255, 182, 182, 255, 198, 182, 255, 218, 182, 255, 234,
				182, 255, 255, 182, 234, 255, 182, 218, 255, 182, 198, 255};

			// Set up two identical sets of the 24 colors in the RGBvalues array.
			Array.Copy(Colors, 0, RGBvalues, 0, 24*3);
			Array.Copy(Colors, 0, RGBvalues, 24*3, 24*3);
		}
	}
}
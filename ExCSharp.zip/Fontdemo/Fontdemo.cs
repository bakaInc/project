/****************************************************************************\
*                                                                            *
*  Fontdemo.cs                                                               *
*                                                                            *
*  This program shows how use Windows stock fonts in Fastgraph for Windows,  *
*  and also how to create and use a Windows logical font. The logical font   *
*  is a 24x12 Arial font.                                                    *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Fontdemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		IntPtr hFont;
		int hPal;
		int hVB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		const int vbWidth = 320;
		const int vbHeight = 240;

		// 24pt Arial font.
		Font Font1 = new Font("Arial", 24);

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Name = "Form1";
			this.Text = "Fastgraph for Windows Font Demo";
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Closed += new System.EventHandler(this.Form1_Closed);
		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();

			fg.setcolor(24);
			fg.fillpage();
			hFont = Font1.ToHfont();
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
			DrawStrings();
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
			if (this.Visible) DrawStrings();
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void DrawStrings()
		{
			int x;

			fg.setcolor(19);
			x = fg.xclient(20);

			fg.move(x, fg.yclient(20));
			fg.fontload(10);
			fg.print("OEM fixed font", 14);

			fg.move(x, fg.yclient(40));
			fg.fontload(11);
			fg.print("ANSI fixed font", 15);

			fg.move(x, fg.yclient(60));
			fg.fontload(12);
			fg.print("ANSI var font", 13);

			fg.move(x, fg.yclient(80));
			fg.fontload(13);
			fg.print("system font", 11);

			fg.move(x, fg.yclient(100));
			fg.fontload(14);
			fg.print("device default font", 19);

			fg.move(x, fg.yclient(120));
			fg.fontload(16);
			fg.print("system fixed font", 17);

			fg.move(x, fg.yclient(160));
			fg.logfont(hFont);
			fg.print("Arial 24 font", 13);
		}
	}
}
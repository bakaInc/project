//---------------------------------------------------------------------------
#ifndef TMcubeXUH
#define TMcubeXUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <FGwin.h>

#define RENDER_STATE (FG_PERSPECTIVE_TM | FG_ZBUFFER | FG_ZCLIP)

// define DIRECTX if creating a DirectDraw or Direct3D application
#define DIRECTX

// define the flag bits for fg_ddsetup()
// specify FG_DX_FLIP for a Direct3D application
// specify FG_DX_RENDER_HW or FG_DX_RENDER_SW for a Direct3D application
// specify FG_DX_ZBUFFER only if FG_ZBUFFER is defined in RENDER_STATE
#define DIRECTX_FLAGS (FG_DX_FLIP | FG_DX_RENDER_HW | FG_DX_ZBUFFER)

#define vbWidth  640
#define vbHeight 480
#define vbDepth   16

#define tmWidth   64

typedef struct point3d
{
   double x;
   double y;
   double z;
} POINT3D;
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
   void __fastcall FormDestroy(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   int hZB;
   int hTM[6];
   bool AppIsActive;
   bool AppIsReady;
   void __fastcall CheckForMovement(bool);
   void __fastcall DrawCube(void);
   void __fastcall ShowCube(void);
   void __fastcall OnActivate(TObject *Sender);
   void __fastcall OnIdle(TObject *Sender, bool &Done);
protected:      // User declarations
   void __fastcall WMActivateApp(TMessage &Msg);
   BEGIN_MESSAGE_MAP
      MESSAGE_HANDLER(WM_ACTIVATEAPP, TMessage, WMActivateApp)
   END_MESSAGE_MAP(TForm)
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
// six faces of a 40x40x40 cube, defined in object coordinates
POINT3D Face1[] = {
   { 20.0,-20.0,-20.0},
   {-20.0,-20.0,-20.0},
   {-20.0, 20.0,-20.0},
   { 20.0, 20.0,-20.0}
};
POINT3D Face2[] = {
   {-20.0,-20.0,-20.0},
   {-20.0,-20.0, 20.0},
   {-20.0, 20.0, 20.0},
   {-20.0, 20.0,-20.0}
};
POINT3D Face3[] = {
   { 20.0, 20.0, 20.0},
   {-20.0, 20.0, 20.0},
   {-20.0,-20.0, 20.0},
   { 20.0,-20.0, 20.0}
};
POINT3D Face4[] = {
   { 20.0,-20.0, 20.0},
   { 20.0,-20.0,-20.0},
   { 20.0, 20.0,-20.0},
   { 20.0, 20.0, 20.0}
};
POINT3D Face5[] = {
   { 20.0,-20.0, 20.0},
   {-20.0,-20.0, 20.0},
   {-20.0,-20.0,-20.0},
   { 20.0,-20.0,-20.0}
};
POINT3D Face6[] = {
   { 20.0, 20.0,-20.0},
   {-20.0, 20.0,-20.0},
   {-20.0, 20.0, 20.0},
   { 20.0, 20.0, 20.0}
};
// for convenience, an array of pointers to each of the six faces
POINT3D *Faces[] = {Face1,Face2,Face3,Face4,Face5,Face6};
// texture map array
byte Texture[6][tmWidth*tmWidth*(vbDepth/8)];
// coordinates defining source polygon vertices within the texture map array
int tmSource[] = {tmWidth-1,tmWidth-1, 0,tmWidth-1, 0,0, tmWidth-1,0};
//---------------------------------------------------------------------------
#endif

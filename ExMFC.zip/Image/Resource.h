//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Image.rc
//
#define IDR_MAINFRAME                   128
#define IDM_BMP_Open                    32771
#define IDM_BMP_Make                    32772
#define IDM_BMP_Details                 32773
#define IDM_PCX_Open                    32774
#define IDM_PCX_Make                    32775
#define IDM_PCX_Details                 32776
#define IDM_JPEG_Open                   32777
#define IDM_JPEG_Details                32778
#define IDM_Flic_Open                   32779
#define IDM_Flic_Play                   32780
#define IDM_Flic_Frame                  32781
#define IDM_Flic_Reset                  32782
#define IDM_Flic_Details                32783
#define IDM_AVI_Open                    32784
#define IDM_AVI_Play                    32785
#define IDM_AVI_Frame                   32786
#define IDM_AVI_Reset                   32787
#define IDM_AVI_Details                 32788
#define IDM_Exit                        32789

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

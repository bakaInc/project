'*****************************************************************************
'                                                                            *
'  Blend.vb                                                                  *
'                                                                            *
'  This program illustrates some of the Fastgraph for Windows alpha blending *
'  functions.                                                                *
'                                                                            *
'  Press F1 to view the foreground image.                                    *
'  Press F2 to view the background image.                                    *
'  Press F3 to create and view a 50% blended image.                          *
'  Press F4 to create and view a variable blended image.                     *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics = Me.CreateGraphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 640
    Const vbHeight As Integer = 480
    Const vbDepth As Integer = 16

    ' Direct color bitmap containing the foreground image.
    Dim Foreground(vbWidth * vbHeight * (vbDepth \ 8)) As Byte

    ' Direct color bitmap containing the background image.
    Dim Background(vbWidth * vbHeight * (vbDepth \ 8)) As Byte

    ' Direct color bitmap containing the resulting blended image.
    Dim Blended(vbWidth * vbHeight * (vbDepth \ 8)) As Byte

    ' 256-color bitmap containing variable opacity values.
    Dim OpacityMap(vbWidth * vbHeight) As Byte

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Name = "Form1"
        Me.Text = "Alpha Blending Demo"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Select Case e.KeyCode
            Case Keys.F1
                ' Display foreground image.
                fg_move(0, vbHeight - 1)
                fg_putdcb(Foreground(0), vbWidth, vbHeight)
                fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
                Text = "Alpha Blending: Foreground Image"

            Case Keys.F2
                ' Display background image.
                fg_move(0, vbHeight - 1)
                fg_putdcb(Background(0), vbWidth, vbHeight)
                fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
                Text = "Alpha Blending: Background Image"

            Case Keys.F3
                ' Display blended image with constant 50% foreground opacity.
                Me.Cursor = Cursors.WaitCursor
                fg_opacity(128)
                fg_blenddcb(Foreground(0), Background(0), Blended(0), vbWidth * vbHeight)
                fg_move(0, vbHeight - 1)
                fg_putdcb(Blended(0), vbWidth, vbHeight)
                fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
                Text = "Alpha Blending: 50% Blended Image"
                Me.Cursor = Cursors.Default

            Case Keys.F4
                ' Display blended image with variable foreground opacity.
                Me.Cursor = Cursors.WaitCursor
                fg_blendvar(Foreground(0), Background(0), OpacityMap(0), Blended(0), vbWidth * vbHeight)
                fg_move(0, vbHeight - 1)
                fg_putdcb(Blended(0), vbWidth, vbHeight)
                fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
                Text = "Alpha Blending: Variable Blended Image"
                Me.Cursor = Cursors.Default
        End Select
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        fg_vbdepth(vbDepth)
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        ' Get background image from the CAT.BMP file.
        fg_showbmp("CAT.BMP", 0)
        fg_move(0, vbHeight - 1)
        fg_getdcb(Background(0), vbWidth, vbHeight)

        ' Get foreground image from the PORCH.BMP file.
        fg_showbmp("PORCH.BMP", 0)
        fg_move(0, vbHeight - 1)
        fg_getdcb(Foreground(0), vbWidth, vbHeight)

        ' Calcluate variable opacity bitmap.
        MakeOpacityBitmap()
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  MakeOpacityBitmap()                                                       *
    '                                                                            *
    '  Define a 256-color bitmap with varying opacity values. The foregound      *
    '  opacities will be zero at the image center and will gradually increase    *
    '  as we move farther from the center.                                       *
    '                                                                            *
    '*****************************************************************************

    Private Sub MakeOpacityBitmap()
        Dim I, X, Y As Integer
        Dim OpacityValue As Integer
        Dim yTerm As Integer

        I = 0

        For Y = 0 To vbHeight - 1
            yTerm = Math.Abs(Y - vbHeight \ 2)
            For X = 0 To vbWidth - 1
                OpacityValue = Math.Abs(X - vbWidth \ 2) + yTerm
                If (OpacityValue > 255) Then
                    OpacityMap(I) = 255
                Else
                    OpacityMap(I) = OpacityValue
                End If
                I += 1
            Next X
        Next Y
    End Sub
End Class
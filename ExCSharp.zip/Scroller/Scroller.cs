/****************************************************************************\
*                                                                            *
*  Scroller.cs                                                               *
*                                                                            *
*  This program demonstrates circular scrolling within a virtual buffer.     *
*                                                                            *
*  Because fg.scroll() requires a "hidden" virtual buffer to save and then   *
*  restore portions of the area being scrolled, we create a second virtual   *
*  buffer for this purpose.                                                  *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Scroller
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB1, hVB2;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		const int vbWidth = 320;
		const int vbHeight = 200;

		// Component declarations.
		private System.Windows.Forms.Timer timer1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			// 
			// timer1
			// 
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Name = "Form1";
			this.Text = "Scrolling Demo";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			hVB1 = fg.vballoc(vbWidth, vbHeight);
			hVB2 = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB2);
			fg.vbcolors();
			fg.vbopen(hVB1);
			fg.vbcolors();
			fg.sethpage(hVB2);

			fg.setcolor(19);
			fg.fillpage();
			fg.setcolor(25);
			fg.rect(132, 188, 50, 150);

			fg.setcolor(20);
			fg.move(160, 67);
			fg.draw(175, 107);
			fg.draw(140, 82);
			fg.draw(180, 82);
			fg.draw(145, 107);
			fg.draw(160, 67);
			fg.paint(160, 77);
			fg.paint(150, 87);
			fg.paint(160, 87);
			fg.paint(170, 87);
			fg.paint(155, 97);
			fg.paint(165, 97);

			timer1.Enabled = true;
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB1);
			fg.vbfree(hVB2);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			Scroll();
		}

		/****************************************************************************\
		*                                                                            *
		*  Scroll()                                                                  *
		*                                                                            *
		*  The Scroll() function moves the scrolling region up four pixels in a      *
		*  circular manner. It is called every 10ms from the timer's OnTick event    *
		*  handler.                                                                  *
		*                                                                            *
		\****************************************************************************/

		private void Scroll()
		{
			fg.scroll(136, 184, 50, 150, -4, 0);
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}
	}
}
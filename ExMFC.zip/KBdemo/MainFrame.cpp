// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "KBdemo.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_PAINT()
	ON_WM_ACTIVATEAPP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
	m_cxLimit = 0;
	m_cyLimit = 0;
	m_xOrigin = 0;
	m_yOrigin = 0;
	m_bCanGoRight = TRUE;
	m_bCanGoDown = TRUE;
	m_bCanGoLeft = FALSE;
	m_bCanGoUp = FALSE;
	m_bAppIsActive = FALSE;
}

CMainFrame::~CMainFrame()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.cx = vbWidth / 2;
	cs.cy = vbHeight / 2;
	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		m_hVB = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		fg_showbmp("PORCH.BMP",0);

		m_bAppIsActive = TRUE;
	}
	return bRet;
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbpaste(m_xOrigin,m_xOrigin+(vbWidth-1),m_yOrigin,m_yOrigin+(vbHeight-1),0,vbHeight-1);
}

void CMainFrame::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;

	if (cx < vbWidth)
	{
		m_cxLimit = vbWidth - cx;
		if (m_xOrigin > 0) m_bCanGoLeft = TRUE;
		if (m_xOrigin < m_cxLimit) m_bCanGoRight = TRUE;
	}
	else
	{
		m_cxLimit = 0;
		m_bCanGoLeft = m_bCanGoRight = FALSE;
	}
	if (cy < vbHeight)
	{
		m_cyLimit = vbHeight - cy;
		if (m_yOrigin > 0) m_bCanGoUp = TRUE;
		if (m_yOrigin < m_cyLimit) m_bCanGoDown = TRUE;
	}
	else
	{
		m_cyLimit = 0;
		m_bCanGoUp = m_bCanGoDown = FALSE;
	}
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

void CMainFrame::OnActivateApp(BOOL bActive, HTASK hTask)
{
	CFrameWnd::OnActivateApp(bActive, hTask);
	m_bAppIsActive = bActive;
}

/****************************************************************************\
*                                                                            *
*  CheckForPanning()                                                         *
*                                                                            *
*  The CheckForPanning() function checks if any of the four arrow keys are   *
*  pressed, and if so, pans in that direction if possible. It is called from *
*  CKBdemoApp::Run() when no messages are waiting.                           *
*                                                                            *
\****************************************************************************/

#define KB_ESCAPE 1
#define KB_LEFT  75
#define KB_RIGHT 77
#define KB_UP    72
#define KB_DOWN  80

void CMainFrame::CheckForPanning()
{
	if (fg_kbtest(KB_LEFT) && m_bCanGoLeft)
	{
		if (m_xOrigin == m_cxLimit) m_bCanGoRight = TRUE;
		m_xOrigin--;
		fg_vbpaste(m_xOrigin,m_xOrigin+(vbWidth-1),m_yOrigin,m_yOrigin+(vbHeight-1),0,vbHeight-1);
		if (m_xOrigin == 0) m_bCanGoLeft = FALSE;
	}

	else if (fg_kbtest(KB_RIGHT) && m_bCanGoRight)
	{
		if (m_xOrigin == 0) m_bCanGoLeft = TRUE;
		m_xOrigin++;
		fg_vbpaste(m_xOrigin,m_xOrigin+(vbWidth-1),m_yOrigin,m_yOrigin+(vbHeight-1),0,vbHeight-1);
		if (m_xOrigin == m_cxLimit) m_bCanGoRight = FALSE;
	}

	else if (fg_kbtest(KB_UP) && m_bCanGoUp)
	{
		if (m_yOrigin == m_cyLimit) m_bCanGoDown = TRUE;
		m_yOrigin--;
		fg_vbpaste(m_xOrigin,m_xOrigin+(vbWidth-1),m_yOrigin,m_yOrigin+(vbHeight-1),0,vbHeight-1);
		if (m_yOrigin == 0) m_bCanGoUp = FALSE;
	}

	else if (fg_kbtest(KB_DOWN) && m_bCanGoDown)
	{
		if (m_yOrigin == 0) m_bCanGoUp = TRUE;
		m_yOrigin++;
		fg_vbpaste(m_xOrigin,m_xOrigin+(vbWidth-1),m_yOrigin,m_yOrigin+(vbHeight-1),0,vbHeight-1);
		if (m_yOrigin == m_cyLimit) m_bCanGoDown = FALSE;
	}

	else if (fg_kbtest(KB_ESCAPE))
	{
		m_xOrigin = m_yOrigin = 0;
		fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);
		if (m_cxLimit > 0) m_bCanGoRight = TRUE;
		if (m_cyLimit > 0) m_bCanGoDown = TRUE;
		m_bCanGoLeft = m_bCanGoUp = FALSE;
	}
}

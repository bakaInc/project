/****************************************************************************\
*                                                                            *
*  Strings1.cpp                                                              *
*  Strings1U.cpp                                                             *
*                                                                            *
*  This program shows how to display strings in the client area.             *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "Strings1U.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_setcolor(24);
   fg_fillpage();

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
   DrawStrings();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DrawStrings()
{
   fg_setcolor(19);

   // upper vertical justification
   fg_move(fg_xclient(0),fg_yclient(0));
   fg_justify(-1,1);
   fg_print("FG/Windows",10);
   fg_move(fg_xclient(vbWidth/2),fg_yclient(0));
   fg_justify(0,1);
   fg_print("FG/Windows",10);
   fg_move(fg_xclient(vbWidth-1),fg_yclient(0));
   fg_justify(1,1);
   fg_print("FG/Windows",10);

   // centered vertical justification
   fg_move(fg_xclient(0),fg_yclient(vbHeight/2));
   fg_justify(-1,0);
   fg_print("FG/Windows",10);
   fg_move(fg_xclient(vbWidth/2),fg_yclient(vbHeight/2));
   fg_justify(0,0);
   fg_print("FG/Windows",10);
   fg_move(fg_xclient(vbWidth-1),fg_yclient(vbHeight/2));
   fg_justify(1,0);
   fg_print("FG/Windows",10);

   // lower vertical justification
   fg_move(fg_xclient(0),fg_yclient(vbHeight-1));
   fg_justify(-1,-1);
   fg_print("FG/Windows",10);
   fg_move(fg_xclient(vbWidth/2),fg_yclient(vbHeight-1));
   fg_justify(0,-1);
   fg_print("FG/Windows",10);
   fg_move(fg_xclient(vbWidth-1),fg_yclient(vbHeight-1));
   fg_justify(1,-1);
   fg_print("FG/Windows",10);
}
//---------------------------------------------------------------------------

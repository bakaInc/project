/****************************************************************************\
*                                                                            *
*  Panner.cpp                                                                *
*  PannerU.cpp                                                               *
*                                                                            *
*  This program shows how to pan the contents of a virtual buffer through    *
*  a smaller window.                                                         *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("PannerU.cpp", Form1);
USERES("Panner.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

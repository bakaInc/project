/****************************************************************************\
*                                                                            *
*  TMcube.cpp                                                                *
*  TMcubeU.cpp                                                               *
*                                                                            *
*  This program draws a texture-mapped cube in 3D world space and allows the *
*  user to move and rotate the cube through keyboard controls. A different   *
*  texture is applied to each cube face. Supports linear or perspective      *
*  texture mapping, z-buffering, and 3D clipping through the RENDER_STATE    *
*  symbol defined in TMcubeU.h.                                              *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("TMcubeU.cpp", Form1);
USERES("TMcube.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
        Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

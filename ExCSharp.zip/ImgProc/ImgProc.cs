/****************************************************************************\
*                                                                            *
*  ImgProc.cs                                                                *
*                                                                            *
*  This program demonstrates several of the Fastgraph for Windows image      *
*  processing functions.                                                     *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace ImgProc
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB, hVBoriginal, hVBundo;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		int cxBuffer, cyBuffer;

		// Application variables.
		int nColors;
		byte [] FileHeader = new byte [128];
		string FileName;
		string mbString;

		// Component declarations.
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuFile;
		private System.Windows.Forms.MenuItem menuFileOpen;
		private System.Windows.Forms.MenuItem menuFileSaveAs;
		private System.Windows.Forms.MenuItem menuFileDetails;
		private System.Windows.Forms.MenuItem menuFileExit;
		private System.Windows.Forms.MenuItem menuEdit;
		private System.Windows.Forms.MenuItem menuEditUndo;
		private System.Windows.Forms.MenuItem menuEditRestoreImage;
		private System.Windows.Forms.MenuItem menuEditContrastEnhancement;
		private System.Windows.Forms.MenuItem menuEditGammaCorrection;
		private System.Windows.Forms.MenuItem menuEditGrayscale;
		private System.Windows.Forms.MenuItem menuEditPhotoInversion;
		private System.Windows.Forms.MenuItem menuEditSeparator;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuFile = new System.Windows.Forms.MenuItem();
			this.menuFileOpen = new System.Windows.Forms.MenuItem();
			this.menuFileSaveAs = new System.Windows.Forms.MenuItem();
			this.menuFileDetails = new System.Windows.Forms.MenuItem();
			this.menuFileExit = new System.Windows.Forms.MenuItem();
			this.menuEdit = new System.Windows.Forms.MenuItem();
			this.menuEditUndo = new System.Windows.Forms.MenuItem();
			this.menuEditRestoreImage = new System.Windows.Forms.MenuItem();
			this.menuEditSeparator = new System.Windows.Forms.MenuItem();
			this.menuEditContrastEnhancement = new System.Windows.Forms.MenuItem();
			this.menuEditGammaCorrection = new System.Windows.Forms.MenuItem();
			this.menuEditGrayscale = new System.Windows.Forms.MenuItem();
			this.menuEditPhotoInversion = new System.Windows.Forms.MenuItem();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuFile,
																					  this.menuEdit});
			// 
			// menuFile
			// 
			this.menuFile.Index = 0;
			this.menuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuFileOpen,
																					 this.menuFileSaveAs,
																					 this.menuFileDetails,
																					 this.menuFileExit});
			this.menuFile.Text = "&File";
			// 
			// menuFileOpen
			// 
			this.menuFileOpen.Index = 0;
			this.menuFileOpen.Text = "&Open";
			this.menuFileOpen.Click += new System.EventHandler(this.menuFileOpen_Click);
			// 
			// menuFileSaveAs
			// 
			this.menuFileSaveAs.Enabled = false;
			this.menuFileSaveAs.Index = 1;
			this.menuFileSaveAs.Text = "&Save As";
			this.menuFileSaveAs.Click += new System.EventHandler(this.menuFileSaveAs_Click);
			// 
			// menuFileDetails
			// 
			this.menuFileDetails.Enabled = false;
			this.menuFileDetails.Index = 2;
			this.menuFileDetails.Text = "&Details";
			this.menuFileDetails.Click += new System.EventHandler(this.menuFileDetails_Click);
			// 
			// menuFileExit
			// 
			this.menuFileExit.Index = 3;
			this.menuFileExit.Text = "E&xit";
			this.menuFileExit.Click += new System.EventHandler(this.menuFileExit_Click);
			// 
			// menuEdit
			// 
			this.menuEdit.Index = 1;
			this.menuEdit.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuEditUndo,
																					 this.menuEditRestoreImage,
																					 this.menuEditSeparator,
																					 this.menuEditContrastEnhancement,
																					 this.menuEditGammaCorrection,
																					 this.menuEditGrayscale,
																					 this.menuEditPhotoInversion});
			this.menuEdit.Text = "&Edit";
			// 
			// menuEditUndo
			// 
			this.menuEditUndo.Enabled = false;
			this.menuEditUndo.Index = 0;
			this.menuEditUndo.Text = "&Undo";
			this.menuEditUndo.Click += new System.EventHandler(this.menuEditUndo_Click);
			// 
			// menuEditRestoreImage
			// 
			this.menuEditRestoreImage.Enabled = false;
			this.menuEditRestoreImage.Index = 1;
			this.menuEditRestoreImage.Text = "&Restore Image";
			this.menuEditRestoreImage.Click += new System.EventHandler(this.menuEditRestoreImage_Click);
			// 
			// menuEditSeparator
			// 
			this.menuEditSeparator.Index = 2;
			this.menuEditSeparator.Text = "-";
			// 
			// menuEditContrastEnhancement
			// 
			this.menuEditContrastEnhancement.Enabled = false;
			this.menuEditContrastEnhancement.Index = 3;
			this.menuEditContrastEnhancement.Text = "&Contrast Enhancement";
			this.menuEditContrastEnhancement.Click += new System.EventHandler(this.menuEditContrastEnhancement_Click);
			// 
			// menuEditGammaCorrection
			// 
			this.menuEditGammaCorrection.Enabled = false;
			this.menuEditGammaCorrection.Index = 4;
			this.menuEditGammaCorrection.Text = "&Gamma Correction";
			this.menuEditGammaCorrection.Click += new System.EventHandler(this.menuEditGammaCorrection_Click);
			// 
			// menuEditGrayscale
			// 
			this.menuEditGrayscale.Enabled = false;
			this.menuEditGrayscale.Index = 5;
			this.menuEditGrayscale.Text = "Gr&ayscale";
			this.menuEditGrayscale.Click += new System.EventHandler(this.menuEditGrayscale_Click);
			// 
			// menuEditPhotoInversion
			// 
			this.menuEditPhotoInversion.Enabled = false;
			this.menuEditPhotoInversion.Index = 6;
			this.menuEditPhotoInversion.Text = "&Photo-Inversion";
			this.menuEditPhotoInversion.Click += new System.EventHandler(this.menuEditPhotoInversion_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.ReadOnlyChecked = true;
			this.openFileDialog1.RestoreDirectory = true;
			this.openFileDialog1.ShowReadOnly = true;
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.FileName = "doc1";
			this.saveFileDialog1.RestoreDirectory = true;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Image Processing Demo";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			// Initialize the virtual buffer environment.
			fg.vbinit();
			fg.vbdepth(24);

			// Create the main virtual buffer for the working copy of the image.
			cxBuffer = 32;
			cyBuffer = 32;
			hVB = fg.vballoc(cxBuffer, cyBuffer);
			fg.vbopen(hVB);

			// Create two additional virtual buffers -- one for a copy of the original
			// image, and one used for the undo operation.
			hVBoriginal = fg.vballoc(cxBuffer, cyBuffer);
			hVBundo = fg.vballoc(cxBuffer, cyBuffer);

			// Start with a window full of white pixels.
			fg.setcolor(-1);
			fg.fillpage();
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfree(hVBoriginal);
			fg.vbfree(hVBundo);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		/****************************************************************************\
		*                                                                            *
		*  Event handlers for the items on the File menu.                            *
		*                                                                            *
		\****************************************************************************/

		private void menuFileOpen_Click(object sender, System.EventArgs e)
		{
			// Open the bmp, jpeg, or pcx image file.
			openFileDialog1.FileName = "";
			openFileDialog1.Filter =
				"All image files (*.bmp,*.jpg,*.pcx)|*.BMP;*.JPG;*.PCX|" +
				"BMP files (*.bmp)|*.BMP|" +
				"JPEG files (*.jpg)|*.JPG|" +
				"PCX files (*.pcx)|*.PCX";
			if (openFileDialog1.ShowDialog() != DialogResult.OK) return;
			FileName = openFileDialog1.FileName;

			// Check for a bmp file.
			if (fg.bmphead(FileName, ref FileHeader[0]) == 0)
			{
				this.Cursor = Cursors.WaitCursor;
				nColors = fg.bmppal(FileName, 0);
				fg.bmpsize(ref FileHeader[0], out cxBuffer, out cyBuffer);
				SwitchBuffers();
				fg.showbmp(FileName, 0);
				saveFileDialog1.DefaultExt = "bmp";
			}

			// Check for a jpeg file.
			else if (fg.jpeghead(FileName, ref FileHeader[0]) == 0)
			{
				this.Cursor = Cursors.WaitCursor;
				nColors = 0;
				fg.jpegsize(ref FileHeader[0], out cxBuffer, out cyBuffer);
				SwitchBuffers();
				fg.showjpeg(FileName, 0);
				saveFileDialog1.DefaultExt = "pcx";
			}

			// Check for a pcx file.
			else if (fg.pcxhead(FileName, ref FileHeader[0]) == 0)
			{
				this.Cursor = Cursors.WaitCursor;
				nColors = fg.pcxpal(FileName, 0);
				fg.pcxsize(ref FileHeader[0], out cxBuffer, out cyBuffer);
				SwitchBuffers();
				fg.move(0, 0);
				fg.showpcx(FileName, fg.AT_XY);
				saveFileDialog1.DefaultExt = "pcx";
			}

			// The file is not a valid bmp, jpeg, or pcx file.
			else
			{
				mbString = FileName + "\nis not a recognized image file.";
				MessageBox.Show(mbString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			// Make a copy of the original image.
			fg.copypage(hVB, hVBoriginal);

			// Display the image.
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			this.Cursor = Cursors.Default;

			// Enable remaining items on the File menu, and the image processing
			// items on the Edit menu.
			menuFileSaveAs.Enabled = true;
			menuFileDetails.Enabled = true;
			menuEditUndo.Enabled = false;
			menuEditRestoreImage.Enabled = false;
			menuEditContrastEnhancement.Enabled = true;
			menuEditGammaCorrection.Enabled = true;
			menuEditGrayscale.Enabled = true;
			menuEditPhotoInversion.Enabled = true;
		}

		private void menuFileSaveAs_Click(object sender, System.EventArgs e)
		{
			// Save image as a bmp file (original image was bmp).
			if (saveFileDialog1.DefaultExt == "bmp")
			{
				saveFileDialog1.FileName = FileName.Substring(0, FileName.IndexOf(".")) + ".bmp";
				saveFileDialog1.Filter = "BMP files (*.bmp)|*.BMP";
				if (saveFileDialog1.ShowDialog() != DialogResult.OK) return;
				FileName = saveFileDialog1.FileName;
				this.Cursor = Cursors.WaitCursor;
				fg.makebmp(0, cxBuffer-1, 0, cyBuffer-1, 24, FileName);
				nColors = 0;
				this.Cursor = Cursors.Default;
			}

			// Save image as a pcx file (original image was jpeg or pcx).
			else if (saveFileDialog1.DefaultExt == "pcx")
			{
				saveFileDialog1.FileName = FileName.Substring(0, FileName.IndexOf(".")) + ".pcx";
				saveFileDialog1.Filter = "PCX files (*.pcx)|*.PCX";
				if (saveFileDialog1.ShowDialog() != DialogResult.OK) return;
				FileName = saveFileDialog1.FileName;
				this.Cursor = Cursors.WaitCursor;
				fg.makepcx(0, cxBuffer-1, 0, cyBuffer-1, FileName);
				nColors = 0;
				this.Cursor = Cursors.Default;
			}
		}

		private void menuFileDetails_Click(object sender, System.EventArgs e)
		{
			// Display the original image resolution and color depth.
			mbString = FileName + String.Format("\n{0:0}x{1:0} pixels\n", cxBuffer, cyBuffer);
			if (nColors > 0)
				mbString += String.Format("{0:0} colors", nColors);
			else
				mbString += "24-bit RGB";
			MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void menuFileExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		/****************************************************************************\
		*                                                                            *
		*  Event handlers for the items on the Edit menu.                            *
		*                                                                            *
		\****************************************************************************/

		private void menuEditUndo_Click(object sender, System.EventArgs e)
		{
			// Undo the previous image processing operation.
			fg.copypage(hVBundo, hVB);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			menuEditUndo.Enabled = false;
			menuEditRestoreImage.Enabled = true;
		}

		private void menuEditRestoreImage_Click(object sender, System.EventArgs e)
		{
			// Restore the original image.
			fg.copypage(hVB, hVBundo);
			fg.copypage(hVBoriginal, hVB);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			menuEditUndo.Enabled = true;
			menuEditRestoreImage.Enabled = false;
		}

		private void menuEditContrastEnhancement_Click(object sender, System.EventArgs e)
		{
			// Perform a contrast enhancement transform on the active virtual buffer.
			fg.copypage(hVB, hVBundo);
			fg.move(0, cyBuffer-1);
			fg.contvb(63, 192, cxBuffer, cyBuffer);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			menuEditUndo.Enabled = true;
			menuEditRestoreImage.Enabled = true;
		}

		private void menuEditGammaCorrection_Click(object sender, System.EventArgs e)
		{
			// Perform a gamma correction transform on the active virtual buffer.
			fg.copypage(hVB, hVBundo);
			fg.move(0, cyBuffer-1);
			fg.gammavb(0.45, cxBuffer, cyBuffer);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			menuEditUndo.Enabled = true;
			menuEditRestoreImage.Enabled = true;
		}

		private void menuEditGrayscale_Click(object sender, System.EventArgs e)
		{
			// Perform a grayscale transform on the active virtual buffer.
			fg.copypage(hVB, hVBundo);
			fg.move(0, cyBuffer-1);
			fg.grayvb(cxBuffer, cyBuffer);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			menuEditUndo.Enabled = true;
			menuEditRestoreImage.Enabled = true;
		}

		private void menuEditPhotoInversion_Click(object sender, System.EventArgs e)
		{
			// Perform a photo-inversion transform on the active virtual buffer.
			fg.copypage(hVB, hVBundo);
			fg.move(0, cyBuffer-1);
			fg.photovb(cxBuffer, cyBuffer);
			fg.vbscale(0, cxBuffer-1, 0, cyBuffer-1, 0, cxClient-1, 0, cyClient-1);
			menuEditUndo.Enabled = true;
			menuEditRestoreImage.Enabled = true;
		}

		/****************************************************************************\
		*                                                                            *
		*  SwitchBuffers()                                                           *
		*                                                                            *
		*  Close the and release the virtual buffers for the current image, then     *
		*  create and open new virtual buffers for the new image file.               *
		*                                                                            *
		\****************************************************************************/

		private void SwitchBuffers()
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfree(hVBoriginal);
			fg.vbfree(hVBundo);
			hVB = fg.vballoc(cxBuffer, cyBuffer);
			fg.vbopen(hVB);
			hVBoriginal = fg.vballoc(cxBuffer, cyBuffer);
			hVBundo = fg.vballoc(cxBuffer, cyBuffer);
		}
	}
}
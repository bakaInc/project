/****************************************************************************\
*                                                                            *
*  Display.cpp                                                               *
*  DisplayU.cpp                                                              *
*                                                                            *
*  This program resizes the desktop to 800x600 using the fg_modeset()        *
*  function.                                                                 *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("DisplayU.cpp", Form1);
USERES("Display.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
        Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

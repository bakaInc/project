/****************************************************************************\
*                                                                            *
*  PCXflip.cpp                                                               *
*  PCXflipU.cpp                                                              *
*                                                                            *
*  This program displays a 320x200 PCX file mirrored about the y-axis using  *
*  the bitmap display routines.                                              *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("PCXflipU.cpp", Form1);
USERES("PCXflip.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

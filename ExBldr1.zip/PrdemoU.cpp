/****************************************************************************\
*                                                                            *
*  Prdemo.cpp                                                                *
*  PrdemoU.cpp                                                               *
*                                                                            *
*  This program shows how to print the contents of a virtual buffer.  It     *
*  first loads a 640x480 BMP file into a virtual buffer and displays it.     *
*  When the user clicks the Print selection on the top-level menu, a 6-inch  *
*  by 4-inch copy of the BMP image is sent to the selected printer.          *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "PrdemoU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_showbmp("PORCH.BMP",0);

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::PrintClick(TObject *Sender)
{
   if (!PrintDialog->Execute()) return;
   Cursor = crHourGlass;
   Printer()->BeginDoc();
   fg_printdc(Printer()->Handle);
   fg_vbprint(0,vbWidth-1,0,vbHeight-1,0,600,0,400,2);
   Printer()->EndDoc();
   Cursor = crDefault;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitClick(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------

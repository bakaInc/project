/****************************************************************************\
*                                                                            *
*  MCdemo.cpp                                                                *
*  MCdemoU.cpp                                                               *
*                                                                            *
*  This program shows how to change the shape of the mouse cursor.           *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("MCdemoU.cpp", Form1);
USERES("MCdemo.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
        Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

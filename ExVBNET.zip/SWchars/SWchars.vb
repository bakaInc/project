'*****************************************************************************
'                                                                            *
'  SWchars.vb                                                                *
'                                                                            *
'  This program displays all characters in the Fastgraph for Windows primary *
'  and alternate software fonts.                                             *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim xDest, yDest As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 640
    Const vbHeight As Integer = 480

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(640, 480)
        Me.Name = "Form1"
        Me.Text = "Software Character Set"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        fg_initw()
        fg_setworld(0.0, 6.39, 0.0, 4.79)
        fg_setsizew(0.2)

        fg_setcolor(25)
        fg_fillpage()
        fg_setcolor(19)
        fg_movew(3.2, 4.2)
        fg_swchar("Software characters - font 1", 28, 0)
        fg_setcolor(10)
        fg_movew(0.5, 3.9)
        fg_swchar("ABCDEFGHIJKLMNOPQRSTUVWXYZ", 26, -1)
        fg_movew(0.5, 3.6)
        fg_swchar("abcdefghijklmnopqrstuvwxyz", 26, -1)
        fg_movew(0.5, 3.3)
        fg_swchar("0123456789", 10, -1)
        fg_movew(0.5, 3.0)
        fg_swchar("!""#$%&='()*+,-./:;<=>?[]^`{|}~", 29, -1)

        fg_setcolor(19)
        fg_movew(3.2, 2.5)
        fg_swchar("Software characters - font 2", 28, 0)
        fg_setcolor(10)
        fg_movew(0.5, 2.2)
        fg_swchar("\ABCDEFGHIJKLMNOPRSTUWXYZ", 25, -1)
        fg_movew(0.5, 1.9)
        fg_swchar("\abcdefghijklmnoprstuwxyz", 25, -1)
        fg_movew(0.5, 1.3)
        fg_swchar("\012345678#$%&()*+/<=>?[]{}", 27, -1)

        fg_setratio(1.2)
        fg_movew(0.5, 0.6)
        fg_swchar("cos\^2\h\+sin\^2\h\=1", 21, -1)

        fg_movew(5.9, 0.6)
        fg_swchar("H\v2O U\v2\v3\v2", 16, 1)

        fg_setratio(1.0)
        fg_movew(3.2, 0.2)
        fg_swchar("One _word_ is underlined.", 25, 0)

        fg_setcolor(19)
        fg_movew(0.0, 2.8)
        fg_draww(6.39, 2.8)
        fg_movew(0.0, 0.9)
        fg_draww(6.39, 0.9)
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbpaste(0, vbWidth - 1, 0, vbHeight - 1, xDest, yDest)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        xDest = (ClientRectangle.Width - vbWidth) \ 2
        yDest = (ClientRectangle.Height - vbHeight) \ 2
        If xDest < 0 Then xDest = 0
        If yDest < 0 Then yDest = 0
        yDest = (ClientRectangle.Height - 1) - yDest
        Refresh()
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub
End Class
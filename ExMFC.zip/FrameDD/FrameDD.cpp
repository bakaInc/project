/****************************************************************************\
*                                                                            *
*  FrameDD.cpp                                                               *
*                                                                            *
*  This program shows how to set up a full screen DirectDraw application     *
*  for either blitting or flipping. The selection of blitting or flipping is *
*  controlled by the BLIT and FLIP symbols defined in MainFrame.cpp.         *
*                                                                            *
\****************************************************************************/

// FrameDD.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "FrameDD.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFrameDDApp

BEGIN_MESSAGE_MAP(CFrameDDApp, CWinApp)
	//{{AFX_MSG_MAP(CFrameDDApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFrameDDApp construction

CFrameDDApp::CFrameDDApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFrameDDApp object

CFrameDDApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CFrameDDApp initialization

BOOL CFrameDDApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"DirectDraw Frame Animation"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->UpdateWindow();

	return TRUE;
}

int CFrameDDApp::Run()
{
	if (!m_pMainWnd)
		AfxPostQuitMessage(0);

	MSG msg;
	CMainFrame* pFrame = STATIC_DOWNCAST(CMainFrame, m_pMainWnd);

	while (TRUE)
	{
		//see if there is a message waiting
		if (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			do //if there is pump all waiting
			{
				if (!PumpMessage())
					return ExitInstance();
			} while (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE));
		}
		else
		{
			if (!pFrame->m_bAppIsActive)
				WaitMessage();
			else
				pFrame->Animate();
		}
	}
	return msg.wParam;
}

/////////////////////////////////////////////////////////////////////////////
// CFrameDDApp message handlers

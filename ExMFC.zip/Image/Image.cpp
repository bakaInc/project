/****************************************************************************\
*                                                                            *
*  Image.cpp                                                                 *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows image file display    *
*  and creation functions.                                                   *
*                                                                            *
\****************************************************************************/

// Image.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Image.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImageApp

BEGIN_MESSAGE_MAP(CImageApp, CWinApp)
	//{{AFX_MSG_MAP(CImageApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImageApp construction

CImageApp::CImageApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CImageApp object

CImageApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CImageApp initialization

BOOL CImageApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->LoadFrame(IDR_MAINFRAME, WS_OVERLAPPEDWINDOW|FWS_ADDTOTITLE,
		NULL, NULL))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CImageApp message handlers

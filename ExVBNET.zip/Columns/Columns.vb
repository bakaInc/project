'*****************************************************************************
'                                                                            *
'  Columns.vb                                                                *
'                                                                            *
'  This program draws a grid of columns in 3D world space. It demonstrates   *
'  polygon culling and Fastgraph's incremental POV functions.                *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim hZB As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 600
    Const vbHeight As Integer = 400

    Const InfoHeight As Integer = 80
    Const WinWidth As Integer = vbWidth
    Const WinHeight As Integer = (vbHeight + InfoHeight)

    ' Six faces of a 2x2x10 column, defined in object coordinates.
    ' Order of faces is top, front, left, right, bottom, back.
    Dim ColumnData(,) As Double = { _
        {-1.0, 10.0, 1.0, 1.0, 10.0, 1.0, 1.0, 10.0, -1.0, -1.0, 10.0, -1.0}, _
        {-1.0, 10.0, -1.0, 1.0, 10.0, -1.0, 1.0, 0.0, -1.0, -1.0, 0.0, -1.0}, _
        {-1.0, 10.0, 1.0, -1.0, 10.0, -1.0, -1.0, 0.0, -1.0, -1.0, 0.0, 1.0}, _
        {1.0, 10.0, -1.0, 1.0, 10.0, 1.0, 1.0, 0.0, 1.0, 1.0, 0.0, -1.0}, _
        {-1.0, 0.0, -1.0, 1.0, 0.0, -1.0, 1.0, 0.0, 1.0, -1.0, 0.0, 1.0}, _
        {1.0, 10.0, 1.0, -1.0, 10.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0, 1.0}}

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "3D Columns"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        ' Initialize the virtual buffer environment.
        fg_vbinit()
        fg_vbdepth(fg_colors())

        ' Create and open the virtual buffer.
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        ' Create and open the z-buffer.
        hZB = fg_zballoc(vbWidth, vbHeight)
        fg_zbopen(hZB)

        ' Define 3D viewport, render state, and initial POV.
        fg_3Dviewport(0, vbWidth - 1, 0, vbHeight - 1, 1.0)
        fg_3Drenderstate(FG_ZBUFFER + FG_ZCLIP)
        fg_3Dlookat(10.0, 20.0, 100.0, 0.0, 20.0, 0.0)

        ' Direct strings to the active virtual buffer.
        fg_fontdc(fg_getdc())

        ' Make the client area equal to the required size.
        Me.Location = New Point(0, 0)
        Me.ClientSize = New Size(WinWidth, WinHeight)

        ' Enable the timer so CheckForMotion() is called every 10ms.
        Timer1.Enabled = True
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        DrawColumns()
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_zbfree(hZB)
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        CheckForMotion()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  CheckForMotion()                                                          *
    '                                                                            *
    '  The CheckForMotion() function checks for key presses that control the     *
    '  viewer's position and orientation, and if required redraws the scene at   *
    '  its new POV. It is called every 10ms from the timer's OnTick event        *
    '  handler.                                                                  *
    '                                                                            *
    '*****************************************************************************

    Private Sub CheckForMotion()
        Dim ShiftKey As Boolean

        ' Check if either shift key is pressed.
        ShiftKey = (fg_kbtest(42) = 1) Or (fg_kbtest(54) = 1)

        If fg_kbtest(71) = 1 Then ' Home
            fg_3Dmoveup(5.0)
            DrawColumns()

        ElseIf fg_kbtest(72) = 1 Then  ' Up arrow
            fg_3Dmoveforward(5.0)
            DrawColumns()

        ElseIf fg_kbtest(73) = 1 Then  ' PgUp
            fg_3Drotateup(100)
            DrawColumns()

        ElseIf fg_kbtest(75) = 1 Then  ' Left arrow
            If (ShiftKey) Then
                fg_3Dmoveright(-5.0)
            Else
                fg_3Drotateright(-100)
            End If
            DrawColumns()

        ElseIf fg_kbtest(77) = 1 Then  ' Right arrow
            If (ShiftKey) Then
                fg_3Dmoveright(5.0)
            Else
                fg_3Drotateright(100)
            End If
            DrawColumns()

        ElseIf fg_kbtest(79) = 1 Then  ' End
            fg_3Dmoveup(-5.0)
            DrawColumns()

        ElseIf fg_kbtest(80) = 1 Then  ' Down arrow
            fg_3Dmoveforward(-5.0)
            DrawColumns()

        ElseIf fg_kbtest(81) = 1 Then  ' PgDn
            fg_3Drotateup(-100)
            DrawColumns()
        End If
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  DrawColumns()                                                             *
    '                                                                            *
    '  Draws each of the six cube faces in 3D world space.                       *
    '                                                                            *
    '*****************************************************************************

    Private Sub DrawColumns()
        Dim nColor(6) As Integer
        Dim nRow, nCol As Integer
        Dim I As Integer

        ' Prepare for the new frame.
        fg_zbframe()
        fg_setcolor(-1)
        fg_fillpage()

        ' Create the six encoded color values.
        nColor(0) = fg_maprgb(254, 219, 164)
        nColor(1) = fg_maprgb(243, 194, 117)
        nColor(2) = fg_maprgb(226, 172, 86)
        nColor(3) = fg_maprgb(203, 150, 67)
        nColor(4) = fg_maprgb(123, 98, 59)
        nColor(5) = fg_maprgb(166, 125, 60)

        ' 50x50x6 = 15000 polygons per frame.
        For nRow = -500 To 480 Step 20
            For nCol = -500 To 480 Step 20
                If fg_3Dbehindviewer(CDbl(nRow), 0.0, CDbl(nCol), -1.0) = 0 Then
                    fg_3Dmoveobject(CDbl(nRow), 0.0, CDbl(nCol))

                    ' Draw all the faces.
                    For I = 0 To 5
                        ' Set the color.
                        fg_setcolor(nColor(I))

                        ' Draw the face.
                        fg_3Dpolygonobject(ColumnData(I, 0), 4)
                    Next I
                End If
            Next nCol
        Next nRow

        ' Display the scene.
        fg_vbpaste(0, vbWidth - 1, 0, vbHeight - 1, 0, vbHeight - 1)

        ' Display the 3D information at the bottom of the window.
        UpdateInfo()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  UpdateInfo()                                                              *
    '                                                                            *
    '  Displays the information at the bottom of the window.                     *
    '                                                                            *
    '*****************************************************************************

    Private Sub UpdateInfo()
        Dim x, y, z As Double
        Dim xDir, yDir, zDir As Double
        Dim MessageText As String

        ' Get current position and direction.
        fg_3Dgetpov(x, y, z, xDir, yDir, zDir)

        ' Clear an area to write on.
        fg_setcolorrgb(0, 0, 140)
        fg_rect(0, 249, 0, InfoHeight - 1)

        fg_setcolorrgb(0, 140, 0)
        fg_rect(250, vbWidth - 1, 0, InfoHeight - 1)

        fg_setcolor(-1)

        ' Print current position and unit vector.
        fg_move(20, 32)
        MessageText = String.Format("x = {0:###0.00}  xDir = {1:###0.00}", x, xDir)
        fg_print(MessageText, MessageText.Length)

        fg_move(20, 46)
        MessageText = String.Format("y = {0:###0.00}  yDir = {1:###0.00}", y, yDir)
        fg_print(MessageText, MessageText.Length)

        fg_move(20, 60)
        MessageText = String.Format("z = {0:###0.00}  zDir = {1:###0.00}", z, zDir)
        fg_print(MessageText, MessageText.Length)

        ' Print instructions.
        fg_move(270, 18)
        MessageText = "Up    = move forward   Home = move up"
        fg_print(MessageText, MessageText.Length)

        fg_move(270, 32)
        MessageText = "Down  = move back      End  = move down"
        fg_print(MessageText, MessageText.Length)

        fg_move(270, 46)
        MessageText = "Left  = turn left      PgUp = look up"
        fg_print(MessageText, MessageText.Length)

        fg_move(270, 60)
        MessageText = "Right = turn right     PgDn = look down"
        fg_print(MessageText, MessageText.Length)

        fg_move(290, 74)
        MessageText = "Shift+Left/Right = move left/right"
        fg_print(MessageText, MessageText.Length)

        fg_vbpaste(0, vbWidth - 1, 0, InfoHeight - 1, 0, WinHeight - 1)
    End Sub
End Class
/****************************************************************************\
*                                                                            *
*  Panner.cpp                                                                *
*                                                                            *
*  This program shows how to pan the contents of a virtual buffer through    *
*  a smaller window.                                                         *
*                                                                            *
\****************************************************************************/

// Panner.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Panner.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPannerApp

BEGIN_MESSAGE_MAP(CPannerApp, CWinApp)
	//{{AFX_MSG_MAP(CPannerApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPannerApp construction

CPannerApp::CPannerApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CPannerApp object

CPannerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CPannerApp initialization

BOOL CPannerApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->LoadFrame(IDR_MAINFRAME, WS_OVERLAPPEDWINDOW|FWS_ADDTOTITLE,
		NULL, NULL))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CPannerApp message handlers

/****************************************************************************\
*                                                                            *
*  Scale.cpp                                                                 *
*  ScaleU.cpp                                                                *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows 256-color bitmap      *
*  scaling and shearing functions.                                           *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "ScaleU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_setcolor(20);
   fg_fillpage();

   // draw 40x20 bird (original bitmap)
   fg_move(6,80);
   fg_drwimage(Bird,40,20);

   // draw 50x25 bird
   fg_move(48,80);
   fg_scale(Bird,ScaledBird,40,20,50,25);
   fg_drwimage(ScaledBird,50,25);

   // draw 60x30 bird
   fg_move(100,80);
   fg_scale(Bird,ScaledBird,40,20,60,30);
   fg_drwimage(ScaledBird,60,30);

   // draw 70x35 bird
   fg_move(162,80);
   fg_scale(Bird,ScaledBird,40,20,70,35);
   fg_drwimage(ScaledBird,70,35);

   // draw 80x40 bird
   fg_move(234,80);
   fg_scale(Bird,ScaledBird,40,20,80,40);
   fg_drwimage(ScaledBird,80,40);

   // draw 50x20 bird sheared left horizontally
   fg_move(55,160);
   fg_shear(Bird,ScaledBird,40,20,50,0);
   fg_drwimage(ScaledBird,50,20);

   // draw 50x20 bird sheared right horizontally
   fg_move(115,160);
   fg_shear(Bird,ScaledBird,40,20,50,1);
   fg_drwimage(ScaledBird,50,20);

   // draw 40x30 bird sheared left vertically
   fg_move(175,160);
   fg_shear(Bird,ScaledBird,40,20,30,2);
   fg_drwimage(ScaledBird,40,30);

   // draw 40x30 bird sheared left vertically
   fg_move(225,160);
   fg_shear(Bird,ScaledBird,40,20,30,3);
   fg_drwimage(ScaledBird,40,30);

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------

// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Columns.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// six faces of a 2x2x10 column, defined in object coordinates
double ColumnData[6][12] =
{
	{-1.0,10.0, 1.0,  1.0,10.0, 1.0,  1.0,10.0,-1.0, -1.0,10.0,-1.0}, // top
	{-1.0,10.0,-1.0,  1.0,10.0,-1.0,  1.0, 0.0,-1.0, -1.0, 0.0,-1.0}, // front
	{-1.0,10.0, 1.0, -1.0,10.0,-1.0, -1.0, 0.0,-1.0, -1.0, 0.0, 1.0}, // left
	{ 1.0,10.0,-1.0,  1.0,10.0, 1.0,  1.0, 0.0, 1.0,  1.0, 0.0,-1.0}, // right
	{-1.0, 0.0,-1.0,  1.0, 0.0,-1.0,  1.0, 0.0, 1.0, -1.0, 0.0, 1.0}, // bottom
	{ 1.0,10.0, 1.0, -1.0,10.0, 1.0, -1.0, 0.0, 1.0,  1.0, 0.0, 1.0}  // back
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_PAINT()
	ON_WM_ACTIVATEAPP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_hZB = -1;
	m_bAppIsActive = FALSE;
}

CMainFrame::~CMainFrame()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	if (m_hZB >= 0)
	{
		fg_zbfree(m_hZB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.x = 0;
	cs.y = 0;
	cs.cx = WinWidth;
	cs.cy = WinHeight;
	cs.style = WS_POPUPWINDOW | WS_CAPTION | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
		// set up the device context and logical palette
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		// initialize the virtual buffer environment
		fg_vbinit();
		fg_vbdepth(fg_colors());

		// create and open the virtual buffer
		m_hVB = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		// create and open the z-buffer
		m_hZB = fg_zballoc(vbWidth,vbHeight);
		fg_zbopen(m_hZB);

		// define 3D viewport, render state, and initial POV
		fg_3Dviewport(0,vbWidth-1,0,vbHeight-1,1.0);
		fg_3Drenderstate(FG_ZBUFFER|FG_ZCLIP);
		fg_3Dlookat(10.0,20.0,100.0,0.0,20.0,0.0);

		// direct strings to the active virtual buffer
		fg_fontdc(fg_getdc());

		// make the client area equal to the required size
		ShowWindow(SW_SHOWNORMAL);
		SetWindowSize(WinWidth,WinHeight);

		m_bAppIsActive = TRUE;
	}
	return bRet;
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	DrawColumns();
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

void CMainFrame::OnActivateApp(BOOL bActive, HTASK hTask)
{
	CFrameWnd::OnActivateApp(bActive, hTask);
	m_bAppIsActive = bActive;
}

/****************************************************************************\
*                                                                            *
*  CheckForMotion()                                                          *
*                                                                            *
*  The CheckForMotion() function checks for key presses that control the     *
*  viewer's position and orientation, and if required redraws the scene at   *
*  its new POV. It is called from CColumnsApp::Run() when there are no       *
*  messages waiting.                                                         *
*                                                                            *
\****************************************************************************/

void CMainFrame::CheckForMotion()
{
	BOOL ShiftKey;

	// check if either shift key is pressed
	ShiftKey = fg_kbtest(42) | fg_kbtest(54);

	if (fg_kbtest(71))      // Home
	{
		fg_3Dmoveup(5.0);
		DrawColumns();
	}
	else if (fg_kbtest(72)) // Up arrow
	{
		fg_3Dmoveforward(5.0);
		DrawColumns();
	}
	else if (fg_kbtest(73)) // PgUp
	{
		fg_3Drotateup(100);
		DrawColumns();
	}
	else if (fg_kbtest(75)) // Left arrow
	{
		if (ShiftKey)
			fg_3Dmoveright(-5.0);
		else
			fg_3Drotateright(-100);
		DrawColumns();
	}
	else if (fg_kbtest(77)) // Right arrow
	{
		if (ShiftKey)
			fg_3Dmoveright(5.0);
		else
			fg_3Drotateright(100);
		DrawColumns();
	}
	else if (fg_kbtest(79)) // End
	{
		fg_3Dmoveup(-5.0);
		DrawColumns();
	}
	else if (fg_kbtest(80)) // Down arrow
	{
		fg_3Dmoveforward(-5.0);
		DrawColumns();
	}
	else if (fg_kbtest(81)) // PgDn
	{
		fg_3Drotateup(-100);
		DrawColumns();
	}
}

/****************************************************************************\
*                                                                            *
*  DrawColumns()                                                             *
*                                                                            *
*  Draws the scene at its new POV. Columns behind the viewer are culled out. *
*                                                                            *
\****************************************************************************/

void CMainFrame::DrawColumns()
{
	static int r[] = {254,243,226,203,123,166};
	static int g[] = {219,194,172,150, 98,125};
	static int b[] = {164,117, 86, 67, 59, 60};
	int nColor[6];
	int row, col;
	register int i;

	// prepare for the new frame
	fg_zbframe();
	fg_setcolor(-1);
	fg_fillpage();

	// create the six encoded color values
	for (i = 0; i < 6; i++)
		nColor[i] = fg_maprgb(r[i],g[i],b[i]);

	// 50x50x6 = 15000 polygons per frame
	for (row = -500; row < 500; row += 20)
	{
		for (col = -500; col < 500; col += 20)
		{
			if (fg_3Dbehindviewer((double)row,0.0,(double)col,-1.0) == 0)
			{
				fg_3Dmoveobject((double)row,0.0,(double)col);

				// draw all the faces
				for (i = 0; i < 6; i++)
				{
					// set the color
					fg_setcolor(nColor[i]);

					// draw the face
					fg_3Dpolygonobject(ColumnData[i],4);
				}
			}
		}
	}

	// display the scene
	fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);

	// display the 3D information at the bottom of the window
	UpdateInfo();
}

/****************************************************************************\
*                                                                            *
*  UpdateInfo()                                                              *
*                                                                            *
*  Displays the information at the bottom of the window.                     *
*                                                                            *
\****************************************************************************/

void CMainFrame::UpdateInfo()
{
	double x, y, z, xDir, yDir, zDir;
	char String[64];

	// get current position and direction
	fg_3Dgetpov(&x,&y,&z,&xDir,&yDir,&zDir);

	// clear an area to write on
	fg_setcolorrgb(0,0,140);
	fg_rect(0,249,0,InfoHeight-1);

	fg_setcolorrgb(0,140,0);
	fg_rect(250,vbWidth-1,0,InfoHeight-1);

	fg_setcolor(-1);

	// print current position and unit vector
	fg_move(20,32);
	sprintf(String,"x =%7.2f  xDir = %7.2f",x,xDir);
	fg_print(String,strlen(String));

	fg_move(20,46);
	sprintf(String,"y =%7.2f  yDir = %7.2f",y,yDir);
	fg_print(String,strlen(String));

	fg_move(20,60);
	sprintf(String,"z =%7.2f  zDir = %7.2f",z,zDir);
	fg_print(String,strlen(String));

	// print instructions
	fg_move(270,18);
	sprintf(String,"Up    = move forward   Home = move up");
	fg_print(String,strlen(String));

	fg_move(270,32);
	sprintf(String,"Down  = move back      End  = move down");
	fg_print(String,strlen(String));

	fg_move(270,46);
	sprintf(String,"Left  = turn left      PgUp = look up");
	fg_print(String,strlen(String));

	fg_move(270,60);
	sprintf(String,"Right = turn right     PgDn = look down");
	fg_print(String,strlen(String));

	fg_move(290,74);
	sprintf(String,"Shift+Left/Right = move left/right");
	fg_print(String,strlen(String));

	fg_vbpaste(0,vbWidth-1,0,InfoHeight-1,0,WinHeight-1);
}

/****************************************************************************\
*                                                                            *
*  SetWindowSize()                                                           *
*                                                                            *
*  Sets the window size so the client area has the specified dimensions.     *
*                                                                            *
\****************************************************************************/

void CMainFrame::SetWindowSize(int ClientWidth, int ClientHeight)
{
	RECT ClientRect;
	RECT WindowRect;
	int WindowWidth, WindowHeight;

	GetClientRect(&ClientRect);
	GetWindowRect(&WindowRect);

	WindowWidth = ClientWidth +
		(WindowRect.right - WindowRect.left) -
		(ClientRect.right - ClientRect.left);
	WindowHeight = ClientHeight +
		(WindowRect.bottom - WindowRect.top) -
		(ClientRect.bottom - ClientRect.top);
	SetWindowPos(NULL,0,0,WindowWidth,WindowHeight,SWP_NOMOVE|SWP_NOZORDER);
}

/****************************************************************************\
*                                                                            *
*  Cube.cpp                                                                  *
*                                                                            *
*  This program draws a cube in 3D world space and allows the user to move   *
*  and rotate the cube through keyboard controls. Each of the six cube faces *
*  is a different color.                                                     *
*                                                                            *
\****************************************************************************/

// Cube.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Cube.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCubeApp

BEGIN_MESSAGE_MAP(CCubeApp, CWinApp)
	//{{AFX_MSG_MAP(CCubeApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCubeApp construction

CCubeApp::CCubeApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCubeApp object

CCubeApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CCubeApp initialization

BOOL CCubeApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Single 3D Cube"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

int CCubeApp::Run()
{
	if (!m_pMainWnd)
		AfxPostQuitMessage(0);

	MSG msg;
	CMainFrame* pFrame = STATIC_DOWNCAST(CMainFrame, m_pMainWnd);

	while (TRUE)
	{
		//see if there is a message waiting
		if (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			do //if there is pump all waiting
			{
				if (!PumpMessage())
					return ExitInstance();
			} while (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE));
		}
		else
		{
			if (!pFrame->m_bAppIsActive)
				WaitMessage();
			else
				pFrame->CheckForMovement();
		}
	}
	return msg.wParam;
}

/////////////////////////////////////////////////////////////////////////////
// CCubeApp message handlers

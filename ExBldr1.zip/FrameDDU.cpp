/****************************************************************************\
*                                                                            *
*  FrameDD.cpp                                                               *
*  FrameDDU.cpp                                                              *
*                                                                            *
*  This program shows how to set up a full screen DirectDraw application     *
*  for either blitting or flipping. The selection of blitting or flipping is *
*  controlled by the BLIT and FLIP symbols defined in FrameDDU.h.            *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "FrameDDU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OnActivate(TObject *Sender)
{
   fg_realize(hPal);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OnIdle(TObject *Sender, bool &Done)
{
   if (AppIsActive) Animate();
   Done = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::WMActivateApp(TMessage &Msg)
{
   AppIsActive = Msg.WParam;
   if (AppIsActive) fg_ddrestore();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
#ifdef BLIT
   fg_ddsetup(vbWidth,vbHeight,8,FG_DX_BLIT);
#else
   fg_ddsetup(vbWidth,vbHeight,8,FG_DX_FLIP);
#endif
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);
   Visible = True;

   fg_vbinit();
   // if blitting, create a virtual buffer the same size as the screen
   // resolution; if flipping, use the primary surface's back buffer
#ifdef BLIT
   hVB = fg_vballoc(vbWidth,vbHeight);
#else
   hVB = 0;
#endif
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_mouseini();
   fg_mousevis(0);

   Application->OnActivate = OnActivate;
   Application->OnIdle = OnIdle;
   AppIsActive = True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
	TShiftState Shift)
{
   if (Key == VK_ESCAPE || Key == VK_F12) Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_mousevis(1);
   fg_vbclose();
#ifdef BLIT
   fg_vbfree(hVB);
#endif
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
   Application->Minimize();
}

/****************************************************************************\
*                                                                            *
*  Animate()                                                                 *
*                                                                            *
*  Construct the next frame of animation and display it with either blitting *
*  or flipping, as directed by the BLIT and FLIP symbols above.              *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::Animate()
{
   // fill drawing surface with the next color
   fg_setcolor((fg_getcolor() + 1) & 0xFF);
   fg_fillpage();

   // blit or flip the surface to the screen
#ifdef BLIT
   fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);
#else
   fg_ddflip();
#endif
}
//---------------------------------------------------------------------------

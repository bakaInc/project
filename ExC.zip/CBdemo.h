//---------------------
// CBdemo.h header file
//---------------------

#define IDM_Cut   1
#define IDM_Paste 2
#define IDM_Exit  3

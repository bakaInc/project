// Rotate.h : main header file for the ROTATE application
//
#if !defined(AFX_ROTATE_H__ABF79781_7FD4_11D2_8EB9_204C4F4F5020__INCLUDED_)
#define AFX_ROTATE_H__ABF79781_7FD4_11D2_8EB9_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CRotateApp:
// See Rotate.cpp for the implementation of this class
//

class CRotateApp : public CWinApp
{
public:
	CRotateApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRotateApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

public:
	//{{AFX_MSG(CRotateApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ROTATE_H__ABF79781_7FD4_11D2_8EB9_204C4F4F5020__INCLUDED_)

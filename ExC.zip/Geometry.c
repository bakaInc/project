/****************************************************************************\
*                                                                            *
*  Geometry.c                                                                *
*                                                                            *
*  This program shows how to display 3D objects in object space and 3D world *
*  space.                                                                    *
*                                                                            *
\****************************************************************************/

#include <fgwin.h>

#define vbWidth  300
#define vbHeight 300

// six faces of a 2x2x2 cube, defined in object coordinates
double CubeFaces[6][12] =
{
   {-1.0, 1.0, 1.0,  1.0, 1.0, 1.0,  1.0, 1.0,-1.0, -1.0, 1.0,-1.0}, // top
   {-1.0, 1.0,-1.0,  1.0, 1.0,-1.0,  1.0,-1.0,-1.0, -1.0,-1.0,-1.0}, // front
   {-1.0, 1.0, 1.0, -1.0, 1.0,-1.0, -1.0,-1.0,-1.0, -1.0,-1.0, 1.0}, // left
   { 1.0, 1.0,-1.0,  1.0, 1.0, 1.0,  1.0,-1.0, 1.0,  1.0,-1.0,-1.0}, // right
   {-1.0,-1.0,-1.0,  1.0,-1.0,-1.0,  1.0,-1.0, 1.0, -1.0,-1.0, 1.0}, // bottom
   { 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0,-1.0, 1.0,  1.0,-1.0, 1.0}  // back
};

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);
void DrawCubes(void);
void SetWindowSize(int,int);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGgeometry";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor(NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindow(szAppName, // window class name
      "3D Geometry",           // window caption
      WS_OVERLAPPEDWINDOW,     // window style
      CW_USEDEFAULT,           // initial x position
      CW_USEDEFAULT,           // initial y position
      CW_USEDEFAULT,           // initial x size
      CW_USEDEFAULT,           // initial y size
      NULL,                    // parent window handle
      NULL,                    // window menu handle
      hInstance,               // program instance handle
      NULL);                   // creation parameters

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   while (GetMessage(&msg,NULL,0,0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HDC      hDC;
HPALETTE hPal;
int      hVB;
int      hZB;
UINT     cxClient, cyClient;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch (iMsg)
   {
      case WM_CREATE:
         // create the device context and logical palette
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);

         // create and open the virtual buffer
         fg_vbinit();
         hVB = fg_vballoc(vbWidth,vbHeight);
         fg_vbopen(hVB);
         fg_vbcolors();

         // fill the virtual buffer with white pixels
         fg_setcolor(-1);
         fg_fillpage();

         // create and open the z-buffer
         hZB = fg_zballoc(vbWidth,vbHeight);
         fg_zbopen(hZB);

         // define 3D viewport and render state
         fg_3Dviewport(0,vbWidth-1,0,vbHeight-1,1.0);
         fg_3Drenderstate(FG_ZBUFFER);

         // make the client area equal to the virtual buffer size
         ShowWindow(hWnd,SW_SHOWNORMAL);
         SetWindowSize(vbWidth,vbHeight);

         // draw the cubes and coordinate axes
         DrawCubes();
         return 0;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
         fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,TRUE);
         return 0;

      case WM_SIZE:
         cxClient = LOWORD(lParam);
         cyClient = HIWORD(lParam);
         return 0;

      case WM_DESTROY:
         fg_vbclose();
         fg_zbfree(hZB);
         fg_vbfree(hVB);
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

/****************************************************************************\
*                                                                            *
*  DrawCubes()                                                               *
*                                                                            *
*  Draws two cubes, one in 3D world space and the other in object space,     *
*  along with 3D coordinate axes.                                            *
*                                                                            *
\****************************************************************************/

void DrawCubes()
{
   register int i;
   static int Colors[] = {19,20,21,22,23,24};

   // set the point of view (POV)
   fg_3Dmove(4.0,4.0,-15.0);

   // position a cube at z=20.0 with no rotation
   fg_3Dmoveobject(0.0,0.0,20.0);

   // draw the 3D coordinate axes in world space
   fg_setcolor(0);
   fg_3Dline(0.0,0.0,0.0,10.0,0.0,0.0);
   fg_3Dline(0.0,0.0,0.0,0.0,10.0,0.0);
   fg_3Dline(0.0,0.0,0.0,0.0,0.0,500.0);

   // draw all six faces in both cubes
   for (i = 0; i < 6; i++)
   {
      fg_setcolor(Colors[i]);
      fg_3Dpolygon(CubeFaces[i],4);
      fg_3Dpolygonobject(CubeFaces[i],4);
   }
}

/****************************************************************************\
*                                                                            *
*  SetWindowSize()                                                           *
*                                                                            *
*  Sets the window size so the client area has the specified dimensions.     *
*                                                                            *
\****************************************************************************/

void SetWindowSize(int ClientWidth, int ClientHeight)
{
   RECT ClientRect;
   RECT WindowRect;
   int WindowWidth, WindowHeight;

   GetClientRect(GetActiveWindow(),&ClientRect);
   GetWindowRect(GetActiveWindow(),&WindowRect);

   WindowWidth = ClientWidth +
      (WindowRect.right - WindowRect.left) -
      (ClientRect.right - ClientRect.left);
   WindowHeight = ClientHeight +
      (WindowRect.bottom - WindowRect.top) -
      (ClientRect.bottom - ClientRect.top);
   SetWindowPos(GetActiveWindow(),NULL,0,0,
      WindowWidth,WindowHeight,SWP_NOMOVE|SWP_NOZORDER);
}

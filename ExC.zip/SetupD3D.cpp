/****************************************************************************\
*                                                                            *
*  SetupD3D.cpp                                                              *
*                                                                            *
*  This program shows how to manage Direct3D outside of Fastgraph and still  *
*  use Fastgraph with DirectX.                                               *
*                                                                            *
*  Works with DirectX 5, 6, or 7.                                            *
*                                                                            *
\****************************************************************************/

// Define the DX5, DX6, DX7 symbol depending on what version of DirectX you
// are using. One, and only one, of these three symbols must be defined.

//#define DX5
//#define DX6
#define DX7

// The vbWidth and vbHeight symbols define the virtual buffer resolution in
// pixels. For full screen DirectDraw programs, they also define the screen
// resolution, and vbDepth defines the virtual buffer and screen color depth.

#define vbWidth  640
#define vbHeight 480
#define vbDepth   16

#define ddFlags (FG_DX_FLIP | FG_DX_RENDER_HW | FG_DX_RENDER_SW | FG_DX_ZBUFFER)

#define D3D_OVERLOADS

#include <fgwin.h>
#include <initguid.h>
#include <ddraw.h>
#include <d3d.h>

#ifdef DX5
#define DXVERSION 5
#define IID_IDirectDrawN IID_IDirectDraw2
#define IID_IDirect3Dn IID_IDirect3D2

#define DDSURFACEDESCn DDSURFACEDESC
#define D3DDEVICEDESCn D3DDEVICEDESC
#define D3DVIEWPORTn D3DVIEWPORT2

#define LPDIRECTDRAWn LPDIRECTDRAW2
#define LPDIRECTDRAWSURFACEn LPDIRECTDRAWSURFACE
#define LPDIRECT3Dn LPDIRECT3D2
#define LPDIRECT3DDEVICEn LPDIRECT3DDEVICE2
#define LPDIRECT3DVIEWPORTn LPDIRECT3DVIEWPORT2
#endif

#ifdef DX6
#define DXVERSION 6
#define IID_IDirectDrawN IID_IDirectDraw4
#define IID_IDirect3Dn IID_IDirect3D3

#define DDSURFACEDESCn DDSURFACEDESC2
#define D3DDEVICEDESCn D3DDEVICEDESC
#define D3DVIEWPORTn D3DVIEWPORT2

#define LPDIRECTDRAWn LPDIRECTDRAW4
#define LPDIRECTDRAWSURFACEn LPDIRECTDRAWSURFACE4
#define LPDIRECT3Dn LPDIRECT3D3
#define LPDIRECT3DDEVICEn LPDIRECT3DDEVICE3
#define LPDIRECT3DVIEWPORTn LPDIRECT3DVIEWPORT3
#endif

#ifdef DX7
#define DXVERSION 7
#define IID_IDirectDrawN IID_IDirectDraw7
#define IID_IDirect3Dn IID_IDirect3D7

#define DDSURFACEDESCn DDSURFACEDESC2
#define D3DDEVICEDESCn D3DDEVICEDESC7
#define D3DVIEWPORTn D3DVIEWPORT7

#define LPDIRECTDRAWn LPDIRECTDRAW7
#define LPDIRECTDRAWSURFACEn LPDIRECTDRAWSURFACE7
#define LPDIRECT3Dn LPDIRECT3D7
#define LPDIRECT3DDEVICEn LPDIRECT3DDEVICE7
#define LPDIRECT3DVIEWPORTn LPDIRECT3DVIEWPORT3
#endif

LPDIRECTDRAWn        lpDD = NULL;          // DirectDraw object
LPDIRECTDRAWSURFACEn lpDDPrimary = NULL;   // DirectDrawSurface object
LPDIRECT3Dn          lpD3D = NULL;         // Direct3D object
LPDIRECT3DDEVICEn    lpD3DDevice = NULL;   // Direct3DDevice object
LPDIRECT3DVIEWPORTn  lpD3DViewport = NULL; // Direct3DViewport object
LPDIRECTDRAWSURFACEn lpD3DZBuffer = NULL;  // Direct3D z-buffer

LPGUID lpHWGuid = NULL;
LPGUID lpSWGuid = NULL;
D3DDEVICEDESCn HWDeviceDesc;
D3DDEVICEDESCn SWDeviceDesc;

DWORD ErrorCode = 0;
char  ErrorString[256];

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);
#ifdef DX7
HRESULT WINAPI EnumDeviceCallback(LPSTR,LPSTR,LPD3DDEVICEDESC7,LPVOID);
#else
HRESULT WINAPI EnumDeviceCallback(LPGUID,LPSTR,LPSTR,LPD3DDEVICEDESC,
                                  LPD3DDEVICEDESC,LPVOID);
#endif
void EndDirectX(void);
void FatalError(HRESULT,char*);
BOOL InitDirect3D(void);
BOOL InitDirectDraw(HWND,int,int,int);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGfirst";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor(NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindowEx(
      WS_EX_TOPMOST,           // extended window style
      szAppName,               // window class name
      "DirectDraw Full Screen",// window caption
      WS_POPUP,                // window style
      0,                       // initial x position
      0,                       // initial y position
      vbWidth,                 // initial x size
      vbHeight,                // initial y size
      NULL,                    // parent window handle
      NULL,                    // window menu handle
      hInstance,               // program instance handle
      NULL);                   // creation parameters

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   while (GetMessage(&msg,NULL,0,0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }

   if (ErrorCode)
      MessageBox(GetActiveWindow(),ErrorString,"Error",MB_OK|MB_ICONSTOP);
   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HDC      hDC;
HPALETTE hPal;
UINT     cxClient, cyClient;
int      hVB;

int Vertex[] = {60,0, 199,60, 160,175, 0,199};
double xyzNear[] = {0.0,0.0,100.0, 0.0,0.0,100.0, 0.0,0.0,100.0, 0.0,0.0,100.0};
double xyzFar[]  = {0.0,0.0,200.0, 0.0,0.0,200.0, 0.0,0.0,200.0, 0.0,0.0,200.0};

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;
   D3DRECT rect;
   BOOL success;

   switch(iMsg)
   {
      case WM_CREATE:
         fg_ddsetup(vbWidth,vbHeight,vbDepth,ddFlags);
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);
         ShowWindow(hWnd,SW_SHOWNORMAL);

         // Initialize DirectDraw for full-screen page flipping
         success = InitDirectDraw(hWnd,vbWidth,vbHeight,vbDepth);
         if (!success)
         {
            DestroyWindow(hWnd);
            return 0;
         }
         fg_vbinit();
         fg_vbdepth(vbDepth);
         fg_ddapply(DXVERSION);

         // Initialize Direct3D
         success = InitDirect3D();
         if (!success)
         {
            DestroyWindow(hWnd);
            return 0;
         }

         hVB = 0;
         fg_vbopen(hVB);
         fg_vbcolors();

         fg_setcolor(-1);
         fg_fillpage();
         fg_mouseini();
         fg_mousevis(0);
         return 0;

      case WM_KEYDOWN:
         switch(wParam)
         {
            case VK_F1:
               lpD3DDevice->BeginScene();
               fg_setcolor(-1);
               fg_fillpage();
               fg_setcolorrgb(85,255,85);
               fg_polyoff(220,140);
               fg_polyfill(Vertex,NULL,4);
               lpD3DDevice->EndScene();
               fg_ddflip();
               break;

            case VK_F2:
               lpD3DDevice->BeginScene();
               rect.x1 = 0;
               rect.y1 = 0;
               rect.x2 = vbWidth;
               rect.y2 = vbHeight;
#ifdef DX7
               lpD3DDevice->Clear(1,&rect,D3DCLEAR_ZBUFFER,0,(D3DVALUE)1.0,0);
#else
               lpD3DViewport->Clear(1,&rect,D3DCLEAR_ZBUFFER);
#endif
               fg_setcolor(-1);
               fg_fillpage();
               fg_setcolorrgb(85,255,85);
               fg_polyoff(220,140);
               fg_polyfilz(Vertex,xyzNear,4);
               fg_setcolorrgb(255,85,85);
               fg_polyoff(320,170);
               fg_polyfilz(Vertex,xyzFar,4);
               lpD3DDevice->EndScene();
               fg_ddflip();
               break;

            case VK_ESCAPE:
            case VK_F12:
               DestroyWindow(hWnd);
               break;
         }
         return 0;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
         fg_ddflip();
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,FALSE);
         return 0;

      case WM_SIZE:
         cxClient = LOWORD(lParam);
         cyClient = HIWORD(lParam);
         return 0;

      case WM_DESTROY:
         fg_mousevis(1);
         fg_vbclose();
         EndDirectX();
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

/****************************************************************************\
*                                                                            *
*  EnumDeviceCallback()                                                      *
*                                                                            *
\****************************************************************************/

#ifdef DX7

HRESULT WINAPI EnumDeviceCallback (LPSTR lpDeviceDescription,
                                   LPSTR lpDeviceName,
                                   LPD3DDEVICEDESC7 lpDesc,
                                   LPVOID lpUnused)
{
   DWORD DepthList;

   // Hardware device?
   if (lpDesc->dwDevCaps & D3DDEVCAPS_HWRASTERIZATION)
   {
      // Does the device support the required color depth?
      DepthList = lpDesc->dwDeviceRenderBitDepth;
      if (vbDepth == 16 && (DepthList & DDBD_16) == 0)
         return D3DENUMRET_OK;
      else if (vbDepth == 24 && (DepthList & DDBD_24) == 0)
         return D3DENUMRET_OK;
      else if (vbDepth == 32 && (DepthList & DDBD_32) == 0)
         return D3DENUMRET_OK;

      // Does the device have z-buffering capabilities?
      if (ddFlags & FG_DX_ZBUFFER)
      {
         DepthList = lpDesc->dwDeviceZBufferBitDepth;
         if ((DepthList & 0xF00) == 0)
            return D3DENUMRET_OK;
      }

      // Save driver's HAL description and GUID
      memcpy(&HWDeviceDesc,lpDesc,sizeof(D3DDEVICEDESC7));
      lpHWGuid = &HWDeviceDesc.deviceGUID;

      // Found the device we're going to use!
      return D3DENUMRET_CANCEL;
   }

   // Software device?
   else
   {
      // Does the device support the required color depth?
      DepthList = lpDesc->dwDeviceRenderBitDepth;
      if (vbDepth == 16 && (DepthList & DDBD_16) == 0)
         return D3DENUMRET_OK;
      else if (vbDepth == 24 && (DepthList & DDBD_24) == 0)
         return D3DENUMRET_OK;
      else if (vbDepth == 32 && (DepthList & DDBD_32) == 0)
         return D3DENUMRET_OK;

      // Does the device have z-buffering capabilities?
      if (ddFlags & FG_DX_ZBUFFER)
      {
         DepthList = lpDesc->dwDeviceZBufferBitDepth;
         if ((DepthList & 0xF00) == 0)
            return D3DENUMRET_OK;
      }

      // Save driver's HEL description and GUID
      memcpy(&SWDeviceDesc,lpDesc,sizeof(D3DDEVICEDESC7));
      lpSWGuid = &SWDeviceDesc.deviceGUID;
   }

   return D3DENUMRET_OK;
}

#else

HRESULT WINAPI EnumDeviceCallback (LPGUID lpGuid,
                                   LPSTR lpDeviceDescription,
                                   LPSTR lpDeviceName,
                                   LPD3DDEVICEDESC lpHWDesc,
                                   LPD3DDEVICEDESC lpSWDesc,
                                   LPVOID lpUnused)
{
   DWORD DepthList;

   // Hardware device?
   if (lpHWDesc->dcmColorModel)
   {
      // Does the device support the required color depth?
      DepthList = lpHWDesc->dwDeviceRenderBitDepth;
      if (vbDepth == 16 && (DepthList & DDBD_16) == 0)
         return D3DENUMRET_OK;
      else if (vbDepth == 24 && (DepthList & DDBD_24) == 0)
         return D3DENUMRET_OK;
      else if (vbDepth == 32 && (DepthList & DDBD_32) == 0)
         return D3DENUMRET_OK;

      // Does the device have z-buffering capabilities?
      DepthList = lpHWDesc->dwDeviceZBufferBitDepth;
      if ((DepthList & 0xF00) == 0)
         return D3DENUMRET_OK;

      // Save driver's HAL description and GUID
      memcpy(&HWDeviceDesc,lpHWDesc,sizeof(D3DDEVICEDESC));
      lpHWGuid = lpGuid;

      // Found the device we're going to use!
      return D3DENUMRET_CANCEL;
   }

   // Sofware device?
   else if (lpSWDesc->dcmColorModel)
   {
      // Does the device support the required color depth?
      DepthList = lpSWDesc->dwDeviceRenderBitDepth;
      if (vbDepth == 16 && (DepthList & DDBD_16) == 0)
         return D3DENUMRET_OK;
      else if (vbDepth == 24 && (DepthList & DDBD_24) == 0)
         return D3DENUMRET_OK;
      else if (vbDepth == 32 && (DepthList & DDBD_32) == 0)
         return D3DENUMRET_OK;

      // Does the device have z-buffering capabilities?
      DepthList = lpSWDesc->dwDeviceZBufferBitDepth;
      if ((DepthList & 0xF00) == 0)
         return D3DENUMRET_OK;

      // Save driver's HEL description and GUID
      memcpy(&SWDeviceDesc,lpSWDesc,sizeof(D3DDEVICEDESC));
      lpSWGuid = lpGuid;
   }

   return D3DENUMRET_OK;
}

#endif

/****************************************************************************\
*                                                                            *
*  InitDirect3D()                                                            *
*                                                                            *
\****************************************************************************/

BOOL InitDirect3D (void)
{
   LPGUID lpGuid;
   LPDIRECTDRAWSURFACEn lpBackBuffer;
   D3DDEVICEDESCn DeviceDesc;
   DDSURFACEDESCn ddsd;
   D3DVIEWPORTn viewport;
   DWORD DepthList, BitDepth;
   HRESULT rc;

   // Create the Direct3Dn object
   rc = lpDD->QueryInterface(IID_IDirect3Dn,(void**)&lpD3D);
   if (rc != DD_OK)
   {
      FatalError(rc,"Could not create Direct3Dn object.");
      return FALSE;
   }

   // Locate a suitable Direct3D device
   rc = lpD3D->EnumDevices(EnumDeviceCallback,NULL);
   if (rc != DD_OK || (lpHWGuid == NULL && lpSWGuid == NULL))
   {
      FatalError(rc,"Could not find suitable Direct3D device.");
      return FALSE;
   }

   // Give precedence to a hardware device
   if (lpHWGuid && (ddFlags & FG_DX_RENDER_HW))
   {
      lpGuid = lpHWGuid;
      DeviceDesc = HWDeviceDesc;
      lpSWGuid = NULL;
   }
   else if (lpSWGuid && (ddFlags & FG_DX_RENDER_SW))
   {
      lpGuid = lpSWGuid;
      DeviceDesc = SWDeviceDesc;
      lpHWGuid = NULL;
   }
   else
   {
      lpGuid = NULL;
      lpHWGuid = NULL;
      lpSWGuid = NULL;
   }

   // Set up the z-buffer (must occur before creating the Direct3D device)
   if (ddFlags & FG_DX_ZBUFFER)
   {
      // Use the highest supported z-buffer bit depth
      DepthList = DeviceDesc.dwDeviceZBufferBitDepth;
      if (DepthList & DDBD_32)
         BitDepth = 32;
      else if (DepthList & DDBD_24)
         BitDepth = 24;
      else if (DepthList & DDBD_16)
         BitDepth = 16;
      else if (DepthList & DDBD_8)
         BitDepth = 8;
      else
      {
         FatalError(rc,"No supported z-buffer bit depths.");
         return FALSE;
      }

      // Create the z-buffer surface
      ZeroMemory(&ddsd,sizeof(ddsd));
      ddsd.dwSize = sizeof(ddsd);
      ddsd.dwWidth = vbWidth;
      ddsd.dwHeight = vbHeight;
#ifdef DX5
      ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT | DDSD_ZBUFFERBITDEPTH;
      ddsd.dwZBufferBitDepth = BitDepth;
#else
      ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT | DDSD_PIXELFORMAT;
      ddsd.ddpfPixelFormat.dwSize = sizeof(DDPIXELFORMAT);
      ddsd.ddpfPixelFormat.dwFlags = DDPF_ZBUFFER;
      ddsd.ddpfPixelFormat.dwZBufferBitDepth = BitDepth;
      ddsd.ddpfPixelFormat.dwZBitMask = (1 << BitDepth) - 1;
#endif
      if (lpHWGuid)
         ddsd.ddsCaps.dwCaps = DDSCAPS_ZBUFFER | DDSCAPS_VIDEOMEMORY;
      else
         ddsd.ddsCaps.dwCaps = DDSCAPS_ZBUFFER | DDSCAPS_SYSTEMMEMORY;

      rc = lpDD->CreateSurface(&ddsd,&lpD3DZBuffer,NULL);
      if (rc != DD_OK)
      {
         FatalError(rc,"CreateSurface() failed on z-buffer.");
         return FALSE;
      }

      // Attach the z-buffer to the primary surface's back buffer
      lpBackBuffer = (LPDIRECTDRAWSURFACEn)fg_vbaddr(hVB);
      rc = lpBackBuffer->AddAttachedSurface(lpD3DZBuffer);
      if (rc != DD_OK)
      {
         FatalError(rc,"AddAttachedSurface() failed on z-buffer.");
         return FALSE;
      }

      // Tell Fastgraph about the Direct3D z-buffer
      fg_ddsetobj(lpD3DZBuffer,8);
   }

   // Create the Direct3D device
   lpBackBuffer = (LPDIRECTDRAWSURFACEn)fg_vbaddr(hVB);
#ifdef DX6
   rc = lpD3D->CreateDevice(*lpGuid,lpBackBuffer,&lpD3DDevice,NULL);
#else
   rc = lpD3D->CreateDevice(*lpGuid,lpBackBuffer,&lpD3DDevice);
#endif
   if (rc != DD_OK)
   {
      FatalError(rc,"Could not create Direct3D device.");
      return FALSE;
   }

   // Make sure z-buffering is enabled
   if (ddFlags & FG_DX_ZBUFFER)
   {
      lpD3DDevice->SetRenderState(D3DRENDERSTATE_ZENABLE,TRUE);
   }

#ifndef DX7
   // Create the Direct3D viewport
   rc = lpD3D->CreateViewport(&lpD3DViewport,NULL);
   if (rc != D3D_OK)
   {
      FatalError(rc,"CreateViewport() failed.");
      return FALSE;
   }

   // Associate the viewport with the Direct3D device
   rc = lpD3DDevice->AddViewport(lpD3DViewport);
   if (rc != D3D_OK)
   {
      FatalError(rc,"AddViewport() failed.");
      return FALSE;
   }
#endif

   // Define the viewport attributes
#ifdef DX7
   viewport.dwX = 0;
   viewport.dwY = 0;
   viewport.dwWidth  = vbWidth;
   viewport.dwHeight = vbHeight;
   viewport.dvMinZ = D3DVAL(0.0);
   viewport.dvMaxZ = D3DVAL(1.0);
   rc = lpD3DDevice->SetViewport(&viewport);
   if (rc != D3D_OK)
   {
      FatalError(rc,"SetViewport() failed.");
      return FALSE;
   }
#else
   viewport.dwSize = sizeof(viewport);
   viewport.dwX = 0;
   viewport.dwY = 0;
   viewport.dwWidth  = vbWidth;
   viewport.dwHeight = vbHeight;
   viewport.dvClipX = D3DVAL(0.0);
   viewport.dvClipY = D3DVAL(0.0);
   viewport.dvClipWidth  = D3DVAL(vbWidth);
   viewport.dvClipHeight = D3DVAL(vbHeight);
   viewport.dvMinZ = D3DVAL(0.0);
   viewport.dvMaxZ = D3DVAL(1.0);
   rc = lpD3DViewport->SetViewport2(&viewport);
   if (rc != D3D_OK)
   {
      FatalError(rc,"SetViewport2() failed.");
      return FALSE;
   }

   // Define the current viewport
   rc = lpD3DDevice->SetCurrentViewport(lpD3DViewport);
   if (rc != D3D_OK)
   {
      FatalError(rc,"SetCurrentViewport() failed.");
      return FALSE;
   }
#endif

   // Tell Fastgraph about the Direct3Dn, Direct3DDeviceN, and
   // Direct3DViewportN objects
   fg_ddsetobj(lpD3D,4);
   if (lpHWGuid)
      fg_ddsetobj(lpD3DDevice,5);
   else
      fg_ddsetobj(lpD3DDevice,6);
   fg_ddsetobj(lpD3DViewport,7);

   return TRUE;
}

/****************************************************************************\
*                                                                            *
*  InitDirectDraw()                                                          *
*                                                                            *
\****************************************************************************/

BOOL InitDirectDraw (HWND hWnd, int xRes, int yRes, int Depth)
{
#ifndef DX7
   LPDIRECTDRAW   lpDD1;
#endif
   DDSURFACEDESCn ddsd;
   DWORD          dwFlags;
   HRESULT        rc;

#ifdef DX7
   // Create the DirectDraw7 object
   rc = DirectDrawCreateEx(NULL,(void**)&lpDD,IID_IDirectDraw7,NULL);
   if (rc != DD_OK)
   {
      FatalError(rc,"DirectDrawCreateEx() failed.");
      return FALSE;
   }
#else
   // Create the DirectDraw object
   rc = DirectDrawCreate(NULL,&lpDD1,NULL);
   if (rc != DD_OK)
   {
      FatalError(rc,"DirectDrawCreate() failed.");
      return FALSE;
   }

   // Obtain the DirectDrawN object from the DirectDraw object (which can
   // then be released)
   rc = lpDD1->QueryInterface(IID_IDirectDrawN,(void**)&lpDD);
   lpDD1->Release();
   if (rc != DD_OK)
   {
      FatalError(rc,"Could not create DirectDrawN object.");
      return FALSE;
   }
#endif

   // Set the application's cooperative level
   dwFlags = DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT;
   rc = lpDD->SetCooperativeLevel(hWnd,dwFlags);
   if (rc != DD_OK)
   {
      FatalError(rc,"SetCooperativeLevel() failed.");
      return FALSE;
   }

   //  Set the display mode
   rc = lpDD->SetDisplayMode(xRes,yRes,Depth,0,0);
   if (rc != DD_OK)
   {
      FatalError(rc,"SetDisplayMode() failed.");
      return FALSE;
   }

   // Create the primary surface
   ZeroMemory(&ddsd,sizeof(ddsd));
   ddsd.dwSize = sizeof(ddsd);
   ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
   ddsd.dwBackBufferCount = 1;
   ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_VIDEOMEMORY |
                         DDSCAPS_3DDEVICE | DDSCAPS_COMPLEX | DDSCAPS_FLIP;
   rc = lpDD->CreateSurface(&ddsd,&lpDDPrimary,NULL);
   if (rc != DD_OK)
   {
      FatalError(rc,"CreateSurface() failed on primary surface.");
      return FALSE;
   }

   // Tell Fastgraph about the DirectDrawN object and the primary surface
   fg_ddsetobj(lpDD,0);
   fg_ddsetobj(lpDDPrimary,1);

   return TRUE;
}

/****************************************************************************\
*                                                                            *
*  EndDirectX()                                                              *
*                                                                            *
\****************************************************************************/

void EndDirectX (void)
{
   // If we created a Direct3D z-buffer surface, release it
   if (lpD3DZBuffer != NULL)
   {
      lpD3DDevice->SetRenderState(D3DRENDERSTATE_ZENABLE,FALSE);
      lpD3DZBuffer->Release();
      lpD3DZBuffer = NULL;
      fg_ddsetobj(NULL,8);
   }

   // If we created a Direct3DViewportN object, release it
   if (lpD3DViewport != NULL)
   {
      lpD3DViewport->Release();
      lpD3DViewport = NULL;
      fg_ddsetobj(NULL,7);
   }

   // If we created a Direct3DDeviceN object, release it
   if (lpD3DDevice != NULL)
   {
      lpD3DDevice->Release();
      lpD3DDevice = NULL;
      fg_ddsetobj(NULL,6);
      fg_ddsetobj(NULL,5);
   }

   // If we created a Direct3Dn object, release it
   if (lpD3D != NULL)
   {
      lpD3D->Release();
      lpD3D = NULL;
      fg_ddsetobj(NULL,4);
   }

   // If we created a DirectDraw primary surface, release it
   if (lpDDPrimary != NULL)
   {
      lpDDPrimary->Release();
      lpDDPrimary = NULL;
      fg_ddsetobj(NULL,1);
   }

   // If we created a DirectDrawN object, release it
   if (lpDD != NULL)
   {
      lpDD->Release();
      lpDD = NULL;
      fg_ddsetobj(NULL,0);
   }
}

/****************************************************************************\
*                                                                            *
*  FatalError()                                                              *
*                                                                            *
\****************************************************************************/

void FatalError (HRESULT rc, char *description)
{
   ErrorCode = (DWORD)rc;
   wsprintf(ErrorString,"%s\nError %8.8X",description,ErrorCode);
}

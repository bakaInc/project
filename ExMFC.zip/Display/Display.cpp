/****************************************************************************\
*                                                                            *
*  Display.cpp                                                               *
*                                                                            *
*  This program resizes the desktop to 800x600 using the fg_modeset()        *
*  function.                                                                 *
*                                                                            *
\****************************************************************************/

// Display.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Display.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDisplayApp

BEGIN_MESSAGE_MAP(CDisplayApp, CWinApp)
	//{{AFX_MSG_MAP(CDisplayApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDisplayApp construction

CDisplayApp::CDisplayApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CDisplayApp object

CDisplayApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CDisplayApp initialization

BOOL CDisplayApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Change Display Settings"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CDisplayApp message handlers

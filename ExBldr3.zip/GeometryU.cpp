/****************************************************************************\
*                                                                            *
*  Geometry.cpp                                                              *
*  GeometryU.cpp                                                             *
*                                                                            *
*  This program shows how to display 3D objects in object space and 3D world *
*  space.                                                                    *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "GeometryU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   // create the device context and logical palette
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   // create and open the virtual buffer
   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   // fill the virtual buffer with white pixels
   fg_setcolor(-1);
   fg_fillpage();

   // create and open the z-buffer
   hZB = fg_zballoc(vbWidth,vbHeight);
   fg_zbopen(hZB);

   // define 3D viewport and render state
   fg_3Dviewport(0,vbWidth-1,0,vbHeight-1,1.0);
   fg_3Drenderstate(FG_ZBUFFER);

   // draw the cubes and coordinate axes
   DrawCubes();

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_zbfree(hZB);
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}

/****************************************************************************\
*                                                                            *
*  DrawCubes()                                                               *
*                                                                            *
*  Draws two cubes, one in 3D world space and the other in object space,     *
*  along with 3D coordinate axes.                                            *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::DrawCubes()
{
   register int i;
   static int Colors[] = {19,20,21,22,23,24};

   // set the point of view (POV)
   fg_3Dmove(4.0,4.0,-15.0);

   // position a cube at z=20.0 with no rotation
   fg_3Dmoveobject(0.0,0.0,20.0);

   // draw the 3D coordinate axes in world space
   fg_setcolor(0);
   fg_3Dline(0.0,0.0,0.0,10.0,0.0,0.0);
   fg_3Dline(0.0,0.0,0.0,0.0,10.0,0.0);
   fg_3Dline(0.0,0.0,0.0,0.0,0.0,500.0);

   // draw all six faces in both cubes
   for (i = 0; i < 6; i++)
   {
      fg_setcolor(Colors[i]);
      fg_3Dpolygon(CubeFaces[i],4);
      fg_3Dpolygonobject(CubeFaces[i],4);
   }
}

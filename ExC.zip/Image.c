/****************************************************************************\
*                                                                            *
*  Image.c                                                                   *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows image file display    *
*  and creation functions.                                                   *
*                                                                            *
\****************************************************************************/

#include <fgwin.h>
#include <commdlg.h>
#include <windowsx.h>
#include "Image.h"

#define OK   1
#define ERR -1

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);

void BMPOpenClick(void);
void BMPMakeClick(void);
void BMPDetailsClick(void);

void PCXOpenClick(void);
void PCXMakeClick(void);
void PCXDetailsClick(void);

void JPEGOpenClick(void);
void JPEGDetailsClick(void);

void FlicOpenClick(void);
void FlicPlayClick(void);
void FlicFrameClick(void);
void FlicResetClick(void);
void FlicDetailsClick(void);

void AVIOpenClick(void);
void AVIPlayClick(void);
void AVIFrameClick(void);
void AVIResetClick(void);
void AVIDetailsClick(void);

void CloseContext(void);
int  GetOpenFilename(char *, char *);
int  GetSaveFilename(char *);
void SwitchBuffers(void);

BYTE Context[48];
char DefaultFile[256];
BYTE FileHeader[128];
char FileName[256];
char mbString[256];

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGimage";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor(NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = szAppName;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindow(szAppName, // window class name
      "Image File Demo",       // window caption
      WS_OVERLAPPEDWINDOW,     // window style
      CW_USEDEFAULT,           // initial x position
      CW_USEDEFAULT,           // initial y position
      CW_USEDEFAULT,           // initial x size
      CW_USEDEFAULT,           // initial y size
      NULL,                    // parent window handle
      NULL,                    // window menu handle
      hInstance,               // program instance handle
      NULL);                   // creation parameters

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   while (GetMessage(&msg,NULL,0,0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HCURSOR  hCursor;
HDC      hDC;
HMENU    hMenu;
HPALETTE hPal;
int      hVB;
UINT     cxClient, cyClient;
int      cxBuffer, cyBuffer;
int      nColors;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch (iMsg)
   {
      case WM_CREATE:
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);

         fg_vbinit();
         cxBuffer = cyBuffer = 32;
         hVB = fg_vballoc(cxBuffer,cyBuffer);
         fg_vbopen(hVB);
         fg_vbcolors();

         fg_setcolor(-1);
         fg_fillpage();

         hMenu = GetMenu(hWnd);
         return 0;

      case WM_COMMAND:
         switch (wParam)
         {
            case IDM_BMP_Open:
               BMPOpenClick();
               return 0;

            case IDM_BMP_Make:
               BMPMakeClick();
               return 0;

            case IDM_BMP_Details:
               BMPDetailsClick();
               return 0;

            case IDM_PCX_Open:
               PCXOpenClick();
               return 0;

            case IDM_PCX_Make:
               PCXMakeClick();
               return 0;

            case IDM_PCX_Details:
               PCXDetailsClick();
               return 0;

            case IDM_JPEG_Open:
               JPEGOpenClick();
               return 0;

            case IDM_JPEG_Details:
               JPEGDetailsClick();
               return 0;

            case IDM_Flic_Open:
               FlicOpenClick();
               return 0;

            case IDM_Flic_Play:
               FlicPlayClick();
               return 0;

            case IDM_Flic_Frame:
               FlicFrameClick();
               return 0;

            case IDM_Flic_Reset:
               FlicResetClick();
               return 0;

            case IDM_Flic_Details:
               FlicDetailsClick();
               return 0;

            case IDM_AVI_Open:
               AVIOpenClick();
               return 0;

            case IDM_AVI_Play:
               AVIPlayClick();
               return 0;

            case IDM_AVI_Frame:
               AVIFrameClick();
               return 0;

            case IDM_AVI_Reset:
               AVIResetClick();
               return 0;

            case IDM_AVI_Details:
               AVIDetailsClick();
               return 0;

            case IDM_Exit:
               DestroyWindow(hWnd);
               return 0;
         }
         break;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
         fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,TRUE);
         return 0;

      case WM_SIZE:
         cxClient = LOWORD(lParam);
         cyClient = HIWORD(lParam);
         return 0;

      case WM_DESTROY:
         CloseContext();
         fg_vbclose();
         fg_vbfree(hVB);
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the BMP menu.                             *
*                                                                            *
\****************************************************************************/

void BMPOpenClick()
{
   if (GetOpenFilename("BMP files (*.bmp)","*.BMP") == ERR) return;
   if (fg_bmphead(FileName,FileHeader) < 0)
   {
      wsprintf(mbString,"%s\nis not a BMP file.",(LPSTR)FileName);
      MessageBox(GetActiveWindow(),mbString,"Error",MB_ICONSTOP|MB_OK);
      return;
   }

   hCursor = SetCursor(LoadCursor(NULL,IDC_WAIT));
   ShowCursor(TRUE);
   nColors = fg_bmppal(FileName,NULL);
   fg_bmpsize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   fg_showbmp(FileName,0);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   ShowCursor(FALSE);
   SetCursor(hCursor);

   EnableMenuItem(hMenu,IDM_BMP_Make,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_BMP_Details,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_PCX_Make,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_PCX_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_JPEG_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Play,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Frame,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Reset,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Play,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Frame,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Reset,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Details,MF_GRAYED);
}

//---------------------------------------------------------------------------

void BMPMakeClick()
{
   int ColorDepth;

   if (GetSaveFilename("bmp") == ERR) return;

   if (nColors == 0)
      ColorDepth = 24;
   else if (nColors == 256)
      ColorDepth = 8;
   else if (nColors == 16)
      ColorDepth = 4;
   else
      ColorDepth = 1;
   hCursor = SetCursor(LoadCursor(NULL,IDC_WAIT));
   ShowCursor(TRUE);
   fg_makebmp(0,cxBuffer-1,0,cyBuffer-1,ColorDepth,FileName);
   ShowCursor(FALSE);
   SetCursor(hCursor);
}

//---------------------------------------------------------------------------

void BMPDetailsClick()
{
   if (nColors > 0)
      wsprintf(mbString,"%s\n%dx%d pixels\n%d colors",
         (LPSTR)FileName,cxBuffer,cyBuffer,nColors);
   else
      wsprintf(mbString,"%s\n%dx%d pixels\n24-bit RGB",
         (LPSTR)FileName,cxBuffer,cyBuffer);
   MessageBox(GetActiveWindow(),mbString,"Information",MB_ICONINFORMATION|MB_OK);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the PCX menu.                             *
*                                                                            *
\****************************************************************************/

void PCXOpenClick()
{
   if (GetOpenFilename("PCX files (*.pcx)","*.PCX") == ERR) return;
   if (fg_pcxhead(FileName,FileHeader) < 0)
   {
      wsprintf(mbString,"%s\nis not a PCX file.",(LPSTR)FileName);
      MessageBox(GetActiveWindow(),mbString,"Error",MB_ICONSTOP|MB_OK);
      return;
   }

   hCursor = SetCursor(LoadCursor(NULL,IDC_WAIT));
   ShowCursor(TRUE);
   nColors = fg_pcxpal(FileName,NULL);
   fg_pcxsize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   fg_move(0,0);
   fg_showpcx(FileName,FG_AT_XY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   ShowCursor(FALSE);
   SetCursor(hCursor);

   EnableMenuItem(hMenu,IDM_BMP_Make,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_BMP_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_PCX_Make,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_PCX_Details,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_JPEG_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Play,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Frame,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Reset,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Play,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Frame,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Reset,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Details,MF_GRAYED);
}

//---------------------------------------------------------------------------

void PCXMakeClick()
{
   if (GetSaveFilename("pcx") == ERR) return;

   hCursor = SetCursor(LoadCursor(NULL,IDC_WAIT));
   ShowCursor(TRUE);
   fg_makepcx(0,cxBuffer-1,0,cyBuffer-1,FileName);
   ShowCursor(FALSE);
   SetCursor(hCursor);
}

//---------------------------------------------------------------------------

void PCXDetailsClick()
{
   if (nColors > 0)
      wsprintf(mbString,"%s\n%dx%d pixels\n%d colors",
         (LPSTR)FileName,cxBuffer,cyBuffer,nColors);
   else
      wsprintf(mbString,"%s\n%dx%d pixels\n24-bit RGB",
         (LPSTR)FileName,cxBuffer,cyBuffer);
   MessageBox(GetActiveWindow(),mbString,"Information",MB_ICONINFORMATION|MB_OK);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the JPEG menu.                            *
*                                                                            *
\****************************************************************************/

void JPEGOpenClick()
{
   if (GetOpenFilename("JPEG files (*.jpg)","*.JPG") == ERR) return;

   if (fg_jpeghead(FileName,FileHeader) < 0)
   {
      wsprintf(mbString,"%s\nis not a baseline JPEG file.",(LPSTR)FileName);
      MessageBox(GetActiveWindow(),mbString,"Error",MB_ICONSTOP|MB_OK);
      return;
   }
   hCursor = SetCursor(LoadCursor(NULL,IDC_WAIT));
   ShowCursor(TRUE);
   nColors = 0;
   fg_jpegsize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   fg_showjpeg(FileName,0);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   ShowCursor(FALSE);
   SetCursor(hCursor);

   EnableMenuItem(hMenu,IDM_BMP_Make,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_BMP_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_PCX_Make,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_PCX_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_JPEG_Details,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_Flic_Play,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Frame,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Reset,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Play,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Frame,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Reset,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Details,MF_GRAYED);
}

//---------------------------------------------------------------------------

void JPEGDetailsClick()
{
   wsprintf(mbString,"%s\n%dx%d pixels\n24-bit RGB",
      (LPSTR)FileName,cxBuffer,cyBuffer);
   MessageBox(GetActiveWindow(),mbString,"Information",MB_ICONINFORMATION|MB_OK);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the FLI/FLC menu.                         *
*                                                                            *
\****************************************************************************/

static int nFrames;

void FlicOpenClick()
{
   if (GetOpenFilename("flic files (*.fli,*.flc)","*.FLI;*.FLC") == ERR)
      return;

   if (fg_flichead(FileName,FileHeader) < 0)
   {
      wsprintf(mbString,"%s\nis not an FLI or FLC file.",(LPSTR)FileName);
      MessageBox(GetActiveWindow(),mbString,"Error",MB_ICONSTOP|MB_OK);
      return;
   }
   nColors = 256;
   fg_flicsize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   fg_flicopen(FileName,Context);
   fg_flicplay(Context,1,FG_NODELAY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   memcpy(&nFrames,&FileHeader[6],2);

   EnableMenuItem(hMenu,IDM_BMP_Make,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_BMP_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_PCX_Make,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_PCX_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_JPEG_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Play,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_Flic_Frame,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_Flic_Reset,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_Flic_Details,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_AVI_Play,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Frame,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Reset,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Details,MF_GRAYED);
}

//---------------------------------------------------------------------------

void FlicPlayClick()
{
   hCursor = SetCursor(LoadCursor(NULL,IDC_WAIT));
   ShowCursor(TRUE);
   fg_showflic(FileName,0,FG_NODELAY);
   ShowCursor(FALSE);
   SetCursor(hCursor);
   fg_flicskip(Context,-1);
}

//---------------------------------------------------------------------------

void FlicFrameClick()
{
   if (fg_flicplay(Context,1,FG_NODELAY) == 0)
   {
      fg_flicskip(Context,-1);
      fg_flicplay(Context,1,FG_NODELAY);
   }
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}

//---------------------------------------------------------------------------

void FlicResetClick()
{
   fg_flicskip(Context,-1);
   fg_flicplay(Context,1,FG_NODELAY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}

//---------------------------------------------------------------------------

void FlicDetailsClick()
{
   wsprintf(mbString,"%s\n%dx%d pixels\n%d frames",
      (LPSTR)FileName,cxBuffer,cyBuffer,nFrames);
   MessageBox(GetActiveWindow(),mbString,"Information",MB_ICONINFORMATION|MB_OK);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the AVI menu.                             *
*                                                                            *
\****************************************************************************/

void AVIOpenClick()
{
   if (GetOpenFilename("AVI files (*.avi)","*.AVI") == ERR)
      return;

   if (fg_avihead(FileName,FileHeader) < 0)
   {
      wsprintf(mbString,"%s\nis not an AVI file.",(LPSTR)FileName);
      MessageBox(GetActiveWindow(),mbString,"Error",MB_ICONSTOP|MB_OK);
      return;
   }
   nColors = fg_avipal(FileName,NULL);
   fg_avisize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   if (fg_aviopen(FileName,Context) < 0)
   {
      wsprintf(mbString,"Cannot play AVI file\n%s.",(LPSTR)FileName);
      MessageBox(GetActiveWindow(),mbString,"Error",MB_ICONSTOP|MB_OK);
      EnableMenuItem(hMenu,IDM_AVI_Play,MF_GRAYED);
      EnableMenuItem(hMenu,IDM_AVI_Frame,MF_GRAYED);
      EnableMenuItem(hMenu,IDM_AVI_Reset,MF_GRAYED);
      EnableMenuItem(hMenu,IDM_AVI_Details,MF_GRAYED);
      return;
   }
   fg_aviplay(Context,1,FG_NODELAY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);

   EnableMenuItem(hMenu,IDM_BMP_Make,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_BMP_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_PCX_Make,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_PCX_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_JPEG_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Play,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Frame,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Reset,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_Flic_Details,MF_GRAYED);
   EnableMenuItem(hMenu,IDM_AVI_Play,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_AVI_Frame,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_AVI_Reset,MF_ENABLED);
   EnableMenuItem(hMenu,IDM_AVI_Details,MF_ENABLED);
}

//---------------------------------------------------------------------------

void AVIPlayClick()
{
   hCursor = SetCursor(LoadCursor(NULL,IDC_WAIT));
   ShowCursor(TRUE);
   fg_showavi(FileName,0,FG_NODELAY);
   ShowCursor(FALSE);
   SetCursor(hCursor);
   fg_aviskip(Context,-1);
}

//---------------------------------------------------------------------------

void AVIFrameClick()
{
   if (fg_aviplay(Context,1,FG_NODELAY) == 0)
   {
      fg_aviskip(Context,-1);
      fg_aviplay(Context,1,FG_NODELAY);
   }
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}

//---------------------------------------------------------------------------

void AVIResetClick()
{
   fg_aviskip(Context,-1);
   fg_aviplay(Context,1,FG_NODELAY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}

//---------------------------------------------------------------------------

void AVIDetailsClick()
{
   if (nColors > 0)
      wsprintf(mbString,"%s\n%dx%d pixels\n%d colors",
         (LPSTR)FileName,cxBuffer,cyBuffer,nColors);
   else
      wsprintf(mbString,"%s\n%dx%d pixels\n24-bit RGB",
         (LPSTR)FileName,cxBuffer,cyBuffer);
   MessageBox(GetActiveWindow(),mbString,"Information",MB_ICONINFORMATION|MB_OK);
}

/****************************************************************************\
*                                                                            *
*  CloseContext()                                                            *
*                                                                            *
*  Closes the active flic or AVI context. This function is called from       *
*  SwitchBuffers() and also from the WM_DESTROY handler.                     *
*                                                                            *
\****************************************************************************/

void CloseContext()
{
   if (!(GetMenuState(hMenu,IDM_Flic_Details,MF_BYCOMMAND) & MFS_DISABLED))
      fg_flicdone(Context);
   else if (!(GetMenuState(hMenu,IDM_AVI_Details,MF_BYCOMMAND) & MFS_DISABLED))
      fg_avidone(Context);
}

/****************************************************************************\
*                                                                            *
*  GetOpenFilename()                                                         *
*                                                                            *
*  Display a dialog box that selects a list of file names that match the     *
*  specified file name. This function uses the Open File dialog box from the *
*  Windows common dialog box library.                                        *
*                                                                            *
*  The selected file name is stored with full path information in the global *
*  variable FileName.                                                        *
*                                                                            *
\****************************************************************************/

int GetOpenFilename(char *MatchType, char *MatchFile)
{
   OPENFILENAME fn;
   register int i;
   char Filter[128];

   // construct file name filter string
   lstrcpy(Filter,MatchType);
   i = lstrlen(Filter) + 1;
   lstrcpy(&Filter[i],MatchFile);
   i += lstrlen(&Filter[i]) + 1;
   Filter[i] = '\0';

   // fill in structure fields for Open File dialog box
   fn.lStructSize       = sizeof(OPENFILENAME);
   fn.hwndOwner         = GetActiveWindow();
   fn.lpstrFilter       = Filter;
   fn.lpstrCustomFilter = NULL;
   fn.nFilterIndex      = 0;
   fn.lpstrFile         = NULL;
   fn.lpstrFile         = DefaultFile;
   fn.nMaxFile          = sizeof(DefaultFile);
   fn.lpstrFileTitle    = NULL;
   fn.lpstrInitialDir   = NULL;
   fn.lpstrTitle        = NULL;
   fn.Flags             = OFN_READONLY;
   fn.lpstrDefExt       = &MatchFile[2];
   *DefaultFile = '\0';

   // activate the Open File dialog box
   if (GetOpenFileName(&fn))
   {
      lstrcpy(FileName,DefaultFile);
      return OK;
   }
   else
      return ERR;
}

/****************************************************************************\
*                                                                            *
*  GetSaveFilename()                                                         *
*                                                                            *
*  Display a dialog box that selects a list of file names that match the     *
*  specified file type. This function uses the Save File dialog box from the *
*  Windows common dialog box library.                                        *
*                                                                            *
*  The selected file name is stored with full path information in the global *
*  variable FileName.                                                        *
*                                                                            *
\****************************************************************************/

int GetSaveFilename(char *DefaultExt)
{
   OPENFILENAME fn;

   // fill in structure fields for Save File dialog box
   fn.lStructSize       = sizeof(OPENFILENAME);
   fn.hwndOwner         = GetActiveWindow();
   fn.lpstrCustomFilter = NULL;
   fn.nFilterIndex      = 0;
   fn.lpstrFile         = DefaultFile;
   fn.nMaxFile          = sizeof(DefaultFile);
   fn.lpstrFileTitle    = NULL;
   fn.lpstrInitialDir   = NULL;
   fn.lpstrTitle        = NULL;
   fn.Flags             = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT |
                          OFN_PATHMUSTEXIST;
   fn.lpstrDefExt       = DefaultExt;

   // construct file name filter string and default file name string
   lstrcpy(DefaultFile,FileName);
   if (lstrcmp(DefaultExt,"bmp") == 0)
   {
      fn.lpstrFilter = "BMP files (*.bmp)\0*.BMP\0\0";
      lstrcpy(strrchr(DefaultFile,'.'),".bmp");
   }
   else if (lstrcmp(DefaultExt,"pcx") == 0)
   {
      fn.lpstrFilter = "PCX files (*.pcx)\0*.PCX\0\0";
      lstrcpy(strrchr(DefaultFile,'.'),".pcx");
   }
   else
   {
      fn.lpstrFilter = NULL;
   }

   // activate the Open File dialog box
   if (GetSaveFileName(&fn))
   {
      lstrcpy(FileName,DefaultFile);
      return OK;
   }
   else
      return ERR;
}

/****************************************************************************\
*                                                                            *
*  SwitchBuffers()                                                           *
*                                                                            *
*  Close the and release the active virtual buffer, then create and open a   *
*  new virtual buffer to hold the new image file.                            *
*                                                                            *
\****************************************************************************/

void SwitchBuffers()
{
   CloseContext();
   fg_vbclose();
   fg_vbfree(hVB);
   if (nColors == 0)
      fg_vbdepth(24);
   else
      fg_vbdepth(8);
   hVB = fg_vballoc(cxBuffer,cyBuffer);
   fg_vbopen(hVB);
   fg_vbcolors();
}

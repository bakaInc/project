/****************************************************************************\
*                                                                            *
*  FullScr.cpp                                                               *
*                                                                            *
*  This is a version of the first Fastgraph for Windows example program      *
*  modified for use as a DirectDraw full screen application.                 *
*                                                                            *
\****************************************************************************/

// FullScr.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "FullScr.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFullScrApp

BEGIN_MESSAGE_MAP(CFullScrApp, CWinApp)
	//{{AFX_MSG_MAP(CFullScrApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFullScrApp construction

CFullScrApp::CFullScrApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFullScrApp object

CFullScrApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CFullScrApp initialization

BOOL CFullScrApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"DirectDraw Full Screen"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CFullScrApp message handlers

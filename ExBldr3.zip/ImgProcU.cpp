/****************************************************************************\
*                                                                            *
*  ImgProc.cpp                                                               *
*  ImgProcU.cpp                                                              *
*                                                                            *
*  This program demonstrates several of the Fastgraph for Windows image      *
*  processing functions.                                                     *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "ImgProcU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   // initialize the virtual buffer environment
   fg_vbinit();
   fg_vbdepth(24);

   // create the main virtual buffer for the working copy of the image
   cxBuffer = cyBuffer = 32;
   hVB = fg_vballoc(cxBuffer,cyBuffer);
   fg_vbopen(hVB);

   // create two additional virtual buffers -- one for a copy of the original
   // image, and one used for the undo operation
   hVBoriginal = fg_vballoc(cxBuffer,cyBuffer);
   hVBundo = fg_vballoc(cxBuffer,cyBuffer);

   // start with a window full of white pixels
   fg_setcolor(-1);
   fg_fillpage();

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfree(hVBoriginal);
   fg_vbfree(hVBundo);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the File menu.                            *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::OpenClick(TObject *Sender)
{
   // open the bmp, jpeg, or pcx image file
   OpenDialog->FileName = "";
   OpenDialog->Filter =
      "All image files (*.bmp,*.jpg,*.pcx)|*.BMP;*.JPG;*.PCX|"
      "BMP files (*.bmp)|*.BMP|"
      "JPEG files (*.jpg)|*.JPG|"
      "PCX files (*.pcx)|*.PCX";
   OpenDialog->Options << ofReadOnly;
   if (!OpenDialog->Execute()) return;
   strcpy(FileName,OpenDialog->FileName.c_str());

   // check for a bmp file
   if (fg_bmphead(FileName,FileHeader) == 0)
   {
      Cursor = crHourGlass;
      nColors = fg_bmppal(FileName,NULL);
      fg_bmpsize(FileHeader,&cxBuffer,&cyBuffer);
      SwitchBuffers();
      fg_showbmp(FileName,0);
      SaveDialog->DefaultExt = "bmp";
   }

   // check for a jpeg file
   else if (fg_jpeghead(FileName,FileHeader) == 0)
   {
      Cursor = crHourGlass;
      nColors = 0;
      fg_jpegsize(FileHeader,&cxBuffer,&cyBuffer);
      SwitchBuffers();
      fg_showjpeg(FileName,0);
      SaveDialog->DefaultExt = "pcx";
   }

   // check for a pcx file
   else if (fg_pcxhead(FileName,FileHeader) == 0)
   {
      Cursor = crHourGlass;
      nColors = fg_pcxpal(FileName,NULL);
      fg_pcxsize(FileHeader,&cxBuffer,&cyBuffer);
      SwitchBuffers();
      fg_move(0,0);
      fg_showpcx(FileName,FG_AT_XY);
      SaveDialog->DefaultExt = "pcx";
   }

   // the file is not a valid bmp, jpeg, or pcx file
   else
   {
      mbString = OpenDialog->FileName +
         "\nis not a recognized image file.";
      MessageDlg(mbString,mtError,TMsgDlgButtons()<<mbOK,0);
      return;
   }

   // make a copy of the original image
   fg_copypage(hVB,hVBoriginal);

   // display the image
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   Cursor = crDefault;

   // enable remaining items on the File menu, and the image processing
   // items on the Edit menu
   SaveAs->Enabled = True;
   Details->Enabled = True;
   Undo->Enabled = False;
   RestoreOriginal->Enabled = False;
   ContrastEnhancement->Enabled = True;
   GammaCorrection->Enabled = True;
   Grayscale->Enabled = True;
   PhotoInversion->Enabled = True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SaveAsClick(TObject *Sender)
{
   // set the file save dialog options
   SaveDialog->Options << ofHideReadOnly;
   SaveDialog->Options << ofOverwritePrompt;
   SaveDialog->Options << ofPathMustExist;
   SaveDialog->FileName = ChangeFileExt(FileName,"."+SaveDialog->DefaultExt);

   // save image as a bmp file (original image was bmp)
   if (SaveDialog->DefaultExt == "bmp")
   {
      SaveDialog->Filter = "BMP files (*.bmp)|*.BMP";
      if (!SaveDialog->Execute()) return;
      Cursor = crHourGlass;
      strcpy(FileName,SaveDialog->FileName.c_str());
      fg_makebmp(0,cxBuffer-1,0,cyBuffer-1,24,FileName);
      nColors = 0;
      Cursor = crDefault;
   }

   // save image as a pcx file (original image was jpeg or pcx)
   else if (SaveDialog->DefaultExt == "pcx")
   {
      SaveDialog->Filter = "PCX files (*.pcx)|*.PCX";
      if (!SaveDialog->Execute()) return;
      Cursor = crHourGlass;
      strcpy(FileName,SaveDialog->FileName.c_str());
      fg_makepcx(0,cxBuffer-1,0,cyBuffer-1,FileName);
      nColors = 0;
      Cursor = crDefault;
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DetailsClick(TObject *Sender)
{
   // display the original image resolution and color depth
   mbString = "";
   mbString = mbString + FileName + "\n" + cxBuffer + "x" + cyBuffer + " pixels\n";
   if (nColors > 0)
      mbString = mbString + nColors + " colors";
   else
      mbString = mbString + "24-bit RGB";
   MessageDlg(mbString,mtInformation,TMsgDlgButtons()<<mbOK,0);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitClick(TObject *Sender)
{
   Close();
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the Edit menu.                            *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::UndoClick(TObject *Sender)
{
   // undo the previous image processing operation
   fg_copypage(hVBundo,hVB);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   Undo->Enabled = False;
   RestoreOriginal->Enabled = True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RestoreOriginalClick(TObject *Sender)
{
   // restore the original image
   fg_copypage(hVB,hVBundo);
   fg_copypage(hVBoriginal,hVB);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   Undo->Enabled = True;
   RestoreOriginal->Enabled = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ContrastEnhancementClick(TObject *Sender)
{
   // perform a contrast enhancement transform on the active virtual buffer
   fg_copypage(hVB,hVBundo);
   fg_move(0,cyBuffer-1);
   fg_contvb(63,192,cxBuffer,cyBuffer);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   Undo->Enabled = True;
   RestoreOriginal->Enabled = True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::GammaCorrectionClick(TObject *Sender)
{
   // perform a gamma correction transform on the active virtual buffer
   fg_copypage(hVB,hVBundo);
   fg_move(0,cyBuffer-1);
   fg_gammavb(0.45,cxBuffer,cyBuffer);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   Undo->Enabled = True;
   RestoreOriginal->Enabled = True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::GrayscaleClick(TObject *Sender)
{
   // perform a grayscale transform on the active virtual buffer
   fg_copypage(hVB,hVBundo);
   fg_move(0,cyBuffer-1);
   fg_grayvb(cxBuffer,cyBuffer);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   Undo->Enabled = True;
   RestoreOriginal->Enabled = True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::PhotoInversionClick(TObject *Sender)
{
   // perform a photo-inversion transform on the active virtual buffer
   fg_copypage(hVB,hVBundo);
   fg_move(0,cyBuffer-1);
   fg_photovb(cxBuffer,cyBuffer);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
   Undo->Enabled = True;
   RestoreOriginal->Enabled = True;
}

/****************************************************************************\
*                                                                            *
*  SwitchBuffers()                                                           *
*                                                                            *
*  Close the and release the virtual buffers for the current image, then     *
*  create and open new virtual buffers for the new image file.               *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::SwitchBuffers(void)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfree(hVBoriginal);
   fg_vbfree(hVBundo);
   hVB = fg_vballoc(cxBuffer,cyBuffer);
   fg_vbopen(hVB);
   hVBoriginal = fg_vballoc(cxBuffer,cyBuffer);
   hVBundo = fg_vballoc(cxBuffer,cyBuffer);
}

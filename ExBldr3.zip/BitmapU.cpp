/****************************************************************************\
*                                                                            *
*  Bitmap.cpp                                                                *
*  Bitmapu.cpp                                                               *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows 256-color bitmap      *
*  display functions.                                                        *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "BitmapU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_setcolor(20);
   fg_fillpage();

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DrwimageClick(TObject *Sender)
{
   fg_fillpage();
   fg_move(vbWidth/2-20,vbHeight/2+10);
   fg_drwimage(Bird,40,20);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ClpimageClick(TObject *Sender)
{
   fg_fillpage();
   fg_move(-20,vbHeight/2+10);
   fg_clpimage(Bird,40,20);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RevimageClick(TObject *Sender)
{
   fg_fillpage();
   fg_move(vbWidth/2-20,vbHeight/2+10);
   fg_revimage(Bird,40,20);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FlpimageClick(TObject *Sender)
{
   fg_fillpage();
   fg_move(vbWidth-20,vbHeight/2+10);
   fg_flpimage(Bird,40,20);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::PutimageClick(TObject *Sender)
{
   fg_fillpage();
   fg_move(vbWidth/2-20,vbHeight/2+10);
   fg_putimage(Bird,40,20);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitClick(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------

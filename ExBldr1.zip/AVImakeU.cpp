/****************************************************************************\
*                                                                            *
*  AVImake.cpp                                                               *
*  AVImakeU.cpp                                                              *
*                                                                            *
*  This program creates an AVI file from an FLI or FLC file.                 *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "AVImakeU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   cxBuffer = cyBuffer = 32;
   hVB = fg_vballoc(cxBuffer,cyBuffer);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_setcolor(-1);
   fg_fillpage();

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ConvertClick(TObject *Sender)
{
   String mbString;
   char FileName[256];
   byte FileHeader[128];
   byte ContextFlic[16];
   byte ContextAVI[24];
   byte *Bitmap;

   // open the flic file to convert
   OpenDialog->DefaultExt = "fli";
   OpenDialog->FileName = "";
   OpenDialog->Filter = "flic files (*.fli,*.flc)|*.FLI;*.FLC";
   OpenDialog->Options << ofReadOnly;
   if (!OpenDialog->Execute()) return;
   strcpy(FileName,OpenDialog->FileName.c_str());

   // make sure it really is a flic file, and if so, open it
   if (fg_flichead(FileName,FileHeader) < 0)
   {
      mbString = OpenDialog->FileName + " is not an FLI or FLC file.";
      MessageDlg(mbString,mtError,TMsgDlgButtons()<<mbOK,0);
      return;
   }
   fg_flicsize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   fg_flicopen(FileName,ContextFlic);

   // display the first flic frame
   fg_flicplay(ContextFlic,1,FG_NODELAY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);

   // create an empty AVI file with the same name as the flic file,
   // but with an .avi extension
   OpenDialog->FileName = ChangeFileExt(OpenDialog->FileName,".avi");
   strcpy(FileName,OpenDialog->FileName.c_str());
   if (fg_avimake(FileName,ContextAVI,-1,cxBuffer,cyBuffer,8,10000,30) < 0)
   {
      mbString = "Cannot create AVI file\n" + OpenDialog->FileName;
      MessageDlg(mbString,mtError,TMsgDlgButtons()<<mbOK,0);
      return;
   }

   // create a 256-color bitmap whose size is equal to the flic resolution
   Bitmap = new byte[fg_imagesiz(cxBuffer,cyBuffer)];

   // create the AVI file frame by frame
   Cursor = crHourGlass;
   fg_move(0,cyBuffer-1);
   do
   {
      fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
      fg_getimage(Bitmap,cxBuffer,cyBuffer);
      fg_aviframe(ContextAVI,Bitmap);
   }
   while (fg_flicplay(ContextFlic,1,FG_NODELAY) == 1);
   Cursor = crDefault;

   // close the flic and AVI files, and release the bitmap memory
   fg_flicdone(ContextFlic);
   fg_avidone(ContextAVI);
   delete [] Bitmap;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitClick(TObject *Sender)
{
   Close();
}

/****************************************************************************\
*                                                                            *
*  SwitchBuffers()                                                           *
*                                                                            *
*  Close the and release the active virtual buffer, then create and open a   *
*  new virtual buffer to hold the new image file.                            *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::SwitchBuffers(void)
{
   fg_vbclose();
   fg_vbfree(hVB);
   hVB = fg_vballoc(cxBuffer,cyBuffer);
   fg_vbopen(hVB);
   fg_vbcolors();
}

//---------------------------------------------------------------------------
#ifndef CBDemoUH
#define CBDemoUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Menus.hpp>
#include <FGwin.h>

#define vbWidth  320
#define vbHeight 200
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   TMainMenu *MainMenu1;
   TMenuItem *Cut;
   TMenuItem *Paste;
   TMenuItem *Exit;
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
   void __fastcall CutClick(TObject *Sender);
   void __fastcall PasteClick(TObject *Sender);
   void __fastcall ExitClick(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   UINT cxClient, cyClient;
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

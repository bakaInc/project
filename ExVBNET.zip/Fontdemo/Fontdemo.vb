'*****************************************************************************
'                                                                            *
'  Fontdemo.vb                                                               *
'                                                                            *
'  This program shows how use Windows stock fonts in Fastgraph for Windows,  *
'  and also how to create and use a Windows logical font. The logical font   *
'  is a 24x12 Arial font.                                                    *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hFont As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 320
    Const vbHeight As Integer = 240

    ' 24pt Arial font.
    Dim Font1 As New Font("Arial", 24)

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Name = "Form1"
        Me.Text = "Fastgraph for Windows Font Demo"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        fg_setcolor(24)
        fg_fillpage()
        hFont = Font1.ToHfont
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
        DrawStrings()
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
        If Me.Visible Then DrawStrings()
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub DrawStrings()
        Dim X As Integer

        fg_setcolor(19)
        X = fg_xclient(20)

        fg_move(X, fg_yclient(20))
        fg_fontload(10)
        fg_print("OEM fixed font", 14)

        fg_move(X, fg_yclient(40))
        fg_fontload(11)
        fg_print("ANSI fixed font", 15)

        fg_move(X, fg_yclient(60))
        fg_fontload(12)
        fg_print("ANSI var font", 13)

        fg_move(X, fg_yclient(80))
        fg_fontload(13)
        fg_print("system font", 11)

        fg_move(X, fg_yclient(100))
        fg_fontload(14)
        fg_print("device default font", 19)

        fg_move(X, fg_yclient(120))
        fg_fontload(16)
        fg_print("system fixed font", 17)

        fg_move(X, fg_yclient(160))
        fg_logfont(hFont)
        fg_print("Arial 24 font", 13)
    End Sub
End Class
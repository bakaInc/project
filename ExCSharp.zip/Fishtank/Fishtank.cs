/****************************************************************************\
*                                                                            *
*  Fishtank.cs                                                               *
*                                                                            *
*  This program shows how to perform simple animation using Fastgraph for    *
*  Windows. Several types of tropical fish swim back and forth against a     *
*  coral reef background. The background image and fish sprites are stored   *
*  in PCX files.                                                             *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Fishtank
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB1, hVB2;
		int cxClient, cyClient;

		// Total number of fish sprites.
		const int nFish = 11;
    
		// Location of fish x & y.
		int [] FishX = {0, 64, 128, 200, 0, 80};
		int [] FishY = {199, 199, 199, 199, 150, 150};

		// Size of fish: width and height.
		int [] FishWidth = {56, 54, 68, 56, 62, 68};
		int [] FishHeight = {25, 38, 26, 30, 22, 36};

		// Bitmap offsets into Fishes() array.
		int [] FishOffset = new int [6];

		// The Fishes array holds the bitmaps for all 6 kinds of fish.
		byte [] Fishes = new byte [56*25 + 54*38 + 68*26 + 56*30 + 62*22 + 68*36];

		// There are 11 fish total, and 6 different kinds of fish. These
		// arrays keep track of what kind of fish each fish is, and how each
		// fish moves:

		// Which fish bitmap applies to this fish?
		int [] Fish = {1, 1, 2, 3, 3, 0, 0, 5, 4, 2, 3};

		// Starting x and y coordinates.
		int [] xStart = {-100, -150, -450, -140, -200, 520, 620, -800, 800, 800, -300};
		int [] yStart = {40, 60, 150, 80, 70, 190, 180, 100, 30, 130, 92};

		// How far left and right (off screen) the fish can go.
		int [] xMin = {-300, -300, -800, -200, -200, -200, -300, -900, -900, -900, -400};
		int [] xMax = {600, 600, 1100, 1000, 1000, 750, 800, 1200, 1400, 1200, 900};

		// How fast the fish goes left and right.
		int [] xInc = {2, 2, 8, 5, 5, -3, -3, 7, -8, -9, 6};

		// Starting direction for each fish.
		int [] FishDir = {0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0};

		// How far up and down this fish can go.
		int [] yMin = {40, 60, 120, 70, 60, 160, 160, 80, 30, 110, 72};
		int [] yMax = {80, 100, 170, 110, 100, 199, 199, 120, 70, 150, 122};

		// How fast the fish moves up or down.
		int [] yInc = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

		// Counter to compare to yTurn values.
		int [] yCount = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

		// How long fish can go in the vertical direction before stopping or turning around.
		int [] yTurn = {50, 30, 10, 30, 20, 10, 10, 10, 30, 20, 10};

		// Component declarations.
		private System.Windows.Forms.Timer timer1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			// 
			// timer1
			// 
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Name = "Form1";
			this.Text = "Fastgraph Fish Tank";
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Closed += new System.EventHandler(this.Form1_Closed);
		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);

			// Use the default logical palette.
			hPal = fg.defpal();
			fg.realize(hPal);

			// Create two 320x200 virtual buffers.
			fg.vbinit();
			hVB1 = fg.vballoc(320, 200);
			hVB2 = fg.vballoc(320, 200);

			// Display the coral background in virtual buffer #2 (which
			// will always contain a clean copy of the background image).
			fg.vbopen(hVB2);
			fg.vbcolors();
			fg.showpcx("..\\CORAL.PCX", fg.AT_XY + fg.KEEPCOLORS);

			// Get the fish bitmaps.
			GetFish();

			// Enable the timer to start the animation.
			timer1.Enabled = true;
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, fg.getmaxx(), 0, fg.getmaxy(), 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, fg.getmaxx(), 0, fg.getmaxy(), 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB1);
			fg.vbfree(hVB2);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			GoFish();
		}

		/****************************************************************************\
		*                                                                            *
		*  GetFish()                                                                 *
		*                                                                            *
		*  Fill the fish bitmap arrays.                                              *
		*                                                                            *
		\****************************************************************************/

		private void GetFish()
		{
			int i, j;

			for (i = 0; i < nFish; i++)
			{
				yCount[i] = 0;
				yInc[i] = 0;
			}

			// Get the fish bitmaps from a PCX file.
			fg.vbopen(hVB1);
			fg.vbcolors();
			fg.showpcx("..\\FISH.PCX", fg.AT_XY + fg.IGNOREPALETTE + fg.KEEPCOLORS);

			j = 0;
			for (i = 0; i < 6; i++)
			{
				fg.move(FishX[i], FishY[i]);
				fg.getimage(ref Fishes[j], FishWidth[i], FishHeight[i]);
				FishOffset[i] = j;
				j += FishWidth[i] * FishHeight[i];
			}

			fg.erase();
		}

		/****************************************************************************\
		*                                                                            *
		*  GoFish()                                                                  *
		*                                                                            *
		*  Make the fish swim around. This function is called every 10ms from the    *
		*  timer's OnTick event handler.                                             *
		*                                                                            *
		\****************************************************************************/
		
		private void GoFish()
		{
			int i;
			Random rnd = new Random();

			// Copy the background to the workspace.
			fg.copypage(hVB2, hVB1);

			// Put all the fish in their new positions.
			for (i = 0; i < nFish; i++)
			{
				yCount[i]++;
				if (yCount[i] > yTurn[i])
				{
					yCount[i] = 0;
					yInc[i] = (int)(rnd.NextDouble() * 3.0) - 1;
				}
				yStart[i] += yInc[i];
				yStart[i] = Math.Min(yMax[i], Math.Max(yStart[i], yMin[i]));

				if (xStart[i] >= -72 && xStart[i] < 320)
				{
					PutFish(Fish[i], xStart[i], yStart[i], FishDir[i]);
				}

				xStart[i] += xInc[i];
				if (xStart[i] <= xMin[i] || xStart[i] >= xMax[i])
				{
					xInc[i] = -xInc[i];
					FishDir[i] = 1 - FishDir[i];
				}
			}

			// Scale the workspace image to fill the client area.
			fg.vbscale(0, 319, 0, 199, 0, cxClient-1, 0, cyClient-1);
		}

		/****************************************************************************\
		*                                                                            *
		*  PutFish()                                                                 *
		*                                                                            *
		*  Draw one of the six fish anywhere you want.                               *
		*                                                                            *
		\****************************************************************************/
		
		private void PutFish(int FishNum, int x, int y, int FishDir)
		{
			int i;

			// Move to position where the fish will appear.
			fg.move(x, y);

			// Draw a left- or right-facing fish, depending on FishDir.
			i = FishOffset[FishNum];
			if (FishDir == 0)
			{
				fg.flpimage(ref Fishes[i], FishWidth[FishNum], FishHeight[FishNum]);
			}
			else
			{
				fg.clpimage(ref Fishes[i], FishWidth[FishNum], FishHeight[FishNum]);
			}
		}
	}
}
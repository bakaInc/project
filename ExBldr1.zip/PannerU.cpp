/****************************************************************************\
*                                                                            *
*  Panner.cpp                                                                *
*  PannerU.cpp                                                               *
*                                                                            *
*  This program shows how to pan the contents of a virtual buffer through    *
*  a smaller window.                                                         *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "PannerU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_showbmp("PORCH.BMP",0);
   x = y = 0;

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
   if (cxClient < vbWidth)
   {
      xLimit = vbWidth - cxClient;
      if (x > 0)      Left->Enabled = True;
      if (x < xLimit) Right->Enabled = True;
   }
   else
   {
      xLimit = 0;
      Left->Enabled = False;
      Right->Enabled = False;
   }
   if (cyClient < vbHeight)
   {
      yLimit = vbHeight - cyClient;
      if (y > 0)      Up->Enabled = False;
      if (y < yLimit) Down->Enabled = True;
   }
   else
   {
      yLimit = 0;
      Up->Enabled = False;
      Down->Enabled = False;
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::LeftClick(TObject *Sender)
{
   if (x == xLimit) Right->Enabled = True;
   x--;
   fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
   if (x == 0) Left->Enabled = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RightClick(TObject *Sender)
{
   if (x == 0) Left->Enabled = True;
   x++;
   fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
   if (x == xLimit) Right->Enabled = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::UpClick(TObject *Sender)
{
    if (y == yLimit) Down->Enabled = True;
    y--;
    fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
    if (y == 0) Up->Enabled = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DownClick(TObject *Sender)
{
   if (y == 0) Up->Enabled = True;
   y++;
   fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
   if (y == yLimit) Down->Enabled = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ResetClick(TObject *Sender)
{
   x = y = 0;
   fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);
   if (xLimit > 0) Right->Enabled = True;
   if (yLimit > 0) Down->Enabled = True;
   Left->Enabled = False;
   Up->Enabled = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitClick(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------

/****************************************************************************\
*                                                                            *
*  Geometry.cpp                                                              *
*                                                                            *
*  This program shows how to display 3D objects in object space and 3D world *
*  space.                                                                    *
*                                                                            *
\****************************************************************************/

// Geometry.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Geometry.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGeometryApp

BEGIN_MESSAGE_MAP(CGeometryApp, CWinApp)
	//{{AFX_MSG_MAP(CGeometryApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGeometryApp construction

CGeometryApp::CGeometryApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CGeometryApp object

CGeometryApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CGeometryApp initialization

BOOL CGeometryApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"3D Geometry"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CGeometryApp message handlers

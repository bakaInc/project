//-------------------
// Fade.h header file
//-------------------

#define IDM_FadeIn  1
#define IDM_FadeOut 2
#define IDM_Exit    3

/****************************************************************************\
*                                                                            *
*  Scroller.cpp                                                              *
*  ScrollerU.cpp                                                             *
*                                                                            *
*  This program demonstrates circular scrolling within a virtual buffer.     *
*                                                                            *
*  Because fg_scroll() requires a "hidden" virtual buffer to save and then   *
*  restore portions of the area being scrolled, we create a second virtual   *
*  buffer for this purpose.                                                  *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "ScrollerU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OnIdle(TObject *Sender, bool &Done)
{
   Scroll();
   Done = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB1 = fg_vballoc(vbWidth,vbHeight);
   hVB2 = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB2);
   fg_vbcolors();
   fg_vbopen(hVB1);
   fg_vbcolors();
   fg_sethpage(hVB2);

   fg_setcolor(19);
   fg_fillpage();
   fg_setcolor(25);
   fg_rect(132,188,50,150);

   fg_setcolor(20);
   fg_move(160,67);
   fg_draw(175,107);
   fg_draw(140,82);
   fg_draw(180,82);
   fg_draw(145,107);
   fg_draw(160,67);
   fg_paint(160,77);
   fg_paint(150,87);
   fg_paint(160,87);
   fg_paint(170,87);
   fg_paint(155,97);
   fg_paint(165,97);

   Application->OnActivate = OnActivate;
   Application->OnIdle = OnIdle;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB1);
   fg_vbfree(hVB2);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}

/****************************************************************************\
*                                                                            *
*  Scroll()                                                                  *
*                                                                            *
*  The Scroll() function moves the scrolling region up four pixels in a      *
*  circular manner. It is called from the OnIdle event handler.              *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::Scroll()
{
   fg_scroll(136,184,50,150,-4,0);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}

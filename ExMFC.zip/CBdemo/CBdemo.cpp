/****************************************************************************\
*                                                                            *
*  CBdemo.cpp                                                                *
*                                                                            *
*  This program demonstrates how to exchange information between the active  *
*  virtual buffer and the Windows clipboard.                                 *
*                                                                            *
\****************************************************************************/

// CBdemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "CBdemo.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCBdemoApp

BEGIN_MESSAGE_MAP(CCBdemoApp, CWinApp)
	//{{AFX_MSG_MAP(CCBdemoApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCBdemoApp construction

CCBdemoApp::CCBdemoApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCBdemoApp object

CCBdemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CCBdemoApp initialization

BOOL CCBdemoApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->LoadFrame(IDR_MAINFRAME, WS_OVERLAPPEDWINDOW|FWS_ADDTOTITLE,
		NULL, NULL))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CCBdemoApp message handlers

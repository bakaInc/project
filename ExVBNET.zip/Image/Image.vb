'*****************************************************************************
'                                                                            *
'  Image.vb                                                                  *
'                                                                            *
'  This program demonstrates the Fastgraph for Windows image file display    *
'  and creation functions.                                                   *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Dim cxBuffer, cyBuffer As Integer

    ' Application variables.
    Dim nColors As Integer
    Dim nFrames As Integer
    Dim Context(48) As Byte
    Dim FileHeader(128) As Byte
    Dim FileName As String
    Dim mbString As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents menuBMP As System.Windows.Forms.MenuItem
    Friend WithEvents menuBMPOpen As System.Windows.Forms.MenuItem
    Friend WithEvents menuBMPMake As System.Windows.Forms.MenuItem
    Friend WithEvents menuBMPDetails As System.Windows.Forms.MenuItem
    Friend WithEvents menuPCX As System.Windows.Forms.MenuItem
    Friend WithEvents menuPCXOpen As System.Windows.Forms.MenuItem
    Friend WithEvents menuPCXMake As System.Windows.Forms.MenuItem
    Friend WithEvents menuPCXDetails As System.Windows.Forms.MenuItem
    Friend WithEvents menuJPEG As System.Windows.Forms.MenuItem
    Friend WithEvents menuJPEGOpen As System.Windows.Forms.MenuItem
    Friend WithEvents menuJPEGDetails As System.Windows.Forms.MenuItem
    Friend WithEvents menuFlic As System.Windows.Forms.MenuItem
    Friend WithEvents menuFlicOpen As System.Windows.Forms.MenuItem
    Friend WithEvents menuFlicPlay As System.Windows.Forms.MenuItem
    Friend WithEvents menuFlicFrame As System.Windows.Forms.MenuItem
    Friend WithEvents menuFlicReset As System.Windows.Forms.MenuItem
    Friend WithEvents menuFlicDetails As System.Windows.Forms.MenuItem
    Friend WithEvents menuAVI As System.Windows.Forms.MenuItem
    Friend WithEvents menuAVIOpen As System.Windows.Forms.MenuItem
    Friend WithEvents menuAVIPlay As System.Windows.Forms.MenuItem
    Friend WithEvents menuAVIFrame As System.Windows.Forms.MenuItem
    Friend WithEvents menuAVIReset As System.Windows.Forms.MenuItem
    Friend WithEvents menuAVIDetails As System.Windows.Forms.MenuItem
    Friend WithEvents menuExit As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.menuBMP = New System.Windows.Forms.MenuItem()
        Me.menuBMPOpen = New System.Windows.Forms.MenuItem()
        Me.menuBMPMake = New System.Windows.Forms.MenuItem()
        Me.menuBMPDetails = New System.Windows.Forms.MenuItem()
        Me.menuPCX = New System.Windows.Forms.MenuItem()
        Me.menuPCXOpen = New System.Windows.Forms.MenuItem()
        Me.menuPCXMake = New System.Windows.Forms.MenuItem()
        Me.menuPCXDetails = New System.Windows.Forms.MenuItem()
        Me.menuJPEG = New System.Windows.Forms.MenuItem()
        Me.menuJPEGOpen = New System.Windows.Forms.MenuItem()
        Me.menuJPEGDetails = New System.Windows.Forms.MenuItem()
        Me.menuFlic = New System.Windows.Forms.MenuItem()
        Me.menuFlicOpen = New System.Windows.Forms.MenuItem()
        Me.menuFlicPlay = New System.Windows.Forms.MenuItem()
        Me.menuFlicFrame = New System.Windows.Forms.MenuItem()
        Me.menuFlicReset = New System.Windows.Forms.MenuItem()
        Me.menuFlicDetails = New System.Windows.Forms.MenuItem()
        Me.menuAVI = New System.Windows.Forms.MenuItem()
        Me.menuAVIOpen = New System.Windows.Forms.MenuItem()
        Me.menuAVIPlay = New System.Windows.Forms.MenuItem()
        Me.menuAVIFrame = New System.Windows.Forms.MenuItem()
        Me.menuAVIReset = New System.Windows.Forms.MenuItem()
        Me.menuAVIDetails = New System.Windows.Forms.MenuItem()
        Me.menuExit = New System.Windows.Forms.MenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuBMP, Me.menuPCX, Me.menuJPEG, Me.menuFlic, Me.menuAVI, Me.menuExit})
        '
        'menuBMP
        '
        Me.menuBMP.Index = 0
        Me.menuBMP.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuBMPOpen, Me.menuBMPMake, Me.menuBMPDetails})
        Me.menuBMP.Text = "&BMP"
        '
        'menuBMPOpen
        '
        Me.menuBMPOpen.Index = 0
        Me.menuBMPOpen.Text = "&Open"
        '
        'menuBMPMake
        '
        Me.menuBMPMake.Enabled = False
        Me.menuBMPMake.Index = 1
        Me.menuBMPMake.Text = "&Make"
        '
        'menuBMPDetails
        '
        Me.menuBMPDetails.Enabled = False
        Me.menuBMPDetails.Index = 2
        Me.menuBMPDetails.Text = "&Details"
        '
        'menuPCX
        '
        Me.menuPCX.Index = 1
        Me.menuPCX.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuPCXOpen, Me.menuPCXMake, Me.menuPCXDetails})
        Me.menuPCX.Text = "&PCX"
        '
        'menuPCXOpen
        '
        Me.menuPCXOpen.Index = 0
        Me.menuPCXOpen.Text = "&Open"
        '
        'menuPCXMake
        '
        Me.menuPCXMake.Enabled = False
        Me.menuPCXMake.Index = 1
        Me.menuPCXMake.Text = "&Make"
        '
        'menuPCXDetails
        '
        Me.menuPCXDetails.Enabled = False
        Me.menuPCXDetails.Index = 2
        Me.menuPCXDetails.Text = "&Details"
        '
        'menuJPEG
        '
        Me.menuJPEG.Index = 2
        Me.menuJPEG.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuJPEGOpen, Me.menuJPEGDetails})
        Me.menuJPEG.Text = "&JPEG"
        '
        'menuJPEGOpen
        '
        Me.menuJPEGOpen.Index = 0
        Me.menuJPEGOpen.Text = "&Open"
        '
        'menuJPEGDetails
        '
        Me.menuJPEGDetails.Enabled = False
        Me.menuJPEGDetails.Index = 1
        Me.menuJPEGDetails.Text = "&Details"
        '
        'menuFlic
        '
        Me.menuFlic.Index = 3
        Me.menuFlic.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuFlicOpen, Me.menuFlicPlay, Me.menuFlicFrame, Me.menuFlicReset, Me.menuFlicDetails})
        Me.menuFlic.Text = "&FLI/FLC"
        '
        'menuFlicOpen
        '
        Me.menuFlicOpen.Index = 0
        Me.menuFlicOpen.Text = "&Open"
        '
        'menuFlicPlay
        '
        Me.menuFlicPlay.Enabled = False
        Me.menuFlicPlay.Index = 1
        Me.menuFlicPlay.Text = "&Play"
        '
        'menuFlicFrame
        '
        Me.menuFlicFrame.Enabled = False
        Me.menuFlicFrame.Index = 2
        Me.menuFlicFrame.Text = "&Frame"
        '
        'menuFlicReset
        '
        Me.menuFlicReset.Enabled = False
        Me.menuFlicReset.Index = 3
        Me.menuFlicReset.Text = "&Reset"
        '
        'menuFlicDetails
        '
        Me.menuFlicDetails.Enabled = False
        Me.menuFlicDetails.Index = 4
        Me.menuFlicDetails.Text = "&Details"
        '
        'menuAVI
        '
        Me.menuAVI.Index = 4
        Me.menuAVI.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuAVIOpen, Me.menuAVIPlay, Me.menuAVIFrame, Me.menuAVIReset, Me.menuAVIDetails})
        Me.menuAVI.Text = "&AVI"
        '
        'menuAVIOpen
        '
        Me.menuAVIOpen.Index = 0
        Me.menuAVIOpen.Text = "&Open"
        '
        'menuAVIPlay
        '
        Me.menuAVIPlay.Enabled = False
        Me.menuAVIPlay.Index = 1
        Me.menuAVIPlay.Text = "&Play"
        '
        'menuAVIFrame
        '
        Me.menuAVIFrame.Enabled = False
        Me.menuAVIFrame.Index = 2
        Me.menuAVIFrame.Text = "&Frame"
        '
        'menuAVIReset
        '
        Me.menuAVIReset.Enabled = False
        Me.menuAVIReset.Index = 3
        Me.menuAVIReset.Text = "&Reset"
        '
        'menuAVIDetails
        '
        Me.menuAVIDetails.Enabled = False
        Me.menuAVIDetails.Index = 4
        Me.menuAVIDetails.Text = "&Details"
        '
        'menuExit
        '
        Me.menuExit.Index = 5
        Me.menuExit.Text = "E&xit"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.ReadOnlyChecked = True
        Me.OpenFileDialog1.RestoreDirectory = True
        Me.OpenFileDialog1.ShowReadOnly = True
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.RestoreDirectory = True
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Image File Demo"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        cxBuffer = 32
        cyBuffer = 32
        hVB = fg_vballoc(cxBuffer, cyBuffer)
        fg_vbopen(hVB)
        fg_vbcolors()

        fg_setcolor(-1)
        fg_fillpage()
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        CloseContext()
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Event handlers for the items on the BMP menu.                             *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuBMPOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBMPOpen.Click
        With OpenFileDialog1
            .DefaultExt = "bmp"
            .FileName = ""
            .Filter = "BMP files (*.bmp)|*.BMP"
            If .ShowDialog() <> DialogResult.OK Then Return
            FileName = .FileName
        End With
        If fg_bmphead(FileName, FileHeader(0)) < 0 Then
            MessageBox.Show(FileName + Chr(13) + "is not a BMP file.", _
               "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        Me.Cursor = Cursors.WaitCursor
        nColors = fg_bmppal(FileName, 0)
        fg_bmpsize(FileHeader(0), cxBuffer, cyBuffer)
        SwitchBuffers()
        fg_showbmp(FileName, 0)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        Me.Cursor = Cursors.Default

        menuBMPMake.Enabled = True
        menuBMPDetails.Enabled = True
        menuPCXMake.Enabled = True
        menuPCXDetails.Enabled = False
        menuJPEGDetails.Enabled = False
        menuFlicPlay.Enabled = False
        menuFlicFrame.Enabled = False
        menuFlicReset.Enabled = False
        menuFlicDetails.Enabled = False
        menuAVIPlay.Enabled = False
        menuAVIFrame.Enabled = False
        menuAVIReset.Enabled = False
        menuAVIDetails.Enabled = False
    End Sub

    Private Sub menuBMPMake_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBMPMake.Click
        Dim ColorDepth As Integer

        With SaveFileDialog1
            .DefaultExt = "bmp"
            .FileName = FileName.Substring(0, FileName.IndexOf(".")) + ".bmp"
            .Filter = "BMP files (*.bmp)|*.BMP"
            If .ShowDialog() <> DialogResult.OK Then Return
            FileName = .FileName
        End With
        If nColors = 0 Then
            ColorDepth = 24
        ElseIf nColors = 256 Then
            ColorDepth = 8
        ElseIf nColors = 16 Then
            ColorDepth = 4
        Else
            ColorDepth = 1
        End If
        Me.Cursor = Cursors.WaitCursor
        fg_makebmp(0, cxBuffer - 1, 0, cyBuffer - 1, ColorDepth, FileName)
        Me.Cursor = Cursors.Default
    End Sub

    Private Sub menuBMPDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBMPDetails.Click
        mbString = FileName + Chr(13) + Format(cxBuffer, "D") + "x" + Format(cyBuffer, "D") + " pixels" + Chr(13)
        If nColors > 0 Then
            mbString += Format(nColors, "D") + " colors"
        Else
            mbString += "24-bit RGB"
        End If
        MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Event handlers for the items on the PCX menu.                             *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuPCXOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuPCXOpen.Click
        With OpenFileDialog1
            .DefaultExt = "pcx"
            .FileName = ""
            .Filter = "PCX files (*.pcx)|*.PCX"
            If .ShowDialog() <> DialogResult.OK Then Return
            FileName = .FileName
        End With
        If fg_pcxhead(FileName, FileHeader(0)) < 0 Then
            MessageBox.Show(FileName + Chr(13) + "is not a PCX file.", _
               "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        Me.Cursor = Cursors.WaitCursor
        nColors = fg_pcxpal(FileName, 0)
        fg_pcxsize(FileHeader(0), cxBuffer, cyBuffer)
        SwitchBuffers()
        fg_move(0, 0)
        fg_showpcx(FileName, FG_AT_XY)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        Me.Cursor = Cursors.Default

        menuBMPMake.Enabled = True
        menuBMPDetails.Enabled = False
        menuPCXMake.Enabled = True
        menuPCXDetails.Enabled = True
        menuJPEGDetails.Enabled = False
        menuFlicPlay.Enabled = False
        menuFlicFrame.Enabled = False
        menuFlicReset.Enabled = False
        menuFlicDetails.Enabled = False
        menuAVIPlay.Enabled = False
        menuAVIFrame.Enabled = False
        menuAVIReset.Enabled = False
        menuAVIDetails.Enabled = False
    End Sub

    Private Sub menuPCXMake_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuPCXMake.Click
        With SaveFileDialog1
            .DefaultExt = "pcx"
            .FileName = FileName.Substring(0, FileName.IndexOf(".")) + ".pcx"
            .Filter = "PCX files (*.pcx)|*.PCX"
            If .ShowDialog() <> DialogResult.OK Then Return
            FileName = .FileName
        End With
        Me.Cursor = Cursors.WaitCursor
        fg_makepcx(0, cxBuffer - 1, 0, cyBuffer - 1, FileName)
        Me.Cursor = Cursors.Default
    End Sub

    Private Sub menuPCXDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuPCXDetails.Click
        mbString = FileName + Chr(13) + Format(cxBuffer, "D") + "x" + Format(cyBuffer, "D") + " pixels" + Chr(13)
        If nColors > 0 Then
            mbString += Format(nColors, "D") + " colors"
        Else
            mbString += "24-bit RGB"
        End If
        MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Event handlers for the items on the JPEG menu.                            *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuJPEGOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuJPEGOpen.Click
        With OpenFileDialog1
            .DefaultExt = "jpg"
            .FileName = ""
            .Filter = "JPEG files (*.jpg)|*.JPG"
            If .ShowDialog() <> DialogResult.OK Then Return
            FileName = .FileName
        End With
        If fg_jpeghead(FileName, FileHeader(0)) < 0 Then
            MessageBox.Show(FileName + Chr(13) + "is not a baseline JPEG file.", _
               "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        Me.Cursor = Cursors.WaitCursor
        nColors = 0
        fg_jpegsize(FileHeader(0), cxBuffer, cyBuffer)
        SwitchBuffers()
        fg_showjpeg(FileName, 0)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        Me.Cursor = Cursors.Default

        menuBMPMake.Enabled = True
        menuBMPDetails.Enabled = False
        menuPCXMake.Enabled = True
        menuPCXDetails.Enabled = False
        menuJPEGDetails.Enabled = True
        menuFlicPlay.Enabled = False
        menuFlicFrame.Enabled = False
        menuFlicReset.Enabled = False
        menuFlicDetails.Enabled = False
        menuAVIPlay.Enabled = False
        menuAVIFrame.Enabled = False
        menuAVIReset.Enabled = False
        menuAVIDetails.Enabled = False
    End Sub

    Private Sub menuJPEGDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuJPEGDetails.Click
        mbString = FileName + Chr(13) + Format(cxBuffer, "D") + "x" + Format(cyBuffer, "D") + " pixels" + Chr(13) + "24-bit RGB"
        MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Event handlers for the items on the FLI/FLC menu.                         *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuFlicOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFlicOpen.Click
        With OpenFileDialog1
            .DefaultExt = "fli"
            .FileName = ""
            .Filter = "flic files (*.fli,*.flc)|*.FLI;*.FLC"
            If .ShowDialog() <> DialogResult.OK Then Return
            FileName = .FileName
        End With
        If fg_flichead(FileName, FileHeader(0)) < 0 Then
            MessageBox.Show(FileName + Chr(13) + "is not an FLI or FLC file.", _
               "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        nColors = 256
        fg_flicsize(FileHeader(0), cxBuffer, cyBuffer)
        SwitchBuffers()
        fg_flicopen(FileName, Context(0))
        fg_flicplay(Context(0), 1, FG_NODELAY)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        nFrames = FileHeader(7) * 256 + FileHeader(6)

        menuBMPMake.Enabled = True
        menuBMPDetails.Enabled = False
        menuPCXMake.Enabled = True
        menuPCXDetails.Enabled = False
        menuJPEGDetails.Enabled = False
        menuFlicPlay.Enabled = True
        menuFlicFrame.Enabled = True
        menuFlicReset.Enabled = True
        menuFlicDetails.Enabled = True
        menuAVIPlay.Enabled = False
        menuAVIFrame.Enabled = False
        menuAVIReset.Enabled = False
        menuAVIDetails.Enabled = False
    End Sub

    Private Sub menuFlicPlay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFlicPlay.Click
        Me.Cursor = Cursors.WaitCursor
        fg_showflic(FileName, 0, FG_NODELAY)
        Me.Cursor = Cursors.Default
        fg_flicskip(Context(0), -1)
    End Sub

    Private Sub menuFlicFrame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFlicFrame.Click
        If fg_flicplay(Context(0), 1, FG_NODELAY) = 0 Then
            fg_flicskip(Context(0), -1)
            fg_flicplay(Context(0), 1, FG_NODELAY)
        End If
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub menuFlicReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFlicReset.Click
        fg_flicskip(Context(0), -1)
        fg_flicplay(Context(0), 1, FG_NODELAY)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub menuFlicDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFlicDetails.Click
        mbString = FileName + Chr(13) + Format(cxBuffer, "D") + "x" + Format(cyBuffer, "D") + " pixels" + Chr(13) + Format(nFrames, "D") + " frames"
        MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Event handlers for the items on the AVI menu.                             *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuAVIOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuAVIOpen.Click
        With OpenFileDialog1
            .DefaultExt = "avi"
            .FileName = ""
            .Filter = "AVI files (*.avi)|*.AVI"
            If .ShowDialog() <> DialogResult.OK Then Return
            FileName = .FileName
        End With
        If fg_avihead(FileName, FileHeader(0)) < 0 Then
            MessageBox.Show(FileName + Chr(13) + "is not an AVI file.", _
               "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        nColors = fg_avipal(FileName, 0)
        fg_avisize(FileHeader(0), cxBuffer, cyBuffer)
        SwitchBuffers()
        If fg_aviopen(FileName, Context(0)) < 0 Then
            MessageBox.Show("Cannot play AVI file" + Chr(13) + FileName + ".", _
               "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            menuAVIPlay.Enabled = False
            menuAVIFrame.Enabled = False
            menuAVIReset.Enabled = False
            menuAVIDetails.Enabled = False
            Return
        End If
        fg_aviplay(Context(0), 1, FG_NODELAY)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)

        menuBMPMake.Enabled = True
        menuBMPDetails.Enabled = False
        menuPCXMake.Enabled = True
        menuPCXDetails.Enabled = False
        menuJPEGDetails.Enabled = False
        menuFlicPlay.Enabled = False
        menuFlicFrame.Enabled = False
        menuFlicReset.Enabled = False
        menuFlicDetails.Enabled = False
        menuAVIPlay.Enabled = True
        menuAVIFrame.Enabled = True
        menuAVIReset.Enabled = True
        menuAVIDetails.Enabled = True
    End Sub

    Private Sub menuAVIPlay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuAVIPlay.Click
        Me.Cursor = Cursors.WaitCursor
        fg_showavi(FileName, 0, FG_NODELAY)
        Me.Cursor = Cursors.Default
        fg_aviskip(Context(0), -1)
    End Sub

    Private Sub menuAVIFrame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuAVIFrame.Click
        If fg_aviplay(Context(0), 1, FG_NODELAY) = 0 Then
            fg_aviskip(Context(0), -1)
            fg_aviplay(Context(0), 1, FG_NODELAY)
        End If
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub menuAVIReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuAVIReset.Click
        fg_aviskip(Context(0), -1)
        fg_aviplay(Context(0), 1, FG_NODELAY)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub menuAVIDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuAVIDetails.Click
        mbString = FileName + Chr(13) + Format(cxBuffer, "D") + "x" + Format(cyBuffer, "D") + " pixels" + Chr(13)
        If nColors > 0 Then
            mbString += Format(nColors, "D") + " colors"
        Else
            mbString += "24-bit RGB"
        End If
        MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    '*****************************************************************************

    Private Sub menuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuExit.Click
        Me.Close()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  CloseContext()                                                            *
    '                                                                            *
    '  Closes the active flic or AVI context. This function is called from       *
    '  SwitchBuffers() and also from the Form_Closed handler.                    *
    '                                                                            *
    '*****************************************************************************

    Private Sub CloseContext()
        If menuFlicDetails.Enabled Then
            fg_flicdone(Context(0))
        ElseIf menuAVIDetails.Enabled Then
            fg_avidone(Context(0))
        End If
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  SwitchBuffers()                                                           *
    '                                                                            *
    '  Close the and release the active virtual buffer, then create and open a   *
    '  new virtual buffer to hold the new image file.                            *
    '                                                                            *
    '*****************************************************************************

    Private Sub SwitchBuffers()
        CloseContext()
        fg_vbclose()
        fg_vbfree(hVB)
        If nColors = 0 Then
            fg_vbdepth(24)
        Else
            fg_vbdepth(8)
        End If
        hVB = fg_vballoc(cxBuffer, cyBuffer)
        fg_vbopen(hVB)
        fg_vbcolors()
    End Sub
End Class
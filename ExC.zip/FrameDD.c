/****************************************************************************\
*                                                                            *
*  FrameDD.c                                                                 *
*                                                                            *
*  This program shows how to set up a full screen DirectDraw application     *
*  for either blitting or flipping. The selection of blitting or flipping is *
*  controlled by the BLIT and FLIP symbols defined below.                    *
*                                                                            *
\****************************************************************************/

#include <fgwin.h>

#define vbWidth  640
#define vbHeight 480

// define either BLIT or FLIP, but not both, for blitting or flipping
#define BLIT
//#define FLIP

BOOL AppIsActive = FALSE;

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);
void Animate(void);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGframedd";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor(NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindowEx(
      WS_EX_TOPMOST,                // extended window style
      szAppName,                    // window class name
      "DirectDraw Frame Animation", // window caption
      WS_POPUP,                     // window style
      0,                            // initial x position
      0,                            // initial y position
      vbWidth,                      // initial x size
      vbHeight,                     // initial y size
      NULL,                         // parent window handle
      NULL,                         // window menu handle
      hInstance,                    // program instance handle
      NULL);                        // creation parameters

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   // The message loop processes entries placed in the message queue.
   // When no message is ready and this is the active application, call
   // Animate() to perform one frame of animation.

   while (TRUE)
   {
      if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
      {
         if (msg.message == WM_QUIT)
            break;
         else
         {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
         }
      }
      else if (AppIsActive)
         Animate();
   }

   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HDC      hDC;
HPALETTE hPal;
int      hVB;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   switch (iMsg)
   {
      case WM_ACTIVATEAPP:
         AppIsActive = wParam;
         if (AppIsActive) fg_ddrestore();
         return 0;

      case WM_CREATE:
#ifdef BLIT
         fg_ddsetup(vbWidth,vbHeight,8,FG_DX_BLIT);
#else
         fg_ddsetup(vbWidth,vbHeight,8,FG_DX_FLIP);
#endif
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);
         ShowWindow(hWnd,SW_SHOWNORMAL);

         // if blitting, create a virtual buffer the same size as the screen
         // resolution; if flipping, use the primary surface's back buffer
         fg_vbinit();
#ifdef BLIT
         hVB = fg_vballoc(vbWidth,vbHeight);
#else
         hVB = 0;
#endif
         fg_vbopen(hVB);
         fg_vbcolors();

         fg_mouseini();
         fg_mousevis(0);
         return 0;

      case WM_KEYDOWN:
         switch(wParam)
         {
            case VK_ESCAPE:
            case VK_F12:
               DestroyWindow(hWnd);
               break;
         }
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,TRUE);
         return 0;

      case WM_DESTROY:
         fg_mousevis(1);
         fg_vbclose();
#ifdef BLIT
         fg_vbfree(hVB);
#endif
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

/****************************************************************************\
*                                                                            *
*  Animate()                                                                 *
*                                                                            *
*  Construct the next frame of animation and display it with either blitting *
*  or flipping, as directed by the BLIT and FLIP symbols above.              *
*                                                                            *
\****************************************************************************/

void Animate(void)
{
   // fill drawing surface with the next color
   fg_setcolor((fg_getcolor() + 1) & 0xFF);
   fg_fillpage();

   // blit or flip surface to the screen
#ifdef BLIT
   fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);
#else
   fg_ddflip();
#endif
}

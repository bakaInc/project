/****************************************************************************\
*                                                                            *
*  Dcb.cpp                                                                   *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows direct color bitmap   *
*  display functions.                                                        *
*                                                                            *
\****************************************************************************/

// Dcb.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Dcb.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDcbApp

BEGIN_MESSAGE_MAP(CDcbApp, CWinApp)
	//{{AFX_MSG_MAP(CDcbApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDcbApp construction

CDcbApp::CDcbApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CDcbApp object

CDcbApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CDcbApp initialization

BOOL CDcbApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->LoadFrame(IDR_MAINFRAME, WS_OVERLAPPEDWINDOW|FWS_ADDTOTITLE,
		NULL, NULL))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CDcbApp message handlers

/****************************************************************************\
*                                                                            *
*  Scroller.cpp                                                              *
*                                                                            *
*  This program demonstrates circular scrolling within a virtual buffer.     *
*                                                                            *
*  Because fg_scroll() requires a "hidden" virtual buffer to save and then   *
*  restore portions of the area being scrolled, we create a second virtual   *
*  buffer for this purpose.                                                  *
*                                                                            *
\****************************************************************************/

// Scroller.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Scroller.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScrollerApp

BEGIN_MESSAGE_MAP(CScrollerApp, CWinApp)
	//{{AFX_MSG_MAP(CScrollerApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScrollerApp construction

CScrollerApp::CScrollerApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CScrollerApp object

CScrollerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CScrollerApp initialization

BOOL CScrollerApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Scrolling Demo"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

int CScrollerApp::Run()
{
	if (!m_pMainWnd)
		AfxPostQuitMessage(0);

	MSG msg;
	CMainFrame* pFrame = STATIC_DOWNCAST(CMainFrame, m_pMainWnd);

	while (TRUE)
	{
		//see if there is a message waiting
		if (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			do //if there is pump all waiting
			{
				if (!PumpMessage())
					return ExitInstance();
			} while (::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE));
		}
		else
		{
			if (!pFrame->m_bAppIsActive)
				WaitMessage();
			else
				pFrame->Scroll();
		}
	}
	return msg.wParam;
}

/////////////////////////////////////////////////////////////////////////////
// CScrollerApp message handlers

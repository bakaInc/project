/****************************************************************************\
*                                                                            *
*  VBdemo.cpp                                                                *
*  VBdemoU.cpp                                                               *
*                                                                            *
*  This program demonstrates how to copy the contents of one virtual buffer  *
*  to another, with and without transparent colors.                          *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("VBdemoU.cpp", Form1);
USERES("VBdemo.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
        Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

//----------------------
// Monomap.h header file
//----------------------

#define IDM_Drawmap 1
#define IDM_Clipmap 2
#define IDM_Exit    3

// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Geometry.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// six faces of a 2x2x2 cube, defined in object coordinates
double CubeFaces[6][12] =
{
	{-1.0, 1.0, 1.0,  1.0, 1.0, 1.0,  1.0, 1.0,-1.0, -1.0, 1.0,-1.0}, // top
	{-1.0, 1.0,-1.0,  1.0, 1.0,-1.0,  1.0,-1.0,-1.0, -1.0,-1.0,-1.0}, // front
	{-1.0, 1.0, 1.0, -1.0, 1.0,-1.0, -1.0,-1.0,-1.0, -1.0,-1.0, 1.0}, // left
	{ 1.0, 1.0,-1.0,  1.0, 1.0, 1.0,  1.0,-1.0, 1.0,  1.0,-1.0,-1.0}, // right
	{-1.0,-1.0,-1.0,  1.0,-1.0,-1.0,  1.0,-1.0, 1.0, -1.0,-1.0, 1.0}, // bottom
	{ 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0,-1.0, 1.0,  1.0,-1.0, 1.0}  // back
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
	m_hZB = -1;
}

CMainFrame::~CMainFrame()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	if (m_hZB >= 0)
	{
		fg_zbfree(m_hZB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.cx = vbWidth;
	cs.cy = vbHeight;
	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
		// create the device context and logical palette
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		// create and open the virtual buffer
		fg_vbinit();
		m_hVB = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		// fill the virtual buffer with white pixels
		fg_setcolor(-1);
		fg_fillpage();

		// create and open the z-buffer
		m_hZB = fg_zballoc(vbWidth,vbHeight);
		fg_zbopen(m_hZB);

		// define 3D viewport and render state
		fg_3Dviewport(0,vbWidth-1,0,vbHeight-1,1.0);
		fg_3Drenderstate(FG_ZBUFFER);

		// make the client area equal to the virtual buffer size
		ShowWindow(SW_SHOWNORMAL);
		SetWindowSize(vbWidth,vbHeight);

		// draw the cubes and coordinate axes
		DrawCubes();
	}
	return bRet;
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CMainFrame::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

/****************************************************************************\
*                                                                            *
*  DrawCubes()                                                               *
*                                                                            *
*  Draws two cubes, one in 3D world space and the other in object space,     *
*  along with 3D coordinate axes.                                            *
*                                                                            *
\****************************************************************************/

void CMainFrame::DrawCubes()
{
	register int i;
	static int Colors[] = {19,20,21,22,23,24};

	// set the point of view (POV)
	fg_3Dmove(4.0,4.0,-15.0);

	// position a cube at z=20.0 with no rotation
	fg_3Dmoveobject(0.0,0.0,20.0);

	// draw the 3D coordinate axes in world space
	fg_setcolor(0);
	fg_3Dline(0.0,0.0,0.0,10.0,0.0,0.0);
	fg_3Dline(0.0,0.0,0.0,0.0,10.0,0.0);
	fg_3Dline(0.0,0.0,0.0,0.0,0.0,500.0);

	// draw all six faces in both cubes
	for (i = 0; i < 6; i++)
	{
		fg_setcolor(Colors[i]);
		fg_3Dpolygon(CubeFaces[i],4);
		fg_3Dpolygonobject(CubeFaces[i],4);
	}
}

/****************************************************************************\
*                                                                            *
*  SetWindowSize()                                                           *
*                                                                            *
*  Sets the window size so the client area has the specified dimensions.     *
*                                                                            *
\****************************************************************************/

void CMainFrame::SetWindowSize(int ClientWidth, int ClientHeight)
{
	RECT ClientRect;
	RECT WindowRect;
	int WindowWidth, WindowHeight;

	GetClientRect(&ClientRect);
	GetWindowRect(&WindowRect);

	WindowWidth = ClientWidth +
		(WindowRect.right - WindowRect.left) -
		(ClientRect.right - ClientRect.left);
	WindowHeight = ClientHeight +
		(WindowRect.bottom - WindowRect.top) -
		(ClientRect.bottom - ClientRect.top);
	SetWindowPos(NULL,0,0,WindowWidth,WindowHeight,SWP_NOMOVE|SWP_NOZORDER);
}


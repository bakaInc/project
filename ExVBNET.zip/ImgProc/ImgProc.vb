'*****************************************************************************
'                                                                            *
'  ImgProc.vb                                                                *
'                                                                            *
'  This program demonstrates several of the Fastgraph for Windows image      *
'  processing functions.                                                     *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB, hVBoriginal, hVBundo As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Dim cxBuffer, cyBuffer As Integer

    ' Application variables.
    Dim nColors As Integer
    Dim FileHeader(128) As Byte
    Dim FileName As String
    Dim mbString As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuEditSeparator As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents menuFile As System.Windows.Forms.MenuItem
    Friend WithEvents menuFileOpen As System.Windows.Forms.MenuItem
    Friend WithEvents menuFileSaveAs As System.Windows.Forms.MenuItem
    Friend WithEvents menuFileDetails As System.Windows.Forms.MenuItem
    Friend WithEvents menuFileExit As System.Windows.Forms.MenuItem
    Friend WithEvents menuEdit As System.Windows.Forms.MenuItem
    Friend WithEvents menuEditUndo As System.Windows.Forms.MenuItem
    Friend WithEvents menuEditRestoreImage As System.Windows.Forms.MenuItem
    Friend WithEvents menuEditContrastEnhancement As System.Windows.Forms.MenuItem
    Friend WithEvents menuEditGammaCorrection As System.Windows.Forms.MenuItem
    Friend WithEvents menuEditGrayscale As System.Windows.Forms.MenuItem
    Friend WithEvents menuEditPhotoInversion As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.menuFile = New System.Windows.Forms.MenuItem()
        Me.menuFileOpen = New System.Windows.Forms.MenuItem()
        Me.menuFileSaveAs = New System.Windows.Forms.MenuItem()
        Me.menuFileDetails = New System.Windows.Forms.MenuItem()
        Me.menuFileExit = New System.Windows.Forms.MenuItem()
        Me.menuEdit = New System.Windows.Forms.MenuItem()
        Me.menuEditUndo = New System.Windows.Forms.MenuItem()
        Me.menuEditRestoreImage = New System.Windows.Forms.MenuItem()
        Me.menuEditSeparator = New System.Windows.Forms.MenuItem()
        Me.menuEditContrastEnhancement = New System.Windows.Forms.MenuItem()
        Me.menuEditGammaCorrection = New System.Windows.Forms.MenuItem()
        Me.menuEditGrayscale = New System.Windows.Forms.MenuItem()
        Me.menuEditPhotoInversion = New System.Windows.Forms.MenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuFile, Me.menuEdit})
        '
        'menuFile
        '
        Me.menuFile.Index = 0
        Me.menuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuFileOpen, Me.menuFileSaveAs, Me.menuFileDetails, Me.menuFileExit})
        Me.menuFile.Text = "&File"
        '
        'menuFileOpen
        '
        Me.menuFileOpen.Index = 0
        Me.menuFileOpen.Text = "&Open"
        '
        'menuFileSaveAs
        '
        Me.menuFileSaveAs.Enabled = False
        Me.menuFileSaveAs.Index = 1
        Me.menuFileSaveAs.Text = "&Save As"
        '
        'menuFileDetails
        '
        Me.menuFileDetails.Enabled = False
        Me.menuFileDetails.Index = 2
        Me.menuFileDetails.Text = "&Details"
        '
        'menuFileExit
        '
        Me.menuFileExit.Index = 3
        Me.menuFileExit.Text = "E&xit"
        '
        'menuEdit
        '
        Me.menuEdit.Index = 1
        Me.menuEdit.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuEditUndo, Me.menuEditRestoreImage, Me.menuEditSeparator, Me.menuEditContrastEnhancement, Me.menuEditGammaCorrection, Me.menuEditGrayscale, Me.menuEditPhotoInversion})
        Me.menuEdit.Text = "&Edit"
        '
        'menuEditUndo
        '
        Me.menuEditUndo.Enabled = False
        Me.menuEditUndo.Index = 0
        Me.menuEditUndo.Text = "&Undo"
        '
        'menuEditRestoreImage
        '
        Me.menuEditRestoreImage.Enabled = False
        Me.menuEditRestoreImage.Index = 1
        Me.menuEditRestoreImage.Text = "&Restore Image"
        '
        'menuEditSeparator
        '
        Me.menuEditSeparator.Index = 2
        Me.menuEditSeparator.Text = "-"
        '
        'menuEditContrastEnhancement
        '
        Me.menuEditContrastEnhancement.Enabled = False
        Me.menuEditContrastEnhancement.Index = 3
        Me.menuEditContrastEnhancement.Text = "&Contrast Enhancement"
        '
        'menuEditGammaCorrection
        '
        Me.menuEditGammaCorrection.Enabled = False
        Me.menuEditGammaCorrection.Index = 4
        Me.menuEditGammaCorrection.Text = "&Gamma Correction"
        '
        'menuEditGrayscale
        '
        Me.menuEditGrayscale.Enabled = False
        Me.menuEditGrayscale.Index = 5
        Me.menuEditGrayscale.Text = "Gr&ayscale"
        '
        'menuEditPhotoInversion
        '
        Me.menuEditPhotoInversion.Enabled = False
        Me.menuEditPhotoInversion.Index = 6
        Me.menuEditPhotoInversion.Text = "&Photo-Inversion"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.ReadOnlyChecked = True
        Me.OpenFileDialog1.RestoreDirectory = True
        Me.OpenFileDialog1.ShowReadOnly = True
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.RestoreDirectory = True
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Image Processing Demo"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        ' Initialize the virtual buffer environment.
        fg_vbinit()
        fg_vbdepth(24)

        ' Create the main virtual buffer for the working copy of the image.
        cxBuffer = 32
        cyBuffer = 32
        hVB = fg_vballoc(cxBuffer, cyBuffer)
        fg_vbopen(hVB)

        ' Create two additional virtual buffers -- one for a copy of the original
        ' image, and one used for the undo operation.
        hVBoriginal = fg_vballoc(cxBuffer, cyBuffer)
        hVBundo = fg_vballoc(cxBuffer, cyBuffer)

        ' Start with a window full of white pixels.
        fg_setcolor(-1)
        fg_fillpage()
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfree(hVBoriginal)
        fg_vbfree(hVBundo)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Event handlers for the items on the File menu.                            *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuFileOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFileOpen.Click
        ' Open the bmp, jpeg, or pcx image file.
        With OpenFileDialog1
            .FileName = ""
            .Filter = "All image files (*.bmp,*.jpg,*.pcx)|*.BMP;*.JPG;*.PCX|" + _
                "BMP files (*.bmp)|*.BMP|" + _
                "JPEG files (*.jpg)|*.JPG|" + _
                "PCX files (*.pcx)|*.PCX"
            If .ShowDialog() <> DialogResult.OK Then Return
            FileName = .FileName
        End With

        ' Check for a bmp file.
        If fg_bmphead(FileName, FileHeader(0)) = 0 Then
            Me.Cursor = Cursors.WaitCursor
            nColors = fg_bmppal(FileName, 0)
            fg_bmpsize(FileHeader(0), cxBuffer, cyBuffer)
            SwitchBuffers()
            fg_showbmp(FileName, 0)
            SaveFileDialog1.DefaultExt = "bmp"

            ' Check for a jpeg file.
        ElseIf fg_jpeghead(FileName, FileHeader(0)) = 0 Then
            Me.Cursor = Cursors.WaitCursor
            nColors = 0
            fg_jpegsize(FileHeader(0), cxBuffer, cyBuffer)
            SwitchBuffers()
            fg_showjpeg(FileName, 0)
            SaveFileDialog1.DefaultExt = "pcx"

            ' Check for a pcx file.
        ElseIf fg_pcxhead(FileName, FileHeader(0)) = 0 Then
            Me.Cursor = Cursors.WaitCursor
            nColors = fg_pcxpal(FileName, 0)
            fg_pcxsize(FileHeader(0), cxBuffer, cyBuffer)
            SwitchBuffers()
            fg_move(0, 0)
            fg_showpcx(FileName, FG_AT_XY)
            SaveFileDialog1.DefaultExt = "pcx"

            ' The file is not a valid bmp, jpeg, or pcx file.
        Else
            mbString = FileName + Chr(13) + "is not a recognized image file."
            MessageBox.Show(mbString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Make a copy of the original image.
        fg_copypage(hVB, hVBoriginal)

        ' Display the image.
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        Me.Cursor = Cursors.Default

        ' Enable remaining items on the File menu, and the image processing
        ' items on the Edit menu.
        menuFileSaveAs.Enabled = True
        menuFileDetails.Enabled = True
        menuEditUndo.Enabled = False
        menuEditRestoreImage.Enabled = False
        menuEditContrastEnhancement.Enabled = True
        menuEditGammaCorrection.Enabled = True
        menuEditGrayscale.Enabled = True
        menuEditPhotoInversion.Enabled = True
    End Sub

    Private Sub menuFileSaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFileSaveAs.Click
        ' Save image as a bmp file (original image was bmp).
        If SaveFileDialog1.DefaultExt = "bmp" Then
            With SaveFileDialog1
                .FileName = FileName.Substring(0, FileName.IndexOf(".")) + ".bmp"
                .Filter = "BMP files (*.bmp)|*.BMP"
                If .ShowDialog() <> DialogResult.OK Then Return
                FileName = .FileName
            End With
            Me.Cursor = Cursors.WaitCursor
            fg_makebmp(0, cxBuffer - 1, 0, cyBuffer - 1, 24, FileName)
            nColors = 0
            Me.Cursor = Cursors.Default

            ' Save image as a pcx file (original image was jpeg or pcx).
        ElseIf SaveFileDialog1.DefaultExt = "pcx" Then
            With SaveFileDialog1
                .FileName = FileName.Substring(0, FileName.IndexOf(".")) + ".pcx"
                .Filter = "PCX files (*.pcx)|*.PCX"
                If .ShowDialog() <> DialogResult.OK Then Return
                FileName = .FileName
            End With
            Me.Cursor = Cursors.WaitCursor
            fg_makepcx(0, cxBuffer - 1, 0, cyBuffer - 1, FileName)
            nColors = 0
            Me.Cursor = Cursors.Default
        End If
    End Sub

    Private Sub menuFileDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFileDetails.Click
        ' Display the original image resolution and color depth.
        mbString = FileName + Chr(13) + Format(cxBuffer, "D") + "x" + Format(cyBuffer, "D") + " pixels" + Chr(13)
        If nColors > 0 Then
            mbString += Format(nColors, "D") + " colors"
        Else
            mbString += "24-bit RGB"
        End If
        MessageBox.Show(mbString, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub menuFileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFileExit.Click
        Me.Close()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  Event handlers for the items on the Edit menu.                            *
    '                                                                            *
    '*****************************************************************************

    Private Sub menuEditUndo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuEditUndo.Click
        ' Undo the previous image processing operation.
        fg_copypage(hVBundo, hVB)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        menuEditUndo.Enabled = False
        menuEditRestoreImage.Enabled = True
    End Sub

    Private Sub menuEditRestoreImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuEditRestoreImage.Click
        ' Restore the original image.
        fg_copypage(hVB, hVBundo)
        fg_copypage(hVBoriginal, hVB)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        menuEditUndo.Enabled = True
        menuEditRestoreImage.Enabled = False
    End Sub

    Private Sub menuEditContrastEnhancement_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuEditContrastEnhancement.Click
        ' Perform a contrast enhancement transform on the active virtual buffer.
        fg_copypage(hVB, hVBundo)
        fg_move(0, cyBuffer - 1)
        fg_contvb(63, 192, cxBuffer, cyBuffer)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        menuEditUndo.Enabled = True
        menuEditRestoreImage.Enabled = True
    End Sub

    Private Sub menuEditGammaCorrection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuEditGammaCorrection.Click
        ' Perform a gamma correction transform on the active virtual buffer.
        fg_copypage(hVB, hVBundo)
        fg_move(0, cyBuffer - 1)
        fg_gammavb(0.45, cxBuffer, cyBuffer)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        menuEditUndo.Enabled = True
        menuEditRestoreImage.Enabled = True
    End Sub

    Private Sub menuEditGrayscale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuEditGrayscale.Click
        ' Perform a grayscale transform on the active virtual buffer.
        fg_copypage(hVB, hVBundo)
        fg_move(0, cyBuffer - 1)
        fg_grayvb(cxBuffer, cyBuffer)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        menuEditUndo.Enabled = True
        menuEditRestoreImage.Enabled = True
    End Sub

    Private Sub menuEditPhotoInversion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuEditPhotoInversion.Click
        ' Perform a photo-inversion transform on the active virtual buffer.
        fg_copypage(hVB, hVBundo)
        fg_move(0, cyBuffer - 1)
        fg_photovb(cxBuffer, cyBuffer)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
        menuEditUndo.Enabled = True
        menuEditRestoreImage.Enabled = True
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  SwitchBuffers()                                                           *
    '                                                                            *
    '  Close the and release the virtual buffers for the current image, then     *
    '  create and open new virtual buffers for the new image file.               *
    '                                                                            *
    '*****************************************************************************

    Private Sub SwitchBuffers()
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfree(hVBoriginal)
        fg_vbfree(hVBundo)
        hVB = fg_vballoc(cxBuffer, cyBuffer)
        fg_vbopen(hVB)
        hVBoriginal = fg_vballoc(cxBuffer, cyBuffer)
        hVBundo = fg_vballoc(cxBuffer, cyBuffer)
    End Sub
End Class
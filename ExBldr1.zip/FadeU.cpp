/****************************************************************************\
*                                                                            *
*  Fade.cpp                                                                  *
*  FadeU.cpp                                                                 *
*                                                                            *
*  This program shows how perform a palette fade.                            *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "FadeU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_showpcx("MOUSE.PCX",FG_AT_XY);
   fg_getdacs(10,236,Original);

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}

/****************************************************************************\
*                                                                            *
*  FadeInClick()                                                             *
*                                                                            *
*  Fade an image back to its original colors.                                *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::FadeInClick(TObject *Sender)
{
   register int i;
   bool Fading;

   Cursor = crHourGlass;
   memset(Current,0,236*3);

   do
   {
      Fading = False;
      for (i = 0; i < 236*3; i++)
      {
         if (Current[i] != Original[i])
         {
            Current[i]++;
            Fading = True;
         }
      }
      fg_setdacs(10,236,Current);
      if (fg_colors() > 8)
         fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
   }
   while (Fading);

   FadeOut->Enabled = True;
   FadeIn->Enabled = False;
   Cursor = crDefault;
}

/****************************************************************************\
*                                                                            *
*  FadeOutClick()                                                            *
*                                                                            *
*  Fade an image to black.                                                   *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::FadeOutClick(TObject *Sender)
{
   register int i;
   bool Fading;

   Cursor = crHourGlass;
   memcpy(Current,Original,236*3);

   do
   {
      Fading = False;
      for (i = 0; i < 236*3; i++)
      {
         if (Current[i] != 0)
         {
            Current[i]--;
            Fading = True;
         }
      }
      fg_setdacs(10,236,Current);
      if (fg_colors() > 8)
         fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
   }
   while (Fading);

   FadeOut->Enabled = False;
   FadeIn->Enabled = True;
   Cursor = crDefault;
}

//---------------------------------------------------------------------------
void __fastcall TForm1::ExitClick(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------

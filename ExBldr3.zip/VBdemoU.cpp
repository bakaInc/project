/****************************************************************************\
*                                                                            *
*  VBdemo.cpp                                                                *
*  VBdemoU.cpp                                                               *
*                                                                            *
*  This program demonstrates how to copy the contents of one virtual buffer  *
*  to another, with and without transparent colors.                          *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "VBDemoU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB2 = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB2);
   fg_vbcolors();
   hVB1 = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB1);
   fg_vbcolors();

   fg_setcolor(25);
   fg_fillpage();
   fg_setcolor(20);
   fg_rect(vbWidth/4,vbWidth*3/4,vbHeight/4,vbHeight*3/4);

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB1);
   fg_vbfree(hVB2);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::CutClick(TObject *Sender)
{
   fg_vbcopy(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1,hVB1,hVB2);
   fg_erase();
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
   Paste->Enabled = True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::PasteClick(TObject *Sender)
{
   fg_tcdefine(25,1);
   fg_vbtccopy(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1,hVB2,hVB1);
   fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitClick(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------

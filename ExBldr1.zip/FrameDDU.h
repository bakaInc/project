//---------------------------------------------------------------------------
#ifndef FrameDDUH
#define FrameDDUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <FGwin.h>

// define either BLIT or FLIP, but not both, for blitting or flipping
#define BLIT
//#define FLIP

#define vbWidth  640
#define vbHeight 480
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
   void __fastcall FormDestroy(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   bool AppIsActive;
   void __fastcall Animate(void);
   void __fastcall OnActivate(TObject *Sender);
   void __fastcall OnIdle(TObject *Sender, bool &Done);
protected:      // User declarations
   void __fastcall WMActivateApp(TMessage &Msg);
   BEGIN_MESSAGE_MAP
      MESSAGE_HANDLER(WM_ACTIVATEAPP, TMessage, WMActivateApp)
   END_MESSAGE_MAP(TForm)
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

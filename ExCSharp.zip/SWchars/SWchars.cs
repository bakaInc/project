/****************************************************************************\
*                                                                            *
*  SWchars.cs                                                                *
*                                                                            *
*  This program displays all characters in the Fastgraph for Windows primary *
*  and alternate software fonts.                                             *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace SWchars
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;

		// Virtual buffer dimensions.
		const int vbWidth = 640;
		const int vbHeight = 480;

		// Application variables.
		int xDest, yDest;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(640, 480);
			this.Name = "Form1";
			this.Text = "Software Character Set";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();

			fg.initw();
			fg.setworld(0.0, 6.39, 0.0, 4.79);
			fg.setsizew(0.2);

			fg.setcolor(25);
			fg.fillpage();
			fg.setcolor(19);
			fg.movew(3.2, 4.2);
			fg.swchar("Software characters - font 1", 28, 0);
			fg.setcolor(10);
			fg.movew(0.5, 3.9);
			fg.swchar("ABCDEFGHIJKLMNOPQRSTUVWXYZ", 26, -1);
			fg.movew(0.5, 3.6);
			fg.swchar("abcdefghijklmnopqrstuvwxyz", 26, -1);
			fg.movew(0.5, 3.3);
			fg.swchar("0123456789", 10, -1);
			fg.movew(0.5, 3.0);
			fg.swchar("!\"#$%&='()*+,-./:;<=>?[]^`{|}~", 29, -1);

			fg.setcolor(19);
			fg.movew(3.2, 2.5);
			fg.swchar("Software characters - font 2", 28, 0);
			fg.setcolor(10);
			fg.movew(0.5, 2.2);
			fg.swchar("\\ABCDEFGHIJKLMNOPRSTUWXYZ", 25, -1);
			fg.movew(0.5, 1.9);
			fg.swchar("\\abcdefghijklmnoprstuwxyz", 25, -1);
			fg.movew(0.5, 1.3);
			fg.swchar("\\012345678#$%&()*+/<=>?[]{}", 27, -1);

			fg.setratio(1.2);
			fg.movew(0.5, 0.6);
			fg.swchar("cos\\^2\\h\\+sin\\^2\\h\\=1", 21, -1);

			fg.movew(5.9, 0.6);
			fg.swchar("H\\v2O U\\v2\\v3\\v2", 16, 1);

			fg.setratio(1.0);
			fg.movew(3.2, 0.2);
			fg.swchar("One _word_ is underlined.", 25, 0);

			fg.setcolor(19);
			fg.movew(0.0, 2.8);
			fg.draww(6.39, 2.8);
			fg.movew(0.0, 0.9);
			fg.draww(6.39, 0.9);

			Form1_Resize(sender, e);
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbpaste(0, vbWidth-1, 0, vbHeight-1, xDest, yDest);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			xDest = (ClientRectangle.Width - vbWidth) / 2;
			yDest = (ClientRectangle.Height - vbHeight) / 2;
			if (xDest < 0) xDest = 0;
			if (yDest < 0) yDest = 0;
			yDest = (ClientRectangle.Height - 1) - yDest;
			Refresh();
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}
	}
}
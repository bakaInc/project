//---------------------------------------------------------------------------
#ifndef TunnelUH
#define TunnelUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <FGwin.h>

#define vbWidth  640
#define vbHeight 480

typedef struct point3d
{
   double x;
   double y;
   double z;
} POINT3D;
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   UINT cxClient, cyClient;
   int hZB;
   void __fastcall CheckForMovement(void);
   void __fastcall DrawTunnel(void);
   void __fastcall OnIdle(TObject *Sender, bool &Done);
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
// four sides of a 20x40x100 tunnel, defined in 3D world coordinates
POINT3D Floor[] = {
   {-10.0, 0.0,100.0},
   {-10.0, 0.0,200.0},
   { 10.0, 0.0,200.0},
   { 10.0, 0.0,100.0}
};
POINT3D WestSide[] = {
   {-10.0,  0.0,100.0},
   {-10.0, 40.0,100.0},
   {-10.0, 40.0,200.0},
   {-10.0,  0.0,200.0}
};
POINT3D EastSide[] = {
   { 10.0,  0.0,100.0},
   { 10.0,  0.0,200.0},
   { 10.0, 40.0,200.0},
   { 10.0, 40.0,100.0}
};
POINT3D Ceiling[] = {
   {-10.0, 40.0,100.0},
   { 10.0, 40.0,100.0},
   { 10.0, 40.0,200.0},
   {-10.0, 40.0,200.0}
};

// RGB color values at each vertex of each side
BYTE FloorRGB[]    = {192,192,192,  64, 64, 64,  64, 64, 64, 192,192,192};
BYTE WestSideRGB[] = { 32, 32,255,  32, 32,255,  32, 32, 96,  32, 32, 96};
BYTE EastSideRGB[] = { 32, 32,255,  32, 32, 96,  32, 32, 96,  32, 32,255};
BYTE CeilingRGB[]  = {192,192,192, 192,192,192,  64, 64, 64,  64, 64, 64};

// for convenience, an array of pointers to each of the four sides
POINT3D *Faces[] = {Floor,WestSide,EastSide,Ceiling};

// a similar array of pointers to each side's RGB values
BYTE *FacesRGB[] = {FloorRGB,WestSideRGB,EastSideRGB,CeilingRGB};
//---------------------------------------------------------------------------
#endif

/****************************************************************************\
*                                                                            *
*  KBdemo.cpp                                                                *
*  KBdemoU.cpp                                                               *
*                                                                            *
*  This program shows how to pan the contents of a virtual buffer through    *
*  a smaller window using the low-level keyboard handler.                    *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "KBDemoU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OnIdle(TObject *Sender, bool &Done)
{
   CheckForPanning();
   Done = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_showbmp("PORCH.BMP",0);
   x = y = 0;
   CanGoRight = CanGoDown = True;
   CanGoLeft = CanGoUp = False;

   Application->OnActivate = OnActivate;
   Application->OnIdle = OnIdle;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();

   if (cxClient < vbWidth)
   {
      xLimit = vbWidth - cxClient;
      if (x > 0)      CanGoLeft = True;
      if (x < xLimit) CanGoRight = True;
   }
   else
   {
      xLimit = 0;
      CanGoLeft = CanGoRight = False;
   }
   if (cyClient < vbHeight)
   {
      yLimit = vbHeight - cyClient;
      if (y > 0)      CanGoUp = True;
      if (y < yLimit) CanGoDown = True;
   }
   else
   {
      yLimit = 0;
      CanGoUp = CanGoDown = False;
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}

/****************************************************************************\
*                                                                            *
*  CheckForPanning()                                                         *
*                                                                            *
*  The CheckForPanning() function checks if any of the four arrow keys are   *
*  pressed, and if so, pans in that direction if possible. It is called from *
*  the OnIdle event handler.                                                 *
*                                                                            *
\****************************************************************************/

#define KB_ESCAPE 1
#define KB_LEFT  75
#define KB_RIGHT 77
#define KB_UP    72
#define KB_DOWN  80

void __fastcall TForm1::CheckForPanning()
{
   if (fg_kbtest(KB_LEFT) && CanGoLeft)
   {
      if (x == xLimit) CanGoRight = True;
      x--;
      fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
      if (x == 0) CanGoLeft = False;
   }
   else if (fg_kbtest(KB_RIGHT) && CanGoRight)
   {
      if (x == 0) CanGoLeft = True;
      x++;
      fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
      if (x == xLimit) CanGoRight = False;
   }
   else if (fg_kbtest(KB_UP) && CanGoUp)
   {
      if (y == yLimit) CanGoDown = True;
      y--;
      fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
      if (y == 0) CanGoUp = False;
   }
   else if (fg_kbtest(KB_DOWN) && CanGoDown)
   {
      if (y == 0) CanGoUp = True;
      y++;
      fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
      if (y == yLimit) CanGoDown = False;
   }
   else if (fg_kbtest(KB_ESCAPE))
   {
      x = y = 0;
      fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);
      if (xLimit > 0) CanGoRight = True;
      if (yLimit > 0) CanGoDown = True;
      CanGoLeft = CanGoUp = False;
   }
}

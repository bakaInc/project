//---------------------------------------------------------------------------
#ifndef CubeUH
#define CubeUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <FGwin.h>

#define vbWidth  640
#define vbHeight 480

typedef struct point3d
{
   double x;
   double y;
   double z;
} POINT3D;
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   UINT cxClient, cyClient;
   int vbDepth;
   void __fastcall CheckForMovement(void);
   void __fastcall DrawCube(void);
   void __fastcall OnIdle(TObject *Sender, bool &Done);
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
// six faces of a 40x40x40 cube, defined in object coordinates
POINT3D Face1[] = {
   { 20.0,-20.0,-20.0},
   {-20.0,-20.0,-20.0},
   {-20.0, 20.0,-20.0},
   { 20.0, 20.0,-20.0}
};
POINT3D Face2[] = {
   {-20.0,-20.0,-20.0},
   {-20.0,-20.0, 20.0},
   {-20.0, 20.0, 20.0},
   {-20.0, 20.0,-20.0}
};
POINT3D Face3[] = {
   { 20.0, 20.0, 20.0},
   {-20.0, 20.0, 20.0},
   {-20.0,-20.0, 20.0},
   { 20.0,-20.0, 20.0}
};
POINT3D Face4[] = {
   { 20.0,-20.0, 20.0},
   { 20.0,-20.0,-20.0},
   { 20.0, 20.0,-20.0},
   { 20.0, 20.0, 20.0}
};
POINT3D Face5[] = {
   { 20.0,-20.0, 20.0},
   {-20.0,-20.0, 20.0},
   {-20.0,-20.0,-20.0},
   { 20.0,-20.0,-20.0}
};
POINT3D Face6[] = {
   { 20.0, 20.0,-20.0},
   {-20.0, 20.0,-20.0},
   {-20.0, 20.0, 20.0},
   { 20.0, 20.0, 20.0}
};
// for convenience, an array of pointers to each of the six faces
POINT3D *Faces[] = {Face1,Face2,Face3,Face4,Face5,Face6};
//---------------------------------------------------------------------------
#endif

/****************************************************************************\
*                                                                            *
*  Colors.cpp                                                                *
*                                                                            *
*  This program illustrates how to establish the current color for 256-color *
*  and direct color virtual buffers. It obtains the display driver's color   *
*  depth, creates a 640x480 virtual buffer with the same color depth, and    *
*  fills it with blue pixels.                                                *
*                                                                            *
\****************************************************************************/

// Colors.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Colors.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColorsApp

BEGIN_MESSAGE_MAP(CColorsApp, CWinApp)
	//{{AFX_MSG_MAP(CColorsApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorsApp construction

CColorsApp::CColorsApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CColorsApp object

CColorsApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CColorsApp initialization

BOOL CColorsApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Color Depth"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CColorsApp message handlers

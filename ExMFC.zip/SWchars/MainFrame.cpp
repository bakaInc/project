// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "SWchars.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_xDest = 0;
	m_yDest = 0;
}

CMainFrame::~CMainFrame()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.cx = vbWidth;
	cs.cy = vbHeight;
	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		m_hVB = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		fg_initw();
		fg_setworld(0.0,6.39,0.0,4.79);
		fg_setsizew(0.2);

		fg_setcolor(25);
		fg_fillpage();
		fg_setcolor(19);
		fg_movew(3.2,4.2);
		fg_swchar("Software characters - font 1",28,0);
		fg_setcolor(10);
		fg_movew(0.5,3.9);
		fg_swchar("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,-1);
		fg_movew(0.5,3.6);
		fg_swchar("abcdefghijklmnopqrstuvwxyz",26,-1);
		fg_movew(0.5,3.3);
		fg_swchar("0123456789",10,-1);
		fg_movew(0.5,3.0);
		fg_swchar("!\"#$%&'()*+,-./:;<=>?[]^`{|}~",29,-1);

		fg_setcolor(19);
		fg_movew(3.2,2.5);
		fg_swchar("Software characters - font 2",28,0);
		fg_setcolor(10);
		fg_movew(0.5,2.2);
		fg_swchar("\\ABCDEFGHIJKLMNOPRSTUWXYZ",25,-1);
		fg_movew(0.5,1.9);
		fg_swchar("\\abcdefghijklmnoprstuwxyz",25,-1);
		fg_movew(0.5,1.3);
		fg_swchar("\\012345678#$%&()*+/<=>?[]{}",27,-1);

		fg_setratio(1.2);
		fg_movew(0.5,0.6);
		fg_swchar("cos\\^2\\h\\+sin\\^2\\h\\=1",21,-1);

		fg_movew(5.9,0.6);
		fg_swchar("H\\v2O U\\v2\\v3\\v2",16,1);

		fg_setratio(1.0);
		fg_movew(3.2,0.2);
		fg_swchar("One _word_ is underlined.",25,0);

		fg_setcolor(19);
		fg_movew(0.0,2.8);
		fg_draww(6.39,2.8);
		fg_movew(0.0,0.9);
		fg_draww(6.39,0.9);
	}
	return bRet;
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbpaste(0,vbWidth-1,0,vbHeight-1,m_xDest,m_yDest);
}

void CMainFrame::OnSize(UINT, int cx, int cy)
{
	m_xDest = (cx - vbWidth) / 2;
	m_yDest = (cy - vbHeight) / 2;
	if (m_xDest < 0) m_xDest = 0;
	if (m_yDest < 0) m_yDest = 0;
	m_yDest = (cy - 1) - m_yDest;
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

/****************************************************************************\
*                                                                            *
*  Fishtank.cpp                                                              *
*  FishtankU.cpp                                                             *
*                                                                            *
*  This program shows how to perform simple animation using Fastgraph for    *
*  Windows. Several types of tropical fish swim back and forth against a     *
*  coral reef background. The background image and fish sprites are stored   *
*  in PCX files.                                                             *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "FishtankU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OnIdle(TObject *Sender, bool &Done)
{
   GoFish();
   Done = False;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   // create two 320x200 virtual buffers
   fg_vbinit();
   hVB1 = fg_vballoc(320,200);
   hVB2 = fg_vballoc(320,200);

   // display the coral background in virtual buffer #2 (which
   // will always contain a clean copy of the background image)
   fg_vbopen(hVB2);
   fg_vbcolors();
   fg_showpcx("CORAL.PCX",FG_AT_XY|FG_KEEPCOLORS);

   // get the fish bitmaps
   GetFish();

   Application->OnActivate = OnActivate;
   Application->OnIdle = OnIdle;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,fg_getmaxx(),0,fg_getmaxy(),0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB1);
   fg_vbfree(hVB2);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}

/****************************************************************************\
*                                                                            *
*  GetFish()                                                                 *
*                                                                            *
*  Fill the fish bitmap arrays.                                              *
*                                                                            *
\****************************************************************************/

byte Fish1[56*25];
byte Fish2[54*38];
byte Fish3[68*26];
byte Fish4[56*30];
byte Fish5[62*22];
byte Fish6[68*36];

int FishX[]      = {  0, 64,128,200,  0, 80}; /* location of fish x & y */
int FishY[]      = {199,199,199,199,150,150};
int FishWidth[]  = { 56, 54, 68, 56, 62, 68}; /* size of fish: width */
int FishHeight[] = { 25, 38, 26, 30, 22, 36}; /* size of fish: height */

byte *Fishes[] = {Fish1, /* for convenience, an array of pointers to fishes */
                  Fish2,
                  Fish3,
                  Fish4,
                  Fish5,
                  Fish6};

void __fastcall TForm1::GetFish()
{
   register int FishNum;

   // get the fish bitmaps from an PCX file
   fg_vbopen(hVB1);
   fg_vbcolors();
   fg_showpcx("FISH.PCX",FG_AT_XY|FG_IGNOREPALETTE|FG_KEEPCOLORS);

   for (FishNum = 0; FishNum < 6; FishNum++)
   {
      fg_move(FishX[FishNum],FishY[FishNum]);
      fg_getimage(Fishes[FishNum],FishWidth[FishNum],FishHeight[FishNum]);
   }

   fg_erase();
}

/****************************************************************************\
*                                                                            *
*  GoFish()                                                                  *
*                                                                            *
*  Make the fish swim around.                                                *
*                                                                            *
\****************************************************************************/

/*  There are 11 fish total, and 6 different kinds of fish. These
*   arrays keep track of what kind of fish each fish is, and how each
*   fish moves:
*
*   Fish[]   -- which fish bitmap applies to this fish?
*   xStart[] -- starting x coordinate
*   yStart[] -- starting y coordinate
*
*   xMin[]   -- how far left (off screen) the fish can go
*   xMax[]   -- how far right (off screen) the fish can go
*   xInc[]   -- how fast the fish goes left and right
*   Dir[]    -- starting direction for each fish
*
*   yMin[]   -- how far up this fish can go
*   yMax[]   -- how far down this fish can go
*   yInc[]   -- how fast the fish moves up or down
*   yTurn[]  -- how long fish can go in the vertical direction
*               before stopping or turning around
*   yCount[] -- counter to compare to yTurn
*/

int Fish[]   = {   1,   1,   2,   3,   3,   0,   0,   5,   4,   2,   3};
int xStart[] = {-100,-150,-450,-140,-200, 520, 620,-800, 800, 800,-300};
int yStart[] = {  40,  60, 150,  80,  70, 190, 180, 100,  30, 130,  92};

int xMin[]   = {-300,-300,-800,-200,-200,-200,-300,-900,-900,-900,-400};
int xMax[]   = { 600, 600,1100,1000,1000, 750, 800,1200,1400,1200, 900};
int xInc[]   = {   2,   2,   8,   5,   5,  -3,  -3,   7,  -8,  -9,   6};
int Dir[]    = {   0,   0,   0,   0,   0,   1,   1,   0,   1,   1,   0};

int yMin[]   = {  40,  60, 120,  70,  60, 160, 160,  80,  30, 110,  72};
int yMax[]   = {  80, 100, 170, 110, 100, 199, 199, 120,  70, 150, 122};
int yTurn[]  = {  50,  30,  10,  30,  20,  10,  10,  10,  30,   20, 10};
int yCount[] = {   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0};
int yInc[]   = {   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0};

void __fastcall TForm1::GoFish()
{
   register int i;

   // copy the background to the workspace
   fg_copypage(hVB2,hVB1);

   // put all the fish in their new positions
   for (i = 0; i < NFISH; i++)
   {
      yCount[i]++;
      if (yCount[i] > yTurn[i])
      {
         yCount[i] = 0;
         yInc[i] = (rand() % 3) - 1;
      }
      yStart[i] += yInc[i];
      yStart[i] = MIN(yMax[i],MAX(yStart[i],yMin[i]));

      if (xStart[i] >= -72 && xStart[i] < 320)
         PutFish(Fish[i],xStart[i],yStart[i],Dir[i]);

      xStart[i] += xInc[i];
      if (xStart[i] <= xMin[i] || xStart[i] >= xMax[i])
      {
         xInc[i] = -xInc[i];
         Dir[i] = 1 - Dir[i];
      }
   }

   // scale the workspace image to fill the client area
   fg_vbscale(0,319,0,199,0,cxClient-1,0,cyClient-1);
}

/****************************************************************************\
*                                                                            *
*  PutFish()                                                                 *
*                                                                            *
*  Draw one of the six fish anywhere you want.                               *
*                                                                            *
\****************************************************************************/

void __fastcall TForm1::PutFish (int FishNum, int x, int y, int FishDir)
{
   // move to position where the fish will appear
   fg_move(x,y);

   // draw a left- or right-facing fish, depending on FishDir
   if (FishDir == 0)
      fg_flpimage(Fishes[FishNum],FishWidth[FishNum],FishHeight[FishNum]);
   else
      fg_clpimage(Fishes[FishNum],FishWidth[FishNum],FishHeight[FishNum]);
}

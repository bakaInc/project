'*****************************************************************************
'                                                                            *
'  FGWinD.vb                                                                 *
'                                                                            *
'  This file contains the Visual Basic function declarations for the         *
'  Fastgraph/Light 6.03 for Windows DirectX libraries.                       *
'                                                                            *
'  Copyright (c) 1996-2003 Ted Gruber Software.  All rights reserved.        *
'                                                                            *
'*****************************************************************************

Module FGWinD
	' fg_3Drenderstate() bit flags
	Public Const FG_LINEAR_TM As Integer = 0
	Public Const FG_PERSPECTIVE_TM As Integer = 1
	Public Const FG_WIREFRAME As Integer = 2
	Public Const FG_ZBUFFER As Integer = 4
	Public Const FG_ZCLIP As Integer = 8
	
	' fg_ddsetup() bit flags
	Public Const FG_DX_BLIT As Integer = 0
	Public Const FG_DX_FLIP As Integer = 1
	Public Const FG_DX_RENDER_FG As Integer = 0
	Public Const FG_DX_RENDER_SW As Integer = 2
	Public Const FG_DX_RENDER_HW As Integer = 4
	Public Const FG_DX_ZBUFFER As Integer = 8
	Public Const FG_DX_TCDEPTH As Integer = 16
	
	' image file bit flags
	Public Const FG_IGNOREPALETTE As Integer = 1
	Public Const FG_AT_XY As Integer = 2
	Public Const FG_FROMBUFFER As Integer = 4
	Public Const FG_KEEPCOLORS As Integer = 8
	Public Const FG_NODELAY As Integer = 1
	Public Const FG_IGNOREAVIPALETTE As Integer = 16
	Public Const FG_IGNOREFLICPALETTE As Integer = 16
	
	' fg_3Dgetmatrix() and fg_3Dsetmatrix() constants
	Public Const FG_OBJECT_ROTATION As Integer = 0
	Public Const FG_OBJECT_TRANSLATION As Integer = 1
	Public Const FG_OBJECT_TRANSFORM As Integer = 2
	Public Const FG_WORLD_ROTATION As Integer = 3
	Public Const FG_WORLD_TRANSLATION As Integer = 4
	Public Const FG_WORLD_TRANSFORM As Integer = 5
	Public Const FG_COMBINED_TRANSFORM As Integer = 6

	Declare Function fg_3Daxisangle Lib "fgw32dd" Alias "_fg_3Daxisangle@28" _
		(ByVal x As Double, ByVal y As Double, ByVal z As Double, ByVal Angle As Integer) As Integer
	Declare Function fg_3Daxisangleobject Lib "fgw32dd" Alias "_fg_3Daxisangleobject@28" _
		(ByVal x As Double, ByVal y As Double, ByVal z As Double, ByVal Angle As Integer) As Integer
	Declare Function fg_3Dbehindviewer Lib "fgw32dd" Alias "_fg_3Dbehindviewer@32" _
		(ByVal x As Double, ByVal y As Double, ByVal z As Double, ByVal Tolerance As Double) As Integer
	Declare Sub fg_3Dgetmatrix Lib "fgw32dd" Alias "_fg_3Dgetmatrix@8" _
		(ByRef Matrix As Double, ByVal Flag As Integer)
	Declare Sub fg_3Dgetpov Lib "fgw32dd" Alias "_fg_3Dgetpov@24" _
		(ByRef x As Double, ByRef y As Double, ByRef z As Double, ByRef xOut As Double, ByRef yOut As Double, ByRef zOut As Double)
	Declare Sub fg_3Dline Lib "fgw32dd" Alias "_fg_3Dline@48" _
		(ByVal x1 As Double, ByVal y1 As Double, ByVal z1 As Double, ByVal x2 As Double, ByVal y2 As Double, ByVal z2 As Double)
	Declare Function fg_3Dlookat Lib "fgw32dd" Alias "_fg_3Dlookat@48" _
		(ByVal xFrom As Double, ByVal yFrom As Double, ByVal zFrom As Double, ByVal xTo As Double, ByVal yTo As Double, ByVal zTo As Double) As Integer
	Declare Sub fg_3Dmove Lib "fgw32dd" Alias "_fg_3Dmove@24" _
		(ByVal x As Double, ByVal y As Double, ByVal z As Double)
	Declare Sub fg_3Dmoveforward Lib "fgw32dd" Alias "_fg_3Dmoveforward@8" _
		(ByVal Amount As Double)
	Declare Sub fg_3Dmoveforwardobject Lib "fgw32dd" Alias "_fg_3Dmoveforwardobject@8" _
		(ByVal Amount As Double)
	Declare Sub fg_3Dmoveobject Lib "fgw32dd" Alias "_fg_3Dmoveobject@24" _
		(ByVal x As Double, ByVal y As Double, ByVal z As Double)
	Declare Sub fg_3Dmoveright Lib "fgw32dd" Alias "_fg_3Dmoveright@8" _
		(ByVal Amount As Double)
	Declare Sub fg_3Dmoverightobject Lib "fgw32dd" Alias "_fg_3Dmoverightobject@8" _
		(ByVal Amount As Double)
	Declare Sub fg_3Dmoveup Lib "fgw32dd" Alias "_fg_3Dmoveup@8" _
		(ByVal Amount As Double)
	Declare Sub fg_3Dmoveupobject Lib "fgw32dd" Alias "_fg_3Dmoveupobject@8" _
		(ByVal Amount As Double)
	Declare Sub fg_3Dpolygon Lib "fgw32dd" Alias "_fg_3Dpolygon@8" _
		(ByRef xyzArray As Double, ByVal n As Integer)
	Declare Sub fg_3Dpolygonobject Lib "fgw32dd" Alias "_fg_3Dpolygonobject@8" _
		(ByRef xyzArray As Double, ByVal n As Integer)
	Declare Sub fg_3Dpov Lib "fgw32dd" Alias "_fg_3Dpov@36" _
		(ByVal x As Double, ByVal y As Double, ByVal z As Double, ByVal xAngle As Integer, ByVal yAngle As Integer, ByVal zAngle As Integer)
	Declare Sub fg_3Dproject Lib "fgw32dd" Alias "_fg_3Dproject@12" _
		(ByRef Source As Double, ByRef Dest As Integer, ByVal n As Integer)
	Declare Sub fg_3Drenderstate Lib "fgw32dd" Alias "_fg_3Drenderstate@4" _
		(ByVal Flags As Integer)
	Declare Sub fg_3Droll Lib "fgw32dd" Alias "_fg_3Droll@4" _
		(ByVal Angle As Integer)
	Declare Sub fg_3Drollobject Lib "fgw32dd" Alias "_fg_3Drollobject@4" _
		(ByVal Angle As Integer)
	Declare Function fg_3Drotate Lib "fgw32dd" Alias "_fg_3Drotate@24" _
		(ByVal xOut As Double, ByVal yOut As Double, ByVal zOut As Double) As Integer
	Declare Function fg_3Drotateobject Lib "fgw32dd" Alias "_fg_3Drotateobject@24" _
		(ByVal xOut As Double, ByVal yOut As Double, ByVal zOut As Double) As Integer
	Declare Sub fg_3Drotateright Lib "fgw32dd" Alias "_fg_3Drotateright@4" _
		(ByVal Angle As Integer)
	Declare Sub fg_3Drotaterightobject Lib "fgw32dd" Alias "_fg_3Drotaterightobject@4" _
		(ByVal Angle As Integer)
	Declare Sub fg_3Drotateup Lib "fgw32dd" Alias "_fg_3Drotateup@4" _
		(ByVal Angle As Integer)
	Declare Sub fg_3Drotateupobject Lib "fgw32dd" Alias "_fg_3Drotateupobject@4" _
		(ByVal Angle As Integer)
	Declare Sub fg_3Dsetmatrix Lib "fgw32dd" Alias "_fg_3Dsetmatrix@12" _
		(ByRef Matrix As Double, ByVal Flag As Integer, ByVal Update As Integer)
	Declare Sub fg_3Dsetobject Lib "fgw32dd" Alias "_fg_3Dsetobject@36" _
		(ByVal x As Double, ByVal y As Double, ByVal z As Double, ByVal xAngle As Integer, ByVal yAngle As Integer, ByVal zAngle As Integer)
	Declare Sub fg_3Dsetzclip Lib "fgw32dd" Alias "_fg_3Dsetzclip@16" _
		(ByVal zNear As Double, ByVal zFar As Double)
	Declare Sub fg_3Dshade Lib "fgw32dd" Alias "_fg_3Dshade@12" _
		(ByRef xyzArray As Double, ByRef rgbArray As Byte, ByVal n As Integer)
	Declare Sub fg_3Dshadeobject Lib "fgw32dd" Alias "_fg_3Dshadeobject@12" _
		(ByRef xyzArray As Double, ByRef rgbArray As Byte, ByVal n As Integer)
	Declare Sub fg_3Dtexturemap Lib "fgw32dd" Alias "_fg_3Dtexturemap@12" _
		(ByRef xyzArray As Double, ByRef uvArray As Integer, ByVal n As Integer)
	Declare Sub fg_3Dtexturemap Lib "fgw32dd" Alias "_fg_3Dtexturemap@12" _
		(ByRef xyzArray As Double, ByRef uvArray As Single, ByVal n As Integer)
	Declare Sub fg_3Dtexturemapobject Lib "fgw32dd" Alias "_fg_3Dtexturemapobject@12" _
		(ByRef xyzArray As Double, ByRef uvArray As Integer, ByVal n As Integer)
	Declare Sub fg_3Dtexturemapobject Lib "fgw32dd" Alias "_fg_3Dtexturemapobject@12" _
		(ByRef xyzArray As Double, ByRef uvArray As Single, ByVal n As Integer)
	Declare Sub fg_3Dtransform Lib "fgw32dd" Alias "_fg_3Dtransform@12" _
		(ByRef Source As Double, ByRef Dest As Double, ByVal n As Integer)
	Declare Sub fg_3Dtransformobject Lib "fgw32dd" Alias "_fg_3Dtransformobject@12" _
		(ByRef Source As Double, ByRef Dest As Double, ByVal n As Integer)
	Declare Sub fg_3Dupvector Lib "fgw32dd" Alias "_fg_3Dupvector@24" _
		(ByVal x As Double, ByVal y As Double, ByVal z As Double)
	Declare Sub fg_3Dviewport Lib "fgw32dd" Alias "_fg_3Dviewport@24" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal Ratio As Double)
	Declare Function fg_3Dzclip Lib "fgw32dd" Alias "_fg_3Dzclip@12" _
		(ByRef xyzSource As Double, ByRef xyzDest As Double, ByVal n As Integer) As Integer
	Declare Function fg_3Dzcliprgb Lib "fgw32dd" Alias "_fg_3Dzcliprgb@20" _
		(ByRef xyzSource As Double, ByRef xyzDest As Double, ByRef rgbSource As Byte, ByRef rgbDest As Byte, ByVal n As Integer) As Integer
	Declare Function fg_3Dzcliptm Lib "fgw32dd" Alias "_fg_3Dzcliptm@20" _
		(ByRef xyzSource As Double, ByRef xyzDest As Double, ByRef uvSource As Integer, ByRef uvDest As Integer, ByVal n As Integer) As Integer
	Declare Function fg_3Dzcliptm Lib "fgw32dd" Alias "_fg_3Dzcliptm@20" _
		(ByRef xyzSource As Double, ByRef xyzDest As Double, ByRef uvSource As Single, ByRef uvDest As Single, ByVal n As Integer) As Integer

	Declare Sub fg_arc Lib "fgw32dd" Alias "_fg_arc@12" _
		(ByVal Radius As Integer, ByVal StartAngle As Integer, ByVal EndAngle As Integer)
	Declare Sub fg_arcw Lib "fgw32dd" Alias "_fg_arcw@16" _
		(ByVal Radius As Double, ByVal StartAngle As Integer, ByVal EndAngle As Integer)
	Declare Sub fg_avidone Lib "fgw32dd" Alias "_fg_avidone@4" _
		(ByRef Context As Byte)
	Declare Function fg_aviframe Lib "fgw32dd" Alias "_fg_aviframe@8" _
		(ByRef Context As Byte, ByRef Bitmap As Byte) As Integer
	Declare Function fg_avihead Lib "fgw32dd" Alias "_fg_avihead@8" _
		(ByVal FileName As String, ByRef Header As Byte) As Integer
	Declare Function fg_avimake Lib "fgw32dd" Alias "_fg_avimake@32" _
		(ByVal FileName As String, ByRef Context As Byte, ByVal Compressor As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal nDepth As Integer, ByVal Quality As Integer, ByVal Rate As Integer) As Integer
	Declare Function fg_aviopen Lib "fgw32dd" Alias "_fg_aviopen@8" _
		(ByVal FileName As String, ByRef Context As Byte) As Integer
	Declare Function fg_avipal Lib "fgw32dd" Alias "_fg_avipal@8" _
		(ByVal FileName As String, ByRef Palette As Byte) As Integer
	Declare Function fg_avipal Lib "fgw32dd" Alias "_fg_avipal@8" _
		(ByVal FileName As String, ByVal NullParam As Integer) As Integer
	Declare Function fg_aviplay Lib "fgw32dd" Alias "_fg_aviplay@12" _
		(ByRef Context As Byte, ByVal nFrames As Integer, ByVal Flags As Integer) As Integer
	Declare Sub fg_avisize Lib "fgw32dd" Alias "_fg_avisize@12" _
		(ByRef Header As Byte, ByRef nWidth As Integer, ByRef nHeight As Integer)
	Declare Function fg_aviskip Lib "fgw32dd" Alias "_fg_aviskip@8" _
		(ByRef Context As Byte, ByVal nFrames As Integer) As Integer

	Declare Function fg_blend Lib "fgw32dd" Alias "_fg_blend@8" _
		(ByVal Foreground As Integer, ByVal Background As Integer) As Integer
	Declare Function fg_blend50 Lib "fgw32dd" Alias "_fg_blend50@8" _
		(ByVal Foreground As Integer, ByVal Background As Integer) As Integer
	Declare Sub fg_blenddcb Lib "fgw32dd" Alias "_fg_blenddcb@16" _
		(ByRef Foreground As Byte, ByRef Background As Byte, ByRef Blended As Byte, ByVal nSize As Integer)
	Declare Sub fg_blendvar Lib "fgw32dd" Alias "_fg_blendvar@20" _
		(ByRef Foreground As Byte, ByRef Background As Byte, ByRef Opacity As Byte, ByRef Blended As Byte, ByVal nSize As Integer)
	Declare Sub fg_blendvb Lib "fgw32dd" Alias "_fg_blendvb@16" _
		(ByRef Foreground As Byte, ByRef Background As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_blendvb Lib "fgw32dd" Alias "_fg_blendvb@16" _
		(ByRef Foreground As Byte, ByVal NullParam As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_blendvbv Lib "fgw32dd" Alias "_fg_blendvbv@20" _
		(ByRef Foreground As Byte, ByRef Background As Byte, ByRef Opacity As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_blendvbv Lib "fgw32dd" Alias "_fg_blendvbv@20" _
		(ByRef Foreground As Byte, ByVal NullParam As Integer, ByRef Opacity As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Function fg_bmphead Lib "fgw32dd" Alias "_fg_bmphead@8" _
		(ByVal FileName As String, ByRef Header As Byte) As Integer
	Declare Function fg_bmppal Lib "fgw32dd" Alias "_fg_bmppal@8" _
		(ByVal FileName As String, ByRef Palette As Byte) As Integer
	Declare Function fg_bmppal Lib "fgw32dd" Alias "_fg_bmppal@8" _
		(ByVal FileName As String, ByVal NullParam As Integer) As Integer
	Declare Sub fg_bmpsize Lib "fgw32dd" Alias "_fg_bmpsize@12" _
		(ByRef Header As Byte, ByRef nWidth As Integer, ByRef nHeight As Integer)
	Declare Sub fg_box Lib "fgw32dd" Alias "_fg_box@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_boxdepth Lib "fgw32dd" Alias "_fg_boxdepth@8" _
		(ByVal xDepth As Integer, ByVal yDepth As Integer)
	Declare Sub fg_boxw Lib "fgw32dd" Alias "_fg_boxw@32" _
		(ByVal xMin As Double, ByVal xMax As Double, ByVal yMin As Double, ByVal yMax As Double)
	Declare Sub fg_boxx Lib "fgw32dd" Alias "_fg_boxx@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_boxxw Lib "fgw32dd" Alias "_fg_boxxw@32" _
		(ByVal xMin As Double, ByVal xMax As Double, ByVal yMin As Double, ByVal yMax As Double)

	Declare Sub fg_circle Lib "fgw32dd" Alias "_fg_circle@4" _
		(ByVal Radius As Integer)
	Declare Sub fg_circlef Lib "fgw32dd" Alias "_fg_circlef@4" _
		(ByVal Radius As Integer)
	Declare Sub fg_circlefw Lib "fgw32dd" Alias "_fg_circlefw@8" _
		(ByVal Radius As Double)
	Declare Sub fg_circlew Lib "fgw32dd" Alias "_fg_circlew@8" _
		(ByVal Radius As Double)
	Declare Function fg_clip2vb Lib "fgw32dd" Alias "_fg_clip2vb@20" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal Flags As Integer) As Integer
	Declare Sub fg_clipdcb Lib "fgw32dd" Alias "_fg_clipdcb@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_clipmap Lib "fgw32dd" Alias "_fg_clipmap@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_clipmask Lib "fgw32dd" Alias "_fg_clipmask@12" _
		(ByRef Bitmap As Byte, ByVal nRuns As Integer, ByVal nWidth As Integer)
	Declare Sub fg_clpimage Lib "fgw32dd" Alias "_fg_clpimage@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_clprect Lib "fgw32dd" Alias "_fg_clprect@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_clprectw Lib "fgw32dd" Alias "_fg_clprectw@32" _
		(ByVal xMin As Double, ByVal xMax As Double, ByVal yMin As Double, ByVal yMax As Double)
	Declare Sub fg_clprectx Lib "fgw32dd" Alias "_fg_clprectx@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Function fg_colors Lib "fgw32dd" Alias "_fg_colors@0" _
		() As Integer
	Declare Sub fg_contdcb Lib "fgw32dd" Alias "_fg_contdcb@20" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal nLower As Integer, ByVal nUpper As Integer, ByVal nSize As Integer)
	Declare Sub fg_contrgb Lib "fgw32dd" Alias "_fg_contrgb@16" _
		(ByRef Values As Byte, ByVal nLower As Integer, ByVal nUpper As Integer, ByVal nCount As Integer)
	Declare Sub fg_contvb Lib "fgw32dd" Alias "_fg_contvb@16" _
		(ByVal nLower As Integer, ByVal nUpper As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_copypage Lib "fgw32dd" Alias "_fg_copypage@8" _
		(ByVal Source As Integer, ByVal Dest As Integer)
	Declare Sub fg_cut Lib "fgw32dd" Alias "_fg_cut@28" _
		(ByRef Bitmap As Byte, ByRef Section As Byte, ByVal xPos As Integer, ByVal yPos As Integer, ByVal nWidth As Integer, ByVal nSecWidth As Integer, ByVal nSecHeight As Integer)
	Declare Sub fg_cutdcb Lib "fgw32dd" Alias "_fg_cutdcb@28" _
		(ByRef Bitmap As Byte, ByRef Section As Byte, ByVal xPos As Integer, ByVal yPos As Integer, ByVal nWidth As Integer, ByVal nSecWidth As Integer, ByVal nSecHeight As Integer)

	Declare Sub fg_dash Lib "fgw32dd" Alias "_fg_dash@12" _
		(ByVal x As Integer, ByVal y As Integer, ByVal Pattern As Integer)
	Declare Sub fg_dashrel Lib "fgw32dd" Alias "_fg_dashrel@12" _
		(ByVal x As Integer, ByVal y As Integer, ByVal Pattern As Integer)
	Declare Sub fg_dashrw Lib "fgw32dd" Alias "_fg_dashrw@20" _
		(ByVal x As Double, ByVal y As Double, ByVal Pattern As Integer)
	Declare Sub fg_dashw Lib "fgw32dd" Alias "_fg_dashw@20" _
		(ByVal x As Double, ByVal y As Double, ByVal Pattern As Integer)
	Declare Sub fg_defcolor Lib "fgw32dd" Alias "_fg_defcolor@8" _
		(ByVal nIndex As Integer, ByVal nValue As Integer)
	Declare Function fg_defpal Lib "fgw32dd" Alias "_fg_defpal@0" _
		() As Integer
	Declare Sub fg_dispfile Lib "fgw32dd" Alias "_fg_dispfile@12" _
		(ByVal FileName As String, ByVal nWidth As Integer, ByVal Format As Integer)
	Declare Sub fg_display Lib "fgw32dd" Alias "_fg_display@12" _
		(ByRef Bitmap As Byte, ByVal nRuns As Integer, ByVal nWidth As Integer)
	Declare Sub fg_displayp Lib "fgw32dd" Alias "_fg_displayp@12" _
		(ByRef Bitmap As Byte, ByVal nRuns As Integer, ByVal nWidth As Integer)
	Declare Sub fg_draw Lib "fgw32dd" Alias "_fg_draw@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_drawdcb Lib "fgw32dd" Alias "_fg_drawdcb@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_drawmap Lib "fgw32dd" Alias "_fg_drawmap@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_drawmask Lib "fgw32dd" Alias "_fg_drawmask@12" _
		(ByRef Bitmap As Byte, ByVal nRuns As Integer, ByVal nWidth As Integer)
	Declare Sub fg_drawrel Lib "fgw32dd" Alias "_fg_drawrel@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_drawrelx Lib "fgw32dd" Alias "_fg_drawrelx@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_drawrw Lib "fgw32dd" Alias "_fg_drawrw@16" _
		(ByVal x As Double, ByVal y As Double)
	Declare Sub fg_drawrxw Lib "fgw32dd" Alias "_fg_drawrxw@16" _
		(ByVal x As Double, ByVal y As Double)
	Declare Sub fg_draww Lib "fgw32dd" Alias "_fg_draww@16" _
		(ByVal x As Double, ByVal y As Double)
	Declare Sub fg_drawx Lib "fgw32dd" Alias "_fg_drawx@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_drawxw Lib "fgw32dd" Alias "_fg_drawxw@16" _
		(ByVal x As Double, ByVal y As Double)
	Declare Sub fg_drawz Lib "fgw32dd" Alias "_fg_drawz@24" _
		(ByVal x As Integer, ByVal y As Integer, ByVal zStart As Double, ByVal zEnd As Double)
	Declare Sub fg_drect Lib "fgw32dd" Alias "_fg_drect@20" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByRef Matrix As Byte)
	Declare Sub fg_drectw Lib "fgw32dd" Alias "_fg_drectw@36" _
		(ByVal xMin As Double, ByVal xMax As Double, ByVal yMin As Double, ByVal yMax As Double, ByRef Matrix As Byte)
	Declare Sub fg_drwimage Lib "fgw32dd" Alias "_fg_drwimage@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)

	Declare Sub fg_ellipse Lib "fgw32dd" Alias "_fg_ellipse@8" _
		(ByVal Horiz As Integer, ByVal Vert As Integer)
	Declare Sub fg_ellipsef Lib "fgw32dd" Alias "_fg_ellipsef@8" _
		(ByVal Horiz As Integer, ByVal Vert As Integer)
	Declare Sub fg_ellipsew Lib "fgw32dd" Alias "_fg_ellipsew@16" _
		(ByVal Horiz As Double, ByVal Vert As Double)
	Declare Sub fg_ellipsfw Lib "fgw32dd" Alias "_fg_ellipsfw@16" _
		(ByVal Horiz As Double, ByVal Vert As Double)
	Declare Sub fg_erase Lib "fgw32dd" Alias "_fg_erase@0" _
		()

	Declare Sub fg_fillpage Lib "fgw32dd" Alias "_fg_fillpage@0" _
		()
	Declare Function fg_findrgb Lib "fgw32dd" Alias "_fg_findrgb@12" _
		(ByVal Red As Integer, ByVal Green As Integer, ByVal Blue As Integer) As Integer
	Declare Function fg_fixdiv Lib "fgw32dd" Alias "_fg_fixdiv@8" _
		(ByVal n1 As Integer, ByVal n2 As Integer) As Integer
	Declare Function fg_fixed Lib "fgw32dd" Alias "_fg_fixed@8" _
		(ByVal n As Double) As Integer
	Declare Function fg_fixmul Lib "fgw32dd" Alias "_fg_fixmul@8" _
		(ByVal n1 As Integer, ByVal n2 As Integer) As Integer
	Declare Sub fg_fixtrig Lib "fgw32dd" Alias "_fg_fixtrig@12" _
		(ByVal Angle As Integer, ByRef Cosine As Integer, ByRef Sine As Integer)
	Declare Sub fg_flicdone Lib "fgw32dd" Alias "_fg_flicdone@4" _
		(ByRef Context As Byte)
	Declare Function fg_flichead Lib "fgw32dd" Alias "_fg_flichead@8" _
		(ByVal FileName As String, ByRef Header As Byte) As Integer
	Declare Function fg_flicopen Lib "fgw32dd" Alias "_fg_flicopen@8" _
		(ByVal FileName As String, ByRef Context As Byte) As Integer
	Declare Function fg_flicplay Lib "fgw32dd" Alias "_fg_flicplay@12" _
		(ByRef Context As Byte, ByVal nFrames As Integer, ByVal Flags As Integer) As Integer
	Declare Sub fg_flicsize Lib "fgw32dd" Alias "_fg_flicsize@12" _
		(ByRef Header As Byte, ByRef nWidth As Integer, ByRef nHeight As Integer)
	Declare Function fg_flicskip Lib "fgw32dd" Alias "_fg_flicskip@8" _
		(ByRef Context As Byte, ByVal nFrames As Integer) As Integer
	Declare Sub fg_flipdcb Lib "fgw32dd" Alias "_fg_flipdcb@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_flipmask Lib "fgw32dd" Alias "_fg_flipmask@12" _
		(ByRef Bitmap As Byte, ByVal nRuns As Integer, ByVal nWidth As Integer)
	Declare Function fg_float Lib "fgw32dd" Alias "_fg_float@4" _
		(ByVal n As Integer) As Double
	Declare Sub fg_flood Lib "fgw32dd" Alias "_fg_flood@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_floodw Lib "fgw32dd" Alias "_fg_floodw@16" _
		(ByVal x As Double, ByVal y As Double)
	Declare Sub fg_flpimage Lib "fgw32dd" Alias "_fg_flpimage@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_fontdc Lib "fgw32dd" Alias "_fg_fontdc@4" _
		(ByVal hDC As IntPtr)
	Declare Sub fg_fontload Lib "fgw32dd" Alias "_fg_fontload@4" _
		(ByVal FontId As Integer)

	Declare Sub fg_gammadcb Lib "fgw32dd" Alias "_fg_gammadcb@20" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal Gamma As Double, ByVal nSize As Integer)
	Declare Sub fg_gammargb Lib "fgw32dd" Alias "_fg_gammargb@16" _
		(ByRef Values As Byte, ByVal Gamma As Double, ByVal nCount As Integer)
	Declare Sub fg_gammavb Lib "fgw32dd" Alias "_fg_gammavb@16" _
		(ByVal Gamma As Double, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_getblock Lib "fgw32dd" Alias "_fg_getblock@20" _
		(ByRef Buffer As Byte, ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_getclip Lib "fgw32dd" Alias "_fg_getclip@16" _
		(ByRef xMin As Integer, ByRef xMax As Integer, ByRef yMin As Integer, ByRef yMax As Integer)
	Declare Function fg_getclock Lib "fgw32dd" Alias "_fg_getclock@0" _
		() As Integer
	Declare Function fg_getcolor Lib "fgw32dd" Alias "_fg_getcolor@0" _
		() As Integer
	Declare Sub fg_getdacs Lib "fgw32dd" Alias "_fg_getdacs@12" _
		(ByVal nStart As Integer, ByVal nCount As Integer, ByRef Values As Byte)
	Declare Function fg_getdc Lib "fgw32dd" Alias "_fg_getdc@0" _
		() As IntPtr
	Declare Sub fg_getdcb Lib "fgw32dd" Alias "_fg_getdcb@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Function fg_getdepth Lib "fgw32dd" Alias "_fg_getdepth@0" _
		() As Integer
	Declare Function fg_gethcbpp Lib "fgw32dd" Alias "_fg_gethcbpp@0" _
		() As Integer
	Declare Function fg_gethpage Lib "fgw32dd" Alias "_fg_gethpage@0" _
		() As Integer
	Declare Sub fg_getimage Lib "fgw32dd" Alias "_fg_getimage@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Function fg_getindex Lib "fgw32dd" Alias "_fg_getindex@4" _
		(ByVal nIndex As Integer) As Integer
	Declare Function fg_getline Lib "fgw32dd" Alias "_fg_getline@4" _
		(ByVal nRow As Integer) As Integer
	Declare Function fg_getlines Lib "fgw32dd" Alias "_fg_getlines@0" _
		() As Integer
	Declare Sub fg_getmap Lib "fgw32dd" Alias "_fg_getmap@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Function fg_getmaxx Lib "fgw32dd" Alias "_fg_getmaxx@0" _
		() As Integer
	Declare Function fg_getmaxy Lib "fgw32dd" Alias "_fg_getmaxy@0" _
		() As Integer
	Declare Function fg_getpage Lib "fgw32dd" Alias "_fg_getpage@0" _
		() As Integer
	Declare Function fg_getpixel Lib "fgw32dd" Alias "_fg_getpixel@8" _
		(ByVal x As Integer, ByVal y As Integer) As Integer
	Declare Sub fg_getrgb Lib "fgw32dd" Alias "_fg_getrgb@16" _
		(ByVal nColor As Integer, ByRef Red As Integer, ByRef Green As Integer, ByRef Blue As Integer)
	Declare Sub fg_getview Lib "fgw32dd" Alias "_fg_getview@32" _
		(ByRef xMinView As Integer, ByRef xMaxView As Integer, ByRef yMinView As Integer, ByRef yMaxView As Integer, ByRef xMin As Integer, ByRef xMax As Integer, ByRef yMin As Integer, ByRef yMax As Integer)
	Declare Sub fg_getworld Lib "fgw32dd" Alias "_fg_getworld@32" _
		(ByRef xMin As Double, ByRef xMax As Double, ByRef yMin As Double, ByRef yMax As Double)
	Declare Function fg_getxbox Lib "fgw32dd" Alias "_fg_getxbox@0" _
		() As Integer
	Declare Function fg_getxjust Lib "fgw32dd" Alias "_fg_getxjust@0" _
		() As Integer
	Declare Function fg_getxpos Lib "fgw32dd" Alias "_fg_getxpos@0" _
		() As Integer
	Declare Function fg_getybox Lib "fgw32dd" Alias "_fg_getybox@0" _
		() As Integer
	Declare Function fg_getyjust Lib "fgw32dd" Alias "_fg_getyjust@0" _
		() As Integer
	Declare Function fg_getypos Lib "fgw32dd" Alias "_fg_getypos@0" _
		() As Integer
	Declare Sub fg_gouraud Lib "fgw32dd" Alias "_fg_gouraud@12" _
		(ByRef xyArray As Integer, ByRef rgbArray As Byte, ByVal n As Integer)
	Declare Sub fg_gouraudz Lib "fgw32dd" Alias "_fg_gouraudz@16" _
		(ByRef xyArray As Integer, ByRef rgbArray As Byte, ByRef xyzArray As Double, ByVal n As Integer)
	Declare Sub fg_graydcb Lib "fgw32dd" Alias "_fg_graydcb@12" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal nSize As Integer)
	Declare Sub fg_grayrgb Lib "fgw32dd" Alias "_fg_grayrgb@8" _
		(ByRef Values As Byte, ByVal nCount As Integer)
	Declare Sub fg_grayvb Lib "fgw32dd" Alias "_fg_grayvb@8" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer)

	Declare Sub fg_imagebuf Lib "fgw32dd" Alias "_fg_imagebuf@8" _
		(ByRef Buffer As Byte, ByVal nSize As Integer)
	Declare Function fg_imagesiz Lib "fgw32dd" Alias "_fg_imagesiz@8" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer) As Integer
	Declare Sub fg_initw Lib "fgw32dd" Alias "_fg_initw@0" _
		()
	Declare Function fg_inside Lib "fgw32dd" Alias "_fg_inside@16" _
		(ByRef xyArray As Integer, ByVal n As Integer, ByVal x As Integer, ByVal y As Integer) As Integer
	Declare Sub fg_invdcb Lib "fgw32dd" Alias "_fg_invdcb@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_invert Lib "fgw32dd" Alias "_fg_invert@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)

	Declare Sub fg_jpegbuf Lib "fgw32dd" Alias "_fg_jpegbuf@8" _
		(ByRef Buffer As Byte, ByVal nSize As Integer)
	Declare Function fg_jpeghead Lib "fgw32dd" Alias "_fg_jpeghead@8" _
		(ByVal FileName As String, ByRef Header As Byte) As Integer
	Declare Function fg_jpegmem Lib "fgw32dd" Alias "_fg_jpegmem@4" _
		(ByRef Header As Byte) As Integer
	Declare Sub fg_jpegsize Lib "fgw32dd" Alias "_fg_jpegsize@12" _
		(ByRef Header As Byte, ByRef nWidth As Integer, ByRef nHeight As Integer)
	Declare Sub fg_justify Lib "fgw32dd" Alias "_fg_justify@8" _
		(ByVal xJust As Integer, ByVal yJust As Integer)

	Declare Function fg_kbtest Lib "fgw32dd" Alias "_fg_kbtest@4" _
		(ByVal ScanCode As Integer) As Integer

	Declare Function fg_loadpcx Lib "fgw32dd" Alias "_fg_loadpcx@8" _
		(ByVal FileName As String, ByVal Flags As Integer) As Integer
	Declare Sub fg_locate Lib "fgw32dd" Alias "_fg_locate@8" _
		(ByVal nRow As Integer, ByVal nColumn As Integer)
	Declare Sub fg_logfont Lib "fgw32dd" Alias "_fg_logfont@4" _
		(ByVal hFont As IntPtr)
	Declare Function fg_logpal Lib "fgw32dd" Alias "_fg_logpal@12" _
		(ByVal nStart As Integer, ByVal nCount As Integer, ByRef Values As Byte) As Integer

	Declare Function fg_makebmp Lib "fgw32dd" Alias "_fg_makebmp@24" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal nDepth As Integer, ByVal FileName As String) As Integer
	Declare Function fg_makepcx Lib "fgw32dd" Alias "_fg_makepcx@20" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal FileName As String) As Integer
	Declare Function fg_makeppr Lib "fgw32dd" Alias "_fg_makeppr@20" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal FileName As String) As Integer
	Declare Function fg_makespr Lib "fgw32dd" Alias "_fg_makespr@20" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal FileName As String) As Integer
	Declare Sub fg_mapdacs Lib "fgw32dd" Alias "_fg_mapdacs@12" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal nCount As Integer)
	Declare Function fg_maprgb Lib "fgw32dd" Alias "_fg_maprgb@12" _
		(ByVal Red As Integer, ByVal Green As Integer, ByVal Blue As Integer) As Integer
	Declare Function fg_measure Lib "fgw32dd" Alias "_fg_measure@0" _
		() As Integer
	Declare Function fg_memavail Lib "fgw32dd" Alias "_fg_memavail@0" _
		() As Integer
	Declare Function fg_modeset Lib "fgw32dd" Alias "_fg_modeset@16" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal nDepth As Integer, ByVal nStyle As Integer) As Integer
	Declare Function fg_modetest Lib "fgw32dd" Alias "_fg_modetest@12" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal nDepth As Integer) As Integer
	Declare Sub fg_mousecur Lib "fgw32dd" Alias "_fg_mousecur@4" _
		(ByVal hCursor As IntPtr)
	Declare Function fg_mouseini Lib "fgw32dd" Alias "_fg_mouseini@0" _
		() As Integer
	Declare Sub fg_mouselim Lib "fgw32dd" Alias "_fg_mouselim@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_mousemov Lib "fgw32dd" Alias "_fg_mousemov@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_mousepos Lib "fgw32dd" Alias "_fg_mousepos@8" _
		(ByRef x As Integer, ByRef y As Integer)
	Declare Function fg_mouseptr Lib "fgw32dd" Alias "_fg_mouseptr@12" _
		(ByRef Masks As Byte, ByVal xOffset As Integer, ByVal yOffset As Integer) As IntPtr
	Declare Sub fg_mousesiz Lib "fgw32dd" Alias "_fg_mousesiz@4" _
		(ByVal nPixels As Integer)
	Declare Sub fg_mousevis Lib "fgw32dd" Alias "_fg_mousevis@4" _
		(ByVal State As Integer)
	Declare Sub fg_move Lib "fgw32dd" Alias "_fg_move@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_move3d Lib "fgw32dd" Alias "_fg_move3d@20" _
		(ByRef Transform As Integer, ByVal x As Integer, ByVal y As Integer, ByVal z As Integer, ByVal Flag As Integer)
	Declare Sub fg_moverel Lib "fgw32dd" Alias "_fg_moverel@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_moverw Lib "fgw32dd" Alias "_fg_moverw@16" _
		(ByVal x As Double, ByVal y As Double)
	Declare Sub fg_movew Lib "fgw32dd" Alias "_fg_movew@16" _
		(ByVal x As Double, ByVal y As Double)

	Declare Sub fg_opacity Lib "fgw32dd" Alias "_fg_opacity@4" _
		(ByVal Opacity As Integer)

	Declare Sub fg_pack Lib "fgw32dd" Alias "_fg_pack@16" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Function fg_pagesize Lib "fgw32dd" Alias "_fg_pagesize@8" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer) As Integer
	Declare Sub fg_paint Lib "fgw32dd" Alias "_fg_paint@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_paintw Lib "fgw32dd" Alias "_fg_paintw@16" _
		(ByVal x As Double, ByVal y As Double)
	Declare Sub fg_paste Lib "fgw32dd" Alias "_fg_paste@28" _
		(ByRef Bitmap As Byte, ByRef Section As Byte, ByVal xPos As Integer, ByVal yPos As Integer, ByVal nWidth As Integer, ByVal nSecWidth As Integer, ByVal nSecHeight As Integer)
	Declare Sub fg_pastedcb Lib "fgw32dd" Alias "_fg_pastedcb@28" _
		(ByRef Bitmap As Byte, ByRef Section As Byte, ByVal xPos As Integer, ByVal yPos As Integer, ByVal nWidth As Integer, ByVal nSecWidth As Integer, ByVal nSecHeight As Integer)
	Declare Function fg_pcxhead Lib "fgw32dd" Alias "_fg_pcxhead@8" _
		(ByVal FileName As String, ByRef Header As Byte) As Integer
	Declare Function fg_pcxpal Lib "fgw32dd" Alias "_fg_pcxpal@8" _
		(ByVal FileName As String, ByRef Palette As Byte) As Integer
	Declare Function fg_pcxpal Lib "fgw32dd" Alias "_fg_pcxpal@8" _
		(ByVal FileName As String, ByVal NullParam As Integer) As Integer
	Declare Sub fg_pcxrange Lib "fgw32dd" Alias "_fg_pcxrange@20" _
		(ByRef Header As Byte, ByRef xMin As Integer, ByRef xMax As Integer, ByRef yMin As Integer, ByRef yMax As Integer)
	Declare Sub fg_pcxsize Lib "fgw32dd" Alias "_fg_pcxsize@12" _
		(ByRef Header As Byte, ByRef nWidth As Integer, ByRef nHeight As Integer)
	Declare Sub fg_photodcb Lib "fgw32dd" Alias "_fg_photodcb@12" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal nSize As Integer)
	Declare Sub fg_photorgb Lib "fgw32dd" Alias "_fg_photorgb@8" _
		(ByRef Values As Byte, ByVal nCount As Integer)
	Declare Sub fg_photovb Lib "fgw32dd" Alias "_fg_photovb@8" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_point Lib "fgw32dd" Alias "_fg_point@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_pointw Lib "fgw32dd" Alias "_fg_pointw@16" _
		(ByVal x As Double, ByVal y As Double)
	Declare Sub fg_pointx Lib "fgw32dd" Alias "_fg_pointx@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_pointxw Lib "fgw32dd" Alias "_fg_pointxw@16" _
		(ByVal x As Double, ByVal y As Double)
	Declare Sub fg_polyedge Lib "fgw32dd" Alias "_fg_polyedge@4" _
		(ByVal Flag As Integer)
	Declare Sub fg_polyfill Lib "fgw32dd" Alias "_fg_polyfill@12" _
		(ByRef xyArray As Integer, ByRef Unused As Byte, ByVal n As Integer)
	Declare Sub fg_polyfilz Lib "fgw32dd" Alias "_fg_polyfilz@12" _
		(ByRef xyArray As Integer, ByRef xyzArray As Double, ByVal n As Integer)
	Declare Sub fg_polygon Lib "fgw32dd" Alias "_fg_polygon@12" _
		(ByRef xArray As Integer, ByRef yArray As Integer, ByVal n As Integer)
	Declare Sub fg_polygonw Lib "fgw32dd" Alias "_fg_polygonw@20" _
		(ByRef xArray As Double, ByRef yArray As Double, ByVal n As Integer)
	Declare Sub fg_polyline Lib "fgw32dd" Alias "_fg_polyline@8" _
		(ByRef xyArray As Integer, ByVal n As Integer)
	Declare Sub fg_polyoff Lib "fgw32dd" Alias "_fg_polyoff@8" _
		(ByVal x As Integer, ByVal y As Integer)
	Declare Sub fg_print Lib "fgw32dd" Alias "_fg_print@8" _
		(ByVal s As String, ByVal n As Integer)
	Declare Sub fg_printdc Lib "fgw32dd" Alias "_fg_printdc@4" _
		(ByVal hDC As IntPtr)
	Declare Function fg_printer Lib "fgw32dd" Alias "_fg_printer@4" _
		(ByVal nMessage As Integer) As Integer
	Declare Sub fg_project Lib "fgw32dd" Alias "_fg_project@16" _
		(ByRef Transform As Integer, ByRef Source As Integer, ByRef Dest As Integer, ByVal n As Integer)
	Declare Sub fg_putblock Lib "fgw32dd" Alias "_fg_putblock@20" _
		(ByRef Buffer As Byte, ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_putdcb Lib "fgw32dd" Alias "_fg_putdcb@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_putimage Lib "fgw32dd" Alias "_fg_putimage@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_putpixel Lib "fgw32dd" Alias "_fg_putpixel@8" _
		(ByVal x As Integer, ByVal y As Integer)

	Declare Sub fg_realize Lib "fgw32dd" Alias "_fg_realize@4" _
		(ByVal hPal As Integer)
	Declare Sub fg_rect Lib "fgw32dd" Alias "_fg_rect@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_rectw Lib "fgw32dd" Alias "_fg_rectw@32" _
		(ByVal xMin As Double, ByVal xMax As Double, ByVal yMin As Double, ByVal yMax As Double)
	Declare Sub fg_rectx Lib "fgw32dd" Alias "_fg_rectx@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_reduce Lib "fgw32dd" Alias "_fg_reduce@12" _
		(ByVal nOffset As Integer, ByVal nColors As Integer, ByRef Values As Byte)
	Declare Sub fg_restore Lib "fgw32dd" Alias "_fg_restore@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_restorew Lib "fgw32dd" Alias "_fg_restorew@32" _
		(ByVal xMin As Double, ByVal xMax As Double, ByVal yMin As Double, ByVal yMax As Double)
	Declare Sub fg_revdcb Lib "fgw32dd" Alias "_fg_revdcb@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_revimage Lib "fgw32dd" Alias "_fg_revimage@12" _
		(ByRef Bitmap As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer)
	Declare Sub fg_revmask Lib "fgw32dd" Alias "_fg_revmask@12" _
		(ByRef Bitmap As Byte, ByVal nRuns As Integer, ByVal nWidth As Integer)
	Declare Sub fg_rotate Lib "fgw32dd" Alias "_fg_rotate@20" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal Angle As Integer)
	Declare Sub fg_rotate3d Lib "fgw32dd" Alias "_fg_rotate3d@20" _
		(ByRef Transform As Integer, ByVal Pitch As Integer, ByVal Yaw As Integer, ByVal Roll As Integer, ByVal Flag As Integer)
	Declare Sub fg_rotdcb Lib "fgw32dd" Alias "_fg_rotdcb@20" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal Angle As Integer)
	Declare Sub fg_rotsize Lib "fgw32dd" Alias "_fg_rotsize@20" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal Angle As Integer, ByRef nNewWidth As Integer, ByRef nNewHeight As Integer)

	Declare Sub fg_save Lib "fgw32dd" Alias "_fg_save@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_savew Lib "fgw32dd" Alias "_fg_savew@32" _
		(ByVal xMin As Double, ByVal xMax As Double, ByVal yMin As Double, ByVal yMax As Double)
	Declare Sub fg_scale Lib "fgw32dd" Alias "_fg_scale@24" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal sWidth As Integer, ByVal sHeight As Integer, ByVal dWidth As Integer, ByVal dHeight As Integer)
	Declare Sub fg_scale Lib "fgw32dd" Alias "_fg_scale@24" _
		(ByVal pSource As Integer, ByVal pDest As Integer, ByVal sWidth As Integer, ByVal sHeight As Integer, ByVal dWidth As Integer, ByVal dHeight As Integer)
	Declare Sub fg_scaledcb Lib "fgw32dd" Alias "_fg_scaledcb@24" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal sWidth As Integer, ByVal sHeight As Integer, ByVal dWidth As Integer, ByVal dHeight As Integer)
	Declare Sub fg_scaledcb Lib "fgw32dd" Alias "_fg_scaledcb@24" _
		(ByVal pSource As Integer, ByVal pDest As Integer, ByVal sWidth As Integer, ByVal sHeight As Integer, ByVal dWidth As Integer, ByVal dHeight As Integer)
	Declare Sub fg_scroll Lib "fgw32dd" Alias "_fg_scroll@24" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal nJump As Integer, ByVal nType As Integer)
	Declare Sub fg_setalpha Lib "fgw32dd" Alias "_fg_setalpha@4" _
		(ByVal Alpha As Integer)
	Declare Sub fg_setangle Lib "fgw32dd" Alias "_fg_setangle@8" _
		(ByVal Angle As Double)
	Declare Sub fg_setclip Lib "fgw32dd" Alias "_fg_setclip@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_setclipw Lib "fgw32dd" Alias "_fg_setclipw@32" _
		(ByVal xMin As Double, ByVal xMax As Double, ByVal yMin As Double, ByVal yMax As Double)
	Declare Sub fg_setcolor Lib "fgw32dd" Alias "_fg_setcolor@4" _
		(ByVal nColor As Integer)
	Declare Sub fg_setcolorrgb Lib "fgw32dd" Alias "_fg_setcolorrgb@12" _
		(ByVal Red As Integer, ByVal Green As Integer, ByVal Blue As Integer)
	Declare Sub fg_setdacs Lib "fgw32dd" Alias "_fg_setdacs@12" _
		(ByVal nStart As Integer, ByVal nCount As Integer, ByRef Values As Byte)
	Declare Sub fg_setdc Lib "fgw32dd" Alias "_fg_setdc@4" _
		(ByVal hDC As IntPtr)
	Declare Sub fg_sethpage Lib "fgw32dd" Alias "_fg_sethpage@4" _
		(ByVal hVB As Integer)
	Declare Sub fg_setpage Lib "fgw32dd" Alias "_fg_setpage@4" _
		(ByVal hVB As Integer)
	Declare Sub fg_setratio Lib "fgw32dd" Alias "_fg_setratio@8" _
		(ByVal Ratio As Double)
	Declare Sub fg_setrgb Lib "fgw32dd" Alias "_fg_setrgb@16" _
		(ByVal nColor As Integer, ByVal Red As Integer, ByVal Green As Integer, ByVal Blue As Integer)
	Declare Sub fg_setsize Lib "fgw32dd" Alias "_fg_setsize@4" _
		(ByVal CharSize As Integer)
	Declare Sub fg_setsizew Lib "fgw32dd" Alias "_fg_setsizew@8" _
		(ByVal CharSize As Double)
	Declare Sub fg_setview Lib "fgw32dd" Alias "_fg_setview@32" _
		(ByVal xMinView As Integer, ByVal xMaxView As Integer, ByVal yMinView As Integer, ByVal yMaxView As Integer, ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer)
	Declare Sub fg_setworld Lib "fgw32dd" Alias "_fg_setworld@32" _
		(ByVal xMin As Double, ByVal xMax As Double, ByVal yMin As Double, ByVal yMax As Double)
	Declare Sub fg_shear Lib "fgw32dd" Alias "_fg_shear@24" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal nNewSize As Integer, ByVal nType As Integer)
	Declare Sub fg_shear Lib "fgw32dd" Alias "_fg_shear@24" _
		(ByVal pSource As Integer, ByVal pDest As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal nNewSize As Integer, ByVal nType As Integer)
	Declare Sub fg_sheardcb Lib "fgw32dd" Alias "_fg_sheardcb@24" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal nNewSize As Integer, ByVal nType As Integer)
	Declare Sub fg_sheardcb Lib "fgw32dd" Alias "_fg_sheardcb@24" _
		(ByVal pSource As Integer, ByRef pDest As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal nNewSize As Integer, ByVal nType As Integer)
	Declare Function fg_showavi Lib "fgw32dd" Alias "_fg_showavi@12" _
		(ByVal FileName As String, ByVal nCount As Integer, ByVal Flags As Integer) As Integer
	Declare Function fg_showbmp Lib "fgw32dd" Alias "_fg_showbmp@8" _
		(ByVal FileName As String, ByVal Flags As Integer) As Integer
	Declare Function fg_showflic Lib "fgw32dd" Alias "_fg_showflic@12" _
		(ByVal FileName As String, ByVal nCount As Integer, ByVal Flags As Integer) As Integer
	Declare Function fg_showjpeg Lib "fgw32dd" Alias "_fg_showjpeg@8" _
		(ByVal FileName As String, ByVal Flags As Integer) As Integer
	Declare Function fg_showpcx Lib "fgw32dd" Alias "_fg_showpcx@8" _
		(ByVal FileName As String, ByVal Flags As Integer) As Integer
	Declare Function fg_showppr Lib "fgw32dd" Alias "_fg_showppr@8" _
		(ByVal FileName As String, ByVal nWidth As Integer) As Integer
	Declare Function fg_showspr Lib "fgw32dd" Alias "_fg_showspr@8" _
		(ByVal FileName As String, ByVal nWidth As Integer) As Integer
	Declare Sub fg_stall Lib "fgw32dd" Alias "_fg_stall@4" _
		(ByVal nDelay As Integer)
	Declare Sub fg_swchar Lib "fgw32dd" Alias "_fg_swchar@12" _
		(ByVal s As String, ByVal n As Integer, ByVal Justify As Integer)
	Declare Function fg_swlength Lib "fgw32dd" Alias "_fg_swlength@8" _
		(ByVal s As String, ByVal n As Integer) As Double
	Declare Sub fg_swtext Lib "fgw32dd" Alias "_fg_swtext@12" _
		(ByVal s As String, ByVal n As Integer, ByVal Justify As Integer)

	Declare Sub fg_tcdefine Lib "fgw32dd" Alias "_fg_tcdefine@8" _
		(ByVal nIndex As Integer, ByVal nAttribute As Integer)
	Declare Sub fg_tcmask Lib "fgw32dd" Alias "_fg_tcmask@4" _
		(ByVal Mask As Integer)
	Declare Sub fg_tcxfer Lib "fgw32dd" Alias "_fg_tcxfer@32" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal xNew As Integer, ByVal yNew As Integer, ByVal Source As Integer, ByVal Dest As Integer)
	Declare Sub fg_texmap Lib "fgw32dd" Alias "_fg_texmap@12" _
		(ByRef xyArray As Integer, ByRef uvArray As Integer, ByVal n As Integer)
	Declare Sub fg_texmap Lib "fgw32dd" Alias "_fg_texmap@12" _
		(ByRef xyArray As Integer, ByRef uvArray As Single, ByVal n As Integer)
	Declare Sub fg_texmapp Lib "fgw32dd" Alias "_fg_texmapp@16" _
		(ByRef xyArray As Integer, ByRef uvArray As Integer, ByRef xyzArray As Double, ByVal n As Integer)
	Declare Sub fg_texmapp Lib "fgw32dd" Alias "_fg_texmapp@16" _
		(ByRef xyArray As Integer, ByRef uvArray As Single, ByRef xyzArray As Double, ByVal n As Integer)
	Declare Sub fg_texmappz Lib "fgw32dd" Alias "_fg_texmappz@16" _
		(ByRef xyArray As Integer, ByRef uvArray As Integer, ByRef xyzArray As Double, ByVal n As Integer)
	Declare Sub fg_texmappz Lib "fgw32dd" Alias "_fg_texmappz@16" _
		(ByRef xyArray As Integer, ByRef uvArray As Single, ByRef xyzArray As Double, ByVal n As Integer)
	Declare Sub fg_texmapz Lib "fgw32dd" Alias "_fg_texmapz@16" _
		(ByRef xyArray As Integer, ByRef uvArray As Integer, ByRef xyzArray As Double, ByVal n As Integer)
	Declare Sub fg_texmapz Lib "fgw32dd" Alias "_fg_texmapz@16" _
		(ByRef xyArray As Integer, ByRef uvArray As Single, ByRef xyzArray As Double, ByVal n As Integer)
	Declare Sub fg_text Lib "fgw32dd" Alias "_fg_text@8" _
		(ByVal s As String, ByVal n As Integer)
	Declare Sub fg_texture Lib "fgw32dd" Alias "_fg_texture@8" _
		(ByRef Texture As Byte, ByVal nWidth As Integer)
	Declare Function fg_tmdefine Lib "fgw32dd" Alias "_fg_tmdefine@12" _
		(ByRef Texture As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer) As Integer
	Declare Sub fg_tmevict Lib "fgw32dd" Alias "_fg_tmevict@0" _
		()
	Declare Sub fg_tmfree Lib "fgw32dd" Alias "_fg_tmfree@4" _
		(ByVal hTM As Integer)
	Declare Function fg_tminit Lib "fgw32dd" Alias "_fg_tminit@4" _
		(ByVal nCount As Integer) As Integer
	Declare Sub fg_tmselect Lib "fgw32dd" Alias "_fg_tmselect@4" _
		(ByVal hTM As Integer)
	Declare Sub fg_tmspan Lib "fgw32dd" Alias "_fg_tmspan@4" _
		(ByVal nPixels As Integer)
	Declare Sub fg_tmtransparency Lib "fgw32dd" Alias "_fg_tmtransparency@4" _
		(ByVal State As Integer)
	Declare Sub fg_tmunits Lib "fgw32dd" Alias "_fg_tmunits@4" _
		(ByVal Units As Integer)
	Declare Sub fg_transdcb Lib "fgw32dd" Alias "_fg_transdcb@20" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal sDepth As Integer, ByVal dDepth As Integer, ByVal nSize As Integer)
	Declare Sub fg_transfer Lib "fgw32dd" Alias "_fg_transfer@32" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal xNew As Integer, ByVal yNew As Integer, ByVal Source As Integer, ByVal Dest As Integer)
	Declare Sub fg_trig Lib "fgw32dd" Alias "_fg_trig@12" _
		(ByVal Angle As Integer, ByRef Cosine As Double, ByRef Sine As Double)

	Declare Sub fg_unmaprgb Lib "fgw32dd" Alias "_fg_unmaprgb@16" _
		(ByVal nColor As Integer, ByRef Red As Integer, ByRef Green As Integer, ByRef Blue As Integer)
	Declare Sub fg_unpack Lib "fgw32dd" Alias "_fg_unpack@12" _
		(ByRef Source As Byte, ByRef Dest As Byte, ByVal nSize As Integer)

	Declare Function fg_vb2clip Lib "fgw32dd" Alias "_fg_vb2clip@16" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer) As Integer
	Declare Function fg_vbaddr Lib "fgw32dd" Alias "_fg_vbaddr@4" _
		(ByVal hVB As Integer) As Integer
	Declare Function fg_vballoc Lib "fgw32dd" Alias "_fg_vballoc@8" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer) As Integer
	Declare Sub fg_vbclose Lib "fgw32dd" Alias "_fg_vbclose@0" _
		()
	Declare Sub fg_vbcolors Lib "fgw32dd" Alias "_fg_vbcolors@0" _
		()
	Declare Sub fg_vbcopy Lib "fgw32dd" Alias "_fg_vbcopy@32" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal xNew As Integer, ByVal yNew As Integer, ByVal Source As Integer, ByVal Dest As Integer)
	Declare Function fg_vbdefine Lib "fgw32dd" Alias "_fg_vbdefine@12" _
		(ByRef Buffer As Byte, ByVal nWidth As Integer, ByVal nHeight As Integer) As Integer
	Declare Sub fg_vbdepth Lib "fgw32dd" Alias "_fg_vbdepth@4" _
		(ByVal nDepth As Integer)
	Declare Sub fg_vbfin Lib "fgw32dd" Alias "_fg_vbfin@0" _
		()
	Declare Sub fg_vbfree Lib "fgw32dd" Alias "_fg_vbfree@4" _
		(ByVal hVB As Integer)
	Declare Function fg_vbhandle Lib "fgw32dd" Alias "_fg_vbhandle@0" _
		() As Integer
	Declare Function fg_vbinit Lib "fgw32dd" Alias "_fg_vbinit@0" _
		() As Integer
	Declare Function fg_vbopen Lib "fgw32dd" Alias "_fg_vbopen@4" _
		(ByVal hVB As Integer) As Integer
	Declare Sub fg_vbpaste Lib "fgw32dd" Alias "_fg_vbpaste@24" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal xClient As Integer, ByVal yClient As Integer)
	Declare Sub fg_vbprint Lib "fgw32dd" Alias "_fg_vbprint@36" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal xMinPrint As Integer, ByVal xMaxPrint As Integer, ByVal yMinPrint As Integer, ByVal yMaxPrint As Integer, ByVal Units As Integer)
	Declare Sub fg_vbscale Lib "fgw32dd" Alias "_fg_vbscale@32" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal xMinClient As Integer, ByVal xMaxClient As Integer, ByVal yMinClient As Integer, ByVal yMaxClient As Integer)
	Declare Function fg_vbsize Lib "fgw32dd" Alias "_fg_vbsize@8" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer) As Integer
	Declare Sub fg_vbtccopy Lib "fgw32dd" Alias "_fg_vbtccopy@32" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal xNew As Integer, ByVal yNew As Integer, ByVal Source As Integer, ByVal Dest As Integer)
	Declare Sub fg_vbtcopy Lib "fgw32dd" Alias "_fg_vbtcopy@36" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal xNew As Integer, ByVal yNew As Integer, ByVal nColor As Integer, ByVal Source As Integer, ByVal Dest As Integer)
	Declare Sub fg_vbtzcopy Lib "fgw32dd" Alias "_fg_vbtzcopy@32" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal xNew As Integer, ByVal yNew As Integer, ByVal Source As Integer, ByVal Dest As Integer)
	Declare Sub fg_vbundef Lib "fgw32dd" Alias "_fg_vbundef@4" _
		(ByVal hVB As Integer)
	Declare Sub fg_version Lib "fgw32dd" Alias "_fg_version@8" _
		(ByRef Major As Integer, ByRef Minor As Integer)
	Declare Sub fg_view3d Lib "fgw32dd" Alias "_fg_view3d@20" _
		(ByVal xMin As Integer, ByVal xMax As Integer, ByVal yMin As Integer, ByVal yMax As Integer, ByVal Ratio As Integer)

	Declare Sub fg_waitfor Lib "fgw32dd" Alias "_fg_waitfor@4" _
		(ByVal nTicks As Integer)
	Declare Sub fg_where Lib "fgw32dd" Alias "_fg_where@8" _
		(ByRef nRow As Integer, ByRef nColumn As Integer)

	Declare Function fg_xalpha Lib "fgw32dd" Alias "_fg_xalpha@4" _
		(ByVal x As Integer) As Integer
	Declare Function fg_xclient Lib "fgw32dd" Alias "_fg_xclient@4" _
		(ByVal x As Integer) As Integer
	Declare Function fg_xconvert Lib "fgw32dd" Alias "_fg_xconvert@4" _
		(ByVal nColumn As Integer) As Integer
	Declare Function fg_xscreen Lib "fgw32dd" Alias "_fg_xscreen@8" _
		(ByVal x As Double) As Integer
	Declare Function fg_xvb Lib "fgw32dd" Alias "_fg_xvb@4" _
		(ByVal x As Integer) As Integer
	Declare Function fg_xview Lib "fgw32dd" Alias "_fg_xview@4" _
		(ByVal xView As Integer) As Integer
	Declare Function fg_xworld Lib "fgw32dd" Alias "_fg_xworld@4" _
		(ByVal x As Integer) As Double

	Declare Function fg_yalpha Lib "fgw32dd" Alias "_fg_yalpha@4" _
		(ByVal y As Integer) As Integer
	Declare Function fg_yclient Lib "fgw32dd" Alias "_fg_yclient@4" _
		(ByVal y As Integer) As Integer
	Declare Function fg_yconvert Lib "fgw32dd" Alias "_fg_yconvert@4" _
		(ByVal nRow As Integer) As Integer
	Declare Function fg_yscreen Lib "fgw32dd" Alias "_fg_yscreen@8" _
		(ByVal y As Double) As Integer
	Declare Function fg_yvb Lib "fgw32dd" Alias "_fg_yvb@4" _
		(ByVal y As Integer) As Integer
	Declare Function fg_yview Lib "fgw32dd" Alias "_fg_yview@4" _
		(ByVal yView As Integer) As Integer
	Declare Function fg_yworld Lib "fgw32dd" Alias "_fg_yworld@4" _
		(ByVal y As Integer) As Double

	Declare Function fg_zballoc Lib "fgw32dd" Alias "_fg_zballoc@8" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer) As Integer
	Declare Sub fg_zbframe Lib "fgw32dd" Alias "_fg_zbframe@0" _
		()
	Declare Sub fg_zbfree Lib "fgw32dd" Alias "_fg_zbfree@4" _
		(ByVal hZB As Integer)
	Declare Sub fg_zbopen Lib "fgw32dd" Alias "_fg_zbopen@4" _
		(ByVal hZB As Integer)

	Declare Sub fg_ddapply Lib "fgw32dd" Alias "_fg_ddapply@4" _
		(ByVal Version As Integer)
	Declare Function fg_ddflip Lib "fgw32dd" Alias "_fg_ddflip@0" _
		() As Integer
	Declare Function fg_ddflipnw Lib "fgw32dd" Alias "_fg_ddflipnw@0" _
		() As Integer
	Declare Sub fg_ddframe Lib "fgw32dd" Alias "_fg_ddframe@4" _
		(ByVal State As Integer)
	Declare Sub fg_ddfreedc Lib "fgw32dd" Alias "_fg_ddfreedc@4" _
		(ByVal hDC As IntPtr)
	Declare Function fg_ddgetdc Lib "fgw32dd" Alias "_fg_ddgetdc@0" _
		() As IntPtr
	Declare Function fg_ddgetobj Lib "fgw32dd" Alias "_fg_ddgetobj@4" _
		(ByVal nCode As Integer) As Integer
	Declare Function fg_ddgetversion Lib "fgw32dd" Alias "_fg_ddgetversion@0" _
		() As Integer
	Declare Function fg_ddlock Lib "fgw32dd" Alias "_fg_ddlock@0" _
		() As Integer
	Declare Sub fg_ddmemory Lib "fgw32dd" Alias "_fg_ddmemory@4" _
		(ByVal MemType As Integer)
	Declare Sub fg_ddrestore Lib "fgw32dd" Alias "_fg_ddrestore@0" _
		()
	Declare Sub fg_ddsetblt Lib "fgw32dd" Alias "_fg_ddsetblt@4" _
		(ByVal Usage As Integer)
	Declare Sub fg_ddsetobj Lib "fgw32dd" Alias "_fg_ddsetobj@8" _
		(ByRef dxObject As Integer, ByVal nCode As Integer)
	Declare Sub fg_ddsetup Lib "fgw32dd" Alias "_fg_ddsetup@16" _
		(ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal nDepth As Integer, ByVal Flags As Integer)
	Declare Sub fg_ddsetversion Lib "fgw32dd" Alias "_fg_ddsetversion@8" _
		(ByVal MinVer As Integer, ByVal MaxVer As Integer)
	Declare Function fg_ddstatus Lib "fgw32dd" Alias "_fg_ddstatus@0" _
		() As Integer
	Declare Sub fg_ddunlock Lib "fgw32dd" Alias "_fg_ddunlock@0" _
		()
	Declare Function fg_ddusage Lib "fgw32dd" Alias "_fg_ddusage@0" _
		() As Integer
	Declare Sub fg_gdiflip Lib "fgw32dd" Alias "_fg_gdiflip@0" _
		()
End Module

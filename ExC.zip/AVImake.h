//----------------------
// AVImake.h header file
//----------------------

#define IDM_Convert 1
#define IDM_Exit    2

/****************************************************************************\
*                                                                            *
*  SWchars.cpp                                                               *
*                                                                            *
*  This program displays all characters in the Fastgraph for Windows primary *
*  and alternate software fonts.                                             *
*                                                                            *
\****************************************************************************/

// SWchars.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "SWchars.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSWcharsApp

BEGIN_MESSAGE_MAP(CSWcharsApp, CWinApp)
	//{{AFX_MSG_MAP(CSWcharsApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSWcharsApp construction

CSWcharsApp::CSWcharsApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSWcharsApp object

CSWcharsApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CSWcharsApp initialization

BOOL CSWcharsApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Software Character Set"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CSWcharsApp message handlers

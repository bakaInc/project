'*****************************************************************************
'                                                                            *
'  KBdemo.vb                                                                 *
'                                                                            *
'  This program shows how to pan the contents of a virtual buffer through    *
'  a smaller window using the low-level keyboard handler.                    *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 640
    Const vbHeight As Integer = 480

    ' Application variables.
    Dim X, Y As Integer
    Dim xLimit, yLimit As Integer
    Dim CanGoLeft, CanGoRight As Boolean
    Dim CanGoUp, CanGoDown As Boolean

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Name = "Form1"
        Me.Text = "Keyboard Handler Demo"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        fg_showbmp("PORCH.BMP", 0)
        X = 0
        Y = 0
        CanGoRight = True
        CanGoDown = True
        CanGoLeft = False
        CanGoUp = False
        Timer1.Enabled = True
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        If cxClient < vbWidth Then
            xLimit = vbWidth - cxClient
            If X > 0 Then CanGoLeft = True
            If X < xLimit Then CanGoRight = True
        Else
            xLimit = 0
            CanGoLeft = False
            CanGoRight = False
        End If
        If cyClient < vbHeight Then
            yLimit = vbHeight - cyClient
            If Y > 0 Then CanGoUp = True
            If Y < yLimit Then CanGoDown = True
        Else
            yLimit = 0
            CanGoUp = False
            CanGoDown = False
        End If
        fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        CheckForPanning()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  CheckForPanning()                                                         *
    '                                                                            *
    '  The CheckForPanning subroutine checks if any of the four arrow keys are   *
    '  pressed, and if so, pans in that direction if possible. It is called      *
    '  every 10ms from the timer's OnTick event handler.                         *
    '                                                                            *
    '*****************************************************************************

    Private Sub CheckForPanning()

        Const kbEscape As Integer = 1
        Const kbLeft As Integer = 75
        Const kbRight As Integer = 77
        Const kbUp As Integer = 72
        Const kbDown As Integer = 80

        If fg_kbtest(kbLeft) And CanGoLeft Then
            If X = xLimit Then CanGoRight = True
            X -= 1
            fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
            If X = 0 Then CanGoLeft = False
        ElseIf fg_kbtest(kbRight) And CanGoRight Then
            If X = 0 Then CanGoLeft = True
            X += 1
            fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
            If X = xLimit Then CanGoRight = False
        ElseIf fg_kbtest(kbUp) And CanGoUp Then
            If Y = yLimit Then CanGoDown = True
            Y -= 1
            fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
            If Y = 0 Then CanGoUp = False
        ElseIf fg_kbtest(kbDown) And CanGoDown Then
            If Y = 0 Then CanGoUp = True
            Y += 1
            fg_vbpaste(X, X + (vbWidth - 1), Y, Y + (vbHeight - 1), 0, vbHeight - 1)
            If Y = yLimit Then CanGoDown = False
        ElseIf fg_kbtest(kbEscape) Then
            X = 0
            Y = 0
            fg_vbpaste(0, vbWidth - 1, 0, vbHeight - 1, 0, vbHeight - 1)
            If xLimit > 0 Then CanGoRight = True
            If yLimit > 0 Then CanGoDown = True
            CanGoLeft = False
            CanGoUp = False
        End If
    End Sub
End Class
/****************************************************************************\
*                                                                            *
*  Columns.cs                                                                *
*                                                                            *
*  This program draws a grid of columns in 3D world space. It demonstrates   *
*  polygon culling and Fastgraph's incremental POV functions.                *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Columns
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int hZB;

		// Virtual buffer dimensions.
		const int vbWidth = 600;
		const int vbHeight = 400;

		const int InfoHeight = 80;
		const int WinWidth = vbWidth;
		const int WinHeight = (vbHeight + InfoHeight);

		// Six faces of a 2x2x10 column, defined in object coordinates.
		// Order of faces is top, front, left, right, bottom, back.
		double [,] ColumnData = {
			{-1.0,10.0, 1.0,  1.0,10.0, 1.0,  1.0,10.0,-1.0, -1.0,10.0,-1.0},
			{-1.0,10.0,-1.0,  1.0,10.0,-1.0,  1.0, 0.0,-1.0, -1.0, 0.0,-1.0},
			{-1.0,10.0, 1.0, -1.0,10.0,-1.0, -1.0, 0.0,-1.0, -1.0, 0.0, 1.0},
			{ 1.0,10.0,-1.0,  1.0,10.0, 1.0,  1.0, 0.0, 1.0,  1.0, 0.0,-1.0},
			{-1.0, 0.0,-1.0,  1.0, 0.0,-1.0,  1.0, 0.0, 1.0, -1.0, 0.0, 1.0},
			{1.0, 10.0, 1.0, -1.0,10.0, 1.0, -1.0, 0.0, 1.0,  1.0, 0.0, 1.0}};

		// Component declarations.
		private System.Windows.Forms.Timer timer1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			// 
			// timer1
			// 
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form1";
			this.Text = "3D Columns";
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.Closed += new System.EventHandler(this.Form1_Closed);
		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			// Initialize the virtual buffer environment.
			fg.vbinit();
			fg.vbdepth(fg.colors());

			// Create and open the virtual buffer.
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();

			// Create and open the z-buffer.
			hZB = fg.zballoc(vbWidth, vbHeight);
			fg.zbopen(hZB);

			// Define 3D viewport, render state, and initial POV.
			fg._3Dviewport(0, vbWidth-1, 0, vbHeight-1, 1.0);
			fg._3Drenderstate(fg.ZBUFFER + fg.ZCLIP);
			fg._3Dlookat(10.0, 20.0, 100.0, 0.0, 20.0, 0.0);

			// Direct strings to the active virtual buffer.
			fg.fontdc(fg.getdc());

			// Make the client area equal to the required size.
			this.Location = new Point(0, 0);
			this.ClientSize = new Size(WinWidth, WinHeight);

			// Enable the timer so CheckForMotion() is called every 10ms.
			timer1.Enabled = true;
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			DrawColumns();
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.zbfree(hZB);
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			CheckForMotion();
		}

		/****************************************************************************\
		*                                                                            *
		*  CheckForMotion()                                                          *
		*                                                                            *
		*  The CheckForMotion() function checks for key presses that control the     *
		*  viewer's position and orientation, and if required redraws the scene at   *
		*  its new POV. It is called every 10ms from the timer's OnTick event        *
		*  handler.                                                                  *
		*                                                                            *
		\****************************************************************************/

		private void CheckForMotion()
		{
			bool ShiftKey;

			// Check if either shift key is pressed.
			ShiftKey = (fg.kbtest(42) == 1) || (fg.kbtest(54) == 1);

			if (fg.kbtest(71) == 1)  // Home
			{
				fg._3Dmoveup(5.0);
				DrawColumns();
			}

			else if (fg.kbtest(72) == 1)  // Up arrow
			{
				fg._3Dmoveforward(5.0);
				DrawColumns();
			}

			else if (fg.kbtest(73) == 1) // PgUp
			{
				fg._3Drotateup(100);
				DrawColumns();
			}

			else if (fg.kbtest(75) == 1)  // Left arrow
			{
				if (ShiftKey)
					fg._3Dmoveright(-5.0);
				else
					fg._3Drotateright(-100);
				DrawColumns();
			}

			else if (fg.kbtest(77) == 1)  // Right arrow
			{
				if (ShiftKey)
					fg._3Dmoveright(5.0);
				else
					fg._3Drotateright(100);
				DrawColumns();
			}

			else if (fg.kbtest(79) == 1)  // End
			{
				fg._3Dmoveup(-5.0);
				DrawColumns();
			}

			else if (fg.kbtest(80) == 1)  // Down arrow
			{
				fg._3Dmoveforward(-5.0);
				DrawColumns();
			}

			else if (fg.kbtest(81) == 1)  // PgDn
			{
				fg._3Drotateup(-100);
				DrawColumns();
			}
		}

		/****************************************************************************\
		*                                                                            *
		*  DrawColumns()                                                             *
		*                                                                            *
		*  Draws each of the six cube faces in 3D world space.                       *
		*                                                                            *
		\****************************************************************************/

		private void DrawColumns()
		{
			int [] nColor = new int [6];
			int nRow, nCol;
			int i;

			// Prepare for the new frame.
			fg.zbframe();
			fg.setcolor(-1);
			fg.fillpage();

			// Create the six encoded color values.
			nColor[0] = fg.maprgb(254, 219, 164);
			nColor[1] = fg.maprgb(243, 194, 117);
			nColor[2] = fg.maprgb(226, 172, 86);
			nColor[3] = fg.maprgb(203, 150, 67);
			nColor[4] = fg.maprgb(123, 98, 59);
			nColor[5] = fg.maprgb(166, 125, 60);

			// 50x50x6 = 15000 polygons per frame.
			for (nRow = -500; nRow < 500; nRow += 20)
			{
				for (nCol = -500; nCol < 500; nCol += 20)
				{
					if (fg._3Dbehindviewer((double)nRow, 0.0, (double)nCol, -1.0) == 0)
					{
						fg._3Dmoveobject((double)nRow, 0.0, (double)nCol);

						// Draw all the faces.
						for (i = 0; i < 6; i++)
						{
							// Set the color.
							fg.setcolor(nColor[i]);

							// Draw the face.
							fg._3Dpolygonobject(ref ColumnData[i,0], 4);
						}
					}
				}
			}

			// Display the scene.
			fg.vbpaste(0, vbWidth-1, 0, vbHeight-1, 0, vbHeight-1);

			// Display the 3D information at the bottom of the window.
			UpdateInfo();
		}

		/****************************************************************************\
		*                                                                            *
		*  UpdateInfo()                                                              *
		*                                                                            *
		*  Displays the information at the bottom of the window.                     *
		*                                                                            *
		\****************************************************************************/

		private void UpdateInfo()
		{
			double x, y, z;
			double xDir, yDir, zDir;
			string MessageText;

			// Get current position and direction.
			fg._3Dgetpov(out x, out y, out z, out xDir, out yDir, out zDir);

			// Clear an area to write on.
			fg.setcolorrgb(0, 0, 140);
			fg.rect(0, 249, 0, InfoHeight-1);

			fg.setcolorrgb(0, 140, 0);
			fg.rect(250, vbWidth-1, 0, InfoHeight-1);

			fg.setcolor(-1);

			// Print current position and unit vector.
			fg.move(20, 32);
			MessageText = String.Format("x = {0:###0.00}  xDir = {1:###0.00}", x, xDir);
			fg.print(MessageText, MessageText.Length);

			fg.move(20, 46);
			MessageText = String.Format("y = {0:###0.00}  yDir = {1:###0.00}", y, yDir);
			fg.print(MessageText, MessageText.Length);

			fg.move(20, 60);
			MessageText = String.Format("z = {0:###0.00}  zDir = {1:###0.00}", z, zDir);
			fg.print(MessageText, MessageText.Length);

			// Print instructions.
			fg.move(270, 18);
			MessageText = "Up    = move forward   Home = move up";
			fg.print(MessageText, MessageText.Length);

			fg.move(270, 32);
			MessageText = "Down  = move back      End  = move down";
			fg.print(MessageText, MessageText.Length);

			fg.move(270, 46);
			MessageText = "Left  = turn left      PgUp = look up";
			fg.print(MessageText, MessageText.Length);

			fg.move(270, 60);
			MessageText = "Right = turn right     PgDn = look down";
			fg.print(MessageText, MessageText.Length);

			fg.move(290, 74);
			MessageText = "Shift+Left/Right = move left/right";
			fg.print(MessageText, MessageText.Length);

			fg.vbpaste(0, vbWidth-1, 0, InfoHeight-1, 0, WinHeight-1);
		}
	}
}
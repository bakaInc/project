/****************************************************************************\
*                                                                            *
*  FGWinD.cs                                                                 *
*                                                                            *
*  This file contains the C# function declarations for the Fastgraph/Light   *
*  6.03 for Windows DirectX libraries.                                       *
*                                                                            *
*  Copyright (c) 2003 Ted Gruber Software.  All rights reserved.             *
*                                                                            *
\****************************************************************************/

using System;
using System.Runtime.InteropServices;

public class fg
{
	// fg._3Drenderstate() bit flags
	public const int LINEAR_TM = 0;
	public const int PERSPECTIVE_TM = 1;
	public const int WIREFRAME = 2;
	public const int ZBUFFER = 4;
	public const int ZCLIP = 8;
	
	// fg.ddsetup() bit flags
	public const int DX_BLIT = 0;
	public const int DX_FLIP = 1;
	public const int DX_RENDER_FG = 0;
	public const int DX_RENDER_SW = 2;
	public const int DX_RENDER_HW = 4;
	public const int DX_ZBUFFER = 8;
	public const int DX_TCDEPTH = 16;
	
	// image file bit flags
	public const int IGNOREPALETTE = 1;
	public const int AT_XY = 2;
	public const int FROMBUFFER = 4;
	public const int KEEPCOLORS = 8;
	public const int NODELAY = 1;
	public const int IGNOREAVIPALETTE = 16;
	public const int IGNOREFLICPALETTE = 16;
	
	// fg._3Dgetmatrix() and fg._3Dsetmatrix() constants
	public const int OBJECT_ROTATION = 0;
	public const int OBJECT_TRANSLATION = 1;
	public const int OBJECT_TRANSFORM = 2;
	public const int WORLD_ROTATION = 3;
	public const int WORLD_TRANSLATION = 4;
	public const int WORLD_TRANSFORM = 5;
	public const int COMBINED_TRANSFORM = 6;
	
	[DllImport("fgw32dd", EntryPoint="_fg_3Daxisangle@28")]
	public static extern int _3Daxisangle(double x, double y, double z, int Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_3Daxisangleobject@28")]
	public static extern int _3Daxisangleobject(double x, double y, double z, int Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dbehindviewer@32")]
	public static extern int _3Dbehindviewer(double x, double y, double z, double Tolerance);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dgetmatrix@8")]
	public static extern void _3Dgetmatrix(ref double Matrix, int Flag);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dgetpov@24")]
	public static extern void _3Dgetpov(out double x, out double y, out double z, out double xOut, out double yOut, out double zOut);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dline@48")]
	public static extern void _3Dline(double x1, double y1, double z1, double x2, double y2, double z2);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dlookat@48")]
	public static extern int _3Dlookat(double xFrom, double yFrom, double zFrom, double xTo, double yTo, double zTo);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dmove@24")]
	public static extern void _3Dmove(double x, double y, double z);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dmoveforward@8")]
	public static extern void _3Dmoveforward(double Amount);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dmoveforwardobject@8")]
	public static extern void _3Dmoveforwardobject(double Amount);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dmoveobject@24")]
	public static extern void _3Dmoveobject(double x, double y, double z);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dmoveright@8")]
	public static extern void _3Dmoveright(double Amount);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dmoverightobject@8")]
	public static extern void _3Dmoverightobject(double Amount);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dmoveup@8")]
	public static extern void _3Dmoveup(double Amount);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dmoveupobject@8")]
	public static extern void _3Dmoveupobject(double Amount);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dpolygon@8")]
	public static extern void _3Dpolygon(ref double xyzArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dpolygonobject@8")]
	public static extern void _3Dpolygonobject(ref double xyzArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dpov@36")]
	public static extern void _3Dpov(double x, double y, double z, int xAngle, int yAngle, int zAngle);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dproject@12")]
	public static extern void _3Dproject(ref double Source, ref int Dest, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Drenderstate@4")]
	public static extern void _3Drenderstate(int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_3Droll@4")]
	public static extern void _3Droll(int Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_3Drollobject@4")]
	public static extern void _3Drollobject(int Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_3Drotate@24")]
	public static extern int _3Drotate(double xOut, double yOut, double zOut);

	[DllImport("fgw32dd", EntryPoint="_fg_3Drotateobject@24")]
	public static extern int _3Drotateobject(double xOut, double yOut, double zOut);

	[DllImport("fgw32dd", EntryPoint="_fg_3Drotateright@4")]
	public static extern void _3Drotateright(int Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_3Drotaterightobject@4")]
	public static extern void _3Drotaterightobject(int Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_3Drotateup@4")]
	public static extern void _3Drotateup(int Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_3Drotateupobject@4")]
	public static extern void _3Drotateupobject(int Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dsetmatrix@12")]
	public static extern void _3Dsetmatrix(ref double Matrix, int Flag, int Update);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dsetobject@36")]
	public static extern void _3Dsetobject(double x, double y, double z, int xAngle, int yAngle, int zAngle);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dsetzclip@16")]
	public static extern void _3Dsetzclip(double zNear, double zFar);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dshade@12")]
	public static extern void _3Dshade(ref double xyzArray, ref byte rgbArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dshadeobject@12")]
	public static extern void _3Dshadeobject(ref double xyzArray, ref byte rgbArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dtexturemap@12")]
	public static extern void _3Dtexturemap(ref double xyzArray, ref int uvArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dtexturemap@12")]
	public static extern void _3Dtexturemap(ref double xyzArray, ref float uvArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dtexturemapobject@12")]
	public static extern void _3Dtexturemapobject(ref double xyzArray, ref int uvArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dtexturemapobject@12")]
	public static extern void _3Dtexturemapobject(ref double xyzArray, ref float uvArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dtransform@12")]
	public static extern void _3Dtransform(ref double Source, ref double Dest, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dtransformobject@12")]
	public static extern void _3Dtransformobject(ref double Source, ref double Dest, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dupvector@24")]
	public static extern void _3Dupvector(double x, double y, double z);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dviewport@24")]
	public static extern void _3Dviewport(int xMin, int xMax, int yMin, int yMax, double Ratio);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dzclip@12")]
	public static extern int _3Dzclip(ref double xyzSource, ref double xyzDest, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dzcliprgb@20")]
	public static extern int _3Dzcliprgb(ref double xyzSource, ref double xyzDest, ref byte rgbSource, ref byte rgbDest, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dzcliptm@20")]
	public static extern int _3Dzcliptm(ref double xyzSource, ref double xyzDest, ref int uvSource, ref int uvDest, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_3Dzcliptm@20")]
	public static extern int _3Dzcliptm(ref double xyzSource, ref double xyzDest, ref float uvSource, ref float uvDest, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_arc@12")]
	public static extern void arc(int Radius, int StartAngle, int EndAngle);

	[DllImport("fgw32dd", EntryPoint="_fg_arcw@16")]
	public static extern void arcw(double Radius, int StartAngle, int EndAngle);

	[DllImport("fgw32dd", EntryPoint="_fg_avidone@4")]
	public static extern void avidone(ref byte Context);

	[DllImport("fgw32dd", EntryPoint="_fg_aviframe@8")]
	public static extern int aviframe(ref byte Context, ref byte Bitmap);

	[DllImport("fgw32dd", EntryPoint="_fg_avihead@8")]
	public static extern int avihead(string FileName, ref byte Header);

	[DllImport("fgw32dd", EntryPoint="_fg_avimake@32")]
	public static extern int avimake(string FileName, ref byte Context, int Compressor, int nWidth, int nHeight, int nDepth, int Quality, int Rate);

	[DllImport("fgw32dd", EntryPoint="_fg_aviopen@8")]
	public static extern int aviopen(string FileName, ref byte Context);

	[DllImport("fgw32dd", EntryPoint="_fg_avipal@8")]
	public static extern int avipal(string FileName, ref byte Palette);

	[DllImport("fgw32dd", EntryPoint="_fg_avipal@8")]
	public static extern int avipal(string FileName, int NullParam);

	[DllImport("fgw32dd", EntryPoint="_fg_aviplay@12")]
	public static extern int aviplay(ref byte Context, int nFrames, int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_avisize@12")]
	public static extern void avisize(ref byte Header, out int nWidth, out int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_aviskip@8")]
	public static extern int aviskip(ref byte Context, int nFrames);

	[DllImport("fgw32dd", EntryPoint="_fg_blend@8")]
	public static extern int blend(int Foreground, int Background);

	[DllImport("fgw32dd", EntryPoint="_fg_blend50@8")]
	public static extern int blend50(int Foreground, int Background);

	[DllImport("fgw32dd", EntryPoint="_fg_blenddcb@16")]
	public static extern void blenddcb(ref byte Foreground, ref byte Background, ref byte Blended, int nSize);

	[DllImport("fgw32dd", EntryPoint="_fg_blendvar@20")]
	public static extern void blendvar(ref byte Foreground, ref byte Background, ref byte Opacity, ref byte Blended, int nSize);

	[DllImport("fgw32dd", EntryPoint="_fg_blendvb@16")]
	public static extern void blendvb(ref byte Foreground, ref byte Background, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_blendvb@16")]
	public static extern void blendvb(ref byte Foreground, int NullParam, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_blendvbv@20")]
	public static extern void blendvbv(ref byte Foreground, ref byte Background, ref byte Opacity, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_blendvbv@20")]
	public static extern void blendvbv(ref byte Foreground, int NullParam, ref byte Opacity, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_bmphead@8")]
	public static extern int bmphead(string FileName, ref byte Header);

	[DllImport("fgw32dd", EntryPoint="_fg_bmppal@8")]
	public static extern int bmppal(string FileName, ref byte Palette);

	[DllImport("fgw32dd", EntryPoint="_fg_bmppal@8")]
	public static extern int bmppal(string FileName, int NullParam);

	[DllImport("fgw32dd", EntryPoint="_fg_bmpsize@12")]
	public static extern void bmpsize(ref byte Header, out int nWidth, out int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_box@16")]
	public static extern void box(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_boxdepth@8")]
	public static extern void boxdepth(int xDepth, int yDepth);

	[DllImport("fgw32dd", EntryPoint="_fg_boxw@32")]
	public static extern void boxw(double xMin, double xMax, double yMin, double yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_boxx@16")]
	public static extern void boxx(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_boxxw@32")]
	public static extern void boxxw(double xMin, double xMax, double yMin, double yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_circle@4")]
	public static extern void circle(int Radius);

	[DllImport("fgw32dd", EntryPoint="_fg_circlef@4")]
	public static extern void circlef(int Radius);

	[DllImport("fgw32dd", EntryPoint="_fg_circlefw@8")]
	public static extern void circlefw(double Radius);

	[DllImport("fgw32dd", EntryPoint="_fg_circlew@8")]
	public static extern void circlew(double Radius);

	[DllImport("fgw32dd", EntryPoint="_fg_clip2vb@20")]
	public static extern int clip2vb(int xMin, int xMax, int yMin, int yMax, int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_clipdcb@12")]
	public static extern void clipdcb(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_clipmap@12")]
	public static extern void clipmap(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_clipmask@12")]
	public static extern void clipmask(ref byte Bitmap, int nRuns, int nWidth);

	[DllImport("fgw32dd", EntryPoint="_fg_clpimage@12")]
	public static extern void clpimage(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_clprect@16")]
	public static extern void clprect(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_clprectw@32")]
	public static extern void clprectw(double xMin, double xMax, double yMin, double yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_clprectx@16")]
	public static extern void clprectx(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_colors@0")]
	public static extern int colors();

	[DllImport("fgw32dd", EntryPoint="_fg_contdcb@20")]
	public static extern void contdcb(ref byte Source, ref byte Dest, int nLower, int nUpper, int nSize);

	[DllImport("fgw32dd", EntryPoint="_fg_contrgb@16")]
	public static extern void contrgb(ref byte Values, int nLower, int nUpper, int nCount);

	[DllImport("fgw32dd", EntryPoint="_fg_contvb@16")]
	public static extern void contvb(int nLower, int nUpper, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_copypage@8")]
	public static extern void copypage(int Source, int Dest);

	[DllImport("fgw32dd", EntryPoint="_fg_cut@28")]
	public static extern void cut(ref byte Bitmap, ref byte Section, int xPos, int yPos, int nWidth, int nSecWidth, int nSecHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_cutdcb@28")]
	public static extern void cutdcb(ref byte Bitmap, ref byte Section, int xPos, int yPos, int nWidth, int nSecWidth, int nSecHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_dash@12")]
	public static extern void dash(int x, int y, int Pattern);

	[DllImport("fgw32dd", EntryPoint="_fg_dashrel@12")]
	public static extern void dashrel(int x, int y, int Pattern);

	[DllImport("fgw32dd", EntryPoint="_fg_dashrw@20")]
	public static extern void dashrw(double x, double y, int Pattern);

	[DllImport("fgw32dd", EntryPoint="_fg_dashw@20")]
	public static extern void dashw(double x, double y, int Pattern);

	[DllImport("fgw32dd", EntryPoint="_fg_defcolor@8")]
	public static extern void defcolor(int nIndex, int nValue);

	[DllImport("fgw32dd", EntryPoint="_fg_defpal@0")]
	public static extern int defpal();

	[DllImport("fgw32dd", EntryPoint="_fg_dispfile@12")]
	public static extern void dispfile(string FileName, int nWidth, int Format);

	[DllImport("fgw32dd", EntryPoint="_fg_display@12")]
	public static extern void display(ref byte Bitmap, int nRuns, int nWidth);

	[DllImport("fgw32dd", EntryPoint="_fg_displayp@12")]
	public static extern void displayp(ref byte Bitmap, int nRuns, int nWidth);

	[DllImport("fgw32dd", EntryPoint="_fg_draw@8")]
	public static extern void draw(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_drawdcb@12")]
	public static extern void drawdcb(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_drawmap@12")]
	public static extern void drawmap(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_drawmask@12")]
	public static extern void drawmask(ref byte Bitmap, int nRuns, int nWidth);

	[DllImport("fgw32dd", EntryPoint="_fg_drawrel@8")]
	public static extern void drawrel(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_drawrelx@8")]
	public static extern void drawrelx(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_drawrw@16")]
	public static extern void drawrw(double x, double y);

	[DllImport("fgw32dd", EntryPoint="_fg_drawrxw@16")]
	public static extern void drawrxw(double x, double y);

	[DllImport("fgw32dd", EntryPoint="_fg_draww@16")]
	public static extern void draww(double x, double y);

	[DllImport("fgw32dd", EntryPoint="_fg_drawx@8")]
	public static extern void drawx(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_drawxw@16")]
	public static extern void drawxw(double x, double y);

	[DllImport("fgw32dd", EntryPoint="_fg_drawz@24")]
	public static extern void drawz(int x, int y, double zStart, double zEnd);

	[DllImport("fgw32dd", EntryPoint="_fg_drect@20")]
	public static extern void drect(int xMin, int xMax, int yMin, int yMax, ref byte Matrix);

	[DllImport("fgw32dd", EntryPoint="_fg_drectw@36")]
	public static extern void drectw(double xMin, double xMax, double yMin, double yMax, ref byte Matrix);

	[DllImport("fgw32dd", EntryPoint="_fg_drwimage@12")]
	public static extern void drwimage(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_ellipse@8")]
	public static extern void ellipse(int Horiz, int Vert);

	[DllImport("fgw32dd", EntryPoint="_fg_ellipsef@8")]
	public static extern void ellipsef(int Horiz, int Vert);

	[DllImport("fgw32dd", EntryPoint="_fg_ellipsew@16")]
	public static extern void ellipsew(double Horiz, double Vert);

	[DllImport("fgw32dd", EntryPoint="_fg_ellipsfw@16")]
	public static extern void ellipsfw(double Horiz, double Vert);

	[DllImport("fgw32dd", EntryPoint="_fg_erase@0")]
	public static extern void erase();

	[DllImport("fgw32dd", EntryPoint="_fg_fillpage@0")]
	public static extern void fillpage();

	[DllImport("fgw32dd", EntryPoint="_fg_findrgb@12")]
	public static extern int findrgb(int Red, int Green, int Blue);

	[DllImport("fgw32dd", EntryPoint="_fg_fixdiv@8")]
	public static extern int fixdiv(int n1, int n2);

	[DllImport("fgw32dd", EntryPoint="_fg_fixed@8")]
	public static extern int Fixed(double n);

	[DllImport("fgw32dd", EntryPoint="_fg_fixmul@8")]
	public static extern int fixmul(int n1, int n2);

	[DllImport("fgw32dd", EntryPoint="_fg_fixtrig@12")]
	public static extern void fixtrig(int Angle, out int Cosine, out int Sine);

	[DllImport("fgw32dd", EntryPoint="_fg_flicdone@4")]
	public static extern void flicdone(ref byte Context);

	[DllImport("fgw32dd", EntryPoint="_fg_flichead@8")]
	public static extern int flichead(string FileName, ref byte Header);

	[DllImport("fgw32dd", EntryPoint="_fg_flicopen@8")]
	public static extern int flicopen(string FileName, ref byte Context);

	[DllImport("fgw32dd", EntryPoint="_fg_flicplay@12")]
	public static extern int flicplay(ref byte Context, int nFrames, int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_flicsize@12")]
	public static extern void flicsize(ref byte Header, out int nWidth, out int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_flicskip@8")]
	public static extern int flicskip(ref byte Context, int nFrames);

	[DllImport("fgw32dd", EntryPoint="_fg_flipdcb@12")]
	public static extern void flipdcb(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_flipmask@12")]
	public static extern void flipmask(ref byte Bitmap, int nRuns, int nWidth);

	[DllImport("fgw32dd", EntryPoint="_fg_float@4")]
	public static extern double Float(int n);

	[DllImport("fgw32dd", EntryPoint="_fg_flood@8")]
	public static extern void flood(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_floodw@16")]
	public static extern void floodw(double x, double y);

	[DllImport("fgw32dd", EntryPoint="_fg_flpimage@12")]
	public static extern void flpimage(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_fontdc@4")]
	public static extern void fontdc(IntPtr hDC);

	[DllImport("fgw32dd", EntryPoint="_fg_fontload@4")]
	public static extern void fontload(int FontId);

	[DllImport("fgw32dd", EntryPoint="_fg_gammadcb@20")]
	public static extern void gammadcb(ref byte Source, ref byte Dest, double Gamma, int nSize);

	[DllImport("fgw32dd", EntryPoint="_fg_gammargb@16")]
	public static extern void gammargb(ref byte Values, double Gamma, int nCount);

	[DllImport("fgw32dd", EntryPoint="_fg_gammavb@16")]
	public static extern void gammavb(double Gamma, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_getblock@20")]
	public static extern void getblock(ref byte Buffer, int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_getclip@16")]
	public static extern void getclip(out int xMin, out int xMax, out int yMin, out int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_getclock@0")]
	public static extern int getclock();

	[DllImport("fgw32dd", EntryPoint="_fg_getcolor@0")]
	public static extern int getcolor();

	[DllImport("fgw32dd", EntryPoint="_fg_getdacs@12")]
	public static extern void getdacs(int nStart, int nCount, ref byte Values);

	[DllImport("fgw32dd", EntryPoint="_fg_getdc@0")]
	public static extern IntPtr getdc();

	[DllImport("fgw32dd", EntryPoint="_fg_getdcb@12")]
	public static extern void getdcb(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_getdepth@0")]
	public static extern int getdepth();

	[DllImport("fgw32dd", EntryPoint="_fg_gethcbpp@0")]
	public static extern int gethcbpp();

	[DllImport("fgw32dd", EntryPoint="_fg_gethpage@0")]
	public static extern int gethpage();

	[DllImport("fgw32dd", EntryPoint="_fg_getimage@12")]
	public static extern void getimage(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_getindex@4")]
	public static extern int getindex(int nIndex);

	[DllImport("fgw32dd", EntryPoint="_fg_getline@4")]
	public static extern int getline(int nRow);

	[DllImport("fgw32dd", EntryPoint="_fg_getlines@0")]
	public static extern int getlines();

	[DllImport("fgw32dd", EntryPoint="_fg_getmap@12")]
	public static extern void getmap(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_getmaxx@0")]
	public static extern int getmaxx();

	[DllImport("fgw32dd", EntryPoint="_fg_getmaxy@0")]
	public static extern int getmaxy();

	[DllImport("fgw32dd", EntryPoint="_fg_getpage@0")]
	public static extern int getpage();

	[DllImport("fgw32dd", EntryPoint="_fg_getpixel@8")]
	public static extern int getpixel(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_getrgb@16")]
	public static extern void getrgb(int nColor, out int Red, out int Green, out int Blue);

	[DllImport("fgw32dd", EntryPoint="_fg_getview@32")]
	public static extern void getview(out int xMinView, out int xMaxView, out int yMinView, out int yMaxView, out int xMin, out int xMax, out int yMin, out int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_getworld@32")]
	public static extern void getworld(out double xMin, out double xMax, out double yMin, out double yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_getxbox@0")]
	public static extern int getxbox();

	[DllImport("fgw32dd", EntryPoint="_fg_getxjust@0")]
	public static extern int getxjust();

	[DllImport("fgw32dd", EntryPoint="_fg_getxpos@0")]
	public static extern int getxpos();

	[DllImport("fgw32dd", EntryPoint="_fg_getybox@0")]
	public static extern int getybox();

	[DllImport("fgw32dd", EntryPoint="_fg_getyjust@0")]
	public static extern int getyjust();

	[DllImport("fgw32dd", EntryPoint="_fg_getypos@0")]
	public static extern int getypos();

	[DllImport("fgw32dd", EntryPoint="_fg_gouraud@12")]
	public static extern void gouraud(ref int xyArray, ref byte rgbArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_gouraudz@16")]
	public static extern void gouraudz(ref int xyArray, ref byte rgbArray, ref double xyzArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_graydcb@12")]
	public static extern void graydcb(ref byte Source, ref byte Dest, int nSize);

	[DllImport("fgw32dd", EntryPoint="_fg_grayrgb@8")]
	public static extern void grayrgb(ref byte Values, int nCount);

	[DllImport("fgw32dd", EntryPoint="_fg_grayvb@8")]
	public static extern void grayvb(int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_imagebuf@8")]
	public static extern void imagebuf(ref byte Buffer, int nSize);

	[DllImport("fgw32dd", EntryPoint="_fg_imagesiz@8")]
	public static extern int imagesiz(int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_initw@0")]
	public static extern void initw();

	[DllImport("fgw32dd", EntryPoint="_fg_inside@16")]
	public static extern int inside(ref int xyArray, int n, int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_invdcb@12")]
	public static extern void invdcb(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_invert@12")]
	public static extern void invert(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_jpegbuf@8")]
	public static extern void jpegbuf(ref byte Buffer, int nSize);

	[DllImport("fgw32dd", EntryPoint="_fg_jpeghead@8")]
	public static extern int jpeghead(string FileName, ref byte Header);

	[DllImport("fgw32dd", EntryPoint="_fg_jpegmem@4")]
	public static extern int jpegmem(ref byte Header);

	[DllImport("fgw32dd", EntryPoint="_fg_jpegsize@12")]
	public static extern void jpegsize(ref byte Header, out int nWidth, out int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_justify@8")]
	public static extern void justify(int xJust, int yJust);

	[DllImport("fgw32dd", EntryPoint="_fg_kbtest@4")]
	public static extern int kbtest(int ScanCode);

	[DllImport("fgw32dd", EntryPoint="_fg_loadpcx@8")]
	public static extern int loadpcx(string FileName, int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_locate@8")]
	public static extern void locate(int nRow, int nColumn);

	[DllImport("fgw32dd", EntryPoint="_fg_logfont@4")]
	public static extern void logfont(IntPtr hFont);

	[DllImport("fgw32dd", EntryPoint="_fg_logpal@12")]
	public static extern int logpal(int nStart, int nCount, ref byte Values);

	[DllImport("fgw32dd", EntryPoint="_fg_makebmp@24")]
	public static extern int makebmp(int xMin, int xMax, int yMin, int yMax, int nDepth, string FileName);

	[DllImport("fgw32dd", EntryPoint="_fg_makepcx@20")]
	public static extern int makepcx(int xMin, int xMax, int yMin, int yMax, string FileName);

	[DllImport("fgw32dd", EntryPoint="_fg_makeppr@20")]
	public static extern int makeppr(int xMin, int xMax, int yMin, int yMax, string FileName);

	[DllImport("fgw32dd", EntryPoint="_fg_makespr@20")]
	public static extern int makespr(int xMin, int xMax, int yMin, int yMax, string FileName);

	[DllImport("fgw32dd", EntryPoint="_fg_mapdacs@12")]
	public static extern void mapdacs(ref byte Source, ref byte Dest, int nCount);

	[DllImport("fgw32dd", EntryPoint="_fg_maprgb@12")]
	public static extern int maprgb(int Red, int Green, int Blue);

	[DllImport("fgw32dd", EntryPoint="_fg_measure@0")]
	public static extern int measure();

	[DllImport("fgw32dd", EntryPoint="_fg_memavail@0")]
	public static extern int memavail();

	[DllImport("fgw32dd", EntryPoint="_fg_modeset@16")]
	public static extern int modeset(int nWidth, int nHeight, int nDepth, int nStyle);

	[DllImport("fgw32dd", EntryPoint="_fg_modetest@12")]
	public static extern int modetest(int nWidth, int nHeight, int nDepth);

	[DllImport("fgw32dd", EntryPoint="_fg_mousecur@4")]
	public static extern void mousecur(IntPtr hCursor);

	[DllImport("fgw32dd", EntryPoint="_fg_mouseini@0")]
	public static extern int mouseini();

	[DllImport("fgw32dd", EntryPoint="_fg_mouselim@16")]
	public static extern void mouselim(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_mousemov@8")]
	public static extern void mousemov(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_mousepos@8")]
	public static extern void mousepos(out int x, out int y);

	[DllImport("fgw32dd", EntryPoint="_fg_mouseptr@12")]
	public static extern IntPtr mouseptr(ref byte Masks, int xOffset, int yOffset);

	[DllImport("fgw32dd", EntryPoint="_fg_mousesiz@4")]
	public static extern void mousesiz(int nPixels);

	[DllImport("fgw32dd", EntryPoint="_fg_mousevis@4")]
	public static extern void mousevis(int State);

	[DllImport("fgw32dd", EntryPoint="_fg_move@8")]
	public static extern void move(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_move3d@20")]
	public static extern void move3d(ref int Transform, int x, int y, int z, int Flag);

	[DllImport("fgw32dd", EntryPoint="_fg_moverel@8")]
	public static extern void moverel(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_moverw@16")]
	public static extern void moverw(double x, double y);

	[DllImport("fgw32dd", EntryPoint="_fg_movew@16")]
	public static extern void movew(double x, double y);

	[DllImport("fgw32dd", EntryPoint="_fg_opacity@4")]
	public static extern void opacity(int Opacity);

	[DllImport("fgw32dd", EntryPoint="_fg_pack@16")]
	public static extern void pack(ref byte Source, ref byte Dest, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_pagesize@8")]
	public static extern int pagesize(int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_paint@8")]
	public static extern void paint(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_paintw@16")]
	public static extern void paintw(double x, double y);

	[DllImport("fgw32dd", EntryPoint="_fg_paste@28")]
	public static extern void paste(ref byte Bitmap, ref byte Section, int xPos, int yPos, int nWidth, int nSecWidth, int nSecHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_pastedcb@28")]
	public static extern void pastedcb(ref byte Bitmap, ref byte Section, int xPos, int yPos, int nWidth, int nSecWidth, int nSecHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_pcxhead@8")]
	public static extern int pcxhead(string FileName, ref byte Header);

	[DllImport("fgw32dd", EntryPoint="_fg_pcxpal@8")]
	public static extern int pcxpal(string FileName, ref byte Palette);

	[DllImport("fgw32dd", EntryPoint="_fg_pcxpal@8")]
	public static extern int pcxpal(string FileName, int NullParam);

	[DllImport("fgw32dd", EntryPoint="_fg_pcxrange@20")]
	public static extern void pcxrange(ref byte Header, out int xMin, out int xMax, out int yMin, out int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_pcxsize@12")]
	public static extern void pcxsize(ref byte Header, out int nWidth, out int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_photodcb@12")]
	public static extern void photodcb(ref byte Source, ref byte Dest, int nSize);

	[DllImport("fgw32dd", EntryPoint="_fg_photorgb@8")]
	public static extern void photorgb(ref byte Values, int nCount);

	[DllImport("fgw32dd", EntryPoint="_fg_photovb@8")]
	public static extern void photovb(int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_point@8")]
	public static extern void point(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_pointw@16")]
	public static extern void pointw(double x, double y);

	[DllImport("fgw32dd", EntryPoint="_fg_pointx@8")]
	public static extern void pointx(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_pointxw@16")]
	public static extern void pointxw(double x, double y);

	[DllImport("fgw32dd", EntryPoint="_fg_polyedge@4")]
	public static extern void polyedge(int Flag);

	[DllImport("fgw32dd", EntryPoint="_fg_polyfill@12")]
	public static extern void polyfill(ref int xyArray, ref byte Unused, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_polyfill@12")]
	public static extern void polyfill(ref int xyArray, int Unused, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_polyfilz@12")]
	public static extern void polyfilz(ref int xyArray, ref double xyzArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_polygon@12")]
	public static extern void polygon(ref int xArray, ref int yArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_polygonw@20")]
	public static extern void polygonw(ref double xArray, ref double yArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_polyline@8")]
	public static extern void polyline(ref int xyArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_polyoff@8")]
	public static extern void polyoff(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_print@8")]
	public static extern void print(string s, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_printdc@4")]
	public static extern void printdc(IntPtr hDC);

	[DllImport("fgw32dd", EntryPoint="_fg_printer@4")]
	public static extern int printer(int nMessage);

	[DllImport("fgw32dd", EntryPoint="_fg_project@16")]
	public static extern void project(ref int Transform, ref int Source, ref int Dest, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_putblock@20")]
	public static extern void putblock(ref byte Buffer, int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_putdcb@12")]
	public static extern void putdcb(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_putimage@12")]
	public static extern void putimage(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_putpixel@8")]
	public static extern void putpixel(int x, int y);

	[DllImport("fgw32dd", EntryPoint="_fg_realize@4")]
	public static extern void realize(int hPal);

	[DllImport("fgw32dd", EntryPoint="_fg_rect@16")]
	public static extern void rect(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_rectw@32")]
	public static extern void rectw(double xMin, double xMax, double yMin, double yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_rectx@16")]
	public static extern void rectx(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_reduce@12")]
	public static extern void reduce(int nOffset, int nColors, ref byte Values);

	[DllImport("fgw32dd", EntryPoint="_fg_restore@16")]
	public static extern void restore(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_restorew@32")]
	public static extern void restorew(double xMin, double xMax, double yMin, double yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_revdcb@12")]
	public static extern void revdcb(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_revimage@12")]
	public static extern void revimage(ref byte Bitmap, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_revmask@12")]
	public static extern void revmask(ref byte Bitmap, int nRuns, int nWidth);

	[DllImport("fgw32dd", EntryPoint="_fg_rotate@20")]
	public static extern void rotate(ref byte Source, ref byte Dest, int nWidth, int nHeight, int Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_rotate3d@20")]
	public static extern void rotate3d(ref int Transform, int Pitch, int Yaw, int Roll, int Flag);

	[DllImport("fgw32dd", EntryPoint="_fg_rotdcb@20")]
	public static extern void rotdcb(ref byte Source, ref byte Dest, int nWidth, int nHeight, int Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_rotsize@20")]
	public static extern void rotsize(int nWidth, int nHeight, int Angle, out int nNewWidth, out int nNewHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_save@16")]
	public static extern void save(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_savew@32")]
	public static extern void savew(double xMin, double xMax, double yMin, double yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_scale@24")]
	public static extern void scale(ref byte Source, ref byte Dest, int sWidth, int sHeight, int dWidth, int dHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_scale@24")]
	public static extern void scale(int pSource, int pDest, int sWidth, int sHeight, int dWidth, int dHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_scaledcb@24")]
	public static extern void scaledcb(ref byte Source, ref byte Dest, int sWidth, int sHeight, int dWidth, int dHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_scaledcb@24")]
	public static extern void scaledcb(int pSource, int pDest, int sWidth, int sHeight, int dWidth, int dHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_scroll@24")]
	public static extern void scroll(int xMin, int xMax, int yMin, int yMax, int nJump, int nType);

	[DllImport("fgw32dd", EntryPoint="_fg_setalpha@4")]
	public static extern void setalpha(int Alpha);

	[DllImport("fgw32dd", EntryPoint="_fg_setangle@8")]
	public static extern void setangle(double Angle);

	[DllImport("fgw32dd", EntryPoint="_fg_setclip@16")]
	public static extern void setclip(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_setclipw@32")]
	public static extern void setclipw(double xMin, double xMax, double yMin, double yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_setcolor@4")]
	public static extern void setcolor(int nColor);

	[DllImport("fgw32dd", EntryPoint="_fg_setcolorrgb@12")]
	public static extern void setcolorrgb(int Red, int Green, int Blue);

	[DllImport("fgw32dd", EntryPoint="_fg_setdacs@12")]
	public static extern void setdacs(int nStart, int nCount, ref byte Values);

	[DllImport("fgw32dd", EntryPoint="_fg_setdc@4")]
	public static extern void setdc(IntPtr hDC);

	[DllImport("fgw32dd", EntryPoint="_fg_sethpage@4")]
	public static extern void sethpage(int hVB);

	[DllImport("fgw32dd", EntryPoint="_fg_setpage@4")]
	public static extern void setpage(int hVB);

	[DllImport("fgw32dd", EntryPoint="_fg_setratio@8")]
	public static extern void setratio(double Ratio);

	[DllImport("fgw32dd", EntryPoint="_fg_setrgb@16")]
	public static extern void setrgb(int nColor, int Red, int Green, int Blue);

	[DllImport("fgw32dd", EntryPoint="_fg_setsize@4")]
	public static extern void setsize(int CharSize);

	[DllImport("fgw32dd", EntryPoint="_fg_setsizew@8")]
	public static extern void setsizew(double CharSize);

	[DllImport("fgw32dd", EntryPoint="_fg_setview@32")]
	public static extern void setview(int xMinView, int xMaxView, int yMinView, int yMaxView, int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_setworld@32")]
	public static extern void setworld(double xMin, double xMax, double yMin, double yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_shear@24")]
	public static extern void shear(ref byte Source, ref byte Dest, int nWidth, int nHeight, int nNewSize, int nType);

	[DllImport("fgw32dd", EntryPoint="_fg_shear@24")]
	public static extern void shear(int pSource, int pDest, int nWidth, int nHeight, int nNewSize, int nType);

	[DllImport("fgw32dd", EntryPoint="_fg_sheardcb@24")]
	public static extern void sheardcb(ref byte Source, ref byte Dest, int nWidth, int nHeight, int nNewSize, int nType);

	[DllImport("fgw32dd", EntryPoint="_fg_sheardcb@24")]
	public static extern void sheardcb(int pSource, int pDest, int nWidth, int nHeight, int nNewSize, int nType);

	[DllImport("fgw32dd", EntryPoint="_fg_showavi@12")]
	public static extern int showavi(string FileName, int nCount, int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_showbmp@8")]
	public static extern int showbmp(string FileName, int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_showflic@12")]
	public static extern int showflic(string FileName, int nCount, int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_showjpeg@8")]
	public static extern int showjpeg(string FileName, int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_showpcx@8")]
	public static extern int showpcx(string FileName, int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_showppr@8")]
	public static extern int showppr(string FileName, int nWidth);

	[DllImport("fgw32dd", EntryPoint="_fg_showspr@8")]
	public static extern int showspr(string FileName, int nWidth);

	[DllImport("fgw32dd", EntryPoint="_fg_stall@4")]
	public static extern void stall(int nDelay);

	[DllImport("fgw32dd", EntryPoint="_fg_swchar@12")]
	public static extern void swchar(string s, int n, int Justify);

	[DllImport("fgw32dd", EntryPoint="_fg_swlength@8")]
	public static extern double swlength(string s, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_swtext@12")]
	public static extern void swtext(string s, int n, int Justify);

	[DllImport("fgw32dd", EntryPoint="_fg_tcdefine@8")]
	public static extern void tcdefine(int nIndex, int nAttribute);

	[DllImport("fgw32dd", EntryPoint="_fg_tcmask@4")]
	public static extern void tcmask(int Mask);

	[DllImport("fgw32dd", EntryPoint="_fg_tcxfer@32")]
	public static extern void tcxfer(int xMin, int xMax, int yMin, int yMax, int xNew, int yNew, int Source, int Dest);

	[DllImport("fgw32dd", EntryPoint="_fg_texmap@12")]
	public static extern void texmap(ref int xyArray, ref int uvArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_texmap@12")]
	public static extern void texmap(ref int xyArray, ref float uvArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_texmapp@16")]
	public static extern void texmapp(ref int xyArray, ref int uvArray, ref double xyzArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_texmapp@16")]
	public static extern void texmapp(ref int xyArray, ref float uvArray, ref double xyzArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_texmappz@16")]
	public static extern void texmappz(ref int xyArray, ref int uvArray, ref double xyzArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_texmappz@16")]
	public static extern void texmappz(ref int xyArray, ref float uvArray, ref double xyzArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_texmapz@16")]
	public static extern void texmapz(ref int xyArray, ref int uvArray, ref double xyzArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_texmapz@16")]
	public static extern void texmapz(ref int xyArray, ref float uvArray, ref double xyzArray, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_text@8")]
	public static extern void text(string s, int n);

	[DllImport("fgw32dd", EntryPoint="_fg_texture@8")]
	public static extern void texture(ref byte Texture, int nWidth);

	[DllImport("fgw32dd", EntryPoint="_fg_tmdefine@12")]
	public static extern int tmdefine(ref byte Texture, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_tmevict@0")]
	public static extern void tmevict();

	[DllImport("fgw32dd", EntryPoint="_fg_tmfree@4")]
	public static extern void tmfree(int hTM);

	[DllImport("fgw32dd", EntryPoint="_fg_tminit@4")]
	public static extern int tminit(int nCount);

	[DllImport("fgw32dd", EntryPoint="_fg_tmselect@4")]
	public static extern void tmselect(int hTM);

	[DllImport("fgw32dd", EntryPoint="_fg_tmspan@4")]
	public static extern void tmspan(int nPixels);

	[DllImport("fgw32dd", EntryPoint="_fg_tmtransparency@4")]
	public static extern void tmtransparency(int State);

	[DllImport("fgw32dd", EntryPoint="_fg_tmunits@4")]
	public static extern void tmunits(int Units);

	[DllImport("fgw32dd", EntryPoint="_fg_transdcb@20")]
	public static extern void transdcb(ref byte Source, ref byte Dest, int sDepth, int dDepth, int nSize);

	[DllImport("fgw32dd", EntryPoint="_fg_transfer@32")]
	public static extern void transfer(int xMin, int xMax, int yMin, int yMax, int xNew, int yNew, int Source, int Dest);

	[DllImport("fgw32dd", EntryPoint="_fg_trig@12")]
	public static extern void trig(int Angle, out double Cosine, out double Sine);

	[DllImport("fgw32dd", EntryPoint="_fg_unmaprgb@16")]
	public static extern void unmaprgb(int nColor, out int Red, out int Green, out int Blue);

	[DllImport("fgw32dd", EntryPoint="_fg_unpack@12")]
	public static extern void unpack(ref byte Source, ref byte Dest, int nSize);

	[DllImport("fgw32dd", EntryPoint="_fg_vb2clip@16")]
	public static extern int vb2clip(int xMin, int xMax, int yMin, int yMax);

	[DllImport("fgw32dd", EntryPoint="_fg_vbaddr@4")]
	public static extern int vbaddr(int hVB);

	[DllImport("fgw32dd", EntryPoint="_fg_vballoc@8")]
	public static extern int vballoc(int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_vbclose@0")]
	public static extern void vbclose();

	[DllImport("fgw32dd", EntryPoint="_fg_vbcolors@0")]
	public static extern void vbcolors();

	[DllImport("fgw32dd", EntryPoint="_fg_vbcopy@32")]
	public static extern void vbcopy(int xMin, int xMax, int yMin, int yMax, int xNew, int yNew, int Source, int Dest);

	[DllImport("fgw32dd", EntryPoint="_fg_vbdefine@12")]
	public static extern int vbdefine(ref byte Buffer, int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_vbdepth@4")]
	public static extern void vbdepth(int nDepth);

	[DllImport("fgw32dd", EntryPoint="_fg_vbfin@0")]
	public static extern void vbfin();

	[DllImport("fgw32dd", EntryPoint="_fg_vbfree@4")]
	public static extern void vbfree(int hVB);

	[DllImport("fgw32dd", EntryPoint="_fg_vbhandle@0")]
	public static extern int vbhandle();

	[DllImport("fgw32dd", EntryPoint="_fg_vbinit@0")]
	public static extern int vbinit();

	[DllImport("fgw32dd", EntryPoint="_fg_vbopen@4")]
	public static extern int vbopen(int hVB);

	[DllImport("fgw32dd", EntryPoint="_fg_vbpaste@24")]
	public static extern void vbpaste(int xMin, int xMax, int yMin, int yMax, int xClient, int yClient);

	[DllImport("fgw32dd", EntryPoint="_fg_vbprint@36")]
	public static extern void vbprint(int xMin, int xMax, int yMin, int yMax, int xMinPrint, int xMaxPrint, int yMinPrint, int yMaxPrint, int Units);

	[DllImport("fgw32dd", EntryPoint="_fg_vbscale@32")]
	public static extern void vbscale(int xMin, int xMax, int yMin, int yMax, int xMinClient, int xMaxClient, int yMinClient, int yMaxClient);

	[DllImport("fgw32dd", EntryPoint="_fg_vbsize@8")]
	public static extern int vbsize(int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_vbtccopy@32")]
	public static extern void vbtccopy(int xMin, int xMax, int yMin, int yMax, int xNew, int yNew, int Source, int Dest);

	[DllImport("fgw32dd", EntryPoint="_fg_vbtcopy@36")]
	public static extern void vbtcopy(int xMin, int xMax, int yMin, int yMax, int xNew, int yNew, int nColor, int Source, int Dest);

	[DllImport("fgw32dd", EntryPoint="_fg_vbtzcopy@32")]
	public static extern void vbtzcopy(int xMin, int xMax, int yMin, int yMax, int xNew, int yNew, int Source, int Dest);

	[DllImport("fgw32dd", EntryPoint="_fg_vbundef@4")]
	public static extern void vbundef(int hVB);

	[DllImport("fgw32dd", EntryPoint="_fg_version@8")]
	public static extern void version(out int Major, out int Minor);

	[DllImport("fgw32dd", EntryPoint="_fg_view3d@20")]
	public static extern void view3d(int xMin, int xMax, int yMin, int yMax, int Ratio);

	[DllImport("fgw32dd", EntryPoint="_fg_waitfor@4")]
	public static extern void waitfor(int nTicks);

	[DllImport("fgw32dd", EntryPoint="_fg_where@8")]
	public static extern void where(out int nRow, out int nColumn);

	[DllImport("fgw32dd", EntryPoint="_fg_xalpha@4")]
	public static extern int xalpha(int x);

	[DllImport("fgw32dd", EntryPoint="_fg_xclient@4")]
	public static extern int xclient(int x);

	[DllImport("fgw32dd", EntryPoint="_fg_xconvert@4")]
	public static extern int xconvert(int nColumn);

	[DllImport("fgw32dd", EntryPoint="_fg_xscreen@8")]
	public static extern int xscreen(double x);

	[DllImport("fgw32dd", EntryPoint="_fg_xvb@4")]
	public static extern int xvb(int x);

	[DllImport("fgw32dd", EntryPoint="_fg_xview@4")]
	public static extern int xview(int xView);

	[DllImport("fgw32dd", EntryPoint="_fg_xworld@4")]
	public static extern double xworld(int x);

	[DllImport("fgw32dd", EntryPoint="_fg_yalpha@4")]
	public static extern int yalpha(int y);

	[DllImport("fgw32dd", EntryPoint="_fg_yclient@4")]
	public static extern int yclient(int y);

	[DllImport("fgw32dd", EntryPoint="_fg_yconvert@4")]
	public static extern int yconvert(int nRow);

	[DllImport("fgw32dd", EntryPoint="_fg_yscreen@8")]
	public static extern int yscreen(double y);

	[DllImport("fgw32dd", EntryPoint="_fg_yvb@4")]
	public static extern int yvb(int y);

	[DllImport("fgw32dd", EntryPoint="_fg_yview@4")]
	public static extern int yview(int yView);

	[DllImport("fgw32dd", EntryPoint="_fg_yworld@4")]
	public static extern double yworld(int y);

	[DllImport("fgw32dd", EntryPoint="_fg_zballoc@8")]
	public static extern int zballoc(int nWidth, int nHeight);

	[DllImport("fgw32dd", EntryPoint="_fg_zbframe@0")]
	public static extern void zbframe();

	[DllImport("fgw32dd", EntryPoint="_fg_zbfree@4")]
	public static extern void zbfree(int hZB);

	[DllImport("fgw32dd", EntryPoint="_fg_zbopen@4")]
	public static extern void zbopen(int hZB);

	[DllImport("fgw32dd", EntryPoint="_fg_ddapply@4")]
	public static extern void ddapply(int Version);

	[DllImport("fgw32dd", EntryPoint="_fg_ddflip@0")]
	public static extern int ddflip();

	[DllImport("fgw32dd", EntryPoint="_fg_ddflipnw@0")]
	public static extern int ddflipnw();

	[DllImport("fgw32dd", EntryPoint="_fg_ddframe@4")]
	public static extern void ddframe(int State);

	[DllImport("fgw32dd", EntryPoint="_fg_ddfreedc@4")]
	public static extern void ddfreedc(IntPtr hDC);

	[DllImport("fgw32dd", EntryPoint="_fg_ddgetdc@0")]
	public static extern IntPtr ddgetdc();

	[DllImport("fgw32dd", EntryPoint="_fg_ddgetobj@4")]
	public static extern int ddgetobj(int nCode);

	[DllImport("fgw32dd", EntryPoint="_fg_ddgetversion@0")]
	public static extern int ddgetversion();

	[DllImport("fgw32dd", EntryPoint="_fg_ddlock@0")]
	public static extern int ddlock();

	[DllImport("fgw32dd", EntryPoint="_fg_ddmemory@4")]
	public static extern void ddmemory(int MemType);

	[DllImport("fgw32dd", EntryPoint="_fg_ddrestore@0")]
	public static extern void ddrestore();

	[DllImport("fgw32dd", EntryPoint="_fg_ddsetblt@4")]
	public static extern void ddsetblt(int Usage);

	[DllImport("fgw32dd", EntryPoint="_fg_ddsetobj@8")]
	public static extern void ddsetobj(ref int dxObject, int nCode);

	[DllImport("fgw32dd", EntryPoint="_fg_ddsetup@16")]
	public static extern void ddsetup(int nWidth, int nHeight, int nDepth, int Flags);

	[DllImport("fgw32dd", EntryPoint="_fg_ddsetversion@8")]
	public static extern void ddsetversion(int MinVer, int MaxVer);

	[DllImport("fgw32dd", EntryPoint="_fg_ddstatus@0")]
	public static extern int ddstatus();

	[DllImport("fgw32dd", EntryPoint="_fg_ddunlock@0")]
	public static extern void ddunlock();

	[DllImport("fgw32dd", EntryPoint="_fg_ddusage@0")]
	public static extern int ddusage();

	[DllImport("fgw32dd", EntryPoint="_fg_gdiflip@0")]
	public static extern void gdiflip();
}

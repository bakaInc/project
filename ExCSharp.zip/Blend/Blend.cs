/****************************************************************************\
*                                                                            *
*  Blend.cs                                                                  *
*                                                                            *
*  This program illustrates some of the Fastgraph for Windows alpha blending *
*  functions.                                                                *
*                                                                            *
*  Press F1 to view the foreground image.                                    *
*  Press F2 to view the background image.                                    *
*  Press F3 to create and view a 50% blended image.                          *
*  Press F4 to create and view a variable blended image.                     *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Blend
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		const int vbWidth = 640;
		const int vbHeight = 480;
		const int vbDepth = 16;

		// Direct color bitmap containing the foreground image.
		byte [] Foreground = new byte [vbWidth * vbHeight * (vbDepth / 8)];

		// Direct color bitmap containing the background image.
		byte [] Background = new byte [vbWidth * vbHeight * (vbDepth / 8)];

		// Direct color bitmap containing the resulting blended image.
		byte [] Blended = new byte [vbWidth * vbHeight * (vbDepth / 8)];

		// 256-color bitmap containing variable opacity values.
		byte [] OpacityMap = new byte [vbWidth * vbHeight];

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Name = "Form1";
			this.Text = "Alpha Blending Demo";
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			switch (e.KeyCode)
			{
				// Display foreground image.
				case Keys.F1:
					fg.move(0, vbHeight-1);
					fg.putdcb(ref Foreground[0], vbWidth, vbHeight);
					fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
					Text = "Alpha Blending: Foreground Image";
					break;

				// Display background image.
				case Keys.F2:
					fg.move(0, vbHeight-1);
					fg.putdcb(ref Background[0], vbWidth, vbHeight);
					fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
					Text = "Alpha Blending: Background Image";
					break;

				// Display blended image with constant 50% foreground opacity.
				case Keys.F3:
					this.Cursor = Cursors.WaitCursor;
					fg.opacity(128);
					fg.blenddcb(ref Foreground[0], ref Background[0], ref Blended[0], vbWidth*vbHeight);
					fg.move(0, vbHeight-1);
					fg.putdcb(ref Blended[0], vbWidth, vbHeight);
					fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
					Text = "Alpha Blending: 50% Blended Image";
					this.Cursor = Cursors.Default;
					break;

				// Display blended image with variable foreground opacity.
				case Keys.F4:
					this.Cursor = Cursors.WaitCursor;
					fg.blendvar(ref Foreground[0], ref Background[0], ref OpacityMap[0], ref Blended[0], vbWidth*vbHeight);
					fg.move(0, vbHeight-1);
					fg.putdcb(ref Blended[0], vbWidth, vbHeight);
					fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
					Text = "Alpha Blending: Variable Blended Image";
					this.Cursor = Cursors.Default;
					break;
			}
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			fg.vbdepth(vbDepth);
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();

			// Get background image from the CAT.BMP file.
			fg.showbmp("..\\CAT.BMP", 0);
			fg.move(0, vbHeight-1);
			fg.getdcb(ref Background[0], vbWidth, vbHeight);

			// Get foreground image from the PORCH.BMP file.
			fg.showbmp("..\\PORCH.BMP", 0);
			fg.move(0, vbHeight-1);
			fg.getdcb(ref Foreground[0], vbWidth, vbHeight);

			// Calcluate variable opacity bitmap.
			MakeOpacityBitmap();
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		/****************************************************************************\
		*                                                                            *
		*  MakeOpacityBitmap()                                                       *
		*                                                                            *
		*  Define a 256-color bitmap with varying opacity values. The foregound      *
		*  opacities will be zero at the image center and will gradually increase    *
		*  as we move farther from the center.                                       *
		*                                                                            *
		\****************************************************************************/

		private void MakeOpacityBitmap()
		{
			int i, x, y;
			int OpacityValue;
			int yTerm;

			i = 0;

			for (y = 0; y < vbHeight; y++)
			{
				yTerm = Math.Abs(y - vbHeight/2);
				for (x = 0; x < vbWidth; x++)
				{
					OpacityValue = Math.Abs(x - vbWidth/2) + yTerm;
					if (OpacityValue > 255)
						OpacityMap[i++] = 255;
					else
						OpacityMap[i++] = (byte)OpacityValue;
				}
			}
		}
	}
}
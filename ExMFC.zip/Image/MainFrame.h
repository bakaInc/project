// MainFrame.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRAME_H__CBDE14E8_829E_11D2_8EBF_204C4F4F5020__INCLUDED_)
#define AFX_MAINFRAME_H__CBDE14E8_829E_11D2_8EBF_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ChildView.h"

class CMainFrame : public CFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

//Attributes
protected:
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnUpdateFrameTitle(BOOL bAddToTitle);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
	void EnableItem(UINT nID, UINT nEnable);
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CChildView m_wndView;
// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void BMPOpenClick();
	afx_msg void BMPMakeClick();
	afx_msg void BMPDetailsClick();
	afx_msg void PCXOpenClick();
	afx_msg void PCXMakeClick();
	afx_msg void PCXDetailsClick();
	afx_msg void JPEGOpenClick();
	afx_msg void JPEGDetailsClick();
	afx_msg void FlicOpenClick();
	afx_msg void FlicPlayClick();
	afx_msg void FlicFrameClick();
	afx_msg void FlicResetClick();
	afx_msg void FlicDetailsClick();
	afx_msg void AVIOpenClick();
	afx_msg void AVIPlayClick();
	afx_msg void AVIFrameClick();
	afx_msg void AVIResetClick();
	afx_msg void AVIDetailsClick();
	afx_msg void ExitClick();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRAME_H__CBDE14E8_829E_11D2_8EBF_204C4F4F5020__INCLUDED_)

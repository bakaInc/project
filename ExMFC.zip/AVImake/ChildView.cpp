// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "AVImake.h"

#include "ChildView.h"
#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
	m_cxBuffer = 32;
	m_cyBuffer = 32;
}

CChildView::~CChildView()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BEGIN_MESSAGE_MAP(CChildView, CWnd)
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_COMMAND(IDM_Convert, ConvertClick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

BOOL CChildView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL bRet = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		m_hVB = fg_vballoc(m_cxBuffer,m_cyBuffer);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		fg_setcolor(-1);
		fg_fillpage();
	}
	return bRet;
}

void CChildView::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CChildView::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CChildView::OnSetFocus(CWnd* pOldWnd)
{
	CWnd::OnSetFocus(pOldWnd);
	fg_realize(m_hPal);
	Invalidate();
}

void CChildView::ConvertClick() 
{
	CString FileName;
	BYTE FileHeader[128];
	BYTE ContextFlic[16];
	BYTE ContextAVI[24];
	BYTE *Bitmap;

	// open the flic file to convert
	CFileDialog dlg(TRUE,"fli",NULL,OFN_READONLY,
		"flic files (*.fli,*.flc)|*.FLI;*.FLC||",this);
	if (dlg.DoModal() != IDOK) return;
	FileName = dlg.GetPathName();

	// make sure it really is a flic file, and if so, open it
	if (fg_flichead((LPSTR)((LPCSTR)FileName),FileHeader) < 0)
	{
		CString mbString = FileName + " is not an FLI or FLC file.";
		MessageBox(mbString,"Error",MB_ICONSTOP|MB_OK);
		return;
	}
	fg_flicsize(FileHeader,&m_cxBuffer,&m_cyBuffer);
	SwitchBuffers();
	fg_flicopen((LPSTR)((LPCSTR)FileName),ContextFlic);

	// display the first flic frame
	fg_flicplay(ContextFlic,1,FG_NODELAY);
	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);

	// create an empty AVI file with the same name as the flic file,
	// but with an .avi extension
	lstrcpy(strrchr((LPSTR)((LPCSTR)FileName),'.'),".avi");
	if (fg_avimake((LPSTR)((LPCSTR)FileName),ContextAVI,-1,m_cxBuffer,m_cyBuffer,8,10000,30) < 0)
	{
		CString mbString = "Cannot create AVI file\n" + FileName;
		MessageBox(mbString,"Error",MB_ICONSTOP|MB_OK);
		return;
	}

	// create a 256-color bitmap whose size is equal to the flic resolution
	Bitmap = new BYTE[fg_imagesiz(m_cxBuffer,m_cyBuffer)];

	// create the AVI file frame by frame
	CWaitCursor wait;
	fg_move(0,m_cyBuffer-1);
	do
	{
		fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
		fg_getimage(Bitmap,m_cxBuffer,m_cyBuffer);
		fg_aviframe(ContextAVI,Bitmap);
	}
	while (fg_flicplay(ContextFlic,1,FG_NODELAY) == 1);

	// close the flic and AVI files, and release the bitmap memory
	fg_flicdone(ContextFlic);
	fg_avidone(ContextAVI);
	delete [] Bitmap;
}

/****************************************************************************\
*                                                                            *
*  SwitchBuffers()                                                           *
*                                                                            *
*  Close the and release the virtual buffers for the current image, then     *
*  create and open new virtual buffers for the new image file.               *
*                                                                            *
\****************************************************************************/

void CChildView::SwitchBuffers()
{
	fg_vbclose();
	fg_vbfree(m_hVB);
	m_hVB = fg_vballoc(m_cxBuffer,m_cyBuffer);
	fg_vbopen(m_hVB);
	fg_vbcolors();
}

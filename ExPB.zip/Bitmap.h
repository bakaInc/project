//---------------------
// Bitmap.h header file
//---------------------

#define IDM_Drwimage 1
#define IDM_Clpimage 2
#define IDM_Revimage 3
#define IDM_Flpimage 4
#define IDM_Putimage 5
#define IDM_Exit     6

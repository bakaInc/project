/****************************************************************************\
*                                                                            *
*  PCXflip.cpp                                                               *
*                                                                            *
*  This program displays a 320x200 PCX file mirrored about the y-axis using  *
*  the bitmap display routines.                                              *
*                                                                            *
\****************************************************************************/

// PCXflip.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "PCXflip.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPCXflipApp

BEGIN_MESSAGE_MAP(CPCXflipApp, CWinApp)
	//{{AFX_MSG_MAP(CPCXflipApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPCXflipApp construction

CPCXflipApp::CPCXflipApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CPCXflipApp object

CPCXflipApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CPCXflipApp initialization

BOOL CPCXflipApp::InitInstance()
{
	// Standard initialization

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	m_pMainWnd = NULL;
	CMainFrame* pFrame = new CMainFrame;

	if (!pFrame->Create(NULL,"Bitmap Flipping Demo"))
		return FALSE;

	m_pMainWnd = pFrame;
	pFrame->ShowWindow(m_nCmdShow);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CPCXflipApp message handlers

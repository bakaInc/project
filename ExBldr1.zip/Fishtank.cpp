/****************************************************************************\
*                                                                            *
*  Fishtank.cpp                                                              *
*  FishtankU.cpp                                                             *
*                                                                            *
*  This program shows how to perform simple animation using Fastgraph for    *
*  Windows. Several types of tropical fish swim back and forth against a     *
*  coral reef background. The background image and fish sprites are stored   *
*  in PCX files.                                                             *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("FishtankU.cpp", Form1);
USERES("Fishtank.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

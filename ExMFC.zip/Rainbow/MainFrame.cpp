// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Rainbow.h"

#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BYTE RGBvalues[2*24*3];    // two sets of 24 RGB triplets

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
	m_nStart = 0;
	m_nTimerID = 0;
}

CMainFrame::~CMainFrame()
{
	if (m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.style = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	int xLen, yLen;
	int nColor;

	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
		// create the logical palette
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		FillColorPalette();
		m_hPal = fg_logpal(10,24,RGBvalues);
		fg_realize(m_hPal);

		// create a 640x480 virtual buffer
		fg_vbinit();
		m_hVB = fg_vballoc(640,480);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		// construct a crude image of a rainbow
		fg_setcolor(255);
		fg_fillpage();
		fg_setclip(0,639,0,300);
		fg_move(320,300);
		xLen = 240;
		yLen = 120;
		for (nColor = 10; nColor < 34; nColor++)
		{
			fg_setcolor(nColor);
			fg_ellipsef(xLen,yLen);
			xLen -= 4;
			yLen -= 3;
		}
		fg_setcolor(255);
		fg_ellipsef(xLen,yLen);
		fg_setclip(0,639,0,479);

		// start the 50ms timer
		m_nTimerID = SetTimer(1,50,NULL);
	}
	return bRet;
}

void CMainFrame::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,fg_getmaxx(),0,fg_getmaxy(),0,m_cxClient-1,0,m_cyClient-1);
}

void CMainFrame::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

void CMainFrame::OnTimer(UINT nIDEvent) 
{
	CFrameWnd::OnTimer(nIDEvent);

	m_nStart = (m_nStart + 3) % 72;
	fg_setdacs(10,24,&RGBvalues[m_nStart]);
	if (fg_colors() > 8)
		fg_vbscale(0,fg_getmaxx(),0,fg_getmaxy(),0,m_cxClient-1,0,m_cyClient-1);
}

/****************************************************************************\
*                                                                            *
*  FillColorPalette()                                                        *
*                                                                            *
*  Set up the colors for the application's logical palette in the RGBvalues  *
*  array. The logical palette will contain 24 non-system colors (indices 10  *
*  to 33) defining the initial RGB values for the colors being cycled.       *
*                                                                            *
*  Note that we store two identical sets of 24 RGB triplets in RGBvalues. We *
*  can then perform color cycling without having to worry about wrapping to  *
*  the start of the array because the index pointing to the starting RGB     *
*  triplet never extends beyond the first set of 24 RGB triplets.            *
*                                                                            *
\****************************************************************************/

void CMainFrame::FillColorPalette()
{
	static BYTE Colors[] = {
		182,182,255, 198,182,255, 218,182,255, 234,182,255, 255,182,255,
		255,182,234, 255,182,218, 255,182,198, 255,182,182, 255,198,182,
		255,218,182, 255,234,182, 255,255,182, 234,255,182, 218,255,182,
		198,255,182, 182,255,182, 182,255,198, 182,255,218, 182,255,234,
		182,255,255, 182,234,255, 182,218,255, 182,198,255};

	// set up two identical sets of the 24 colors in the RGBvalues array
	memcpy(RGBvalues,Colors,24*3);
	memcpy(&RGBvalues[24*3],Colors,24*3);
}

/****************************************************************************\
'                                                                            *
'  Cube.cs                                                                   *
'                                                                            *
'  This program draws a cube in 3D world space and allows the user to move   *
'  and rotate the cube through keyboard controls. Each of the six cube faces *
'  is a different color.                                                     *
'                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Cube
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		const int vbWidth = 640;
		const int vbHeight = 480;

		// Application variables.
		int vbDepth;
		bool Redraw;
		int xAngle, yAngle, zAngle;
		double xWorld, yWorld, zWorld;

		// Colors of the six cube faces.
		int [] Colors = {84, 88, 92, 96, 100, 104};

		// Six faces of a 40x40x40 cube, defined in object coordinates.
		double [,] Faces = {
			{ 20.0,-20.0,-20.0, -20.0,-20.0,-20.0, -20.0, 20.0,-20.0,  20.0, 20.0,-20.0},
			{-20.0,-20.0,-20.0, -20.0,-20.0, 20.0, -20.0, 20.0, 20.0, -20.0, 20.0,-20.0},
			{ 20.0, 20.0, 20.0, -20.0, 20.0, 20.0, -20.0,-20.0, 20.0,  20.0,-20.0, 20.0},
			{ 20.0,-20.0, 20.0,  20.0,-20.0,-20.0,  20.0, 20.0,-20.0,  20.0, 20.0, 20.0},
			{ 20.0,-20.0, 20.0, -20.0,-20.0, 20.0, -20.0,-20.0,-20.0,  20.0,-20.0,-20.0},
			{ 20.0, 20.0,-20.0, -20.0, 20.0,-20.0, -20.0, 20.0, 20.0,  20.0, 20.0, 20.0}};

		// Component declarations.
		private System.Windows.Forms.Timer timer1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			// 
			// timer1
			// 
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(640, 480);
			this.Name = "Form1";
			this.Text = "Single 3D Cube";
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Closed += new System.EventHandler(this.Form1_Closed);
		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			vbDepth = fg.colors();
			fg.vbdepth(vbDepth);
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();
			fg.setcolor(-1);
			fg.fillpage();

			fg._3Dviewport(0, vbWidth-1, 0, vbHeight-1, 0.5);
			fg._3Drenderstate(fg.ZCLIP);
			xAngle = 0;
			yAngle = 0;
			zAngle = 0;
			xWorld = 0.0;
			yWorld = 0.0;
			zWorld = 100.0;
			Redraw = true;
			timer1.Enabled = true;
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			CheckForMovement();
		}

		/****************************************************************************\
		*                                                                            *
		*  CheckForMovement()                                                        *
		*                                                                            *
		*  The CheckForMovement() function checks for key presses that control the   *
		*  cube's movement, and if required redraws the cube at its new position and *
		*  orientation. It is called every 10ms from the timer's OnTick event        *
		*  handler.                                                                  *
		*                                                                            *
		\****************************************************************************/

		private void CheckForMovement()
		{
			bool ShiftKey;

			// Check if either shift key is pressed.
			ShiftKey = (fg.kbtest(42) == 1) || (fg.kbtest(54) == 1);

			// + and - move cube along the z axis (+ is toward viewer, - is
			// away from viewer).
			if (fg.kbtest(74) == 1)
			{
				zWorld += 3.0;
				Redraw = true;
			}
			else if (fg.kbtest(78) == 1)
			{
				zWorld -= 3.0;
				Redraw = true;
			}

			// Left and right arrow keys move cube along x axis.
			else if (fg.kbtest(75) == 1)
			{
				xWorld -= 3.0;
				Redraw = true;
			}
			else if (fg.kbtest(77) == 1)
			{
				xWorld += 3.0;
				Redraw = true;
			}

			// Up and down arrow keys move cube along y axis.
			else if (fg.kbtest(72) == 1)
			{
				yWorld += 3.0;
				Redraw = true;
			}
			else if (fg.kbtest(80) == 1)
			{
				yWorld -= 3.0;
				Redraw = true;
			}

			// x rotates counterclockwise around x axis, X rotates clockwise.
			else if (fg.kbtest(45) == 1)
			{
				if (ShiftKey)
				{
					xAngle += 6;
					if (xAngle >= 360) xAngle -= 360;
				}
				else
				{
					xAngle -= 6;
					if (xAngle < 0) xAngle += 360;
				}
				Redraw = true;
			}

			// y rotates counterclockwise around y axis, Y rotates clockwise.
			else if (fg.kbtest(21) == 1)
			{
				if (ShiftKey)
				{
					yAngle += 6;
					if (yAngle >= 360) yAngle -= 360;
				}
				else
				{
					yAngle -= 6;
					if (yAngle < 0) yAngle += 360;
				}
				Redraw = true;
			}

			// z rotates counterclockwise around z axis, Z rotates clockwise.
			else if (fg.kbtest(44) == 1)
			{
				if (ShiftKey)
				{
					zAngle += 6;
					if (zAngle >= 360) zAngle -= 360;
				}
				else
				{
					zAngle -= 6;
					if (zAngle < 0) zAngle += 360;
				}
				Redraw = true;
			}

			// If the cube's position or orientation changed, redraw the cube.
			if (Redraw)
			{
				// Erase the previous frame from the virtual buffer.
				fg.setcolor(-1);
				fg.fillpage();

				// Define the cube's new position and rotation in 3D world space.
				fg._3Dsetobject(xWorld, yWorld, zWorld, xAngle*10, yAngle*10, zAngle*10);

				// Draw the cube.
				DrawCube();

				// Display what we just drew.
				fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
				Redraw = false;
			}
		}

		/****************************************************************************\
		*                                                                            *
		*  DrawCube()                                                                *
		*                                                                            *
		*  Draws each of the six cube faces in 3D world space.                       *
		*                                                                            *
		\****************************************************************************/

		private void DrawCube()
		{
			int i;
			int r, g, b;

			for (i = 0; i < 6; i++)
			{
				if (vbDepth > 8)
				{
					fg.getrgb(Colors[i], out r, out g, out b);
					fg.setcolorrgb(r, g, b);
				}
				else
				{
					fg.setcolor(Colors[i]);
				}
				fg._3Dpolygonobject(ref Faces[i,0], 4);
			}
		}
	}
}
// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "FrameDD.h"

#include "MainFrame.h"

// define either BLIT or FLIP, but not both, for blitting or flipping
#define BLIT
//#define FLIP

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_KEYDOWN()
	ON_WM_SETFOCUS()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_WM_ACTIVATEAPP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_bAppIsActive = FALSE;
}

CMainFrame::~CMainFrame()
{
	fg_mousevis(1);
	if (m_hVB >= 0)
	{
		fg_vbclose();
#ifdef BLIT
		fg_vbfree(m_hVB);
#endif
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.x = 0;
	cs.y = 0;
	cs.cx = vbWidth;
	cs.cy = vbHeight;
	cs.style = WS_POPUP;
	cs.dwExStyle = WS_EX_TOPMOST;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	if (bRet)
	{
#ifdef BLIT
		fg_ddsetup(vbWidth,vbHeight,8,FG_DX_BLIT);
#else
		fg_ddsetup(vbWidth,vbHeight,8,FG_DX_FLIP);
#endif
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);
		ShowWindow(SW_SHOWNORMAL);

		// if blitting, create a virtual buffer the same size as the screen
		// resolution; if flipping, use the primary surface's back buffer
		fg_vbinit();
#ifdef BLIT
		m_hVB = fg_vballoc(vbWidth,vbHeight);
#else
		m_hVB = 0;
#endif
		fg_vbopen(m_hVB);
		fg_vbcolors();

		fg_mouseini();
		fg_mousevis(0);
	}
	return bRet;
}

void CMainFrame::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CFrameWnd::OnKeyDown(nChar, nRepCnt, nFlags);
	if ((nChar == VK_ESCAPE) || (nChar == VK_F12))
		PostMessage(WM_CLOSE);
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
	fg_realize(m_hPal);
	Invalidate();
	return TRUE;
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
	if ((pFocusWnd != this) && (!IsChild(pFocusWnd)))
		OnQueryNewPalette();
}

void CMainFrame::OnActivateApp(BOOL bActive, HTASK hTask)
{
	CFrameWnd::OnActivateApp(bActive, hTask);
	m_bAppIsActive = bActive;
   if (m_bAppIsActive) fg_ddrestore();
}

/****************************************************************************\
*                                                                            *
*  Animate()                                                                 *
*                                                                            *
*  Construct the next frame of animation and display it with either blitting *
*  or flipping, as directed by the BLIT and FLIP symbols above.              *
*                                                                            *
\****************************************************************************/

void CMainFrame::Animate()
{
	if (m_bAppIsActive)
	{
		// fill drawing surface with the next color
		fg_setcolor((fg_getcolor() + 1) & 0xFF);
		fg_fillpage();

		// blit or flip surface to the screen
#ifdef BLIT
		fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,vbWidth-1,0,vbHeight-1);
#else
		fg_ddflip();
#endif
	}
}

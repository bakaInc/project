//---------------------------------------------------------------------------
#ifndef MonomapUH
#define MonomapUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Menus.hpp>
#include <FGwin.h>

#define vbWidth  320
#define vbHeight 200
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   TMainMenu *MainMenu1;
   TMenuItem *Drawmap;
   TMenuItem *Clipmap;
   TMenuItem *Exit;
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
   void __fastcall DrawmapClick(TObject *Sender);
   void __fastcall ClipmapClick(TObject *Sender);
   void __fastcall ExitClick(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   UINT cxClient, cyClient;
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
byte Hello[] = {
   0x00,0x00,0x00,0x00,0x00,
   0xCC,0x78,0x78,0x78,0x78,
   0xCC,0xC0,0x30,0x30,0xCC,
   0xCC,0xFC,0x30,0x30,0xCC,
   0xFC,0xCC,0x30,0x30,0xCC,
   0xCC,0x78,0x30,0x30,0x78,
   0xCC,0x00,0x30,0x30,0x00,
   0xCC,0x00,0x70,0x70,0x00};
//---------------------------------------------------------------------------
#endif

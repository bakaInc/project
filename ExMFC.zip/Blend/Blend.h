// Blend.h : main header file for the BLEND application
//
#if !defined(AFX_BLEND_H__472A9973_7A9B_11D3_9018_204C4F4F5020__INCLUDED_)
#define AFX_BLEND_H__472A9973_7A9B_11D3_9018_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CBlendApp:
// See Blend.cpp for the implementation of this class
//

class CBlendApp : public CWinApp
{
public:
	CBlendApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBlendApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

public:
	//{{AFX_MSG(CBlendApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BLEND_H__472A9973_7A9B_11D3_9018_204C4F4F5020__INCLUDED_)

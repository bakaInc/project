/****************************************************************************\
*                                                                            *
*  GDIdemo.cpp                                                               *
*  GDIdemoU.cpp                                                              *
*                                                                            *
*  This program shows how to use Windows GDI functions to write to a virtual *
*  buffer. It uses GDI functions to display a cross-hatched rectangle with a *
*  border, something that would require construction from several graphics   *
*  primitives if using Fastgraph for Windows drawing functions only.         *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "GDIDemoU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   HBRUSH hBrush;
   HDC    hDIB;
   HPEN   hPen;

   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(320,240);
   fg_vbopen(hVB);
   fg_vbcolors();

   // use FG to fill the virtual buffer with light green pixels
   fg_setcolor(20);
   fg_fillpage();

   // use Windows GDI functions to display a cross-hatched
   // rectangle with blue border in the virtual buffer
   hDIB = fg_getdc();
   hPen = CreatePen(PS_SOLID,3,RGB(0,0,255));
   hBrush = CreateHatchBrush(HS_DIAGCROSS,RGB(255,0,0));
   SelectObject(hDIB,hPen);
   SelectObject(hDIB,hBrush);
   Rectangle(hDIB,20,20,50,50);
   DeleteObject(hPen);
   DeleteObject(hBrush);

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbscale(0,fg_getmaxx(),0,fg_getmaxy(),0,cxClient-1,0,cyClient-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
   cxClient = ClientWidth;
   cyClient = ClientHeight;
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
}
//---------------------------------------------------------------------------

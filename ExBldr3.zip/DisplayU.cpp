/****************************************************************************\
*                                                                            *
*  Display.cpp                                                               *
*  DisplayU.cpp                                                              *
*                                                                            *
*  This program resizes the desktop to 800x600 using the fg_modeset()        *
*  function.                                                                 *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop

#include "DisplayU.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
   fg_realize(hPal);
   Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
   if (fg_modetest(vbWidth,vbHeight,fg_colors()) != 0)
   {
      MessageDlg("Cannot set 800x600 desktop",mtError,TMsgDlgButtons()<<mbOK,0);
      Application->Terminate();
      return;
   }
   Visible = True;
   fg_modeset(vbWidth,vbHeight,fg_colors(),1);
   WindowState = wsMaximized;

   hDC = GetDC(Form1->Handle);
   fg_setdc(hDC);
   hPal = fg_defpal();
   fg_realize(hPal);

   fg_vbinit();
   hVB = fg_vballoc(vbWidth,vbHeight);
   fg_vbopen(hVB);
   fg_vbcolors();

   fg_setcolor(19);
   fg_fillpage();

   Application->OnActivate = OnActivate;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{
   if (Key == VK_ESCAPE || Key == VK_F12) Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
   fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
   fg_vbclose();
   fg_vbfree(hVB);
   fg_vbfin();
   fg_modeset(0,0,0,0);
   DeleteObject(hPal);
   ReleaseDC(Form1->Handle,hDC);
   Application->Minimize();
}
//---------------------------------------------------------------------------

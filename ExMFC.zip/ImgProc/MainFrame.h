// MainFrame.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRAME_H__35DE8497_954A_11D3_904F_204C4F4F5020__INCLUDED_)
#define AFX_MAINFRAME_H__35DE8497_954A_11D3_904F_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ChildView.h"

class CMainFrame : public CFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

//Attributes
protected:
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnUpdateFrameTitle(BOOL bAddToTitle);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
	void EnableItem(UINT nID, UINT nEnable);
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CChildView m_wndView;
// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void FileOpenClick();
	afx_msg void FileSaveAsClick();
	afx_msg void FileDetailsClick();
	afx_msg void FileExitClick();
	afx_msg void EditUndoClick();
	afx_msg void EditRestoreOriginalClick();
	afx_msg void EditContrastEnhancementClick();
	afx_msg void EditGammaCorrectionClick();
	afx_msg void EditGrayscaleClick();
	afx_msg void EditPhotoInversionClick();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRAME_H__35DE8497_954A_11D3_904F_204C4F4F5020__INCLUDED_)

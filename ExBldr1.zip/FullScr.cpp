/****************************************************************************\
*                                                                            *
*  FullScr.cpp                                                               *
*  FullScrU.cpp                                                              *
*                                                                            *
*  This is a version of the first Fastgraph for Windows example program      *
*  modified for use as a DirectDraw full screen application.                 *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("FullScrU.cpp", Form1);
USERES("FullScr.res");
USELIB("FGWBC32D.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

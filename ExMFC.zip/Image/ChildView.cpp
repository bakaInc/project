// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "Image.h"

#include "ChildView.h"
#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
	m_cxBuffer = 32;
	m_cyBuffer = 32;
	m_nColors = 0;
	m_nFrames = 0;
	m_LoadedFlic = FALSE;
	m_LoadedAVI = FALSE;
}

CChildView::~CChildView()
{
	CloseContext();
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BEGIN_MESSAGE_MAP(CChildView, CWnd)
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

BOOL CChildView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL bRet = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		m_hVB = fg_vballoc(m_cxBuffer,m_cyBuffer);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		fg_setcolor(-1);
		fg_fillpage();
	}
	return bRet;
}

void CChildView::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CChildView::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CChildView::OnSetFocus(CWnd* pOldWnd)
{
	CWnd::OnSetFocus(pOldWnd);
	fg_realize(m_hPal);
	Invalidate();
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the BMP menu.                             *
*                                                                            *
\****************************************************************************/

BOOL CChildView::BMPOpenClick()
{
	CFileDialog dlg(TRUE,"bmp",NULL,OFN_READONLY,
		"BMP files (*.bmp)|*.BMP||",this);
	if (dlg.DoModal() != IDOK) return FALSE;
	m_FileName = dlg.GetPathName();

	if (fg_bmphead((LPSTR)((LPCSTR)m_FileName),m_FileHeader) < 0)
	{
		CString mbString = m_FileName + "\nis not a BMP file.";
		MessageBox(mbString,"Error",MB_ICONSTOP|MB_OK);
		return FALSE;
	}

	CWaitCursor wait;
	m_nColors = fg_bmppal((LPSTR)((LPCSTR)m_FileName),NULL);
	fg_bmpsize(m_FileHeader,&m_cxBuffer,&m_cyBuffer);
	SwitchBuffers();
	fg_showbmp((LPSTR)((LPCSTR)m_FileName),0);
	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
	return TRUE;
}

void CChildView::BMPMakeClick()
{
	int nColorDepth;

	CFileDialog dlg(FALSE,"bmp",m_FileName,
		OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST,
		"BMP files (*.bmp)|*.BMP||",this);
	if (dlg.DoModal() != IDOK) return;
	m_FileName = dlg.GetPathName();

	if (m_nColors == 0)
		nColorDepth = 24;
	else if (m_nColors == 256)
		nColorDepth = 8;
	else if (m_nColors == 16)
		nColorDepth = 4;
	else
		nColorDepth = 1;

	CWaitCursor wait;
	fg_makebmp(0,m_cxBuffer-1,0,m_cyBuffer-1,nColorDepth,(LPSTR)((LPCSTR)m_FileName));
}

void CChildView::BMPDetailsClick()
{
	CString mbString;

	mbString = m_FileName + "\n" +
		IntToStr(m_cxBuffer) + "x" + IntToStr(m_cyBuffer) + " pixels\n";
	if (m_nColors > 0)
		mbString += IntToStr(m_nColors) + " colors";
	else
		mbString += "24-bit RGB";
	MessageBox(mbString,"Information",MB_ICONINFORMATION|MB_OK);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the PCX menu.                             *
*                                                                            *
\****************************************************************************/

BOOL CChildView::PCXOpenClick()
{
	CFileDialog dlg(TRUE,"pcx",NULL,OFN_READONLY,
		"PCX files (*.pcx)|*.PCX||",this);
	if (dlg.DoModal() != IDOK) return FALSE;
	m_FileName = dlg.GetPathName();

	if (fg_pcxhead((LPSTR)((LPCSTR)m_FileName),m_FileHeader) < 0)
	{
		CString mbString = m_FileName + "\nis not a PCX file.";
		MessageBox(mbString,"Error",MB_ICONSTOP|MB_OK);
		return FALSE;
	}

	CWaitCursor wait;
	m_nColors = fg_pcxpal((LPSTR)((LPCSTR)m_FileName),NULL);
	fg_pcxsize(m_FileHeader,&m_cxBuffer,&m_cyBuffer);
	SwitchBuffers();
	fg_move(0,0);
	fg_showpcx((LPSTR)((LPCSTR)m_FileName),FG_AT_XY);
	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
	return TRUE;
}

void CChildView::PCXMakeClick()
{
	CFileDialog dlg(FALSE,"pcx",m_FileName,
		OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST,
		"PCX files (*.pcx)|*.PCX||",this);
	if (dlg.DoModal() != IDOK) return;
	m_FileName = dlg.GetPathName();

	CWaitCursor wait;
	fg_makepcx(0,m_cxBuffer-1,0,m_cyBuffer-1,(LPSTR)((LPCSTR)m_FileName));
}

void CChildView::PCXDetailsClick()
{
	CString mbString;

	mbString = m_FileName + "\n" +
		IntToStr(m_cxBuffer) + "x" + IntToStr(m_cyBuffer) + " pixels\n";
	if (m_nColors > 0)
		mbString += IntToStr(m_nColors) + " colors";
	else
		mbString += "24-bit RGB";
	MessageBox(mbString,"Information",MB_ICONINFORMATION|MB_OK);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the JPEG menu.                            *
*                                                                            *
\****************************************************************************/

BOOL CChildView::JPEGOpenClick()
{
	CFileDialog dlg(TRUE,"jpg",NULL,OFN_READONLY,
		"JPEG files (*.jpg)|*.JPG||",this);
	if (dlg.DoModal() != IDOK) return FALSE;
	m_FileName = dlg.GetPathName();

	if (fg_jpeghead((LPSTR)((LPCSTR)m_FileName),m_FileHeader) < 0)
	{
		CString mbString = m_FileName + "\nis not a baseline JPEG file.";
		MessageBox(mbString,"Error",MB_ICONSTOP|MB_OK);
		return FALSE;
	}
	m_nColors = 0;

	CWaitCursor wait;
	fg_jpegsize(m_FileHeader,&m_cxBuffer,&m_cyBuffer);
	SwitchBuffers();
	fg_showjpeg((LPSTR)((LPCSTR)m_FileName),0);
	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
	return TRUE;
}

void CChildView::JPEGDetailsClick()
{
	CString mbString = m_FileName + "\n" +
		IntToStr(m_cxBuffer) + "x" + IntToStr(m_cyBuffer) + " pixels\n" +
		"24-bit RGB";
	MessageBox(mbString,"Information",MB_ICONINFORMATION|MB_OK);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the FLI/FLC menu.                         *
*                                                                            *
\****************************************************************************/

BOOL CChildView::FlicOpenClick()
{
	CFileDialog dlg(TRUE,"fli",NULL,OFN_READONLY,
		"flic files (*.fli,*.flc)|*.FLI;*.FLC||",this);
	if (dlg.DoModal() != IDOK) return FALSE;
	m_FileName = dlg.GetPathName();

	if (fg_flichead((LPSTR)((LPCSTR)m_FileName),m_FileHeader) < 0)
	{
		CString mbString = m_FileName + "\nis not an FLI or FLC file.";
		MessageBox(mbString,"Error",MB_ICONSTOP|MB_OK);
		return FALSE;
	}
	m_nColors = 256;
	fg_flicsize(m_FileHeader,&m_cxBuffer,&m_cyBuffer);
	SwitchBuffers();
	fg_flicopen((LPSTR)((LPCSTR)m_FileName),m_Context);
	fg_flicplay(m_Context,1,FG_NODELAY);
	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
	memcpy(&m_nFrames,&m_FileHeader[6],2);
	m_LoadedFlic = TRUE;
	return TRUE;
}

void CChildView::FlicPlayClick()
{
	CWaitCursor wait;
	fg_showflic((LPSTR)((LPCSTR)m_FileName),0,FG_NODELAY);
	fg_flicskip(m_Context,-1);
}

void CChildView::FlicFrameClick()
{
	if (fg_flicplay(m_Context,1,FG_NODELAY) == 0)
	{
		fg_flicskip(m_Context,-1);
		fg_flicplay(m_Context,1,FG_NODELAY);
	}
	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CChildView::FlicResetClick()
{
	fg_flicskip(m_Context,-1);
	fg_flicplay(m_Context,1,FG_NODELAY);
	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CChildView::FlicDetailsClick()
{
	CString mbString = m_FileName + "\n" +
		IntToStr(m_cxBuffer) + "x" + IntToStr(m_cyBuffer) + " pixels\n" +
		IntToStr(m_nFrames) + " frames";
	MessageBox(mbString,"Information",MB_ICONINFORMATION|MB_OK);
}

/****************************************************************************\
*                                                                            *
*  Event handlers for the items on the AVI menu.                             *
*                                                                            *
\****************************************************************************/

BOOL CChildView::AVIOpenClick()
{
	CFileDialog dlg(TRUE,"avi",NULL,OFN_READONLY,
		"AVI files (*.avi)|*.AVI||",this);
	if (dlg.DoModal() != IDOK) return FALSE;
	m_FileName = dlg.GetPathName();

	if (fg_avihead((LPSTR)((LPCSTR)m_FileName),m_FileHeader) < 0)
	{
		CString mbString = m_FileName + "\nis not an AVI file.";
		MessageBox(mbString,"Error",MB_ICONSTOP|MB_OK);
		return FALSE;
	}
	m_nColors = fg_avipal((LPSTR)((LPCSTR)m_FileName),NULL);
	fg_avisize(m_FileHeader,&m_cxBuffer,&m_cyBuffer);
	SwitchBuffers();
	if (fg_aviopen((LPSTR)((LPCSTR)m_FileName),m_Context) < 0)
	{
		CString mbString = "Cannot play AVI file\n" + m_FileName + ".";
		MessageBox(mbString,"Error",MB_ICONSTOP|MB_OK);
		return FALSE;
	}
	fg_aviplay(m_Context,1,FG_NODELAY);
	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
	m_LoadedAVI = TRUE;
	return TRUE;
}

void CChildView::AVIPlayClick()
{
	CWaitCursor wait;
	fg_showavi((LPSTR)((LPCSTR)m_FileName),0,FG_NODELAY);
	fg_aviskip(m_Context,-1);
}

void CChildView::AVIFrameClick()
{
	if (fg_aviplay(m_Context,1,FG_NODELAY) == 0)
	{
		fg_aviskip(m_Context,-1);
		fg_aviplay(m_Context,1,FG_NODELAY);
	}
	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CChildView::AVIResetClick()
{
	fg_aviskip(m_Context,-1);
	fg_aviplay(m_Context,1,FG_NODELAY);
	fg_vbscale(0,m_cxBuffer-1,0,m_cyBuffer-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CChildView::AVIDetailsClick()
{
	CString mbString;

	mbString = m_FileName + "\n" +
		IntToStr(m_cxBuffer) + "x" + IntToStr(m_cyBuffer) + " pixels\n";
	if (m_nColors > 0)
		mbString += IntToStr(m_nColors) + " colors";
	else
		mbString += "24-bit RGB";
	MessageBox(mbString,"Information",MB_ICONINFORMATION|MB_OK);
}

/****************************************************************************\
*                                                                            *
*  CloseContext()                                                            *
*                                                                            *
*  Closes the active flic or AVI context. This function is called from       *
*  SwitchBuffers() and also from the CChildView destructor.                  *
*                                                                            *
\****************************************************************************/

void CChildView::CloseContext()
{
	if (m_LoadedFlic)
	{
		fg_flicdone(m_Context);
		m_LoadedFlic = FALSE;
	}
	else if (m_LoadedAVI)
	{
		fg_avidone(m_Context);
		m_LoadedAVI = FALSE;
	}
}

/****************************************************************************\
*                                                                            *
*  IntToStr()                                                                *
*                                                                            *
*  Convert an integer quantity to a CString string.                          *
*                                                                            *
\****************************************************************************/

CString CChildView::IntToStr(int n)
{
	CString Result;

	Result.Format("%d",n);
	return Result;
}

/****************************************************************************\
*                                                                            *
*  SwitchBuffers()                                                           *
*                                                                            *
*  Close the and release the active virtual buffer, then create and open a   *
*  new virtual buffer to hold the new image file.                            *
*                                                                            *
\****************************************************************************/

void CChildView::SwitchBuffers()
{
	CloseContext();
	fg_vbclose();
	fg_vbfree(m_hVB);
	if (m_nColors == 0)
		fg_vbdepth(24);
	else
		fg_vbdepth(8);
	m_hVB = fg_vballoc(m_cxBuffer,m_cyBuffer);
	fg_vbopen(m_hVB);
	fg_vbcolors();
}

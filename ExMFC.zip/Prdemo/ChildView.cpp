// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "Prdemo.h"

#include "ChildView.h"
#include "MainFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
	m_hDC = NULL;
	m_hPal = NULL;
	m_hVB = -1;
	m_cxClient = 0;
	m_cyClient = 0;
}

CChildView::~CChildView()
{
	if (m_hVB >= 0)
	{
		fg_vbclose();
		fg_vbfree(m_hVB);
	}
	fg_vbfin();
	if (m_hPal)
	{
		DeleteObject(m_hPal);
		m_hPal = NULL;
	}
	if (m_hDC)
	{
		::ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}
}

BEGIN_MESSAGE_MAP(CChildView, CWnd)
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_COMMAND(IDM_Print, PrintClick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		LoadCursor(NULL,IDC_ARROW), NULL, NULL);
	return TRUE;
}

BOOL CChildView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL bRet = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if (bRet)
	{
		m_hDC = ::GetDC(m_hWnd);
		fg_setdc(m_hDC);
		m_hPal = fg_defpal();
		fg_realize(m_hPal);

		fg_vbinit();
		m_hVB = fg_vballoc(vbWidth,vbHeight);
		fg_vbopen(m_hVB);
		fg_vbcolors();

		fg_showbmp("PORCH.BMP",0);
	}
	return bRet;
}

void CChildView::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,m_cxClient-1,0,m_cyClient-1);
}

void CChildView::OnSize(UINT, int cx, int cy)
{
	m_cxClient = cx;
	m_cyClient = cy;
}

void CChildView::OnSetFocus(CWnd* pOldWnd)
{
	CWnd::OnSetFocus(pOldWnd);
	fg_realize(m_hPal);
	Invalidate();
}

void CChildView::PrintClick()
{
	CPrintDialog dlg(FALSE,PD_NOPAGENUMS|PD_NOSELECTION,this);
	if (dlg.DoModal() != IDOK) return;

	fg_printdc(dlg.m_pd.hDC);
	if (fg_printer(STARTDOC) == 0)
	{
		CWaitCursor wait;
		fg_vbprint(0,vbWidth-1,0,vbHeight-1,0,600,0,400,2);
		fg_printer(NEWFRAME);
		fg_printer(ENDDOC);
	}
	else
		MessageBox("Printer setup failed","Error",MB_ICONSTOP|MB_OK);
}

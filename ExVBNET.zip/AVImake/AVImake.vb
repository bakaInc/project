'*****************************************************************************
'                                                                            *
'  AVImake.vb                                                                *
'                                                                            *
'  This program creates an AVI file from an FLI or FLC file.                 *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Dim cxBuffer, cyBuffer As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents menuConvert As System.Windows.Forms.MenuItem
    Friend WithEvents menuExit As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.menuConvert = New System.Windows.Forms.MenuItem()
        Me.menuExit = New System.Windows.Forms.MenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuConvert, Me.menuExit})
        '
        'menuConvert
        '
        Me.menuConvert.Index = 0
        Me.menuConvert.Text = "&Convert"
        '
        'menuExit
        '
        Me.menuExit.Index = 1
        Me.menuExit.Text = "E&xit"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.ReadOnlyChecked = True
        Me.OpenFileDialog1.RestoreDirectory = True
        Me.OpenFileDialog1.ShowReadOnly = True
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(446, 276)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Create AVI File From Flic File"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        cxBuffer = 32
        cyBuffer = 32
        hVB = fg_vballoc(cxBuffer, cyBuffer)
        fg_vbopen(hVB)
        fg_vbcolors()

        fg_setcolor(-1)
        fg_fillpage()
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub menuConvert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuConvert.Click
        Dim Bitmap() As Byte
        Dim ContextFlic(16) As Byte
        Dim ContextAVI(24) As Byte
        Dim FileHeader(128) As Byte
        Dim FileName As String

        ' Open the flic file to convert.
        With OpenFileDialog1
            .DefaultExt = "fli"
            .FileName = ""
            .Filter = "flic files (*.fli,*.flc)|*.FLI;*.FLC"
            If .ShowDialog() <> DialogResult.OK Then Return
            FileName = .FileName
        End With

        ' Make sure it really is a flic file, and if so, open it.
        If fg_flichead(FileName, FileHeader(0)) < 0 Then
            MessageBox.Show(FileName + " is not an FLI or FLC file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        fg_flicsize(FileHeader(0), cxBuffer, cyBuffer)
        SwitchBuffers()
        fg_flicopen(FileName, ContextFlic(0))

        ' Display the first flic frame.
        fg_flicplay(ContextFlic(0), 1, FG_NODELAY)
        fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)

        ' Create an empty AVI file with the same name as the flic file,
        ' but with an .avi extension.
        FileName = FileName.Substring(0, FileName.IndexOf(".")) + ".avi"
        If fg_avimake(FileName, ContextAVI(0), -1, cxBuffer, cyBuffer, 8, 10000, 30) < 0 Then
            MessageBox.Show("Cannot create AVI file" + Chr(13) + FileName, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Create a 256-color bitmap whose size is equal to the flic resolution.
        ReDim Bitmap(fg_imagesiz(cxBuffer, cyBuffer))

        ' Create the AVI file frame by frame.
        Me.Cursor = Cursors.WaitCursor
        fg_move(0, cyBuffer - 1)
        Do
            fg_vbscale(0, cxBuffer - 1, 0, cyBuffer - 1, 0, cxClient - 1, 0, cyClient - 1)
            fg_getimage(Bitmap(0), cxBuffer, cyBuffer)
            fg_aviframe(ContextAVI(0), Bitmap(0))
        Loop While fg_flicplay(ContextFlic(0), 1, FG_NODELAY) = 1
        Me.Cursor = Cursors.Default

        ' Close the flic and AVI files, and release the bitmap memory.
        fg_flicdone(ContextFlic(0))
        fg_avidone(ContextAVI(0))
        Erase Bitmap
    End Sub

    Private Sub menuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuExit.Click
        Me.Close()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  SwitchBuffers()                                                           *
    '                                                                            *
    '  Close the and release the active virtual buffer, then create and open a   *
    '  new virtual buffer to hold the new image file.                            *
    '                                                                            *
    '*****************************************************************************

    Private Sub SwitchBuffers()
        fg_vbclose()
        fg_vbfree(hVB)
        hVB = fg_vballoc(cxBuffer, cyBuffer)
        fg_vbopen(hVB)
        fg_vbcolors()
    End Sub
End Class
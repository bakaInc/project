//---------------------------------------------------------------------------
#ifndef TMcubeUH
#define TMcubeUH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <FGwin.h>

#define RENDER_STATE (FG_PERSPECTIVE_TM | FG_ZBUFFER | FG_ZCLIP)

#define vbWidth  640
#define vbHeight 480
#define vbDepth   16

#define tmWidth   64

typedef struct point3d
{
   double x;
   double y;
   double z;
} POINT3D;
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:   // IDE-managed Components
   void __fastcall FormActivate(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormPaint(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
private:   // User declarations
   HDC hDC;
   HPALETTE hPal;
   int hVB;
   UINT cxClient, cyClient;
#if (RENDER_STATE & FG_ZBUFFER)
   int hZB;
#endif
   int hTM[6];
   void __fastcall CheckForMovement(void);
   void __fastcall DrawCube(void);
   void __fastcall OnIdle(TObject *Sender, bool &Done);
public:      // User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
// six faces of a 40x40x40 cube, defined in object coordinates
POINT3D Face1[] = {
   { 20.0,-20.0,-20.0},
   {-20.0,-20.0,-20.0},
   {-20.0, 20.0,-20.0},
   { 20.0, 20.0,-20.0}
};
POINT3D Face2[] = {
   {-20.0,-20.0,-20.0},
   {-20.0,-20.0, 20.0},
   {-20.0, 20.0, 20.0},
   {-20.0, 20.0,-20.0}
};
POINT3D Face3[] = {
   { 20.0, 20.0, 20.0},
   {-20.0, 20.0, 20.0},
   {-20.0,-20.0, 20.0},
   { 20.0,-20.0, 20.0}
};
POINT3D Face4[] = {
   { 20.0,-20.0, 20.0},
   { 20.0,-20.0,-20.0},
   { 20.0, 20.0,-20.0},
   { 20.0, 20.0, 20.0}
};
POINT3D Face5[] = {
   { 20.0,-20.0, 20.0},
   {-20.0,-20.0, 20.0},
   {-20.0,-20.0,-20.0},
   { 20.0,-20.0,-20.0}
};
POINT3D Face6[] = {
   { 20.0, 20.0,-20.0},
   {-20.0, 20.0,-20.0},
   {-20.0, 20.0, 20.0},
   { 20.0, 20.0, 20.0}
};
// for convenience, an array of pointers to each of the six faces
POINT3D *Faces[] = {Face1,Face2,Face3,Face4,Face5,Face6};
// texture map array
byte Texture[6][tmWidth*tmWidth*(vbDepth/8)];
// coordinates defining source polygon vertices within the texture map array
int tmSource[] = {tmWidth-1,tmWidth-1, 0,tmWidth-1, 0,0, tmWidth-1,0};
//---------------------------------------------------------------------------
#endif

'*****************************************************************************
'                                                                            *
'  Tunnel.vb                                                                 *
'                                                                            *
'  This program draws a Gouraud-shaded tunnel and allows the viewer to move  *
'  through the tunnel using keyboard controls.                               *
'                                                                            *
'*****************************************************************************
Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Fastgraph variables.
    Dim g As Graphics
    Dim hDC As IntPtr
    Dim hPal As Integer
    Dim hVB As Integer
    Dim hZB As Integer
    Dim cxClient, cyClient As Integer

    ' Virtual buffer dimensions.
    Const vbWidth As Integer = 640
    Const vbHeight As Integer = 480

    ' Application variables.
    Dim Redraw As Boolean

    ' Four sides of a 20x40x100 tunnel, defined in 3D world coordinates.
    ' Sides are in the order floor, west side, east side, ceiling.
    Dim Faces(,) As Double = { _
        {-10.0, 0.0, 100.0, -10.0, 0.0, 200.0, 10.0, 0.0, 200.0, 10.0, 0.0, 100.0}, _
        {-10.0, 0.0, 100.0, -10.0, 40.0, 100.0, -10.0, 40.0, 200.0, -10.0, 0.0, 200.0}, _
        {10.0, 0.0, 100.0, 10.0, 0.0, 200.0, 10.0, 40.0, 200.0, 10.0, 40.0, 100.0}, _
        {-10.0, 40.0, 100.0, 10.0, 40.0, 100.0, 10.0, 40.0, 200.0, -10.0, 40.0, 200.0}}

    ' RGB color values at each vertex of each side.
    ' Sides are in the order floor, west side, east side, ceiling.
    Dim FacesRGB(,) As Byte = { _
        {192, 192, 192, 64, 64, 64, 64, 64, 64, 192, 192, 192}, _
        {32, 32, 255, 32, 32, 255, 32, 32, 96, 32, 32, 96}, _
        {32, 32, 255, 32, 32, 96, 32, 32, 96, 32, 32, 255}, _
        {192, 192, 192, 192, 192, 192, 64, 64, 64, 64, 64, 64}}

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        g = Me.CreateGraphics

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        g.Dispose()
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(640, 480)
        Me.Name = "Form1"
        Me.Text = "Gouraud-Shaded Tunnel"

    End Sub

#End Region

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        fg_realize(hPal)
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        Refresh()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim vbDepth As Integer

        hDC = g.GetHdc()
        fg_setdc(hDC)
        hPal = fg_defpal()
        fg_realize(hPal)

        fg_vbinit()
        vbDepth = fg_colors()
        If vbDepth < 16 Then vbDepth = 16
        fg_vbdepth(vbDepth)
        hVB = fg_vballoc(vbWidth, vbHeight)
        fg_vbopen(hVB)
        fg_vbcolors()

        hZB = fg_zballoc(vbWidth, vbHeight)
        fg_zbopen(hZB)

        fg_setcolor(-1)
        fg_fillpage()

        fg_3Dviewport(0, vbWidth - 1, 0, vbHeight - 1, 1.0)
        fg_3Drenderstate(FG_ZBUFFER + FG_ZCLIP)
        fg_3Dlookat(0.0, 10.0, 50.0, 0.0, 10.0, 100.0)
        Redraw = True
        Timer1.Enabled = True
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        cxClient = ClientRectangle.Width
        cyClient = ClientRectangle.Height
        fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        fg_vbclose()
        fg_zbfree(hZB)
        fg_vbfree(hVB)
        fg_vbfin()
        g.ReleaseHdc(hDC)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        CheckForMovement()
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  CheckForMovement()                                                        *
    '                                                                            *
    '  The CheckForMovement() function checks for key presses that control the   *
    '  user's movement, and if required redraws the tunnel viewed from the new   *
    '  camera position. It is called every 10ms from the timer's OnTick event    *
    '  handler.                                                                  *
    '                                                                            *
    '*****************************************************************************

    Private Sub CheckForMovement()
        ' Up arrow moves viewer forward.
        If fg_kbtest(72) = 1 Then
            fg_3Dmoveforward(2.0)
            Redraw = True

            ' Down arrow moves viewer backward.
        ElseIf fg_kbtest(80) = 1 Then
            fg_3Dmoveforward(-2.0)
            Redraw = True

            ' Right arrow turns viewer to the right.
        ElseIf fg_kbtest(77) = 1 Then
            fg_3Drotateright(6 * 10)
            Redraw = True

            ' Left arrow turns viewer to the left.
        ElseIf fg_kbtest(75) = 1 Then
            fg_3Drotateright(-6 * 10)
            Redraw = True
        End If

        ' If the viewer's position or orientation changed, redraw the tunnel.
        If Redraw Then
            ' Prepare the z-buffer for the next frame.
            fg_zbframe()

            ' Erase the previous frame from the virtual buffer.
            fg_setcolor(-1)
            fg_fillpage()

            ' Draw the tunnel.
            DrawTunnel()

            ' Display what we just drew.
            fg_vbscale(0, vbWidth - 1, 0, vbHeight - 1, 0, cxClient - 1, 0, cyClient - 1)
            Redraw = False
        End If
    End Sub

    '*****************************************************************************
    '                                                                            *
    '  DrawTunnel()                                                              *
    '                                                                            *
    '  Draws each of the tunnel's four sides in 3D world space.                  *
    '                                                                            *
    '*****************************************************************************

    Private Sub DrawTunnel()
        Dim I As Integer

        For I = 0 To 3
            fg_3Dshade(Faces(I, 0), FacesRGB(I, 0), 4)
        Next
    End Sub
End Class
/****************************************************************************\
*                                                                            *
*  AVImake.c                                                                 *
*                                                                            *
*  This program creates an AVI file from an FLI or FLC file.                 *
*                                                                            *
\****************************************************************************/

#include <fgwin.h>
#include <commdlg.h>
#include <windowsx.h>
#include "AVImake.h"

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);

void ConvertClick(void);
void SwitchBuffers(void);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGavimake";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor(NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = szAppName;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindow(szAppName, // window class name
      "Create AVI File From Flic File", // window caption
      WS_OVERLAPPEDWINDOW,     // window style
      CW_USEDEFAULT,           // initial x position
      CW_USEDEFAULT,           // initial y position
      CW_USEDEFAULT,           // initial x size
      CW_USEDEFAULT,           // initial y size
      NULL,                    // parent window handle
      NULL,                    // window menu handle
      hInstance,               // program instance handle
      NULL);                   // creation parameters

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   while (GetMessage(&msg,NULL,0,0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HDC      hDC;
HMENU    hMenu;
HPALETTE hPal;
int      hVB;
UINT     cxClient, cyClient;
int      cxBuffer, cyBuffer;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch (iMsg)
   {
      case WM_CREATE:
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);

         fg_vbinit();
         cxBuffer = cyBuffer = 32;
         hVB = fg_vballoc(cxBuffer,cyBuffer);
         fg_vbopen(hVB);
         fg_vbcolors();

         fg_setcolor(-1);
         fg_fillpage();

         hMenu = GetMenu(hWnd);
         return 0;

      case WM_COMMAND:
         switch (wParam)
         {
            case IDM_Convert:
               ConvertClick();
               return 0;

            case IDM_Exit:
               DestroyWindow(hWnd);
               return 0;
         }
         break;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
         fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,TRUE);
         return 0;

      case WM_SIZE:
         cxClient = LOWORD(lParam);
         cyClient = HIWORD(lParam);
         return 0;

      case WM_DESTROY:
         fg_vbclose();
         fg_vbfree(hVB);
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

void ConvertClick()
{
   HCURSOR hCursor;
   char mbString[256];
   char FileName[256];
   BYTE FileHeader[128];
   BYTE ContextFlic[16];
   BYTE ContextAVI[24];
   BYTE *Bitmap;

   static OPENFILENAME fn;
   static char Filter[] = "flic files (*.fli,*.flc)\0*.FLI;*.FLC\0";

   // fill in structure fields for Open File dialog box
   fn.lStructSize       = sizeof(OPENFILENAME);
   fn.hwndOwner         = GetActiveWindow();
   fn.lpstrFilter       = Filter;
   fn.lpstrCustomFilter = NULL;
   fn.nFilterIndex      = 0;
   fn.lpstrFile         = FileName;
   fn.nMaxFile          = sizeof(FileName);
   fn.lpstrFileTitle    = NULL;
   fn.lpstrInitialDir   = NULL;
   fn.lpstrTitle        = NULL;
   fn.Flags             = OFN_READONLY;
   fn.lpstrDefExt       = NULL;
   *FileName = '\0';

   // open the flic file to convert
   if (!GetOpenFileName(&fn)) return;

   // make sure it really is a flic file, and if so, open it
   if (fg_flichead(FileName,FileHeader) < 0)
   {
      lstrcpy(mbString,FileName);
      lstrcat(mbString,"\nis not an FLI or FLC file.");
      MessageBox(GetActiveWindow(),mbString,"Error",MB_ICONSTOP|MB_OK);
      return;
   }
   fg_flicsize(FileHeader,&cxBuffer,&cyBuffer);
   SwitchBuffers();
   fg_flicopen(FileName,ContextFlic);

   // display the first flic frame
   fg_flicplay(ContextFlic,1,FG_NODELAY);
   fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);

   // create an empty AVI file with the same name as the flic file,
   // but with an .avi extension
   lstrcpy(strrchr(FileName,'.'),".avi");
   if (fg_avimake(FileName,ContextAVI,-1,cxBuffer,cyBuffer,8,10000,30) < 0)
   {
      lstrcpy(mbString,"Cannot create AVI file\n");
      lstrcat(mbString,FileName);
      MessageBox(GetActiveWindow(),mbString,"Error",MB_ICONSTOP|MB_OK);
      return;
   }

   // create a 256-color bitmap whose size is equal to the flic resolution
   Bitmap = (BYTE *)GlobalAllocPtr(GHND,fg_imagesiz(cxBuffer,cyBuffer));

   // create the AVI file frame by frame
   hCursor = SetCursor(LoadCursor(NULL,IDC_WAIT));
   ShowCursor(TRUE);
   fg_move(0,cyBuffer-1);
   do
   {
      fg_vbscale(0,cxBuffer-1,0,cyBuffer-1,0,cxClient-1,0,cyClient-1);
      fg_getimage(Bitmap,cxBuffer,cyBuffer);
      fg_aviframe(ContextAVI,Bitmap);
   }
   while (fg_flicplay(ContextFlic,1,FG_NODELAY) == 1);
   ShowCursor(FALSE);
   SetCursor(hCursor);

   // close the flic and AVI files, and release the bitmap memory
   fg_flicdone(ContextFlic);
   fg_avidone(ContextAVI);
   GlobalFreePtr(Bitmap);
}

/****************************************************************************\
*                                                                            *
*  SwitchBuffers()                                                           *
*                                                                            *
*  Close the and release the active virtual buffer, then create and open a   *
*  new virtual buffer to hold the new image file.                            *
*                                                                            *
\****************************************************************************/

void SwitchBuffers()
{
   fg_vbclose();
   fg_vbfree(hVB);
   hVB = fg_vballoc(cxBuffer,cyBuffer);
   fg_vbopen(hVB);
   fg_vbcolors();
}

/****************************************************************************\
*                                                                            *
*  Scale.cs                                                                  *
*                                                                            *
*  This program demonstrates the Fastgraph for Windows 256-color bitmap      *
*  scaling and shearing functions.                                           *
*                                                                            *
\****************************************************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace Scale
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// Fastgraph variables.
		Graphics g;
		IntPtr hDC;
		int hPal;
		int hVB;
		int cxClient, cyClient;

		// Virtual buffer dimensions.
		const int vbWidth = 320;
		const int vbHeight = 240;

		// 40x20 256-color bitmapped image of a bird.
		byte [] Bird = {
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0,10,10, 0,10, 0,10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0,10,25,10,17,10,17,10,10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0,10,25,25,10,17,10,17,10,25,10, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			10,25,25,25,25,10,25,10,25,25,10, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,10,10,
			10,25,25,25,25,10,25,10,25,10, 0, 0, 0, 0, 0, 0, 0,10,10, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,25,25,
			10,25,25,25,25,25,25,25,25,10, 0, 0,10,10,10,10,10,17,10, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,10,25,25,10,
			25,25,25,25,25,25,25,25,10, 0, 0,10,25,25,25,25,25,10, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,25,10,25,25,
			10,25,25,25,25,25,25,25,10, 0,10,25,25,25,25,25,10, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,10,25,25,10,25,
			25,25,25,25,25,25,25,25,10, 0,10,25,25,25,25,10, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,25,10,25,25,10,
			25,25,25,25,25,25,25,25,10,10,25,25,25,25,10, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,10,25,25,10,25,
			25,25,25,25,25,25,25,10,25,25,25,25,25,10, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,10,25,25,10,25,25,25,25,
			25,25,25,25,25,25,25,10,25,25,10,25,10, 0, 0, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,25,10,25,25,25,25,25,25,25,
			25,25,25,25,25,25,25,10,25,25,25,25,10, 0, 0, 0, 0, 0, 0, 0,
			 0,10,10,10,10, 0, 0, 0, 0, 0,10,25,25,10,25,25,25,25,25,25,
			25,25,25,25,25,25,25,25,25,10,25,10, 0, 0, 0, 0, 0, 0, 0, 0,
			10,17,17,17,17,10,10,10,10, 0,10,10,25,25,25,25,25,25,25,25,
			25,25,25,25,25,10,25,25,25,10,10,10,10, 0, 0, 0, 0, 0, 0, 0,
			 0,10,17,17,17,17,17,17,17,10,25,25,10,25,25,25,25,25,25,25,
			25,25,25,25,10,25,25,25,10,17,17,17,17,10,10,10,10,10,10, 0,
			 0, 0,10,10,10,10,25,25,25,25,25,25,25,25,25,25,25,25,25,25,
			25,25,25,25,25,25,25,25,25,25,25,25,25,25,10,14,14,10, 0, 0,
			 0, 0, 0, 0, 0, 0,10,10,10,10,10,10,10,10,25,25,25,25,25,25,
			25,25,25,25,25,25,25,25,25,25,25,25,14,25,25,10,10, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,10,25,25,25,25,
			25,25,25,25,25,25,25,10,10,10,10,25,25,25,10, 0, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,10,10,10,10,
			10,10,10,10,10,10,10, 0, 0, 0, 0,10,10,10, 0, 0, 0, 0, 0, 0};

		// Scaled/sheared bird bitmap (80x40 max).
		byte [] ScaledBird = new byte [80*40];

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Add any constructor code after InitializeComponent call
			//
			g = CreateGraphics();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			g.Dispose();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(446, 276);
			this.Name = "Form1";
			this.Text = "Bitmap Scaling and Shearing";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			fg.realize(hPal);
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			Refresh();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			hDC = g.GetHdc();
			fg.setdc(hDC);
			hPal = fg.defpal();
			fg.realize(hPal);

			fg.vbinit();
			hVB = fg.vballoc(vbWidth, vbHeight);
			fg.vbopen(hVB);
			fg.vbcolors();

			fg.setcolor(20);
			fg.fillpage();

			// Draw 40x20 bird (original bitmap).
			fg.move(6, 80);
			fg.drwimage(ref Bird[0], 40, 20);

			// Draw 50x25 bird.
			fg.move(48, 80);
			fg.scale(ref Bird[0], ref ScaledBird[0], 40, 20, 50, 25);
			fg.drwimage(ref ScaledBird[0], 50, 25);

			// Draw 60x30 bird.
			fg.move(100, 80);
			fg.scale(ref Bird[0], ref ScaledBird[0], 40, 20, 60, 30);
			fg.drwimage(ref ScaledBird[0], 60, 30);

			// Draw 70x35 bird.
			fg.move(162, 80);
			fg.scale(ref Bird[0], ref ScaledBird[0], 40, 20, 70, 35);
			fg.drwimage(ref ScaledBird[0], 70, 35);

			// Draw 80x40 bird.
			fg.move(234, 80);
			fg.scale(ref Bird[0], ref ScaledBird[0], 40, 20, 80, 40);
			fg.drwimage(ref ScaledBird[0], 80, 40);

			// Draw 50x20 bird sheared left horizontally.
			fg.move(55, 160);
			fg.shear(ref Bird[0], ref ScaledBird[0], 40, 20, 50, 0);
			fg.drwimage(ref ScaledBird[0], 50, 20);

			// Draw 50x20 bird sheared right horizontally.
			fg.move(115, 160);
			fg.shear(ref Bird[0], ref ScaledBird[0], 40, 20, 50, 1);
			fg.drwimage(ref ScaledBird[0], 50, 20);

			// Draw 40x30 bird sheared left vertically.
			fg.move(175, 160);
			fg.shear(ref Bird[0], ref ScaledBird[0], 40, 20, 30, 2);
			fg.drwimage(ref ScaledBird[0], 40, 30);

			// Draw 40x30 bird sheared left vertically.
			fg.move(225, 160);
			fg.shear(ref Bird[0], ref ScaledBird[0], 40, 20, 30, 3);
			fg.drwimage(ref ScaledBird[0], 40, 30);
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			cxClient = ClientRectangle.Width;
			cyClient = ClientRectangle.Height;
			fg.vbscale(0, vbWidth-1, 0, vbHeight-1, 0, cxClient-1, 0, cyClient-1);
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			fg.vbclose();
			fg.vbfree(hVB);
			fg.vbfin();
			g.ReleaseHdc(hDC);
		}
	}
}
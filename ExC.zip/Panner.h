//---------------------
// Panner.h header file
//---------------------

#define IDM_Left  1
#define IDM_Right 2
#define IDM_Up    3
#define IDM_Down  4
#define IDM_Reset 5
#define IDM_Exit  6

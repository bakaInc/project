/****************************************************************************\
*                                                                            *
*  GDIdemo.cpp                                                               *
*  GDIdemoU.cpp                                                              *
*                                                                            *
*  This program shows how to use Windows GDI functions to write to a virtual *
*  buffer. It uses GDI functions to display a cross-hatched rectangle with a *
*  border, something that would require construction from several graphics   *
*  primitives if using Fastgraph for Windows drawing functions only.         *
*                                                                            *
\****************************************************************************/

#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("GDIDemoU.cpp", Form1);
USERES("GDIdemo.res");
USELIB("FGWBC32.LIB");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
      Application->Initialize();
      Application->CreateForm(__classid(TForm1), &Form1);
        Application->Run();
   }
   catch (Exception &exception)
   {
      Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------

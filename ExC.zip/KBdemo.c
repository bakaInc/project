/****************************************************************************\
*                                                                            *
*  KBdemo.c                                                                  *
*                                                                            *
*  This program shows how to pan the contents of a virtual buffer through    *
*  a smaller window using the low-level keyboard handler.                    *
*                                                                            *
\****************************************************************************/

#include <fgwin.h>

#define vbWidth  640
#define vbHeight 480

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);

void CheckForPanning(void);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGkbdemo";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor (NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindow(szAppName, // window class name
      "Keyboard Handler Demo", // window caption
      WS_OVERLAPPEDWINDOW,     // window style
      CW_USEDEFAULT,           // initial x position
      CW_USEDEFAULT,           // initial y position
      vbWidth/2,               // initial x size
      vbHeight/2,              // initial y size
      NULL,                    // parent window handle
      NULL,                    // window menu handle
      hInstance,               // program instance handle
      NULL);                   // creation parameters

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   // The message loop processes entries placed in the message queue.
   // When no message is ready, call CheckForPanning() to check if we
   // want to perform panning.

   while (TRUE)
   {
      if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
      {
         if (msg.message == WM_QUIT)
            break;
         else
         {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
         }
      }
      else
         CheckForPanning();
   }

   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HDC      hDC;
HPALETTE hPal;
int      hVB;
UINT     cxClient, cyClient;
int      x, y;
int      xLimit, yLimit;
int      CanGoLeft, CanGoRight, CanGoUp, CanGoDown;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch (iMsg)
   {
      case WM_CREATE:
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);

         fg_vbinit();
         hVB = fg_vballoc(vbWidth,vbHeight);
         fg_vbopen(hVB);
         fg_vbcolors();

         fg_showbmp("PORCH.BMP",0);
         x = y = 0;
         CanGoRight = CanGoDown = TRUE;
         CanGoLeft = CanGoUp = FALSE;
         return 0;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
         fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,TRUE);
         return 0;

      case WM_SIZE:
         cxClient = LOWORD(lParam);
         cyClient = HIWORD(lParam);
         if (cxClient < vbWidth)
         {
            xLimit = vbWidth - cxClient;
            if (x > 0)      CanGoLeft = TRUE;
            if (x < xLimit) CanGoRight = TRUE;
         }
         else
         {
            xLimit = 0;
            CanGoLeft = CanGoRight = FALSE;
         }
         if (cyClient < vbHeight)
         {
            yLimit = vbHeight - cyClient;
            if (y > 0)      CanGoUp = TRUE;
            if (y < yLimit) CanGoDown = TRUE;
         }
         else
         {
            yLimit = 0;
            CanGoUp = CanGoDown = FALSE;
         }
         return 0;

      case WM_DESTROY:
         fg_vbclose();
         fg_vbfree(hVB);
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

/****************************************************************************\
*                                                                            *
*  CheckForPanning()                                                         *
*                                                                            *
*  The CheckForPanning() function checks if any of the four arrow keys are   *
*  pressed, and if so, pans in that direction if possible. It is called from *
*  the message loop in WinMain() when no messages are waiting.               *
*                                                                            *
\****************************************************************************/

#define KB_ESCAPE 1
#define KB_LEFT  75
#define KB_RIGHT 77
#define KB_UP    72
#define KB_DOWN  80

void CheckForPanning()
{
   if (fg_kbtest(KB_LEFT) && CanGoLeft)
   {
      if (x == xLimit) CanGoRight = TRUE;
      x--;
      fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
      if (x == 0) CanGoLeft = FALSE;
   }

   else if (fg_kbtest(KB_RIGHT) && CanGoRight)
   {
      if (x == 0) CanGoLeft = TRUE;
      x++;
      fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
      if (x == xLimit) CanGoRight = FALSE;
   }

   else if (fg_kbtest(KB_UP) && CanGoUp)
   {
      if (y == yLimit) CanGoDown = TRUE;
      y--;
      fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
      if (y == 0) CanGoUp = FALSE;
   }

   else if (fg_kbtest(KB_DOWN) && CanGoDown)
   {
      if (y == 0) CanGoUp = TRUE;
      y++;
      fg_vbpaste(x,x+(vbWidth-1),y,y+(vbHeight-1),0,vbHeight-1);
      if (y == yLimit) CanGoDown = FALSE;
   }

   else if (fg_kbtest(KB_ESCAPE))
   {
      x = y = 0;
      fg_vbpaste(0,vbWidth-1,0,vbHeight-1,0,vbHeight-1);
      if (xLimit > 0) CanGoRight = TRUE;
      if (yLimit > 0) CanGoDown = TRUE;
      CanGoLeft = CanGoUp = FALSE;
   }
}

// ChildView.h : interface of the CChildView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDVIEW_H__ABF7974B_7FD4_11D2_8EB9_204C4F4F5020__INCLUDED_)
#define AFX_CHILDVIEW_H__ABF7974B_7FD4_11D2_8EB9_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define vbWidth  320
#define vbHeight 240

class CMainFrame;

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildView)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CChildView();

	CString& GetTitleText()          {return m_Title;}

	// Generated message map functions
protected:
	CMainFrame* GetMainFrame() {return (CMainFrame*)AfxGetApp()->m_pMainWnd;}

	CString m_Title;
	HDC m_hDC;
	HPALETTE m_hPal;
	int m_hVB;
	UINT m_cxClient;
	UINT m_cyClient;
	//{{AFX_MSG(CChildView)
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT,int,int);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void ClipDCBClick();
	afx_msg void DrawDCBClick();
	afx_msg void FlipDCBClick();
	afx_msg void PutDCBClick();
	afx_msg void RevDCBClick();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDVIEW_H__ABF7974B_7FD4_11D2_8EB9_204C4F4F5020__INCLUDED_)

/****************************************************************************\
*                                                                            *
*  Strings2.c                                                                *
*                                                                            *
*  This program shows how to display strings in a virtual buffer.            *
*                                                                            *
\****************************************************************************/

#include <fgwin.h>

#define vbWidth  320
#define vbHeight 240

LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);
void DrawStrings(void);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdParam, int iCmdShow)
{
   static char szAppName[] = "FGstrings2";
   HWND        hWnd;
   MSG         msg;
   WNDCLASSEX  wndclass;

   wndclass.cbSize        = sizeof(wndclass);
   wndclass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
   wndclass.lpfnWndProc   = WindowProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = hInstance;
   wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor (NULL,IDC_ARROW);
   wndclass.hbrBackground = NULL;
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = szAppName;
   wndclass.hIconSm       = LoadIcon(NULL,IDI_APPLICATION);
   RegisterClassEx(&wndclass);

   hWnd = CreateWindow(szAppName, // window class name
      "Display Strings in Virtual Buffer", // window caption
      WS_OVERLAPPEDWINDOW,        // window style
      CW_USEDEFAULT,              // initial x position
      CW_USEDEFAULT,              // initial y position
      CW_USEDEFAULT,              // initial x size
      CW_USEDEFAULT,              // initial y size
      NULL,                       // parent window handle
      NULL,                       // window menu handle
      hInstance,                  // program instance handle
      NULL);                      // creation parameters

   ShowWindow(hWnd,iCmdShow);
   UpdateWindow(hWnd);

   while (GetMessage(&msg,NULL,0,0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return msg.wParam;
}

/****************************************************************************\
*                                                                            *
*  WindowProc()                                                              *
*                                                                            *
\****************************************************************************/

HDC      hDC;
HPALETTE hPal;
int      hVB;
UINT     cxClient, cyClient;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch (iMsg)
   {
      case WM_CREATE:
         hDC = GetDC(hWnd);
         fg_setdc(hDC);
         hPal = fg_defpal();
         fg_realize(hPal);

         fg_vbinit();
         hVB = fg_vballoc(vbWidth,vbHeight);
         fg_vbopen(hVB);
         fg_vbcolors();

         fg_setcolor(24);
         fg_fillpage();
         fg_fontdc(fg_getdc());
         DrawStrings();
         return 0;

      case WM_PAINT:
         BeginPaint(hWnd,&ps);
         fg_vbscale(0,vbWidth-1,0,vbHeight-1,0,cxClient-1,0,cyClient-1);
         EndPaint(hWnd,&ps);
         return 0;

      case WM_SETFOCUS:
         fg_realize(hPal);
         InvalidateRect(hWnd,NULL,TRUE);
         return 0;

      case WM_SIZE:
         cxClient = LOWORD(lParam);
         cyClient = HIWORD(lParam);
         return 0;

      case WM_DESTROY:
         fg_vbclose();
         fg_vbfree(hVB);
         fg_vbfin();
         DeleteObject(hPal);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         return 0;
   }
   return DefWindowProc(hWnd,iMsg,wParam,lParam);
}

void DrawStrings()
{
   fg_setcolor(19);

   // upper vertical justification
   fg_move(0,0);
   fg_justify(-1,1);
   fg_print("FG/Windows",10);
   fg_move(vbWidth/2,0);
   fg_justify(0,1);
   fg_print("FG/Windows",10);
   fg_move(vbWidth-1,0);
   fg_justify(1,1);
   fg_print("FG/Windows",10);

   // centered vertical justification
   fg_move(0,vbHeight/2);
   fg_justify(-1,0);
   fg_print("FG/Windows",10);
   fg_move(vbWidth/2,vbHeight/2);
   fg_justify(0,0);
   fg_print("FG/Windows",10);
   fg_move(vbWidth-1,vbHeight/2);
   fg_justify(1,0);
   fg_print("FG/Windows",10);

   // lower vertical justification
   fg_move(0,vbHeight-1);
   fg_justify(-1,-1);
   fg_print("FG/Windows",10);
   fg_move(vbWidth/2,vbHeight-1);
   fg_justify(0,-1);
   fg_print("FG/Windows",10);
   fg_move(vbWidth-1,vbHeight-1);
   fg_justify(1,-1);
   fg_print("FG/Windows",10);
}
